return {
  colors = true,
  compact = false,
  keepMacroDebugOpenWhenOverlayClosed = false,
  keepMenuOpenWhenOverlayClosed = false,
  lastPoseRig = "Player Woman",
  poseSearchLimit = 240,
}
