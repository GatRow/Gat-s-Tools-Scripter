-- Gat's Tools & Scripter asset (auto)
-- 2026-03-26 21:21:53

return {
  asset = {
    createdAtText = "2026-03-26 21:21:53",
    data = {
      steps = {
        {
          displayName = "add accl",
          endAction = "None",
          name = "add_accl",
          rig = "Player Man",
          seconds = 3,
          secondsText = "3",
        },
      },
    },
    id = "asset_003",
    name = "ddd",
    type = "animation_sequence",
    updatedAtText = "2026-03-26 21:21:53",
  },
  kind = "gts_asset",
  savedAt = "2026-03-26 21:21:53",
  version = 3,
}
