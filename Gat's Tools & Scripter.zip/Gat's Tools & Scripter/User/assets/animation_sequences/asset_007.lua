-- Gat's Tools & Scripter asset (auto)
-- 2026-03-27 02:07:56

return {
  asset = {
    createdAtText = "2026-03-27 02:07:56",
    data = {
      steps = {
        {
          displayName = "grapple sync shove",
          endAction = "Stop",
          name = "grapple_sync_shove",
          rig = "Player Man",
          seconds = 1,
          secondsText = "1",
        },
      },
    },
    id = "asset_007",
    name = "Kick",
    type = "animation_sequence",
    updatedAtText = "2026-03-27 02:07:56",
  },
  kind = "gts_asset",
  savedAt = "2026-03-27 02:07:56",
  version = 3,
}
