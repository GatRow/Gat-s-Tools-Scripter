-- Gat's Tools & Scripter asset (auto)
-- 2026-03-27 18:35:55

return {
  asset = {
    createdAtText = "2026-03-27 18:35:55",
    data = {
      entities = {
        {
          actionDelaySeconds = 0,
          appearance = "ToCName{ hash_lo = 0xA0784423, hash_hi = 0x9F89E137 --[[ boss__adam_smasher_mb_bossfight_stage_00 --]] }",
          appearanceApplyDelaySeconds = 0,
          despawnAfterSeconds = 0,
          enabled = true,
          freezeOnSpawn = true,
          id = "target_1",
          label = "Character.Smasher",
          mode = "Character",
          record = "Character.Smasher",
          relPos = {
            x = 0.025819662762589,
            y = 2.3489460362846,
            z = 0.13639831542969,
          },
          relYaw = 163.15840148926,
          spawnDelaySeconds = 0,
          statusApplyDelaySeconds = 0,
          statusEffectId = "",
          statusRemoveDelaySeconds = 0,
          unfreezeAfterSeconds = 0,
          worldPos = {
            w = 1,
            x = -1138.0505371094,
            y = 1393.0305175781,
            z = 18.098655700684,
          },
          worldYaw = -0.005096435546875,
        },
      },
      mode = "anchored",
      origin = {
        x = -1138.71,
        y = 1395.29,
        yaw = -163.16,
        z = 17.96,
      },
      playerState = {
        captureClothing = false,
        captureJohnnyArm = false,
        captureTimeOfDay = false,
        clothing = {
        },
        currentWeapon = "",
        forceEquipCurrentWeapon = false,
        forceEquipWeapon = false,
        frozenTime = false,
        hour = 12,
        johnnyArmOn = false,
        minute = 0,
        weaponId = "",
      },
      teleportPlayer = false,
    },
    id = "scenario_002",
    name = "Smash",
    type = "scenario",
    updatedAtText = "2026-03-27 18:35:55",
  },
  kind = "gts_asset",
  savedAt = "2026-03-27 18:35:55",
  version = 3,
}
