-- Gat's Tools & Scripter asset (auto)
-- 2026-03-26 17:14:47

return {
  asset = {
    createdAtText = "2026-03-26 17:14:47",
    data = {
      actionGroups = {
        {
          actions = {
            {
              despawnAfterSeconds = 0,
              recordId = "Attacks.ExplosionLarge",
              spawnMode = "Attack",
              type = "spawn_at_target",
            },
          },
          id = "group_1",
          mode = "ordered",
          name = "Group 1",
        },
      },
      actions = {
      },
      conditionMode = "ALL",
      conditions = {
        {
          expected = true,
          key = "target_npc",
          kind = "observer_state",
          label = "Observer: Target Is NPC",
        },
      },
      cooldown = 0.25,
      enabled = true,
      execution = {
        cadence = "every_time",
        cadenceValue = 2,
        cooldown = 0.25,
        disableAfterFire = false,
        falseActions = {
        },
        falsePolicy = "do_nothing",
        triggerMode = "on_true",
      },
      falseActionGroups = {
        {
          actions = {
          },
          id = "exit_group_1",
          mode = "ordered",
          name = "Exit Group 1",
        },
      },
      falseActions = {
      },
      runOnceUntilFalse = true,
    },
    id = "rule_001",
    name = "ff",
    type = "rule",
    updatedAtText = "2026-03-26 17:14:47",
  },
  kind = "gts_asset",
  savedAt = "2026-03-26 17:14:47",
  version = 3,
}
