-- Gat's Tools & Scripter asset index (auto)
-- 2026-03-26 17:14:47

return {
  items = {
    rule_001 = {
      createdAtText = "2026-03-26 17:14:47",
      file = "assets/rules/rule_001.lua",
      id = "rule_001",
      name = "ff",
      type = "rule",
      updatedAtText = "2026-03-26 17:14:47",
    },
  },
  mode = "per_asset_manifest",
  nextId = 2,
  order = {
    "rule_001",
  },
  savedAt = "2026-03-26 17:14:47",
  selectedId = "rule_001",
  version = 3,
}
