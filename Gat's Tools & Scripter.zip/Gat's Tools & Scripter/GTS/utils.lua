local Utils = Utils or {}

function Utils.clone(value, seen)
  if type(value) ~= "table" then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do
    out[Utils.clone(k, seen)] = Utils.clone(v, seen)
  end
  return out
end

function Utils.checkboxValue(label, current)
  local a, b = ImGui.Checkbox(label, current == true)
  if type(a) == "boolean" and type(b) == "boolean" then
    if b == (a ~= current) then return a == true end
    if a == (b ~= current) then return b == true end
    return b == true
  end
  if type(a) == "boolean" then return a == true end
  if type(b) == "boolean" then return b == true end
  return current == true
end

function Utils.inputTextValue(label, value, size)
  local a, b = ImGui.InputText(label, value or "", size or 128)
  if type(a) == "string" and type(b) == "boolean" then return a end
  if type(a) == "boolean" and type(b) == "string" then return b end
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return value or ""
end

function Utils.inputFloatValue(label, value, step, fast, fmt)
  local a, b = ImGui.InputFloat(label, tonumber(value or 0) or 0, step or 0.05, fast or 0.25, fmt or "%.2f")
  if type(a) == "number" then return a end
  if type(b) == "number" then return b end
  return tonumber(value or 0) or 0
end

function Utils.inputIntValue(label, value, step, fast)
  local current = math.floor(tonumber(value or 0) or 0)
  local a, b = ImGui.InputInt(label, current, step or 1, fast or 10)
  if type(a) == "number" then return math.floor(a) end
  if type(b) == "number" then return math.floor(b) end
  return current
end

function Utils.comboSelect(label, currentValue, labels)
  if type(labels) ~= "table" or #labels == 0 then return currentValue end
  local current = currentValue
  local found = false
  for i = 1, #labels do
    if labels[i] == current then
      found = true
      break
    end
  end
  if not found then current = labels[1] end
  if ImGui.BeginCombo and ImGui.BeginCombo(label, tostring(current or "")) then
    for i = 1, #labels do
      local item = labels[i]
      local selected = (item == current)
      if ImGui.Selectable(item, selected) then current = item end
      if selected and ImGui.SetItemDefaultFocus then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  return current
end

return Utils
