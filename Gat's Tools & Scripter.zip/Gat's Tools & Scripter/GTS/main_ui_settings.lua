local Persistence = require("GTS/persistence")

local Settings = {
  compact = false,
  colors = true,
  keepMenuOpenWhenOverlayClosed = false,
  keepMacroDebugOpenWhenOverlayClosed = false,
  poseSearchLimit = 240,
  lastPoseRig = "Player Man",
}

local function _settingsPath()
  local base = (Persistence.GetUserDir and Persistence.GetUserDir()) or "User"
  base = tostring(base or "User")
  if base:sub(-1) == "/" or base:sub(-1) == "\\" then
    return base .. "gts_ui_settings.lua"
  end
  return base .. "/gts_ui_settings.lua"
end

local function _serialize(value, depth)
  depth = depth or 0
  local indent = string.rep("  ", depth)
  local nextIndent = string.rep("  ", depth + 1)

  if type(value) == "table" then
    local parts = {"{"}
    local keys = {}
    for k in pairs(value) do keys[#keys + 1] = k end
    table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
    for i = 1, #keys do
      local k = keys[i]
      local v = value[k]
      local keyText
      if type(k) == "string" and k:match("^[%a_][%w_]*$") then
        keyText = k
      else
        keyText = "[" .. _serialize(k, depth + 1) .. "]"
      end
      parts[#parts + 1] = string.format("\n%s%s = %s,", nextIndent, keyText, _serialize(v, depth + 1))
    end
    if #keys > 0 then
      parts[#parts + 1] = "\n" .. indent
    end
    parts[#parts + 1] = "}"
    return table.concat(parts)
  end

  if type(value) == "string" then
    return string.format("%q", value)
  end

  if type(value) == "number" or type(value) == "boolean" then
    return tostring(value)
  end

  return "nil"
end

local function _loadFromDisk()
  local path = _settingsPath()
  if not loadfile then
    return nil
  end

  local okChunk, chunkOrErr = pcall(loadfile, path)
  if not okChunk or type(chunkOrErr) ~= "function" then
    return nil
  end

  local okData, data = pcall(chunkOrErr)
  if not okData or type(data) ~= "table" then
    return nil
  end
  return data
end

function Settings.Load()
  local data = _loadFromDisk()
  if type(data) ~= "table" then
    return Settings
  end

  for k, v in pairs(data) do
    Settings[k] = v
  end

  Settings.compact = Settings.compact == true
  Settings.colors = Settings.colors ~= false
  Settings.keepMenuOpenWhenOverlayClosed = Settings.keepMenuOpenWhenOverlayClosed == true
  Settings.keepMacroDebugOpenWhenOverlayClosed = Settings.keepMacroDebugOpenWhenOverlayClosed == true
  Settings.poseSearchLimit = math.max(50, math.floor(tonumber(Settings.poseSearchLimit or 240) or 240))
  Settings.lastPoseRig = tostring(Settings.lastPoseRig or "Player Man")

  return Settings
end

function Settings.Save(state)
  local source = type(state) == "table" and state or Settings
  local data = {
    compact = source.compact == true,
    colors = source.colors ~= false,
    keepMenuOpenWhenOverlayClosed = source.keepMenuOpenWhenOverlayClosed == true,
    keepMacroDebugOpenWhenOverlayClosed = source.keepMacroDebugOpenWhenOverlayClosed == true,
    poseSearchLimit = math.max(50, math.floor(tonumber(source.poseSearchLimit or 240) or 240)),
    lastPoseRig = tostring(source.lastPoseRig or "Player Man"),
  }

  local path = _settingsPath()
  local file, err = io.open(path, "w")
  if not file then
    return false, err or "Could not open UI settings file"
  end

  local okWrite, writeErr = pcall(function()
    file:write("return ")
    file:write(_serialize(data))
    file:write("\n")
  end)
  file:close()
  if not okWrite then
    return false, writeErr or "Could not write UI settings"
  end

  for k, v in pairs(data) do
    Settings[k] = v
  end
  return true, path
end

return Settings.Load()
