local TargetActions = TargetActions or {}

local TargetService = require("GTS/target_service")

TargetActions.state = TargetActions.state or {
  pendingMoves = {},
  nextMoveToken = 1,
  tether = { active = false, entityID = nil, handle = nil, startedAt = 0, nextTickAt = 0, offsetX = 0, offsetY = 0, offsetZ = 0, refreshEvery = 0.03, endMode = "manual", endAfterSeconds = 5.0, endStillSeconds = 3.0, stillSince = nil },
}

local function _pcall(fn)
  local ok, res = pcall(fn)
  if ok then return res end
  return nil
end

local function _player()
  return (Game and Game.GetPlayer and Game.GetPlayer()) or nil
end

local function _sameEntity(a, b)
  if not a or not b then return false end
  local aid = _pcall(function() return a:GetEntityID() end)
  local bid = _pcall(function() return b:GetEntityID() end)
  if aid == nil or bid == nil then return false end
  return tostring(aid) == tostring(bid)
end

local function _getDES()
  return (Game and Game.GetDynamicEntitySystem and Game.GetDynamicEntitySystem()) or nil
end

local function _getTF()
  return (Game and Game.GetTeleportationFacility and Game.GetTeleportationFacility()) or nil
end

local function _zeroEuler()
  if type(ToEulerAngles) == "function" then
    return ToEulerAngles{ roll = 0, pitch = 0, yaw = 0 }
  end
  return nil
end

local function _asVector4(pos)
  if type(pos) ~= "table" and type(pos) ~= "userdata" then return nil end
  return Vector4.new(tonumber(pos.x or 0) or 0, tonumber(pos.y or 0) or 0, tonumber(pos.z or 0) or 0, tonumber(pos.w or 1) or 1)
end

local function _targetSnapshot(force)
  local snap = TargetService and TargetService.GetSnapshot and TargetService.GetSnapshot(force == true) or nil
  if type(snap) ~= "table" or snap.exists ~= true then return nil end
  return snap
end

local function _resolveTargetHandle(force)
  local snap = _targetSnapshot(force)
  if not snap then return nil, nil end

  local handle = nil
  if snap.entityID ~= nil then
    handle = _pcall(function() return Game.FindEntityByID(snap.entityID) end)
  end
  if handle == nil and TargetService and type(TargetService.GetHandle) == "function" then
    handle = TargetService.GetHandle(force == true)
  end
  if handle == nil then
    handle = snap.handle
  end
  if handle == nil then return nil, snap end
  return handle, snap
end

local function _targetVector4(force)
  local handle, snap = _resolveTargetHandle(force)
  local pos = nil
  if handle and handle.GetWorldPosition then
    pos = _pcall(function() return handle:GetWorldPosition() end)
  end
  if pos == nil and snap and type(snap.xyz) == "table" then
    pos = snap.xyz
  end
  if pos == nil then return nil, snap, handle end
  return _asVector4(pos), snap, handle
end

local function _vecDistSq(a, b)
  if not a or not b then return math.huge end
  local dx = (tonumber(a.x or 0) or 0) - (tonumber(b.x or 0) or 0)
  local dy = (tonumber(a.y or 0) or 0) - (tonumber(b.y or 0) or 0)
  local dz = (tonumber(a.z or 0) or 0) - (tonumber(b.z or 0) or 0)
  return (dx * dx) + (dy * dy) + (dz * dz)
end

local function _readWorldPos(handle, snap)
  local pos = nil
  if handle and handle.GetWorldPosition then
    pos = _pcall(function() return handle:GetWorldPosition() end)
  end
  if pos == nil and snap and type(snap.xyz) == "table" then pos = snap.xyz end
  return _asVector4(pos)
end

local function _basisFromCenterAndForward(center, forward)
  local ct = type(center)
  if ct ~= "table" and ct ~= "userdata" then return nil end
  local fx = tonumber((forward or {}).x or 0) or 0
  local fy = tonumber((forward or {}).y or 0) or 0
  local flen = math.sqrt((fx * fx) + (fy * fy))
  if flen < 0.0001 then fx, fy, flen = 0, 1, 1 end
  fx, fy = fx / flen, fy / flen
  local rx, ry = -fy, fx
  return center, fx, fy, rx, ry
end

local function _gridPointFromCenter(center, forward, cfg, gx, gy)
  local pos, fx, fy, rx, ry = _basisFromCenterAndForward(center, forward)
  if not pos then return nil end
  local size = tonumber(cfg.gridSize or 11) or 11
  local half = math.floor(size / 2)
  local spacing = tonumber(cfg.gridSpacing or "2.0") or 2.0
  local zOffset = tonumber(cfg.gridZOffset or "0.05") or 0.05
  local dx = gx - half - 1
  local dy = half - gy + 1
  return Vector4.new(
    (tonumber(pos.x or 0) or 0) + (rx * dx * spacing) + (fx * dy * spacing),
    (tonumber(pos.y or 0) or 0) + (ry * dx * spacing) + (fy * dy * spacing),
    (tonumber(pos.z or 0) or 0) + zOffset,
    1
  )
end

local function _normalizeGridData(asset)
  if type(asset) ~= "table" or tostring(asset.type or "") ~= "spawn_grid" then return nil end
  local data = ((((asset or {}).data or {}).grid) or {})
  if type(data) ~= "table" then return nil end
  local out = {
    mode = tostring(data.mode or "Character"),
    record = tostring(data.record or ""),
    gridSize = math.floor(tonumber(data.gridSize or 11) or 11),
    gridSpacing = tostring(data.gridSpacing or "2.0"),
    gridZOffset = tostring(data.gridZOffset or "0.05"),
    gridMarks = {},
    despawnAfterSeconds = tonumber(data.despawnAfterSeconds or 0) or 0,
  }
  if out.gridSize < 5 then out.gridSize = 5 end
  if out.gridSize > 21 then out.gridSize = 21 end
  if (out.gridSize % 2) == 0 then out.gridSize = out.gridSize + 1 end
  if out.mode ~= "Vehicle" and out.mode ~= "Prop" and out.mode ~= "FX" and out.mode ~= "Attack" and out.mode ~= "Entity" then out.mode = "Character" end
  if type(data.gridMarks) == "table" then
    for k, v in pairs(data.gridMarks) do
      if v == true then
        out.gridMarks[tostring(k)] = { active = true, mode = out.mode, record = out.record, despawnAfterSeconds = out.despawnAfterSeconds }
      elseif type(v) == "table" and v.active == true then
        local mode = tostring(v.mode or out.mode or "Character")
        if mode ~= "Vehicle" and mode ~= "Prop" and mode ~= "FX" and mode ~= "Attack" and mode ~= "Entity" then mode = "Character" end
        out.gridMarks[tostring(k)] = { active = true, mode = mode, record = tostring(v.record or out.record or ""), despawnAfterSeconds = tonumber(v.despawnAfterSeconds or out.despawnAfterSeconds or 0) or 0 }
      end
    end
  end
  return out
end

local function _tryTeleportHandle(handle, dest)
  if not handle or not dest then return false, "Missing handle or destination" end
  local before = _readWorldPos(handle, nil)
  if before == nil then
    return false, "Could not read current target position"
  end
  local tf = _getTF()
  local ori = nil
  if handle.GetWorldOrientation then ori = _pcall(function() return handle:GetWorldOrientation() end) end
  if ori == nil then ori = _zeroEuler() end

  local errors = {}

  if tf and type(tf.Teleport) == "function" then
    local ok, err = pcall(function() tf:Teleport(handle, dest, ori) end)
    if ok then
      local after = _readWorldPos(handle, nil)
      if after and (_vecDistSq(after, dest) <= 0.25 or _vecDistSq(before, after) > 0.01) then
        return true, nil
      end
      errors[#errors + 1] = "Teleport no-op"
    else
      errors[#errors + 1] = tostring(err or "Teleport failed")
    end
  end

  if handle.SetWorldPosition then
    local ok, err = pcall(function() handle:SetWorldPosition(dest) end)
    if ok then
      local after = _readWorldPos(handle, nil)
      if after and (_vecDistSq(after, dest) <= 0.25 or _vecDistSq(before, after) > 0.01) then
        return true, nil
      end
      errors[#errors + 1] = "SetWorldPosition no-op"
    else
      errors[#errors + 1] = tostring(err or "SetWorldPosition failed")
    end
  end

  if handle.SetPosition then
    local ok, err = pcall(function() handle:SetPosition(dest) end)
    if ok then
      local after = _readWorldPos(handle, nil)
      if after and (_vecDistSq(after, dest) <= 0.25 or _vecDistSq(before, after) > 0.01) then
        return true, nil
      end
      errors[#errors + 1] = "SetPosition no-op"
    else
      errors[#errors + 1] = tostring(err or "SetPosition failed")
    end
  end

  return false, (#errors > 0 and table.concat(errors, " | ") or "Teleportation facility unavailable")
end

local function _resolveMoveEntryHandle(entry)
  if type(entry) ~= "table" then return nil end
  local handle = nil
  if entry.entityID ~= nil then
    handle = _pcall(function() return Game.FindEntityByID(entry.entityID) end)
  end
  if handle == nil and TargetService and type(TargetService.GetHandle) == "function" then
    handle = TargetService.GetHandle(true)
  end
  return handle
end

local function _queueMove(entityID, dest)
  local st = TargetActions.state
  local token = st.nextMoveToken or 1
  st.nextMoveToken = token + 1
  st.pendingMoves[#st.pendingMoves + 1] = {
    token = token,
    entityID = entityID,
    dest = _asVector4(dest),
    startedAt = os.clock(),
    nextTryAt = 0.0,
    tries = 0,
    maxTries = 30,
  }
  return token
end


local function _statusRecordID(handle)
  if not handle or handle.GetRecordID == nil then return nil end
  return _pcall(function() return handle:GetRecordID() end)
end

local function _stopTetherInternal()
  local t = TargetActions.state.tether or {}
  t.active = false
  t.entityID = nil
  t.handle = nil
  t.startedAt = 0
  t.nextTickAt = 0
  t.stillSince = nil
  TargetActions.state.tether = t
end

local function _resolveEntityByID(entityID)
  if entityID == nil then return nil end
  return _pcall(function() return Game.FindEntityByID(entityID) end)
end
local function _getTargetControl()
  local ok, mod = pcall(require, "GTS/target_control")
  if ok and type(mod) == "table" then return mod end
  return nil
end

local function _tcReadWorldPos(handle)
  local tc = _getTargetControl()
  if tc and type(tc.ReadWorldPosition) == "function" then
    return tc.ReadWorldPosition(handle)
  end
  return _readWorldPos(handle, nil)
end

local function _tcMoveHandleToDest(handle, dest, opts)
  local tc = _getTargetControl()
  if tc and type(tc.MoveHandleToDest) == "function" then
    return tc.MoveHandleToDest(handle, dest, opts)
  end
  return _tryTeleportHandle(handle, dest)
end


function TargetActions.OnUpdate(_delta)
  local st = TargetActions.state
  local pending = st.pendingMoves or {}
  local now = os.clock()
  for i = #pending, 1, -1 do
    local entry = pending[i]
    if type(entry) ~= "table" or entry.dest == nil then
      table.remove(pending, i)
    elseif now >= (tonumber(entry.nextTryAt or 0) or 0) then
      local handle = _resolveMoveEntryHandle(entry)
      if handle == nil then
        entry.tries = (entry.tries or 0) + 1
        entry.nextTryAt = now + 0.02
      else
        local pos = _readWorldPos(handle, nil)
        if pos and _vecDistSq(pos, entry.dest) <= 0.25 then
          table.remove(pending, i)
        else
          local ok = _tryTeleportHandle(handle, entry.dest)
          entry.tries = (entry.tries or 0) + 1
          entry.nextTryAt = now + 0.02
          local after = _readWorldPos(handle, nil)
          if ok or (after and _vecDistSq(after, entry.dest) <= 0.25) then
            table.remove(pending, i)
          end
        end
      end
      if (entry.tries or 0) >= (entry.maxTries or 18) then
        table.remove(pending, i)
      end
    end
  end
  local tether = TargetActions.state.tether or {}
  if tether.active == true and now >= (tonumber(tether.nextTickAt or 0) or 0) then
    tether.nextTickAt = now + math.max(0.005, tonumber(tether.refreshEvery or 0.03) or 0.03)
    local player = _player()
    local handle = tether.handle
    if handle == nil or _tcReadWorldPos(handle) == nil then
      handle = _resolveEntityByID(tether.entityID)
      tether.handle = handle
    end
    if not player or not handle then
      _stopTetherInternal()
    else
      local ppos = _pcall(function() return player:GetWorldPosition() end)
      local tpos = _tcReadWorldPos(handle)
      if ppos and tpos then
        local dest = { x = (ppos.x or 0) + (tonumber(tether.offsetX or 0) or 0), y = (ppos.y or 0) + (tonumber(tether.offsetY or 0) or 0), z = (ppos.z or 0) + (tonumber(tether.offsetZ or 0) or 0), w = 1 }
        local dist = math.sqrt(((tpos.x or 0) - dest.x)^2 + ((tpos.y or 0) - dest.y)^2 + ((tpos.z or 0) - dest.z)^2)
        if dist <= 0.03 then
          tether.stillSince = tether.stillSince or now
        else
          tether.stillSince = nil
          _tcMoveHandleToDest(handle, dest, { preferNpcAI = true })
        end
        local elapsed = now - (tonumber(tether.startedAt or now) or now)
        local mode = tostring(tether.endMode or 'manual')
        local hitTime = (mode == 'after_time' or mode == 'either') and elapsed >= (tonumber(tether.endAfterSeconds or 5.0) or 5.0)
        local hitStill = (mode == 'while_still' or mode == 'either') and tether.stillSince and ((now - tether.stillSince) >= (tonumber(tether.endStillSeconds or 3.0) or 3.0))
        if hitTime or hitStill then _stopTetherInternal() end
      end
    end
  end
end

function TargetActions.GetTargetSnapshot(force)
  return _targetSnapshot(force)
end

function TargetActions.GetTargetPosition(force)
  local pos = _targetVector4(force)
  return pos
end

function TargetActions.DespawnTarget()
  local handle, snap = _resolveTargetHandle(true)
  if not snap then return false, "No valid target" end
  if handle == nil then return false, "No valid target handle" end
  local p = _player()
  if p and _sameEntity(handle, p) then return false, "Refused to despawn player" end

  local des = _getDES()
  local entId = snap.entityID or _pcall(function() return handle:GetEntityID() end)
  local didAnything = false
  local okDispose = pcall(function() handle:Dispose() end)
  if okDispose then didAnything = true end
  if des and entId ~= nil then
    local okDelete = pcall(function() des:DeleteEntity(entId) end)
    if okDelete then didAnything = true end
  end
  if not didAnything then return false, "Could not despawn target" end
  return true, "Despawned target"
end

function TargetActions.MoveTarget(action)
  local point, snap, handle = _targetVector4(true)
  if not snap then return false, "No valid target" end
  if not handle then return false, "No valid target handle" end

  local moveMode = tostring((action or {}).moveMode or "offset")
  if moveMode ~= "absolute" then moveMode = "offset" end
  local x = tonumber((action or {}).x)
  local y = tonumber((action or {}).y)
  local z = tonumber((action or {}).z)
  if type(x) ~= "number" or type(y) ~= "number" or type(z) ~= "number" then return false, "Set X, Y, and Z first" end

  local dest = nil
  if moveMode == "absolute" then
    dest = Vector4.new(x, y, z, 1)
  else
    local base = point or _asVector4((snap or {}).xyz or {})
    if not base then return false, "Could not read target position" end
    dest = Vector4.new((tonumber(base.x or 0) or 0) + x, (tonumber(base.y or 0) or 0) + y, (tonumber(base.z or 0) or 0) + z, 1)
  end

  local ok, err = false, nil
  if snap and snap.entityID ~= nil then
    local live = _pcall(function() return Game.FindEntityByID(snap.entityID) end)
    if live then
      handle = live
      ok, err = _tryTeleportHandle(live, dest)
    end
  end
  if not ok then
    ok, err = _tryTeleportHandle(handle, dest)
  end

  local after = _readWorldPos(handle, snap)
  if after and _vecDistSq(after, dest) <= 0.25 then ok = true end

  if not ok then
    local token = _queueMove(snap and snap.entityID or _pcall(function() return handle:GetEntityID() end), dest)
    local msg = (moveMode == "absolute")
      and string.format("Queued target move to %.2f, %.2f, %.2f [retry %d]", x, y, z, token)
      or string.format("Queued target offset %.2f, %.2f, %.2f [retry %d]", x, y, z, token)
    return true, msg
  end

  if moveMode == "absolute" then
    return true, string.format("Moved target to %.2f, %.2f, %.2f", x, y, z)
  end
  return true, string.format("Offset target by %.2f, %.2f, %.2f", x, y, z)
end

function TargetActions.SpawnGridAtTargetAsset(asset)
  local cfg = _normalizeGridData(asset)
  if type(cfg) ~= "table" then return false, "Missing saved grid" end

  local point, _, handle = _targetVector4(true)
  if not point then return false, "No valid target" end

  local SpawnTools = require("GTS/spawn_tools")
  if not SpawnTools or type(SpawnTools.SpawnRecordAtPoint) ~= "function" then
    return false, "Spawn tools unavailable"
  end

  local fwd = nil
  if handle and handle.GetWorldForward then fwd = _pcall(function() return handle:GetWorldForward() end) end
  if not fwd then
    local p = _player()
    if p and p.GetWorldForward then fwd = _pcall(function() return p:GetWorldForward() end) end
  end
  if not fwd then fwd = Vector4.new(0, 1, 0, 0) end

  local ran, activeCount = 0, 0
  for key, mark in pairs(cfg.gridMarks or {}) do
    local isActive = (mark == true) or (type(mark) == "table" and mark.active == true)
    if isActive then
      local gx, gy = key:match("^(%-?%d+):(%-?%d+)$")
      gx, gy = tonumber(gx), tonumber(gy)
      if gx and gy then
        local worldPoint = _gridPointFromCenter(point, fwd, cfg, gx, gy)
        local mode = tostring((type(mark) == "table" and mark.mode) or cfg.mode or "Character")
        local record = tostring((type(mark) == "table" and mark.record) or cfg.record or "")
        local despawn = tonumber((type(mark) == "table" and mark.despawnAfterSeconds) or cfg.despawnAfterSeconds or 0) or 0
        if worldPoint and record ~= "" then
          local ok = SpawnTools.SpawnRecordAtPoint(record, mode, worldPoint, despawn)
          if ok then ran = ran + 1 end
          activeCount = activeCount + 1
        end
      end
    end
  end

  if activeCount == 0 and tostring(cfg.record or "") ~= "" then
    local centerPoint = Vector4.new(point.x or 0, point.y or 0, (point.z or 0) + (tonumber(cfg.gridZOffset or "0.05") or 0.05), 1)
    local ok = SpawnTools.SpawnRecordAtPoint(tostring(cfg.record), tostring(cfg.mode), centerPoint, tonumber(cfg.despawnAfterSeconds or 0) or 0)
    if ok then ran = ran + 1 end
  end

  if ran > 0 then
    return true, string.format("Spawned saved grid at target (%d item%s)", ran, ran == 1 and "" or "s")
  end
  return false, "Could not spawn grid at target"
end

function TargetActions.SpawnAtTarget(action)
  local point = _targetVector4(true)
  if not point then return false, "No valid target" end
  local mode = tostring((action or {}).spawnMode or "Character")
  if mode ~= "Vehicle" and mode ~= "Prop" and mode ~= "FX" and mode ~= "Attack" and mode ~= "Entity" then mode = "Character" end
  local record = tostring((action or {}).recordId or (action or {}).record or "")
  if record == "" then return false, "Choose a record first" end
  local SpawnTools = require("GTS/spawn_tools")
  if not SpawnTools or type(SpawnTools.SpawnRecordAtPoint) ~= "function" then return false, "Spawn tools unavailable" end
  local ok, itemOrErr = SpawnTools.SpawnRecordAtPoint(record, mode, point, tonumber((action or {}).despawnAfterSeconds or 0) or 0)
  if ok then return true, string.format("Spawned %s at target", mode) end
  return false, tostring(itemOrErr or "Could not spawn at target")
end


function TargetActions.ApplyStatusEffectToTarget(rawEffectId)
  local handle, snap = _resolveTargetHandle(true)
  if not snap or not handle then return false, 'No valid target' end
  local Status = require('GTS/macro_actions_status')
  if not Status or type(Status.ApplyStatusEffectToEntity) ~= 'function' then return false, 'Status actions unavailable' end
  local eid = snap.entityID or _pcall(function() return handle:GetEntityID() end)
  local rid = _statusRecordID(handle)
  return Status.ApplyStatusEffectToEntity(rawEffectId, eid, rid)
end

function TargetActions.StartTetherToPlayer(action)
  local handle, snap = _resolveTargetHandle(true)
  if not snap or not handle then return false, 'No valid target' end
  local eid = snap.entityID or _pcall(function() return handle:GetEntityID() end)
  if eid == nil then return false, 'Could not resolve target entity id' end
  local t = TargetActions.state.tether or {}
  t.active = true
  t.entityID = eid
  t.handle = handle
  t.startedAt = os.clock()
  t.nextTickAt = 0
  t.offsetX = tonumber((action or {}).offsetX or 0) or 0
  t.offsetY = tonumber((action or {}).offsetY or 0) or 0
  t.offsetZ = tonumber((action or {}).offsetZ or 0) or 0
  t.refreshEvery = tonumber((action or {}).refreshEvery or 0.03) or 0.03
  t.endMode = tostring((action or {}).endMode or 'manual')
  t.endAfterSeconds = tonumber((action or {}).endAfterSeconds or 5.0) or 5.0
  t.endStillSeconds = tonumber((action or {}).endStillSeconds or 3.0) or 3.0
  t.stillSince = nil
  TargetActions.state.tether = t
  return true, 'Started tether to player location'
end

function TargetActions.StopTether()
  _stopTetherInternal()
  return true, 'Stopped tether'
end


function TargetActions.CycleAppearance(step)
  local tc = _getTargetControl()
  if tc and type(tc.CycleAppearance) == "function" then
    return tc.CycleAppearance(step)
  end
  return false, 'Target control appearance actions unavailable'
end

return TargetActions
