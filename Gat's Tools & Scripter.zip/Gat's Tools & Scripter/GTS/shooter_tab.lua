local Shooter = Shooter or {}
local AssetRegistry = require("GTS/asset_registry")
local ShooterFxLibrary = require("GTS/shooter_fx_library")
local SpawnTools = require("GTS/spawn_tools")
local EntTemplateLibrary = require("GTS/ent_template_library")

Shooter.state = Shooter.state or {
  dbBuilt = false,
  vehicles = {},
  npcs = {},
  props = {},
  fxPresets = {},
  attacks = {},
  entities = {},
  global = {
    enabled = false,
    type = "FX",
    assetId = "",
    search = "",
    selectedIndex = 1,
    cooldown = 0.25,
    npcAsCompanion = true,
    npcImpactZLift = 0.05,
    npcSteps = 10,
    npcStepDist = 0.65,
    npcDespawn = 10.0,
    propImpactZLift = 0.05,
    propSteps = 8,
    propStepDist = 0.55,
    propDespawn = 10.0,
    vehicleZLift = 0.10,
    vehicleDespawn = 10.0,
    gridEnabled = false,
    gridSize = 7,
    gridSpacing = 2.0,
    gridZOffset = 0.00,
    gridMarks = {},
  },
  perWeapon = {},
  runtime = {
    activeWeaponKey = nil,
    lastMagAmmo = nil,
    lastFireAt = 0.0,
    pending = {},
    lastAimPos = nil,
  },
  ui = {
    savedOverrideSelected = nil,
    selectedProfileId = nil,
    profileName = "",
    profileLoadTarget = "global",
    status = "Shooter ready.",
    statusAt = 0,
  },
}

local function _pcall(fn)
  local ok, res = pcall(fn)
  if ok then return res end
  return nil
end

local function _setStatus(msg)
  Shooter.state.ui.status = tostring(msg or "")
  Shooter.state.ui.statusAt = os.clock()
  print("[GTS][Shooter] " .. tostring(msg or ""))
end

local function _trim(s)
  return tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function _cloneTable(src)
  if type(src) ~= "table" then return src end
  local out = {}
  for k, v in pairs(src) do out[k] = _cloneTable(v) end
  return out
end

local function _checkboxValue(label, current)
  local a, b = ImGui.Checkbox(label, current == true)
  if type(a) == "boolean" and type(b) == "boolean" then
    if b == (a ~= current) then return a == true end
    if a == (b ~= current) then return b == true end
    return b == true
  end
  if type(a) == "boolean" then return a == true end
  if type(b) == "boolean" then return b == true end
  return current == true
end

local function _inputTextValue(label, value, bufSize)
  local a, b = ImGui.InputText(label, tostring(value or ""), bufSize or 256)
  if type(a) == "boolean" and type(b) == "string" then return b end
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return tostring(value or "")
end

local function _comboValue(label, current, values)
  local idx = 0
  for i = 1, #values do if values[i] == current then idx = i - 1 break end end
  local a, b = ImGui.Combo(label, idx, values, #values)
  if type(a) == "boolean" then
    if a then return values[(b or 0) + 1] or current end
    return current
  end
  if type(a) == "number" then return values[(a or 0) + 1] or current end
  if type(b) == "number" then return values[(b or 0) + 1] or current end
  return current
end

local function _sliderFloatValue(label, current, minv, maxv, fmt)
  local a, b = ImGui.SliderFloat(label, tonumber(current or 0) or 0, minv, maxv, fmt or "%.2f")
  if type(a) == "boolean" and type(b) == "number" then return b end
  if type(a) == "number" then return a end
  if type(b) == "number" then return b end
  return tonumber(current or 0) or 0
end

local function _sliderIntValue(label, current, minv, maxv)
  local a, b = ImGui.SliderInt(label, tonumber(current or 0) or 0, minv, maxv)
  if type(a) == "boolean" and type(b) == "number" then return math.floor(b) end
  if type(a) == "number" then return math.floor(a) end
  if type(b) == "number" then return math.floor(b) end
  return math.floor(tonumber(current or 0) or 0)
end

local function _extractItemsIdFromAny(x)
  if x == nil then return nil end
  local s = tostring(x)
  if s == nil or s == "" then return nil end
  local m = s:match("%-%-%[%[(Items%.[%w_]+)%]%]")
  if m ~= nil and m ~= "" then return m end
  m = s:match("(Items%.[%w_]+)")
  if m ~= nil and m ~= "" then return m end
  return nil
end

local function _recordPathFromRec(rec)
  if not rec then return nil end
  local id = _pcall(function() return rec:GetID() end)
  if id and type(id.value) == "string" and id.value ~= "" then return id.value end
  local rid = _pcall(function() return rec:GetRecordID() end)
  if rid and type(rid.value) == "string" and rid.value ~= "" then return rid.value end
  local probes = {
    function() return tostring(rec:GetID()) end,
    function() return tostring(rec:GetRecordID()) end,
    function() return tostring(rec) end,
  }
  for _, fn in ipairs(probes) do
    local s = _pcall(fn)
    if type(s) == "string" and s ~= "" then
      s = s:gsub("^TweakDBID%(", ""):gsub("%)$", "")
      s = s:gsub("^RecordID%(", ""):gsub("%)$", "")
      if s ~= "" then return s end
    end
  end
  return nil
end

local function _appendRecordList(dst, recordTypeName, prefix)
  local records = _pcall(function() return TweakDB:GetRecords(recordTypeName) end)
  if type(records) ~= "table" then return end
  for i = 1, #records do
    local path = _recordPathFromRec(records[i])
    if path and ((not prefix) or path:match("^" .. prefix)) then dst[#dst + 1] = path end
  end
end

local function _fxBasename(path)
  local s = tostring(path or "")
  local name = s:match("([^\\/]+)$")
  return name or s
end

local function _entBasename(path)
  local s = tostring(path or "")
  local name = s:match("([^\\/]+)$")
  return name or s
end

local function _normalizeEntityTemplatePath(path)
  local s = _trim(path)
  s = s:gsub("/", "\\")
  s = s:gsub("\\+", "\\")
  if s ~= "" and not s:lower():match("%.ent$") then s = s .. ".ent" end
  return s
end

local function _normalizeEffectInput(s)
  s = _trim(s)
  s = s:gsub('^gameFxResource%.new%(%s*{%s*effect%s*=%s*"', '')
  s = s:gsub('"%s*}%s*%)$', '')
  s = s:gsub('^"', ''):gsub('"$', '')
  return s
end

local function _resolveFxPath(effectId)
  local s = _normalizeEffectInput(effectId)
  if s == "" then return nil end
  if s:find("\\", 1, true) or s:find("/", 1, true) then return s end
  local low = string.lower(s)
  local src = Shooter.state.fxPresets or {}
  for i = 1, #src do
    local full = src[i]
    if string.lower(full) == low then return full end
  end
  for i = 1, #src do
    local full = src[i]
    if string.lower(_fxBasename(full)) == low then return full end
  end
  if not low:match("%.effect$") then
    local withExt = low .. ".effect"
    for i = 1, #src do
      local full = src[i]
      if string.lower(_fxBasename(full)) == withExt then return full end
    end
  end
  return s
end

local function _buildDB()
  local st = Shooter.state
  if st.dbBuilt then return end
  local chars, vehs, props, effects, attacks, entities = {}, {}, {}, {}, {}, {}
  _appendRecordList(chars, "gamedataCharacter_Record", "Character%.")
  _appendRecordList(vehs, "gamedataVehicle_Record", "Vehicle%.")
  _appendRecordList(props, "gamedataProp_Record", nil)
  if ShooterFxLibrary and type(ShooterFxLibrary.effects) == "table" then
    for i = 1, #ShooterFxLibrary.effects do
      effects[#effects + 1] = tostring(ShooterFxLibrary.effects[i])
    end
  end
  _appendRecordList(attacks, "gamedataAttack_Record", "Attacks%.")
  _appendRecordList(attacks, "gamedataAttack_GameEffect_Record", "Attacks%.")
  if EntTemplateLibrary and type(EntTemplateLibrary.paths) == "table" then
    for i = 1, #EntTemplateLibrary.paths do entities[#entities + 1] = tostring(EntTemplateLibrary.paths[i]) end
  end
  _appendRecordList(attacks, "gamedataAttack_GameEffect_Record", "Attacks%.")
  local function dedupeSort(src)
    local out, seen = {}, {}
    for i = 1, #src do
      local v = src[i]
      if type(v) == "string" and v ~= "" and not seen[v] then
        seen[v] = true
        out[#out + 1] = v
      end
    end
    table.sort(out)
    return out
  end
  st.npcs = dedupeSort(chars)
  st.vehicles = dedupeSort(vehs)
  st.props = dedupeSort(props)
  st.fxPresets = dedupeSort(effects)
  st.attacks = dedupeSort(attacks)
  st.entities = dedupeSort(entities)
  st.dbBuilt = true
  _setStatus(string.format("Shooter DB built: %d NPCs, %d Vehicles, %d Props, %d FX paths, %d Attacks, %d .ent templates", #st.npcs, #st.vehicles, #st.props, #st.fxPresets, #st.attacks, #st.entities))
end

local function _defaultConfig()
  local g = Shooter.state.global
  return {
    enabled = false,
    type = g.type,
    assetId = "",
    search = "",
    selectedIndex = 1,
    cooldown = g.cooldown,
    npcAsCompanion = g.npcAsCompanion,
    npcImpactZLift = g.npcImpactZLift,
    npcSteps = g.npcSteps,
    npcStepDist = g.npcStepDist,
    npcDespawn = g.npcDespawn,
    propImpactZLift = g.propImpactZLift,
    propSteps = g.propSteps,
    propStepDist = g.propStepDist,
    propDespawn = g.propDespawn,
    vehicleZLift = g.vehicleZLift,
    vehicleDespawn = g.vehicleDespawn,
    gridEnabled = g.gridEnabled,
    gridSize = g.gridSize,
    gridSpacing = g.gridSpacing,
    gridZOffset = g.gridZOffset,
    gridMarks = {},
  }
end

local function _normalizeConfig(cfg)
  if type(cfg) ~= "table" then cfg = _defaultConfig() end
  if cfg.enabled == nil then cfg.enabled = false end
  cfg.type = tostring(cfg.type or "FX")
  cfg.assetId = tostring(cfg.assetId or "")
  cfg.search = tostring(cfg.search or "")
  cfg.selectedIndex = tonumber(cfg.selectedIndex or 1) or 1
  cfg.cooldown = tonumber(cfg.cooldown or 0.25) or 0.25
  cfg.npcAsCompanion = cfg.npcAsCompanion ~= false
  cfg.npcImpactZLift = tonumber(cfg.npcImpactZLift or 0.05) or 0.05
  cfg.npcSteps = math.floor(tonumber(cfg.npcSteps or 10) or 10)
  cfg.npcStepDist = tonumber(cfg.npcStepDist or 0.65) or 0.65
  cfg.npcDespawn = tonumber(cfg.npcDespawn or 10.0) or 10.0
  cfg.propImpactZLift = tonumber(cfg.propImpactZLift or 0.05) or 0.05
  cfg.propSteps = math.floor(tonumber(cfg.propSteps or 8) or 8)
  cfg.propStepDist = tonumber(cfg.propStepDist or 0.55) or 0.55
  cfg.propDespawn = tonumber(cfg.propDespawn or 10.0) or 10.0
  cfg.vehicleZLift = tonumber(cfg.vehicleZLift or 0.10) or 0.10
  cfg.vehicleDespawn = tonumber(cfg.vehicleDespawn or 10.0) or 10.0
  cfg.gridEnabled = cfg.gridEnabled == true
  cfg.gridSize = math.floor(tonumber(cfg.gridSize or 7) or 7)
  if cfg.gridSize < 3 then cfg.gridSize = 3 end
  if cfg.gridSize > 15 then cfg.gridSize = 15 end
  if (cfg.gridSize % 2) == 0 then cfg.gridSize = cfg.gridSize + 1 end
  cfg.gridSpacing = tonumber(cfg.gridSpacing or 2.0) or 2.0
  cfg.gridZOffset = tonumber(cfg.gridZOffset or 0.0) or 0.0
  if type(cfg.gridMarks) ~= "table" then cfg.gridMarks = {} end
  if cfg.selectedIndex < 1 then cfg.selectedIndex = 1 end
  return cfg
end

local function _getPlayer()
  return (Game and Game.GetPlayer and Game.GetPlayer()) or nil
end

local function _getActiveWeapon(player)
  local p = player or _getPlayer()
  if not p then return nil end
  return _pcall(function() return p:GetActiveWeapon() end)
end

local function _getActiveWeaponKey(player)
  local p = player or _getPlayer()
  if not p then return nil end
  local w = _getActiveWeapon(p)
  if not w then return nil end
  local itemID = _pcall(function() return w:GetItemID() end)
  local itemKey = _extractItemsIdFromAny(itemID)
  if itemKey then return itemKey end
  local itemData = _pcall(function() return w:GetItemData() end)
  if itemData ~= nil then
    local iid = _pcall(function() return itemData:GetID() end)
    itemKey = _extractItemsIdFromAny(iid)
    if itemKey then return itemKey end
  end
  local rec = _pcall(function() return w:GetRecordID() end)
  if rec then
    local s = tostring(rec)
    local m = s:match("(Items%.[%w_]+)")
    if m then return m end
  end
  return nil
end

local function _getMagAmmo(weaponObj, playerObj)
  local w = weaponObj or _getActiveWeapon(playerObj)
  if w ~= nil then
    local candidates = {
      "GetAmmoCount", "GetAmmoInMagazine", "GetMagazineAmmoCount", "GetMagazineAmmoCurrent",
      "GetCurrentAmmo", "GetAmmoCurrent", "GetAmmo",
    }
    for _, name in ipairs(candidates) do
      if w[name] ~= nil then
        local ok, val = pcall(function() return w[name](w) end)
        if ok and type(val) == "number" then return val end
      end
    end
    local itemData = _pcall(function() return w:GetItemData() end)
    if itemData ~= nil then
      for _, name in ipairs(candidates) do
        if itemData[name] ~= nil then
          local ok, val = pcall(function() return itemData[name](itemData) end)
          if ok and type(val) == "number" then return val end
        end
      end
    end
    local wid = _pcall(function() return w:GetEntityID() end)
    local ss = (Game and Game.GetStatsSystem and Game.GetStatsSystem()) or nil
    if ss ~= nil and wid ~= nil and gamedataStatType ~= nil then
      local stats = {
        gamedataStatType.MagazineAmmoCount,
        gamedataStatType.MagazineAmmoCurrent,
        gamedataStatType.MagazineAmmo,
        gamedataStatType.AmmoInClip,
        gamedataStatType.AmmoCurrent,
        gamedataStatType.AmmoCount,
      }
      for _, st in ipairs(stats) do
        if st ~= nil then
          local ok, val = pcall(function() return ss:GetStatValue(wid, st) end)
          if ok and type(val) == "number" then return val end
        end
      end
    end
  end
  return nil
end

local function _vecLen(v)
  if not v then return 0 end
  return math.sqrt((v.x or 0)^2 + (v.y or 0)^2 + (v.z or 0)^2)
end

local function _vecNormalize(v)
  local l = _vecLen(v)
  if l <= 0.0001 then return Vector4.new(0, 1, 0, 0) end
  return Vector4.new((v.x or 0) / l, (v.y or 0) / l, (v.z or 0) / l, 0)
end

local function _getLookAtPosition(player)
  local p = player or _getPlayer()
  if not p then return nil end
  local ts = (Game and Game.GetTargetingSystem and Game.GetTargetingSystem()) or nil
  if ts == nil then return nil end
  local tries = {
    function() return ts:GetLookAtPosition(p, true, false) end,
    function() return ts:GetLookAtPosition(p, true, true) end,
    function() return ts:GetLookAtPosition(p, true) end,
    function() return ts:GetLookAtPosition(p) end,
  }
  for _, fn in ipairs(tries) do
    local ok, pos = pcall(fn)
    if ok and pos ~= nil then return pos end
  end
  return nil
end

local function _tdbidFromString(idStr)
  local s = _trim(idStr)
  if s == "" then return nil end
  if not TweakDBID or not TweakDBID.new then return nil end
  local hex, extra = s:match("^0[xX]([%da-fA-F]+)%s*,%s*(%d+)$")
  if hex and extra then
    local hash = tonumber(hex, 16)
    local len = tonumber(extra)
    if hash and len then return _pcall(function() return TweakDBID.new(hash, len) end) end
  end
  return _pcall(function() return TweakDBID.new(s) end)
end

local function _spawnRecord(recordPath, pos, tag)
  local des = (Game and Game.GetDynamicEntitySystem and Game.GetDynamicEntitySystem()) or nil
  if not des then return nil, "DynamicEntitySystem unavailable" end
  if not DynamicEntitySpec or not DynamicEntitySpec.new then return nil, "DynamicEntitySpec unavailable" end
  local tid = _tdbidFromString(recordPath)
  if tid == nil then return nil, "Invalid record ID" end
  local spec = DynamicEntitySpec.new()
  pcall(function() spec.persistState = false end)
  pcall(function() spec.persistSpawn = false end)
  pcall(function() spec.alwaysSpawned = false end)
  pcall(function() spec.spawnInView = true end)
  spec.recordID = tid
  spec.position = Vector4.new(pos.x, pos.y, pos.z, pos.w or 1.0)
  pcall(function() spec.tags = { tag or "MG_SHOOTER" } end)
  local ok, eid = pcall(function() return des:CreateEntity(spec) end)
  if ok and eid ~= nil then return eid end
  return nil, "CreateEntity failed"
end

local function _trySpawnVehicleAt(recordPath, pos)
  return _spawnRecord(recordPath, pos, "MG_SHOOTER_VEHICLE")
end

local function _trySpawnNPCAt(recordPath, pos)
  return _spawnRecord(recordPath, pos, "MG_SHOOTER_NPC")
end

local function _trySpawnPropAt(recordPath, pos)
  return _spawnRecord(recordPath, pos, "MG_SHOOTER_PROP")
end

local function _tryMakeCompanion(ent)
  if not ent then return end
  local player = _getPlayer()
  if not player then return end
  pcall(function() if ent.SetDisableAI then ent:SetDisableAI(false) end end)
  pcall(function() if ent.EnableAI then ent:EnableAI(true) end end)
  pcall(function() if ent.DisableAI then ent:DisableAI(false) end end)
  local ssc = _pcall(function() return Game.GetScriptableSystemsContainer and Game.GetScriptableSystemsContainer() or nil end)
  local attSys = _pcall(function() return Game.GetAttitudeSystem and Game.GetAttitudeSystem() or nil end)
  if not attSys and ssc then
    attSys = _pcall(function() return ssc:Get(CName.new("AttitudeSystem")) end) or _pcall(function() return ssc:Get("AttitudeSystem") end)
  end
  if attSys and attSys.SetAttitudeTowards and ent.GetAttitudeAgent and player.GetAttitudeAgent and EAIAttitude then
    pcall(function() attSys:SetAttitudeTowards(ent:GetAttitudeAgent(), player:GetAttitudeAgent(), EAIAttitude.AIA_Friendly) end)
  end
  local compSys = _pcall(function() return Game.GetCompanionSystem and Game.GetCompanionSystem() or nil end)
  if not compSys and ssc then
    compSys = _pcall(function() return ssc:Get(CName.new("CompanionSystem")) end) or _pcall(function() return ssc:Get("CompanionSystem") end)
  end
  if compSys then
    pcall(function() if compSys.SetNPCAsCompanion then compSys:SetNPCAsCompanion(ent) end end)
    pcall(function() if compSys.MakeCompanion then compSys:MakeCompanion(ent) end end)
    pcall(function() if compSys.AddCompanion then compSys:AddCompanion(ent) end end)
    pcall(function() if compSys.SetCompanion then compSys:SetCompanion(ent) end end)
  end
end

local function _queueLaunch(entityID, dir, steps, stepDist, makeCompanion)
  local rt = Shooter.state.runtime
  rt.pending = rt.pending or {}
  table.insert(rt.pending, {
    entityID = entityID,
    dir = dir,
    steps = steps,
    stepDist = stepDist,
    launched = false,
    makeCompanion = makeCompanion == true,
    companionDone = false,
    nextStepAt = 0.0,
    stepIdx = 0,
    age = 0.0,
  })
end

local function _queueDespawn(entityID, seconds)
  if entityID == nil then return end
  if type(seconds) ~= "number" or seconds <= 0 then return end
  Shooter.state.runtime.pending = Shooter.state.runtime.pending or {}
  table.insert(Shooter.state.runtime.pending, {
    entityID = entityID,
    despawnAt = os.clock() + seconds,
    despawnOnly = true,
  })
end

local function _despawnEntityByID(entityID)
  if entityID == nil then return end
  local des = (Game and Game.GetDynamicEntitySystem and Game.GetDynamicEntitySystem()) or nil
  local ent = _pcall(function() return Game.FindEntityByID(entityID) end)
  if ent then pcall(function() ent:Dispose() end) end
  if des then pcall(function() des:DeleteEntity(entityID) end) end
end

local function _processPending(dt)
  local pend = Shooter.state.runtime.pending or nil
  if type(pend) ~= "table" or #pend == 0 then return end
  local tf = (Game and Game.GetTeleportationFacility and Game.GetTeleportationFacility()) or nil
  local now = os.clock()
  for i = #pend, 1, -1 do
    local p = pend[i]
    if p.despawnOnly == true then
      if now >= (p.despawnAt or 0.0) then
        _despawnEntityByID(p.entityID)
        table.remove(pend, i)
      end
    else
      local ent = nil
      if p.entityID ~= nil then ent = _pcall(function() return Game.FindEntityByID(p.entityID) end) end
      if ent == nil then
        p.age = (p.age or 0) + (dt or 0)
        if (p.age or 0) > 3.0 then table.remove(pend, i) end
      else
        if not p.launched then
          p.launched = true
          p.nextStepAt = 0.0
          p.stepIdx = 0
          if p.makeCompanion and not p.companionDone then
            p.companionDone = true
            _tryMakeCompanion(ent)
          end
        end
        if now >= (p.nextStepAt or 0.0) then
          p.stepIdx = (p.stepIdx or 0) + 1
          local wp = _pcall(function() return ent:GetWorldPosition() end)
          if wp and tf and tf.Teleport then
            local nd = p.dir or Vector4.new(0, 1, 0, 0)
            local d = p.stepDist or 0.6
            local newPos = Vector4.new(wp.x + nd.x * d, wp.y + nd.y * d, wp.z + nd.z * d, 1)
            pcall(function()
              local ori = nil
              if ent.GetWorldOrientation then ori = ent:GetWorldOrientation() end
              tf:Teleport(ent, newPos, ori)
            end)
          end
          p.nextStepAt = now + 0.02
          if (p.stepIdx or 0) >= (p.steps or 8) then table.remove(pend, i) end
        end
      end
    end
  end
end

local function _trySpawnEntityTemplateAt(templatePath, pos)
  local path = _normalizeEntityTemplatePath(templatePath)
  if path == "" then return nil, "Missing entity template path" end
  if pos == nil then return nil, "Missing position" end
  if exEntitySpawner == nil or exEntitySpawner.Spawn == nil then return nil, "exEntitySpawner.Spawn unavailable" end
  local player = _getPlayer()
  if not player then return nil, "Player unavailable" end
  local tr = _pcall(function() return player:GetWorldTransform() end)
  if tr == nil then return nil, "Could not get transform" end
  local okPos, posErr = pcall(function() tr:SetPosition(Vector4.new(pos.x or 0, pos.y or 0, pos.z or 0, pos.w or 1.0)) end)
  if not okPos then return nil, tostring(posErr or "Could not set entity transform position") end
  pcall(function() local ori = player:GetWorldOrientation() if ori ~= nil then tr:SetOrientation(ori) end end)
  local okS, spawned = pcall(function() return exEntitySpawner.Spawn(path, tr, "", "") end)
  if not okS then return nil, tostring(spawned or "Entity spawn threw an error") end
  if spawned == nil then return nil, "Entity spawn returned nil" end
  return spawned, nil
end

local function _spawnFXAt(effectId, pos, player)
  local resolved = _resolveFxPath(effectId)
  if _trim(resolved) == "" or pos == nil then return false, "Missing FX path or position" end
  local fxSystem = (Game and Game.GetFxSystem and Game.GetFxSystem()) or nil
  if fxSystem == nil then return false, "FxSystem unavailable" end
  if gameFxResource == nil or gameFxResource.new == nil then return false, "gameFxResource unavailable" end
  local transform = WorldTransform.new()
  if player and player.GetWorldOrientation then
    local ori = _pcall(function() return player:GetWorldOrientation() end)
    if ori ~= nil then pcall(function() transform:SetOrientation(ori) end) end
  end
  pcall(function() transform:SetPosition(Vector4.new(pos.x or 0, pos.y or 0, pos.z or 0, 1)) end)
  local fxParticle = gameFxResource.new({ effect = resolved })
  local okHandle, fxHandle = pcall(function() return fxSystem:SpawnEffect(fxParticle, transform) end)
  if okHandle and fxHandle ~= nil and (IsDefined == nil or IsDefined(fxHandle)) then
    return true, resolved
  end
  local okGround = pcall(function() fxSystem:SpawnEffectOnGround(fxParticle, transform, true) end)
  if okGround then return true, resolved end
  return false, resolved
end

local function _filteredAssets(cfg)
  _buildDB()
  local t = tostring(cfg.type or "FX")
  local src = Shooter.state.fxPresets
  if t == "NPC" then src = Shooter.state.npcs
  elseif t == "Vehicle" then src = Shooter.state.vehicles
  elseif t == "Prop" then src = Shooter.state.props
  elseif t == "Attack" then src = Shooter.state.attacks
  elseif t == "Entity" then src = Shooter.state.entities end
  local out = {}
  local low = string.lower(tostring(cfg.search or ""))
  if low == "" then
    for i = 1, #src do out[#out + 1] = src[i] end
  else
    for i = 1, #src do
      local v = src[i]
      local vv = string.lower(v)
      local bn = string.lower(_fxBasename(v))
      if string.find(vv, low, 1, true) or ((t == "FX" or t == "Entity") and string.find(bn, low, 1, true)) then
        out[#out + 1] = v
      end
    end
  end
  if cfg.selectedIndex < 1 then cfg.selectedIndex = 1 end
  if cfg.selectedIndex > #out then cfg.selectedIndex = math.max(1, #out) end
  return out
end

local function _cloneGlobalInto(cfg)
  local g = Shooter.state.global
  cfg.type = g.type
  cfg.assetId = g.assetId
  cfg.search = g.search
  cfg.selectedIndex = g.selectedIndex
  cfg.cooldown = g.cooldown
  cfg.npcAsCompanion = g.npcAsCompanion
  cfg.npcImpactZLift = g.npcImpactZLift
  cfg.npcSteps = g.npcSteps
  cfg.npcStepDist = g.npcStepDist
  cfg.propImpactZLift = g.propImpactZLift
  cfg.propSteps = g.propSteps
  cfg.propStepDist = g.propStepDist
  cfg.propDespawn = g.propDespawn
  cfg.vehicleZLift = g.vehicleZLift
  cfg.gridEnabled = g.gridEnabled
  cfg.gridSize = g.gridSize
  cfg.gridSpacing = g.gridSpacing
  cfg.gridZOffset = g.gridZOffset
  cfg.gridMarks = _cloneTable(g.gridMarks)
end

local function _glyphFromKeys(keys, fallback)
  if type(IconGlyphs) == "table" then
    for _, k in ipairs(keys or {}) do
      local g = IconGlyphs[k]
      if g ~= nil and g ~= "" and g ~= "?" and g ~= "S" then
        return g
      end
    end
  end
  return fallback
end

local function _glyphOpen()
  return _glyphFromKeys({ "SquareMediumOutline", "SquareOutline", "CheckboxBlankOutline", "SquareRoundedOutline" }, "□")
end

local function _glyphFilled()
  return _glyphFromKeys({ "SquareMedium", "Square", "CheckboxMarked", "Stop", "SquareRounded" }, "■")
end

local function _glyphCenter()
  return _glyphFromKeys({ "Crosshairs", "CrosshairsGps", "Target", "CircleMedium", "RecordCircleOutline" }, "◎")
end

local function _gridCellKey(gx, gy)
  return tostring(gx) .. ":" .. tostring(gy)
end

local function _impactBasisXZ(player, impact)
  local p = player or _getPlayer()
  if not p or impact == nil then return nil end
  local ppos = _pcall(function() return p:GetWorldPosition() end)
  local pfwd = _pcall(function() return p:GetWorldForward() end)
  if not ppos then return nil end
  local fx = (impact.x or 0) - (ppos.x or 0)
  local fy = (impact.y or 0) - (ppos.y or 0)
  local flen = math.sqrt((fx * fx) + (fy * fy))
  if flen < 0.0001 and pfwd then
    fx, fy = tonumber(pfwd.x or 0) or 0, tonumber(pfwd.y or 0) or 0
    flen = math.sqrt((fx * fx) + (fy * fy))
  end
  if flen < 0.0001 then fx, fy, flen = 0, 1, 1 end
  fx, fy = fx / flen, fy / flen
  local rx, ry = -fy, fx
  return fx, fy, rx, ry
end

local function _impactGridWorldPosition(cfg, player, impact, gx, gy)
  cfg = _normalizeConfig(cfg)
  local fx, fy, rx, ry = _impactBasisXZ(player, impact)
  if fx == nil then return nil end
  local size = tonumber(cfg.gridSize or 7) or 7
  local half = math.floor(size / 2)
  local spacing = tonumber(cfg.gridSpacing or 2.0) or 2.0
  local zOffset = tonumber(cfg.gridZOffset or 0.0) or 0.0
  local dx = gx - half - 1
  local dy = half - gy + 1
  return Vector4.new(
    (impact.x or 0) + (rx * dx * spacing) + (fx * dy * spacing),
    (impact.y or 0) + (ry * dx * spacing) + (fy * dy * spacing),
    (impact.z or 0) + zOffset,
    1
  )
end

local function _drawImpactGridTooltip(point, active)
  if point == nil then return end
  ImGui.BeginTooltip()
  ImGui.Text(string.format("XYZ: %.2f, %.2f, %.2f", point.x or 0, point.y or 0, point.z or 0))
  ImGui.Text(active and "Active" or "Inactive")
  ImGui.EndTooltip()
end

local function _drawImpactGridPlanner(title, cfg, player)
  cfg = _normalizeConfig(cfg)
  local size = tonumber(cfg.gridSize or 7) or 7
  if size < 3 then size = 3 end
  if size > 15 then size = 15 end
  if (size % 2) == 0 then size = size + 1 end
  cfg.gridSize = size
  cfg.gridSpacing = _sliderFloatValue("Cell Spacing##grid_spacing_" .. tostring(title), cfg.gridSpacing, 0.25, 10.0, "%.2f m")
  cfg.gridZOffset = _sliderFloatValue("Z Offset##grid_z_" .. tostring(title), cfg.gridZOffset, -5.0, 5.0, "%.2f")
  local sizeText = tostring(size)
  sizeText = _comboValue("Grid Size##grid_size_" .. tostring(title), sizeText, { "3", "5", "7", "9", "11", "13", "15" })
  cfg.gridSize = tonumber(sizeText) or size
  ImGui.SameLine()
  if ImGui.SmallButton("Clear Pattern##clear_grid_" .. tostring(title)) then cfg.gridMarks = {} end
  ImGui.TextDisabled("Center cell = bullet impact. Click cells to toggle extra spawn points.")
  local center = math.floor(cfg.gridSize / 2) + 1
  local cellSize = 20
  local previewImpact = _getLookAtPosition(player)
  if ImGui.BeginChild("impact_grid_" .. tostring(title), 0, math.min(330, (cfg.gridSize * 22) + 10), true) then
    for gy = 1, cfg.gridSize do
      for gx = 1, cfg.gridSize do
        if gx > 1 then ImGui.SameLine() end
        local key = _gridCellKey(gx, gy)
        local isCenter = (gx == center and gy == center)
        local active = (type(cfg.gridMarks[key]) == "table" and cfg.gridMarks[key].active == true) or (cfg.gridMarks[key] == true)
        local label = active and _glyphFilled() or _glyphOpen()
        if isCenter then label = _glyphCenter() end
        ImGui.PushID("impactgrid_" .. tostring(title) .. "_" .. key)
        local transparent = {0.00, 0.00, 0.00, 0.00}
        ImGui.PushStyleColor(ImGuiCol.Button, transparent[1], transparent[2], transparent[3], transparent[4])
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, transparent[1], transparent[2], transparent[3], transparent[4])
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, transparent[1], transparent[2], transparent[3], transparent[4])
        ImGui.PushStyleColor(ImGuiCol.Border, transparent[1], transparent[2], transparent[3], transparent[4])
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, 0, 0)
        local clicked = ImGui.Button(label, cellSize, cellSize)
        ImGui.PopStyleVar(1)
        ImGui.PopStyleColor(4)
        if clicked then
          if active then
            cfg.gridMarks[key] = nil
          else
            cfg.gridMarks[key] = { active = true }
          end
        end
        if ImGui.IsItemHovered() and previewImpact ~= nil then
          _drawImpactGridTooltip(_impactGridWorldPosition(cfg, player, previewImpact, gx, gy), active)
        end
        ImGui.PopID()
      end
    end
    ImGui.EndChild()
  end
end

local function _drawConfigEditor(title, cfg, allowEnable)
  cfg = _normalizeConfig(cfg)
  if title and title ~= "" then
    ImGui.Separator()
    ImGui.Text(title)
  end
  if allowEnable then cfg.enabled = _checkboxValue("Enabled##" .. title, cfg.enabled) end
  cfg.type = _comboValue("Shooter Type##" .. title, cfg.type, { "FX", "Prop", "NPC", "Vehicle", "Attack", "Entity" })
  cfg.cooldown = _sliderFloatValue("Cooldown##" .. title, cfg.cooldown, 0.05, 5.0, "%.2f s")
  cfg.search = _inputTextValue("Search##" .. title, cfg.search, 256)
  cfg.assetId = _inputTextValue("Asset ID##" .. title, cfg.assetId, 512)

  local filtered = _filteredAssets(cfg)
  ImGui.Text("Results: " .. tostring(#filtered))
  if ImGui.BeginChild("results_" .. tostring(title), -1, 160, true) then
    for i = 1, #filtered do
      local entry = filtered[i]
      local selected = (cfg.selectedIndex == i)
      local label = entry
      if cfg.type == "FX" then label = _fxBasename(entry) elseif cfg.type == "Entity" then label = _entBasename(entry) end
      if ImGui.Selectable(label .. "##" .. tostring(title) .. "_" .. tostring(i), selected) then
        cfg.selectedIndex = i
        cfg.assetId = tostring(entry or "")
      end
      if (cfg.type == "FX" or cfg.type == "Entity") and ImGui.IsItemHovered() then
        ImGui.BeginTooltip()
        ImGui.TextWrapped(tostring(entry))
        ImGui.EndTooltip()
      end
    end
    ImGui.EndChild()
  end

  if cfg.type == "NPC" then
    cfg.npcAsCompanion = _checkboxValue("Spawn As Companion##" .. title, cfg.npcAsCompanion)
    cfg.npcImpactZLift = _sliderFloatValue("Impact Z Lift##" .. title, cfg.npcImpactZLift, 0.00, 2.00, "%.2f")
    cfg.npcSteps = _sliderIntValue("Launch Steps##" .. title, cfg.npcSteps, 0, 40)
    cfg.npcStepDist = _sliderFloatValue("Step Distance##" .. title, cfg.npcStepDist, 0.00, 5.00, "%.2f")
  elseif cfg.type == "Prop" then
    cfg.propImpactZLift = _sliderFloatValue("Impact Z Lift##" .. title, cfg.propImpactZLift, 0.00, 2.00, "%.2f")
    cfg.propSteps = _sliderIntValue("Launch Steps##" .. title, cfg.propSteps, 0, 40)
    cfg.propStepDist = _sliderFloatValue("Step Distance##" .. title, cfg.propStepDist, 0.00, 5.00, "%.2f")
    cfg.propDespawn = _sliderFloatValue("Despawn Seconds##" .. title, cfg.propDespawn, 0.00, 60.00, "%.2f")
  elseif cfg.type == "Vehicle" then
    cfg.vehicleZLift = _sliderFloatValue("Spawn Z Lift##" .. title, cfg.vehicleZLift, 0.00, 4.00, "%.2f")
  end

  cfg.gridEnabled = _checkboxValue("Impact Grid##" .. tostring(title), cfg.gridEnabled)
  if cfg.gridEnabled then _drawImpactGridPlanner(title, cfg, _getPlayer()) end
end

local function _activeConfig(player)
  local weaponKey = _getActiveWeaponKey(player)
  if weaponKey ~= nil then
    local override = Shooter.state.perWeapon[weaponKey]
    if type(override) == "table" and override.enabled == true then
      return override, weaponKey, "Per-Weapon"
    end
  end
  local g = Shooter.state.global
  if g and g.enabled == true then return g, weaponKey, "Global" end
  return nil, weaponKey, nil
end

local function _impactPointsForConfig(cfg, player, aim)
  cfg = _normalizeConfig(cfg)
  if not cfg.gridEnabled then return { Vector4.new(aim.x, aim.y, aim.z, 1) } end
  local points = {}
  local activeCount = 0
  for key, mark in pairs(cfg.gridMarks or {}) do
    if mark == true or (type(mark) == "table" and mark.active == true) then
      local gx, gy = key:match("^(%-?%d+):(%-?%d+)$")
      gx, gy = tonumber(gx), tonumber(gy)
      if gx and gy then
        local pt = _impactGridWorldPosition(cfg, player, aim, gx, gy)
        if pt ~= nil then
          points[#points + 1] = pt
          activeCount = activeCount + 1
        end
      end
    end
  end
  if activeCount == 0 then
    points[#points + 1] = Vector4.new(aim.x, aim.y, aim.z, 1)
  end
  return points
end

local function _fireOneAt(cfg, player, aim)
  cfg = _normalizeConfig(cfg)
  if _trim(cfg.assetId) == "" then return false, "No asset ID selected" end
  local p = player or _getPlayer()
  if not p then return false, "Player unavailable" end
  if aim == nil then return false, "No target point" end
  local ppos = _pcall(function() return p:GetWorldPosition() end)
  local dir = (ppos and aim) and _vecNormalize(Vector4.new((aim.x - ppos.x), (aim.y - ppos.y), (aim.z - ppos.z), 0)) or Vector4.new(0, 1, 0, 0)

  if cfg.type == "FX" then
    local ok, resolved = _spawnFXAt(cfg.assetId, aim, p)
    return ok, ok and ("FX fired: " .. tostring(resolved or cfg.assetId)) or ("FX failed: " .. tostring(resolved or cfg.assetId))
  elseif cfg.type == "Vehicle" then
    local pos = Vector4.new(aim.x, aim.y, aim.z + (cfg.vehicleZLift or 0.10), 1)
    local eid, err = _trySpawnVehicleAt(cfg.assetId, pos)
    if eid ~= nil and (cfg.vehicleDespawn or 0) > 0 then _queueDespawn(eid, cfg.vehicleDespawn) end
    return eid ~= nil, eid and ("Vehicle fired: " .. tostring(cfg.assetId)) or tostring(err or "Vehicle spawn failed")
  elseif cfg.type == "NPC" then
    local pos = Vector4.new(aim.x, aim.y, aim.z + (cfg.npcImpactZLift or 0.05), 1)
    local eid, err = _trySpawnNPCAt(cfg.assetId, pos)
    if eid ~= nil then
      if (cfg.npcSteps or 0) > 0 then _queueLaunch(eid, dir, cfg.npcSteps, cfg.npcStepDist, cfg.npcAsCompanion) end
      if (cfg.npcDespawn or 0) > 0 then _queueDespawn(eid, cfg.npcDespawn) end
      return true, "NPC fired: " .. tostring(cfg.assetId)
    end
    return false, tostring(err or "NPC spawn failed")
  elseif cfg.type == "Prop" then
    local pos = Vector4.new(aim.x, aim.y, aim.z + (cfg.propImpactZLift or 0.05), 1)
    local eid, err = _trySpawnPropAt(cfg.assetId, pos)
    if eid ~= nil then
      if (cfg.propSteps or 0) > 0 then _queueLaunch(eid, dir, cfg.propSteps, cfg.propStepDist, false) end
      if (cfg.propDespawn or 0) > 0 then _queueDespawn(eid, cfg.propDespawn) end
      return true, "Prop fired: " .. tostring(cfg.assetId)
    end
    return false, tostring(err or "Prop spawn failed")
  elseif cfg.type == "Attack" then
    if not SpawnTools or type(SpawnTools.SpawnRecordAtPoint) ~= "function" then return false, "Spawn tools unavailable" end
    local ok, itemOrErr = SpawnTools.SpawnRecordAtPoint(cfg.assetId, "Attack", Vector4.new(aim.x, aim.y, aim.z, 1), 0)
    if ok then return true, "Attack fired: " .. tostring(cfg.assetId) end
    return false, tostring(itemOrErr or "Attack spawn failed")
  elseif cfg.type == "Entity" then
    local eid, err = _trySpawnEntityTemplateAt(cfg.assetId, Vector4.new(aim.x, aim.y, aim.z, 1))
    if eid ~= nil then return true, ".ent fired: " .. tostring(cfg.assetId) end
    return false, tostring(err or ".ent spawn failed")
  end
  return false, "Unknown shooter type"
end

local function _fireWithConfig(cfg, player, aimPos)
  cfg = _normalizeConfig(cfg)
  if _trim(cfg.assetId) == "" then return false, "No asset ID selected" end
  local p = player or _getPlayer()
  if not p then return false, "Player unavailable" end
  local aim = aimPos or _getLookAtPosition(p)
  if aim == nil then return false, "No look-at position" end
  local points = _impactPointsForConfig(cfg, p, aim)
  local successCount, failCount, lastMsg = 0, 0, nil
  for i = 1, #points do
    local ok, msg = _fireOneAt(cfg, p, points[i])
    lastMsg = msg
    if ok then successCount = successCount + 1 else failCount = failCount + 1 end
  end
  if successCount > 0 then
    return true, string.format("%s at %d point(s)%s", tostring(cfg.type), successCount, cfg.gridEnabled and (" using impact grid") or "")
  end
  return false, tostring(lastMsg or "Shooter fire failed")
end

function Shooter.FireNowCurrentConfig()
  local p = _getPlayer()
  local cfg = nil
  local activeKey = _getActiveWeaponKey(p)
  if activeKey and Shooter.state.perWeapon[activeKey] and Shooter.state.perWeapon[activeKey].enabled == true then
    cfg = Shooter.state.perWeapon[activeKey]
  else
    cfg = Shooter.state.global
  end
  if cfg == nil then return false, "No shooter config" end
  local ok, msg = _fireWithConfig(cfg, p, nil)
  _setStatus(msg)
  return ok, msg
end

function Shooter.OnUpdate(delta)
  _buildDB()
  _processPending(delta)

  local p = _getPlayer()
  if not p then
    Shooter.state.runtime.activeWeaponKey = nil
    Shooter.state.runtime.lastMagAmmo = nil
    return
  end

  local cfg, weaponKey = _activeConfig(p)
  if cfg == nil then
    Shooter.state.runtime.activeWeaponKey = weaponKey
    Shooter.state.runtime.lastMagAmmo = nil
    return
  end

  local w = _getActiveWeapon(p)
  if not w then
    Shooter.state.runtime.activeWeaponKey = weaponKey
    Shooter.state.runtime.lastMagAmmo = nil
    return
  end

  local aim = _getLookAtPosition(p)
  Shooter.state.runtime.lastAimPos = aim

  if Shooter.state.runtime.activeWeaponKey ~= weaponKey then
    Shooter.state.runtime.activeWeaponKey = weaponKey
    Shooter.state.runtime.lastMagAmmo = nil
  end

  local magAmmo = _getMagAmmo(w, p)
  if type(magAmmo) ~= "number" then
    Shooter.state.runtime.lastMagAmmo = nil
    return
  end
  if type(Shooter.state.runtime.lastMagAmmo) ~= "number" then
    Shooter.state.runtime.lastMagAmmo = magAmmo
    return
  end

  local decreased = (magAmmo < Shooter.state.runtime.lastMagAmmo)
  Shooter.state.runtime.lastMagAmmo = magAmmo
  if not decreased then return end

  local cd = tonumber(cfg.cooldown or 0.25) or 0.25
  local now = os.clock()
  if (now - (Shooter.state.runtime.lastFireAt or 0.0)) < cd then return end
  Shooter.state.runtime.lastFireAt = now

  local ok, msg = _fireWithConfig(cfg, p, aim)
  _setStatus((ok and "Fired | " or "Failed | ") .. tostring(msg or ""))
end

local function _drawSavedOverrides()
  local keys = {}
  for k, v in pairs(Shooter.state.perWeapon or {}) do
    if type(v) == "table" then keys[#keys + 1] = k end
  end
  table.sort(keys)
  ImGui.Text("Saved Per-Weapon Overrides: " .. tostring(#keys))
  if ImGui.BeginChild("saved_weapon_overrides", -1, 120, true) then
    for i = 1, #keys do
      local key = keys[i]
      local cfg = Shooter.state.perWeapon[key]
      local label = key .. " | " .. tostring((cfg and cfg.type) or "-") .. " | " .. tostring((cfg and cfg.enabled) and "ON" or "OFF")
      local selected = (Shooter.state.ui.savedOverrideSelected == key)
      if ImGui.Selectable(label .. "##saved_override_" .. tostring(i), selected) then
        Shooter.state.ui.savedOverrideSelected = key
      end
    end
    ImGui.EndChild()
  end
  local sel = Shooter.state.ui.savedOverrideSelected
  if sel and Shooter.state.perWeapon[sel] then
    if ImGui.SmallButton("Delete Selected Override") then
      Shooter.state.perWeapon[sel] = nil
      Shooter.state.ui.savedOverrideSelected = nil
      _setStatus("Deleted override: " .. tostring(sel))
    end
  end
end

function Shooter.DrawTab(_)
  _buildDB()
  local p = _getPlayer()
  local activeWeapon = _getActiveWeaponKey(p) or "-"
  ImGui.Text("Shooter")
  ImGui.Separator()
  ImGui.TextWrapped("Global applies to all guns that can report magazine ammo. Per-weapon override takes priority for the currently equipped weapon.")
  ImGui.Text("Active Weapon: " .. tostring(activeWeapon))
  ImGui.Text("Last Status: " .. tostring(Shooter.state.ui.status or "-"))

  if ImGui.CollapsingHeader("Global Shooter", ImGuiTreeNodeFlags.DefaultOpen) then
    _drawConfigEditor("Global", Shooter.state.global, true)
    if ImGui.SmallButton("Test Fire Global") then
      local ok, msg = _fireWithConfig(Shooter.state.global, p, nil)
      _setStatus((ok and "Global test OK | " or "Global test failed | ") .. tostring(msg or ""))
    end
  end

  if ImGui.CollapsingHeader("Per-Weapon Override", ImGuiTreeNodeFlags.DefaultOpen) then
    if activeWeapon == "-" then
      ImGui.TextWrapped("Equip a ranged weapon to edit its override.")
    else
      local cfg = Shooter.state.perWeapon[activeWeapon]
      if type(cfg) ~= "table" then
        cfg = _defaultConfig()
        Shooter.state.perWeapon[activeWeapon] = cfg
      end
      ImGui.TextWrapped("Editing override for: " .. tostring(activeWeapon))
      if ImGui.SmallButton("Copy Global Into Active Override") then
        _cloneGlobalInto(cfg)
        _setStatus("Copied global shooter settings into active weapon override")
      end
      ImGui.SameLine()
      if ImGui.SmallButton("Remove Active Override") then
        Shooter.state.perWeapon[activeWeapon] = nil
        _setStatus("Removed override for " .. tostring(activeWeapon))
      else
        _drawConfigEditor("PerWeapon", cfg, true)
        if ImGui.SmallButton("Test Fire Active Override") then
          local ok, msg = _fireWithConfig(cfg, p, nil)
          _setStatus((ok and "Override test OK | " or "Override test failed | ") .. tostring(msg or ""))
        end
      end
    end
    _drawSavedOverrides()
  end

  _drawProfileManager(activeWeapon)

  ImGui.Separator()
  ImGui.TextWrapped("Runtime priority: active weapon override if enabled -> otherwise global shooter if enabled -> otherwise nothing fires.")
end



local function _findNamedShooterProfile(name)
  if type(name) ~= "string" or name == "" then return nil end
  return AssetRegistry.FindByTypeAndName and AssetRegistry.FindByTypeAndName("shooter_profile", name) or nil
end

local function _normalizeSavedProfileData(data)
  if type(data) ~= "table" then return nil end
  local out = _normalizeConfig(_cloneTable(data))
  out.gridMarks = _cloneTable(out.gridMarks or {})
  return out
end

function Shooter.GetCurrentConfigData(source)
  local p = _getPlayer()
  local activeWeapon = _getActiveWeaponKey(p)
  local src = tostring(source or "global")
  local cfg = nil
  if src == "active_override" then
    if activeWeapon and type(Shooter.state.perWeapon[activeWeapon]) == "table" then
      cfg = Shooter.state.perWeapon[activeWeapon]
    else
      return nil
    end
  else
    cfg = Shooter.state.global
  end
  if type(cfg) ~= "table" then return nil end
  return _normalizeSavedProfileData(cfg)
end

function Shooter.SaveConfigAsProfile(name, source)
  local trimmed = _trim(name)
  if trimmed == "" then return nil, "Enter a profile name first." end
  local cfg = Shooter.GetCurrentConfigData(source)
  if type(cfg) ~= "table" then return nil, "No shooter config to save." end
  local asset = {
    type = "shooter_profile",
    name = trimmed,
    data = {
      source = tostring(source or "global"),
      config = cfg,
    }
  }
  return (AssetRegistry.UpsertNew and AssetRegistry.UpsertNew(asset, trimmed)) or AssetRegistry.Upsert(asset)
end

function Shooter.ApplyProfileAsset(asset, targetMode, forceEnabled)
  if type(asset) ~= "table" or tostring(asset.type or "") ~= "shooter_profile" then
    return false, "Missing shooter profile"
  end
  local cfg = _normalizeSavedProfileData(((asset or {}).data or {}).config or {})
  if type(cfg) ~= "table" then return false, "Invalid shooter profile" end
  if forceEnabled ~= false then cfg.enabled = true end
  local target = tostring(targetMode or "global")
  local player = _getPlayer()
  local activeWeapon = _getActiveWeaponKey(player)
  if target == "active_override" then
    if not activeWeapon or activeWeapon == "" then return false, "Equip a weapon first" end
    Shooter.state.perWeapon[activeWeapon] = cfg
    _setStatus("Applied shooter profile to active weapon override: " .. tostring(asset.name or asset.id))
    return true, "Applied to active weapon override"
  end
  Shooter.state.global = cfg
  _setStatus("Applied shooter profile to global shooter: " .. tostring(asset.name or asset.id))
  return true, "Applied to global shooter"
end

local function _drawProfileManager(activeWeapon)
  local ui = Shooter.state.ui
  ImGui.Separator()
  ImGui.Text("Saved Shooter Profiles")
  ui.profileName = _inputTextValue("Profile Name##shooter_profile_name", ui.profileName or "", 128)
  if ImGui.Button("Save Global As Profile") then
    local _, err = Shooter.SaveConfigAsProfile(ui.profileName, "global")
    if err then _setStatus(err) else _setStatus("Saved global shooter profile") end
  end
  ImGui.SameLine()
  if ImGui.Button("Save Active Override As Profile") then
    local _, err = Shooter.SaveConfigAsProfile(ui.profileName, "active_override")
    if err then _setStatus(err) else _setStatus("Saved active weapon shooter profile") end
  end

  local profiles = AssetRegistry.List("shooter_profile")
  ImGui.TextDisabled("Automation can apply these directly. Build once here, then use the saved profile in Macros.")
  if #profiles == 0 then
    ImGui.TextDisabled("No shooter profiles saved yet.")
    return
  end

  local loadLabel = (tostring(ui.profileLoadTarget or "global") == "active_override") and "Active Weapon Override" or "Global Shooter"
  loadLabel = _comboValue("Load Target##shooter_profile_target", loadLabel, { "Global Shooter", "Active Weapon Override" })
  ui.profileLoadTarget = (loadLabel == "Active Weapon Override") and "active_override" or "global"

  if ImGui.BeginChild("shooter_profiles_list", -1, 150, true) then
    for i = 1, #profiles do
      local asset = profiles[i]
      local cfg = _normalizeSavedProfileData((((asset or {}).data or {}).config) or {}) or {}
      local tag = tostring(cfg.type or "-") .. " | " .. tostring(cfg.enabled and "ON" or "OFF")
      local label = tostring(asset.name or asset.id) .. " | " .. tag
      local selected = (ui.selectedProfileId == asset.id)
      if ImGui.Selectable(label .. "##shooter_profile_" .. tostring(i), selected) then
        ui.selectedProfileId = asset.id
      end
      if ImGui.IsItemHovered() then
        ImGui.BeginTooltip()
        ImGui.TextWrapped(tostring(cfg.assetId or ""))
        ImGui.EndTooltip()
      end
    end
    ImGui.EndChild()
  end

  local selected = ui.selectedProfileId and AssetRegistry.Get(ui.selectedProfileId) or nil
  if selected then
    if ImGui.SmallButton("Load Selected Profile") then
      local ok, msg = Shooter.ApplyProfileAsset(selected, ui.profileLoadTarget, false)
      _setStatus(msg or (ok and "Profile loaded" or "Profile load failed"))
    end
    ImGui.SameLine()
    if ImGui.SmallButton("Test Fire Selected") then
      local cfg = _normalizeSavedProfileData((((selected or {}).data or {}).config) or {})
      local ok, msg = _fireWithConfig(cfg, _getPlayer(), nil)
      _setStatus((ok and "Profile test OK | " or "Profile test failed | ") .. tostring(msg or ""))
    end
    ImGui.SameLine()
    if ImGui.SmallButton("Delete Selected Profile") then
      AssetRegistry.Delete(selected.id)
      ui.selectedProfileId = nil
      _setStatus("Deleted shooter profile")
    end
  end
end

return Shooter
