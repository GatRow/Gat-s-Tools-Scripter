
local Persistence = Persistence or {}

Persistence.state = Persistence.state or {
  lastError = nil,
  lastSaveAt = nil,
  lastLoadAt = nil,
  resolvedUserDir = nil,
  lastSavePath = nil,
  lastLoadPath = nil,
}

local _serializeLua
local _serializeJson

local function _quote(s)
  return string.format('%q', tostring(s or ''))
end

local function _normalize(path)
  return tostring(path or ''):gsub('\\', '/')
end

local function _dirname(path)
  local p = _normalize(path)
  return p:match('^(.*)/[^/]+$') or p
end

local function _moduleFile(stackLevel)
  local info = debug and debug.getinfo and debug.getinfo(stackLevel or 1, 'S') or nil
  local src = info and info.source or ''
  src = tostring(src or '')
  if string.sub(src, 1, 1) == '@' then src = string.sub(src, 2) end
  return _normalize(src)
end

local function _extractKnownModRoot(path)
  path = _normalize(path)
  if path == '' then return nil end
  local marker = "Gat's Tools & Scripter"
  local idx = path:lower():find(marker:lower(), 1, true)
  if idx then
    return _normalize(path:sub(1, idx + #marker - 1))
  end
  local alt = path:match('^(.*)/GTS/[^/]+%.lua$')
  if alt and alt ~= '' then return _normalize(alt) end
  return nil
end

local function _detectModRoot()
  local dir = nil

  pcall(function()
    if GetMod ~= nil then
      local m = GetMod()
      if m ~= nil and m.GetDirectory ~= nil then
        dir = m:GetDirectory()
      elseif m ~= nil and m.GetPath ~= nil then
        dir = m:GetPath()
      end
    end
  end)

  dir = _extractKnownModRoot(dir) or _normalize(dir)
  if dir ~= '' then return dir end

  for level = 6, 1, -1 do
    local file = _moduleFile(level)
    local root = _extractKnownModRoot(file)
    if root and root ~= '' then return root end
    if file ~= '' then
      local gtsDir = _dirname(file)
      local modRoot = _dirname(gtsDir)
      if modRoot and modRoot ~= '' and modRoot ~= '.' then return _normalize(modRoot) end
    end
  end

  return _normalize("./mods/Gat's Tools & Scripter")
end

local function _candidateUserDirs()
  local out, seen = {}, {}
  local function add(path)
    path = _normalize(path)
    if path ~= '' and not seen[path] then
      seen[path] = true
      out[#out + 1] = path
    end
  end
  local modRoot = _detectModRoot()
  add(modRoot .. '/User')
  add("./mods/Gat's Tools & Scripter/User")
  add("mods/Gat's Tools & Scripter/User")
  add('./User')
  add("./bin/x64/plugins/cyber_engine_tweaks/mods/Gat's Tools & Scripter/User")
  add("bin/x64/plugins/cyber_engine_tweaks/mods/Gat's Tools & Scripter/User")
  add("./plugins/cyber_engine_tweaks/mods/Gat's Tools & Scripter/User")
  return out
end

local function _probeFile(path)
  local fh = io and io.open and io.open(path, 'r') or nil
  if fh then fh:close(); return true end
  return false
end

local function _ensureDir(path)
  local dir = _normalize(path)
  if dir == '' or not io or not io.open then return false end

  local probe = io.open(dir .. '/.probe', 'w')
  if probe then
    probe:close()
    if os and os.remove then os.remove(dir .. '/.probe') end
    return true
  end

  local acc = ''
  local first = true
  for part in string.gmatch(dir, '[^/]+') do
    if first and part:match('^[A-Za-z]:$') then
      acc = part
      first = false
    else
      if acc == '' then acc = part else acc = acc .. '/' .. part end
      local test = io.open(acc .. '/.probe', 'w')
      if test then
        test:close()
        if os and os.remove then os.remove(acc .. '/.probe') end
      elseif os and os.execute then
        os.execute('mkdir "' .. acc:gsub('/', '\\\\') .. '" >nul 2>nul')
        os.execute('mkdir -p "' .. acc .. '" >/dev/null 2>/dev/null')
      end
      first = false
    end
  end

  probe = io.open(dir .. '/.probe', 'w')
  if probe then
    probe:close()
    if os and os.remove then os.remove(dir .. '/.probe') end
    return true
  end
  return false
end

local function _resolveWritableUserDir()
  if Persistence.state.resolvedUserDir and _ensureDir(Persistence.state.resolvedUserDir) then
    return Persistence.state.resolvedUserDir
  end
  local dirs = _candidateUserDirs()
  for i = 1, #dirs do
    local dir = dirs[i]
    if _ensureDir(dir) then
      Persistence.state.resolvedUserDir = dir
      return dir
    end
  end
  Persistence.state.resolvedUserDir = nil
  return nil
end

local function _isSerializableType(t)
  return (t == 'nil' or t == 'number' or t == 'string' or t == 'boolean' or t == 'table')
end

local function _sanitizeForSave(v, seen, depth)
  seen = seen or {}
  depth = depth or 0
  local tv = type(v)
  if not _isSerializableType(tv) then return nil end
  if tv ~= 'table' then return v end
  if seen[v] ~= nil then return nil end
  if depth > 32 then return nil end
  seen[v] = true
  local out = {}
  for k, vv in pairs(v) do
    local tk = type(k)
    if tk == 'string' or tk == 'number' then
      local sv = _sanitizeForSave(vv, seen, depth + 1)
      if sv ~= nil then out[k] = sv end
    end
  end
  seen[v] = nil
  return out
end

local function _isArray(t)
  if type(t) ~= 'table' then return false end
  local n = 0
  for k, _ in pairs(t) do
    if type(k) ~= 'number' or k < 1 or math.floor(k) ~= k then return false end
    if k > n then n = k end
  end
  return true, n
end

_serializeLua = function(value, indent, seen)
  indent = indent or 0
  seen = seen or {}
  local t = type(value)
  if t == 'nil' then return 'nil' end
  if t == 'number' then return tostring(value) end
  if t == 'boolean' then return value and 'true' or 'false' end
  if t == 'string' then return _quote(value) end
  if t ~= 'table' then return 'nil' end
  if seen[value] then return 'nil' end
  seen[value] = true
  local pad = string.rep('  ', indent)
  local child = string.rep('  ', indent + 1)
  local arr, n = _isArray(value)
  local out = {'{'}
  if arr then
    for i = 1, n do out[#out + 1] = child .. _serializeLua(value[i], indent + 1, seen) .. ',' end
  else
    local keys = {}
    for k in pairs(value) do keys[#keys + 1] = k end
    table.sort(keys, function(a, b)
      local ta, tb = type(a), type(b)
      if ta ~= tb then return tostring(ta) < tostring(tb) end
      if ta == 'number' then return a < b end
      return tostring(a) < tostring(b)
    end)
    for _, k in ipairs(keys) do
      local keyText
      if type(k) == 'string' and k:match('^[_%a][_%w]*$') then
        keyText = k
      else
        keyText = '[' .. _serializeLua(k, indent + 1, seen) .. ']'
      end
      out[#out + 1] = child .. keyText .. ' = ' .. _serializeLua(value[k], indent + 1, seen) .. ','
    end
  end
  out[#out + 1] = pad .. '}'
  seen[value] = nil
  return table.concat(out, '\n')
end

local function _jsonString(s)
  s = tostring(s or '')
  s = s:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', '\\n'):gsub('\r', '\\r'):gsub('\t', '\\t')
  return '"' .. s .. '"'
end

_serializeJson = function(value, seen)
  seen = seen or {}
  local t = type(value)
  if t == 'nil' then return 'null' end
  if t == 'number' then return tostring(value) end
  if t == 'boolean' then return value and 'true' or 'false' end
  if t == 'string' then return _jsonString(value) end
  if t ~= 'table' then return 'null' end
  if seen[value] then return 'null' end
  seen[value] = true
  local arr, n = _isArray(value)
  local out = {}
  if arr then
    for i = 1, n do out[#out + 1] = _serializeJson(value[i], seen) end
    seen[value] = nil
    return '[' .. table.concat(out, ',') .. ']'
  end
  local keys = {}
  for k in pairs(value) do keys[#keys + 1] = k end
  table.sort(keys, function(a, b)
    local ta, tb = type(a), type(b)
    if ta ~= tb then return tostring(ta) < tostring(tb) end
    if ta == 'number' then return a < b end
    return tostring(a) < tostring(b)
  end)
  for _, k in ipairs(keys) do
    out[#out + 1] = _jsonString(k) .. ':' .. _serializeJson(value[k], seen)
  end
  seen[value] = nil
  return '{' .. table.concat(out, ',') .. '}'
end

local function _platformIsWindows()
  local cfg = package and package.config or nil
  return type(cfg) == 'string' and cfg:sub(1, 1) == '\\'
end

local function _safeFileToken(text)
  local s = tostring(text or '')
  s = s:gsub('[\\/:*?"<>|]', '_')
  s = s:gsub('%s+', '_')
  s = s:gsub('[^%w%._%-]', '_')
  s = s:gsub('_+', '_')
  s = s:gsub('^_+', ''):gsub('_+$', '')
  if s == '' then s = 'asset' end
  return s
end

local function _manifestStem(baseDir)
  return _normalize(baseDir) .. '/assets'
end

local function _assetRoot(baseDir)
  return _normalize(baseDir) .. '/assets'
end

local function _assetFolderName(assetType)
  local map = {
    stat_preset = 'stat_presets',
    observer_preset = 'observer_presets',
    spawn_set = 'spawn_sets',
    spawn_grid = 'spawn_grids',
    inventory_bundle = 'inventory_bundles',
    shooter_profile = 'shooter_profiles',
    rule = 'rules',
    macro = 'macros',
    custom_code = 'custom_codes',
    teleport_preset = 'teleport_presets',
    launcher = 'launchers',
    animation_sequence = 'animation_sequences',
    scenario = 'scenarios',
  }
  local key = tostring(assetType or 'asset')
  return map[key] or (_safeFileToken(key) .. 's')
end

local function _typePrefix(assetType)
  local map = {
    stat_preset = 'preset',
    observer_preset = 'observer',
    spawn_set = 'spawn',
    spawn_grid = 'grid',
    inventory_bundle = 'bundle',
    shooter_profile = 'shooter',
    rule = 'rule',
    macro = 'macro',
    custom_code = 'code',
    teleport_preset = 'tele',
    launcher = 'launch',
    animation_sequence = 'animseq',
    scenario = 'scenario',
  }
  return map[tostring(assetType or '')] or 'asset'
end

local function _assetStem(baseDir, asset)
  local folder = _assetFolderName(asset and asset.type or 'asset')
  local id = _safeFileToken(asset and asset.id or 'asset')
  return _assetRoot(baseDir) .. '/' .. folder .. '/' .. id
end

local function _relativeAssetLuaPath(asset)
  return 'assets/' .. _assetFolderName(asset and asset.type or 'asset') .. '/' .. _safeFileToken(asset and asset.id or 'asset') .. '.lua'
end

local function _writePairFromStem(stem, payload, header)
  local safePayload = _sanitizeForSave(payload) or {}
  stem = _normalize(stem)
  local dir = _dirname(stem)
  if not _ensureDir(dir) then return false, 'Could not create folder: ' .. tostring(dir) end

  local luaPath = stem .. '.lua'
  local jsonPath = stem .. '.json'

  local fh, err = io.open(luaPath, 'w+')
  if not fh then return false, tostring(err or ('Failed to open ' .. tostring(luaPath) .. ' for write')) end
  if header and header ~= '' then fh:write('-- ' .. tostring(header) .. '\n') end
  if os and os.date then fh:write('-- ' .. os.date('%Y-%m-%d %H:%M:%S') .. '\n\n') end
  fh:write('return ')
  fh:write(_serializeLua(safePayload, 0, {}))
  fh:write('\n')
  fh:close()

  local jh = io.open(jsonPath, 'w+')
  if jh then
    jh:write(_serializeJson(safePayload, {}))
    jh:write('\n')
    jh:close()
  end
  return true, luaPath
end

local function _readLuaTable(path)
  local loader, err = loadfile(path)
  if not loader then return nil, tostring(err or ('Failed to load ' .. tostring(path))) end
  local ok, data = pcall(loader)
  if not ok or type(data) ~= 'table' then return nil, tostring(data or ('File did not return a table: ' .. tostring(path))) end
  return data, nil
end

local function _deletePair(stem)
  stem = _normalize(stem)
  local ok = false
  if os and os.remove then
    if os.remove(stem .. '.lua') then ok = true end
    if os.remove(stem .. '.json') then ok = true end
  end
  return ok
end

local function _assetSummary(asset)
  return {
    id = tostring(asset and asset.id or ''),
    type = tostring(asset and asset.type or 'asset'),
    name = tostring(asset and asset.name or ''),
    file = _relativeAssetLuaPath(asset),
    createdAtText = asset and asset.createdAtText or nil,
    updatedAtText = asset and asset.updatedAtText or nil,
  }
end

local function _manifestPayload(state)
  local reg = type(state) == 'table' and state or {}
  local payload = {
    version = 3,
    mode = 'per_asset_manifest',
    savedAt = (os and os.date and os.date('%Y-%m-%d %H:%M:%S')) or nil,
    nextId = tonumber(reg.nextId or 1) or 1,
    selectedId = reg.selectedId,
    order = {},
    items = {},
  }
  local order = type(reg.order) == 'table' and reg.order or {}
  local items = type(reg.items) == 'table' and reg.items or {}
  for i = 1, #order do
    local id = order[i]
    local item = items[id]
    if type(id) == 'string' and type(item) == 'table' then
      payload.order[#payload.order + 1] = id
      payload.items[id] = _assetSummary(item)
    end
  end
  return payload
end

local function _writeManifest(baseDir, state)
  return _writePairFromStem(_manifestStem(baseDir), _manifestPayload(state), "Gat's Tools & Scripter asset index (auto)")
end

local function _loadManifest(baseDir)
  local path = _manifestStem(baseDir) .. '.lua'
  if not _probeFile(path) then return nil end
  local data, err = _readLuaTable(path)
  if not data then return nil, err end
  if type(data.registry) == 'table' then
    return { mode = 'legacy_registry', registry = data.registry, savedAt = data.savedAt, version = tonumber(data.version or 2) or 2 }
  end
  if type(data.items) == 'table' or tostring(data.mode or '') == 'per_asset_manifest' then
    data.mode = 'per_asset_manifest'
    data.order = type(data.order) == 'table' and data.order or {}
    data.items = type(data.items) == 'table' and data.items or {}
    return data, nil
  end
  return nil, 'Unsupported assets.lua format'
end

local function _listFilesRecursive(dir, suffix)
  dir = _normalize(dir)
  local out, seen = {}, {}
  local function accept(path)
    path = _normalize(path)
    if path == '' then return end
    if suffix and suffix ~= '' and path:sub(-#suffix) ~= suffix then return end
    if not seen[path] then
      seen[path] = true
      out[#out + 1] = path
    end
  end

  if not _ensureDir(dir) then return out end

  local command = nil
  if _platformIsWindows() then
    command = 'dir /b /s "' .. dir:gsub('/', '\\\\') .. '" 2>nul'
  else
    command = 'find "' .. dir .. '" -type f 2>/dev/null'
  end

  if io and io.popen and command then
    local pipe = io.popen(command)
    if pipe then
      for line in pipe:lines() do accept(line) end
      pipe:close()
    end
  end

  if #out == 0 and os and os.execute and io and io.open then
    local tempStem = dir .. '/.gts_scan_' .. tostring(math.random(100000, 999999))
    local tempFile = tempStem .. '.txt'
    local cmd
    if _platformIsWindows() then
      cmd = 'dir /b /s "' .. dir:gsub('/', '\\\\') .. '" > "' .. tempFile:gsub('/', '\\\\') .. '" 2>nul'
    else
      cmd = 'find "' .. dir .. '" -type f > "' .. tempFile .. '" 2>/dev/null'
    end
    os.execute(cmd)
    local fh = io.open(tempFile, 'r')
    if fh then
      for line in fh:lines() do accept(line) end
      fh:close()
      if os and os.remove then os.remove(tempFile) end
    end
  end

  table.sort(out)
  return out
end

local function _loadAssetFromPath(path)
  local data, err = _readLuaTable(path)
  if not data then return nil, err end
  local asset = data.asset
  if type(asset) ~= 'table' and type(data.id) == 'string' and type(data.type) == 'string' then
    asset = data
  end
  if type(asset) ~= 'table' then return nil, 'Not an asset file: ' .. tostring(path) end
  asset = _sanitizeForSave(asset) or {}
  asset.id = tostring(asset.id or '')
  asset.type = tostring(asset.type or 'asset')
  return asset, nil
end

local function _cloneSimple(value, seen)
  if type(value) ~= 'table' then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do
    out[_cloneSimple(k, seen)] = _cloneSimple(v, seen)
  end
  return out
end

local function _stateItems(registryState)
  return type(registryState) == 'table' and type(registryState.items) == 'table' and registryState.items or {}
end

local function _resolveAssetFromState(assetId, registryState)
  local items = _stateItems(registryState)
  local key = tostring(assetId or '')
  if key == '' then return nil end
  local asset = items[key]
  return type(asset) == 'table' and asset or nil
end

local function _embedAssetDependencies(asset, registryState, seen)
  if type(asset) ~= 'table' then return nil end
  seen = seen or {}
  if seen[asset] then return _sanitizeForSave(asset) or {} end
  seen[asset] = true

  local out = _cloneSimple(asset) or {}
  out.type = tostring(out.type or 'asset')

  local function embedAction(action)
    if type(action) ~= 'table' then return action end
    local a = _cloneSimple(action) or {}
    local ref = tostring(a.ref or '')
    if ref ~= '' and type(a.embeddedAsset) ~= 'table' then
      local dep = _resolveAssetFromState(ref, registryState)
      if dep then a.embeddedAsset = _embedAssetDependencies(dep, registryState, seen) end
    elseif type(a.embeddedAsset) == 'table' then
      a.embeddedAsset = _embedAssetDependencies(a.embeddedAsset, registryState, seen)
    end

    local sourceMode = tostring(a.sourceMode or '')
    local seqRef = tostring(a.sequenceRef or '')
    if sourceMode == 'saved_sequence' and seqRef ~= '' and type(a.sequenceAsset) ~= 'table' then
      local dep = _resolveAssetFromState(seqRef, registryState)
      if dep then a.sequenceAsset = _embedAssetDependencies(dep, registryState, seen) end
    elseif type(a.sequenceAsset) == 'table' then
      a.sequenceAsset = _embedAssetDependencies(a.sequenceAsset, registryState, seen)
    end
    return a
  end

  local function embedActionList(list)
    if type(list) ~= 'table' then return list end
    local outList = {}
    for i = 1, #list do outList[i] = embedAction(list[i]) end
    return outList
  end

  local function embedGroups(groups)
    if type(groups) ~= 'table' then return groups end
    local outGroups = {}
    for i = 1, #groups do
      local g = _cloneSimple(groups[i]) or {}
      g.actions = embedActionList(g.actions)
      outGroups[i] = g
    end
    return outGroups
  end

  local function embedLauncherEntries(entries)
    if type(entries) ~= 'table' then return entries end
    local outEntries = {}
    for i = 1, #entries do
      local e = _cloneSimple(entries[i]) or {}
      local ref = tostring(e.ref or '')
      if ref ~= '' and type(e.embeddedAsset) ~= 'table' then
        local dep = _resolveAssetFromState(ref, registryState)
        if dep then e.embeddedAsset = _embedAssetDependencies(dep, registryState, seen) end
      elseif type(e.embeddedAsset) == 'table' then
        e.embeddedAsset = _embedAssetDependencies(e.embeddedAsset, registryState, seen)
      end
      outEntries[i] = e
    end
    return outEntries
  end

  local data = type(out.data) == 'table' and out.data or nil
  if out.type == 'rule' and data then
    data.actions = embedActionList(data.actions)
    data.falseActions = embedActionList(data.falseActions)
    data.actionGroups = embedGroups(data.actionGroups)
    data.falseActionGroups = embedGroups(data.falseActionGroups)
    if type(data.execution) == 'table' then
      data.execution = _cloneSimple(data.execution)
      data.execution.falseActions = embedActionList(data.execution.falseActions)
    end
    out.data = data
  elseif out.type == 'macro' and data then
    data.onActionGroups = embedGroups(data.onActionGroups)
    data.offActionGroups = embedGroups(data.offActionGroups)
    out.data = data
  elseif out.type == 'launcher' and data then
    data.entries = embedLauncherEntries(data.entries)
    out.data = data
  elseif out.type == 'animation_sequence' and data then
    out.data = _cloneSimple(data)
  end

  seen[asset] = nil
  return _sanitizeForSave(out) or {}
end

local function _allocateUniqueId(assetType, used)
  local prefix = _typePrefix(assetType)
  local maxNum = 0
  for id in pairs(used or {}) do
    local n = tostring(id or ''):match('_(%d+)$')
    n = tonumber(n)
    if n and n > maxNum then maxNum = n end
  end
  local nextNum = maxNum + 1
  local id = string.format('%s_%03d', tostring(prefix), nextNum)
  while used[id] do
    nextNum = nextNum + 1
    id = string.format('%s_%03d', tostring(prefix), nextNum)
  end
  return id
end

local function _collectAssetFiles(baseDir)
  return _listFilesRecursive(_assetRoot(baseDir), '.lua')
end

local function _buildStateFromFiles(baseDir, manifest)
  local st = {
    nextId = tonumber(manifest and manifest.nextId or 1) or 1,
    items = {},
    order = {},
    selectedId = manifest and manifest.selectedId or nil,
  }

  local byPath = {}
  local orderedPaths = {}
  local seenPaths = {}

  local function addPath(path, prioritized)
    path = _normalize(path)
    if path == '' or seenPaths[path] then return end
    local asset = _loadAssetFromPath(path)
    if type(asset) == 'table' then
      byPath[path] = asset
      orderedPaths[#orderedPaths + 1] = path
      seenPaths[path] = true
    elseif prioritized ~= true then
      -- ignore missing supplemental files
    end
  end

  if manifest and type(manifest.items) == 'table' and type(manifest.order) == 'table' then
    for i = 1, #manifest.order do
      local id = manifest.order[i]
      local meta = manifest.items[id]
      if type(meta) == 'table' and type(meta.file) == 'string' then
        addPath(baseDir .. '/' .. tostring(meta.file), true)
      end
    end
    for id, meta in pairs(manifest.items) do
      if type(id) == 'string' and type(meta) == 'table' and type(meta.file) == 'string' then
        addPath(baseDir .. '/' .. tostring(meta.file), false)
      end
    end
  end

  local files = _collectAssetFiles(baseDir)
  for i = 1, #files do
    addPath(files[i], false)
  end

  local used = {}
  local count = 0
  for i = 1, #orderedPaths do
    local path = orderedPaths[i]
    local item = byPath[path]
    if type(item) == 'table' then
      local id = tostring(item.id or '')
      if id == '' or used[id] then
        id = _allocateUniqueId(item.type, used)
        item.id = id
      end
      used[id] = true
      st.items[id] = item
      st.order[#st.order + 1] = id
      count = count + 1
    end
  end

  if st.selectedId ~= nil and st.items[st.selectedId] == nil then st.selectedId = st.order[1] end
  return st, count
end

local function _saveAssetToDir(baseDir, asset, registryState)
  if type(asset) ~= 'table' then return false, 'Missing asset' end
  local payload = {
    version = 3,
    kind = 'gts_asset',
    savedAt = (os and os.date and os.date('%Y-%m-%d %H:%M:%S')) or nil,
    asset = _embedAssetDependencies(asset, registryState) or (_sanitizeForSave(asset) or {}),
  }
  return _writePairFromStem(_assetStem(baseDir, asset), payload, "Gat's Tools & Scripter asset (auto)")
end

local function _deleteAssetFromDir(baseDir, asset)
  if type(asset) ~= 'table' then return false end
  local stem = _assetStem(baseDir, asset)
  local removed = _deletePair(stem)

  local manifest = _loadManifest(baseDir)
  if type(manifest) == 'table' and manifest.mode == 'per_asset_manifest' and type(manifest.items) == 'table' then
    local meta = manifest.items[asset.id]
    if type(meta) == 'table' and type(meta.file) == 'string' then
      local oldStem = _normalize(baseDir .. '/' .. tostring(meta.file))
      oldStem = oldStem:gsub('%.lua$', '')
      if oldStem ~= stem then
        if _deletePair(oldStem) then removed = true end
      end
    end
  end

  return removed
end

local function _orderedUserDirs()
  local dirs = _candidateUserDirs()
  local primary = _resolveWritableUserDir()
  local ordered, seen = {}, {}
  local function addDir(d)
    d = _normalize(d)
    if d ~= '' and not seen[d] then
      seen[d] = true
      ordered[#ordered + 1] = d
    end
  end
  addDir(primary)
  for i = 1, #dirs do addDir(dirs[i]) end
  return ordered
end

function Persistence.GetUserDir()
  return _resolveWritableUserDir() or _candidateUserDirs()[1]
end

function Persistence.UpsertAsset(asset, state)
  if type(asset) ~= 'table' then return false, 'Missing asset' end
  local dirs = _orderedUserDirs()
  local savedPath, lastErr = nil, nil
  for i = 1, #dirs do
    local dir = dirs[i]
    if _ensureDir(dir) then
      local manifest = _loadManifest(dir)
      if type(manifest) == 'table' and manifest.mode == 'per_asset_manifest' and type(manifest.items) == 'table' then
        local meta = manifest.items[asset.id]
        if type(meta) == 'table' and type(meta.file) == 'string' then
          local oldStem = _normalize(dir .. '/' .. tostring(meta.file)):gsub('%.lua$', '')
          local newStem = _assetStem(dir, asset)
          if oldStem ~= newStem then _deletePair(oldStem) end
        end
      end

      local ok, pathOrErr = _saveAssetToDir(dir, asset, state)
      if ok then
        local mok, mpathOrErr = _writeManifest(dir, state or { items = { [asset.id] = asset }, order = { asset.id }, nextId = 1, selectedId = asset.id })
        if mok and not savedPath then
          savedPath = pathOrErr
          Persistence.state.resolvedUserDir = dir
        elseif not mok then
          lastErr = mpathOrErr
        end
      else
        lastErr = pathOrErr
      end
    end
  end

  if not savedPath then
    Persistence.state.lastError = tostring(lastErr or 'Could not write asset to any User folder candidate')
    return false, Persistence.state.lastError
  end

  Persistence.state.lastSaveAt = (os and os.date and os.date('%Y-%m-%d %H:%M:%S')) or nil
  Persistence.state.lastSavePath = savedPath
  Persistence.state.lastError = nil
  return true, savedPath
end

function Persistence.DeleteAsset(asset, state)
  if type(asset) ~= 'table' or tostring(asset.id or '') == '' then return false, 'Missing asset' end
  local dirs = _orderedUserDirs()
  local removedAny = false
  local savedPath = nil
  for i = 1, #dirs do
    local dir = dirs[i]
    if _ensureDir(dir) then
      if _deleteAssetFromDir(dir, asset) then removedAny = true end
      local ok, pathOrErr = _writeManifest(dir, state or { items = {}, order = {}, nextId = 1, selectedId = nil })
      if ok and not savedPath then
        savedPath = pathOrErr
        Persistence.state.resolvedUserDir = dir
      elseif not ok then
        Persistence.state.lastError = pathOrErr
      end
    end
  end

  Persistence.state.lastSaveAt = (os and os.date and os.date('%Y-%m-%d %H:%M:%S')) or nil
  Persistence.state.lastSavePath = savedPath or (_manifestStem(_resolveWritableUserDir()) .. '.lua')
  if removedAny or state then
    Persistence.state.lastError = nil
    return true, Persistence.state.lastSavePath
  end
  return false, 'Asset files were not found on disk'
end

function Persistence.SaveAssetRegistryState(state)
  if type(state) ~= 'table' then return false, 'Missing registry state' end

  local dirs = _orderedUserDirs()
  local savedPath = nil
  local lastErr = nil

  for i = 1, #dirs do
    local dir = dirs[i]
    if _ensureDir(dir) then
      local manifest = _loadManifest(dir)
      local stale = {}
      if type(manifest) == 'table' and manifest.mode == 'per_asset_manifest' and type(manifest.items) == 'table' then
        for id, meta in pairs(manifest.items) do
          if type(id) == 'string' and (type(state.items) ~= 'table' or state.items[id] == nil) then
            stale[#stale + 1] = meta
          end
        end
      elseif type(manifest) == 'table' and manifest.mode == 'legacy_registry' and type(manifest.registry) == 'table' and type(manifest.registry.items) == 'table' then
        for id, item in pairs(manifest.registry.items) do
          if type(id) == 'string' and (type(state.items) ~= 'table' or state.items[id] == nil) and type(item) == 'table' then
            stale[#stale + 1] = _assetSummary(item)
          end
        end
      end

      for _, meta in ipairs(stale) do
        if type(meta) == 'table' and type(meta.file) == 'string' then
          local stem = _normalize(dir .. '/' .. tostring(meta.file)):gsub('%.lua$', '')
          _deletePair(stem)
        end
      end

      local order = type(state.order) == 'table' and state.order or {}
      local items = type(state.items) == 'table' and state.items or {}
      for j = 1, #order do
        local id = order[j]
        local item = items[id]
        if type(item) == 'table' then
          local ok, pathOrErr = _saveAssetToDir(dir, item, state)
          if ok and not savedPath then
            savedPath = pathOrErr
            Persistence.state.resolvedUserDir = dir
          elseif not ok then
            lastErr = pathOrErr
          end
        end
      end

      local mok, mpathOrErr = _writeManifest(dir, state)
      if mok and not savedPath then
        savedPath = mpathOrErr
        Persistence.state.resolvedUserDir = dir
      elseif not mok then
        lastErr = mpathOrErr
      end
    end
  end

  if not savedPath then
    local dirs = _orderedUserDirs()
    Persistence.state.lastError = tostring(lastErr or ('Could not write assets to any User folder candidate: ' .. table.concat(dirs, ' | ')))
    return false, Persistence.state.lastError
  end

  Persistence.state.lastSaveAt = (os and os.date and os.date('%Y-%m-%d %H:%M:%S')) or nil
  Persistence.state.lastSavePath = savedPath
  Persistence.state.lastError = nil
  return true, savedPath
end

function Persistence.LoadAssetRegistryState()
  local dirs = _orderedUserDirs()

  for i = 1, #dirs do
    local dir = dirs[i]
    local manifest = _loadManifest(dir)
    local st, count = _buildStateFromFiles(dir, manifest)
    if count > 0 then
      Persistence.state.lastLoadAt = (os and os.date and os.date('%Y-%m-%d %H:%M:%S')) or nil
      Persistence.state.lastLoadPath = _assetRoot(dir)
      Persistence.state.lastError = nil
      Persistence.state.resolvedUserDir = dir
      return st, nil
    end
    if type(manifest) == 'table' and manifest.mode == 'legacy_registry' and type(manifest.registry) == 'table' then
      Persistence.state.lastLoadAt = (os and os.date and os.date('%Y-%m-%d %H:%M:%S')) or nil
      Persistence.state.lastLoadPath = _manifestStem(dir) .. '.lua'
      Persistence.state.lastError = nil
      Persistence.state.resolvedUserDir = dir
      return manifest.registry, nil
    end
  end

  return nil, 'No saved assets on disk yet.'
end

return Persistence
