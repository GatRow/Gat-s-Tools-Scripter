-- GTS/main_ui.lua
-- Unified UI with top-level tabs and grouped subtabs
print("[GTS] GTS/main_ui.lua loaded")

local Utils = require("GTS/utils")

local function _clearLoaded(name)
  if type(package) == "table" and type(package.loaded) == "table" then
    package.loaded[name] = nil
  end
end

local function _safeRequire(name)
  _clearLoaded(name)
  local ok, mod = pcall(require, name)
  if ok then
    return mod, nil
  end
  print("[GTS] Failed to load module '" .. tostring(name) .. "': " .. tostring(mod))
  return nil, tostring(mod)
end

local function _loadSharedUIState()
  local defaults = {
    compact = false,
    colors = true,
    keepMenuOpenWhenOverlayClosed = false,
    keepMacroDebugOpenWhenOverlayClosed = false,
    poseSearchLimit = 240,
    lastPoseRig = "Player Man",
    playerSubtab = "Stats Editor",
  }

  local ok, mod = pcall(require, "GTS/main_ui_settings")
  if not ok or type(mod) ~= "table" then
    if not ok then
      print("[GTS] Failed to load module 'GTS/main_ui_settings': " .. tostring(mod))
    end
    return defaults
  end

  if mod.compact == nil then mod.compact = defaults.compact end
  if mod.colors == nil then mod.colors = defaults.colors end
  if mod.keepMenuOpenWhenOverlayClosed == nil then
    mod.keepMenuOpenWhenOverlayClosed = defaults.keepMenuOpenWhenOverlayClosed
  end
  if mod.keepMacroDebugOpenWhenOverlayClosed == nil then
    mod.keepMacroDebugOpenWhenOverlayClosed = defaults.keepMacroDebugOpenWhenOverlayClosed
  end

  mod.compact = mod.compact == true
  mod.colors = mod.colors ~= false
  mod.keepMenuOpenWhenOverlayClosed = mod.keepMenuOpenWhenOverlayClosed == true
  mod.keepMacroDebugOpenWhenOverlayClosed = mod.keepMacroDebugOpenWhenOverlayClosed == true
  mod.poseSearchLimit = math.max(50, math.floor(tonumber(mod.poseSearchLimit or defaults.poseSearchLimit) or defaults.poseSearchLimit))
  mod.lastPoseRig = tostring(mod.lastPoseRig or defaults.lastPoseRig)
  mod.playerSubtab = tostring(mod.playerSubtab or defaults.playerSubtab)

  return mod
end

local UIState = _loadSharedUIState()
local AssetRegistry = require("GTS/asset_registry")
local Persistence = require("GTS/persistence")

-- Normalize CET ImGui return conventions (value / changed / both).
local checkboxValue = Utils.checkboxValue
local inputIntValue = Utils.inputIntValue

local function _persistUIState()
  if type(UIState) == "table" and type(UIState.Save) == "function" then
    local ok, err = UIState.Save(UIState)
    if not ok then
      print("[GTS] Failed to save UI settings: " .. tostring(err))
    end
  end
end

local function _settingsChanged(before, after)
  local keys = {
    "compact",
    "colors",
    "keepMenuOpenWhenOverlayClosed",
    "keepMacroDebugOpenWhenOverlayClosed",
    "poseSearchLimit",
    "lastPoseRig",
    "playerSubtab",
  }
  for i = 1, #keys do
    local key = keys[i]
    if tostring(before[key]) ~= tostring(after[key]) then
      return true
    end
  end
  return false
end

local function _makeSettingsTab(shared)
  local SettingsTab = {}

  function SettingsTab.ShouldKeepMenuOpen()
    return shared.keepMenuOpenWhenOverlayClosed == true
  end

  function SettingsTab.OnOverlayStateChanged(_) end
  function SettingsTab.OnUpdate(_) end

  function SettingsTab.DrawTab(_)
    local before = {
      compact = shared.compact,
      colors = shared.colors,
      keepMenuOpenWhenOverlayClosed = shared.keepMenuOpenWhenOverlayClosed,
      keepMacroDebugOpenWhenOverlayClosed = shared.keepMacroDebugOpenWhenOverlayClosed,
      poseSearchLimit = shared.poseSearchLimit,
      lastPoseRig = shared.lastPoseRig,
      playerSubtab = shared.playerSubtab,
    }

    ImGui.Separator()
    ImGui.Text("Settings")

    shared.keepMenuOpenWhenOverlayClosed = checkboxValue(
      "Keep Menu Open While CET Overlay Is Closed",
      shared.keepMenuOpenWhenOverlayClosed
    )

    shared.compact = checkboxValue("Compact Mode", shared.compact)
    shared.colors  = checkboxValue("Colors On / Off", shared.colors)
    shared.keepMacroDebugOpenWhenOverlayClosed = checkboxValue(
      "Keep Scripter Debug Open While CET Overlay Is Closed",
      shared.keepMacroDebugOpenWhenOverlayClosed
    )
    shared.poseSearchLimit = math.max(50, inputIntValue("Pose Search Result Cap", tonumber(shared.poseSearchLimit or 240) or 240, 10, 50))

    ImGui.Spacing()
    ImGui.TextWrapped("UI and pose-browser preferences now persist across sessions in the User folder.")
    ImGui.TextWrapped("User Folder: " .. tostring((Persistence.GetUserDir and Persistence.GetUserDir()) or "-"))
    if ImGui.Button("Save Assets To Disk") then
      local ok, msg = AssetRegistry.SaveToDisk()
      print("[GTS] " .. tostring(msg or (ok and "Assets saved" or "Asset save failed")))
    end
    ImGui.SameLine()
    if ImGui.Button("Reload Assets From Disk") then
      local ok, msg = AssetRegistry.ReloadFromDisk()
      print("[GTS] " .. tostring(msg or (ok and "Assets reloaded" or "Asset reload failed")))
    end

    local info = AssetRegistry.GetPersistenceInfo and AssetRegistry.GetPersistenceInfo() or {}
    if info.lastSaveAt then ImGui.Text("Last Asset Save: " .. tostring(info.lastSaveAt)) end
    if info.lastLoadAt then ImGui.Text("Last Asset Load: " .. tostring(info.lastLoadAt)) end
    if info.lastError then ImGui.TextWrapped("Persistence: " .. tostring(info.lastError)) end

    ImGui.Spacing()
    ImGui.Separator()
    ImGui.Text("Keep Menu Open: " .. tostring(shared.keepMenuOpenWhenOverlayClosed):upper())
    ImGui.Text("Compact Mode: " .. tostring(shared.compact):upper())
    ImGui.Text("Colors Enabled: " .. tostring(shared.colors):upper())
    ImGui.Text("Keep Scripter Debug Open: " .. tostring(shared.keepMacroDebugOpenWhenOverlayClosed):upper())
    ImGui.Text("Pose Search Result Cap: " .. tostring(shared.poseSearchLimit))

    if _settingsChanged(before, shared) then
      _persistUIState()
    end
  end

  return SettingsTab
end

local TargetService, TargetServiceErr = _safeRequire("GTS/target_service")
local MoveObserver, MoveObserverErr = _safeRequire("GTS/move_observer")
local StatsUI, StatsUIErr = _safeRequire("GTS/stats_browser")
local SpawnTools, SpawnToolsErr = _safeRequire("GTS/spawn_tools")
local InventoryTab, InventoryTabErr = _safeRequire("GTS/inventory_tab")
local RuleBuilder, RuleBuilderErr = _safeRequire("GTS/rule_builder")
local MacroBuilder, MacroBuilderErr = _safeRequire("GTS/macro_builder")
local CreatedTab, CreatedTabErr = _safeRequire("GTS/created_tab")
local ShooterTab, ShooterTabErr = _safeRequire("GTS/shooter_tab")
local CameraActions, CameraActionsErr = _safeRequire("GTS/macro_actions_camera")
local TargetActions, TargetActionsErr = _safeRequire("GTS/macro_actions_target")
local TargetControl, TargetControlErr = _safeRequire("GTS/target_control")
local MenuMaker, MenuMakerErr = _safeRequire("GTS/menu_maker")
local PoseBuilder, PoseBuilderErr = _safeRequire("GTS/pose_builder")
local ScenarioBuilder, ScenarioBuilderErr = _safeRequire("GTS/scenario_builder")
local SettingsTab = _makeSettingsTab(UIState)
local SettingsTabErr = nil

local UI = {
  open = true,
  state = UIState,
  _justOpened = false,
  _lastAppliedCompact = nil,
}

local function drawCog()
  if type(IconGlyphs) == "table" then
    local keys = {
      "Cog", "CogOutline",
      "Wrench", "WrenchOutline", "WrenchCog", "WrenchCogOutline",
      "fas_cog", "fa_cog", "fa-cog",
    }
    for _, k in ipairs(keys) do
      local g = IconGlyphs[k]
      if g ~= nil and g ~= "" and g ~= "?" and g ~= "S" then
        return g
      end
    end
  end

  if utf8 and utf8.char then
    return utf8.char(0xF013)
  end

  return "Cog"
end

local function _callIfTableMethod(mod, methodName, ...)
  if type(mod) == "table" and type(mod[methodName]) == "function" then
    local ok, err = pcall(mod[methodName], ...)
    if not ok then
      print("[GTS] " .. tostring(methodName) .. " error: " .. tostring(err))
    end
  end
end

local function _drawTabModuleChild(id, mod, methodName, label, err, ...)
  if type(ImGui.BeginChild) == "function" then
    ImGui.BeginChild("gts_tab_body_" .. tostring(id), 0, 0, false)
  end
  if type(mod) == "table" and type(mod[methodName]) == "function" then
    _callIfTableMethod(mod, methodName, ...)
  else
    _drawModuleError(label, err)
  end
  if type(ImGui.EndChild) == "function" then
    ImGui.EndChild()
  end
end

_callIfTableMethod(TargetControl, "OnInit")
_callIfTableMethod(MenuMaker, "OnInit")

registerForEvent("onUpdate", function(delta)
  _callIfTableMethod(TargetService, "OnUpdate", delta)
  _callIfTableMethod(MoveObserver, "OnUpdate", delta)
  _callIfTableMethod(StatsUI, "OnUpdate", delta)
  _callIfTableMethod(SpawnTools, "OnUpdate", delta)
  _callIfTableMethod(InventoryTab, "OnUpdate", delta)
  _callIfTableMethod(RuleBuilder, "OnUpdate", delta)
  _callIfTableMethod(MacroBuilder, "OnUpdate", delta)
  _callIfTableMethod(CreatedTab, "OnUpdate", delta)
  _callIfTableMethod(ShooterTab, "OnUpdate", delta)
  _callIfTableMethod(CameraActions, "OnUpdate", delta)
  _callIfTableMethod(TargetActions, "OnUpdate", delta)
  _callIfTableMethod(TargetControl, "OnUpdate", delta)
  _callIfTableMethod(MenuMaker, "OnUpdate", delta)
  _callIfTableMethod(PoseBuilder, "OnUpdate", delta)
  _callIfTableMethod(ScenarioBuilder, "OnUpdate", delta)
  _callIfTableMethod(SettingsTab, "OnUpdate", delta)
end)


local function _drawMiniTabButtons(stateTable, key, labels, idPrefix)
  if type(stateTable) ~= "table" then return nil end
  local current = tostring(stateTable[key] or labels[1] or "")
  for i = 1, #labels do
    local label = tostring(labels[i])
    local selected = (current == label)
    if selected then
      if type(ImGui.PushStyleColor) == "function" then
        pcall(ImGui.PushStyleColor, ImGuiCol.Button, 0.14, 0.40, 0.85, 0.95)
        pcall(ImGui.PushStyleColor, ImGuiCol.ButtonHovered, 0.18, 0.48, 0.95, 1.00)
        pcall(ImGui.PushStyleColor, ImGuiCol.ButtonActive, 0.12, 0.34, 0.78, 1.00)
      end
    end
    if ImGui.Button(label .. "##" .. tostring(idPrefix or key) .. "_" .. tostring(i)) then
      stateTable[key] = label
      current = label
      _persistUIState()
    end
    if selected and type(ImGui.PopStyleColor) == "function" then
      pcall(ImGui.PopStyleColor, 3)
    end
    if i < #labels then ImGui.SameLine() end
  end
  return current
end

registerForEvent("onOverlayOpen", function()
  UI.open = true
  UI._justOpened = true
  _callIfTableMethod(SettingsTab, "OnOverlayStateChanged", true)
  _callIfTableMethod(TargetControl, "OnOverlayStateChanged", true)
  print("[GTS] overlay opened")
end)

registerForEvent("onOverlayClose", function()
  _callIfTableMethod(SettingsTab, "OnOverlayStateChanged", false)
  _callIfTableMethod(TargetControl, "OnOverlayStateChanged", false)
  if type(SettingsTab) == "table" and type(SettingsTab.ShouldKeepMenuOpen) == "function" then
    local ok, keepOpen = pcall(SettingsTab.ShouldKeepMenuOpen)
    UI.open = ok and keepOpen == true or false
  else
    UI.open = false
  end
  print("[GTS] overlay closed")
end)

local function _drawModuleError(label, err)
  ImGui.Text(label .. " module not loaded.")
  if err and err ~= "" then
    ImGui.Spacing()
    ImGui.TextWrapped(tostring(err))
  end
end

local function _applyWindowSizeFromSettings()
  local targetW = UI.state.compact and 900 or 1120
  local targetH = UI.state.compact and 640 or 760

  if type(ImGui.SetNextWindowSizeConstraints) == "function" then
    ImGui.SetNextWindowSizeConstraints(UI.state.compact and 820 or 980, UI.state.compact and 560 or 680, 2600, 1800)
  end

  if UI._lastAppliedCompact ~= UI.state.compact then
    ImGui.SetNextWindowSize(targetW, targetH, ImGuiCond.Always)
    UI._lastAppliedCompact = UI.state.compact
  else
    ImGui.SetNextWindowSize(targetW, targetH, ImGuiCond.FirstUseEver)
  end
end


registerForEvent("onShutdown", function()
  _persistUIState()
  _callIfTableMethod(TargetControl, "OnShutdown")
  _callIfTableMethod(PoseBuilder, "OnShutdown")
  _callIfTableMethod(ScenarioBuilder, "OnShutdown")
end)

registerForEvent("onDraw", function()
  if not UI.open then
    if UI.state.keepMacroDebugOpenWhenOverlayClosed == true then
      _callIfTableMethod(RuleBuilder, "DrawWindows", UI.state)
    end
    return
  end

  if UI._justOpened then
    ImGui.SetNextWindowCollapsed(false, ImGuiCond.Always)
    if ImGui.SetNextWindowFocus then ImGui.SetNextWindowFocus() end
    UI._justOpened = false
  end

  _applyWindowSizeFromSettings()
  ImGui.Begin("Gat's Tools & Scripter")

  local w = ImGui.GetWindowWidth()
  ImGui.SameLine(w - 40)
  if ImGui.SmallButton(drawCog() .. "##settings") then
    ImGui.OpenPopup("ui_settings")
  end

  if ImGui.BeginPopup("ui_settings") then
    local beforePopup = {
      compact = UI.state.compact,
      colors = UI.state.colors,
      keepMenuOpenWhenOverlayClosed = UI.state.keepMenuOpenWhenOverlayClosed,
      keepMacroDebugOpenWhenOverlayClosed = UI.state.keepMacroDebugOpenWhenOverlayClosed,
      poseSearchLimit = UI.state.poseSearchLimit,
      lastPoseRig = UI.state.lastPoseRig,
    }
    UI.state.compact = checkboxValue("Compact Mode", UI.state.compact)
    UI.state.colors  = checkboxValue("Colors On / Off", UI.state.colors)
    UI.state.keepMenuOpenWhenOverlayClosed = checkboxValue(
      "Keep Menu Open While CET Overlay Is Closed",
      UI.state.keepMenuOpenWhenOverlayClosed
    )
    UI.state.keepMacroDebugOpenWhenOverlayClosed = checkboxValue(
      "Keep Scripter Debug Open While CET Overlay Is Closed",
      UI.state.keepMacroDebugOpenWhenOverlayClosed
    )
    UI.state.poseSearchLimit = math.max(50, inputIntValue("Pose Search Result Cap##popup", tonumber(UI.state.poseSearchLimit or 240) or 240, 10, 50))
    if _settingsChanged(beforePopup, UI.state) then
      _persistUIState()
    end
    ImGui.EndPopup()
  end

  ImGui.Separator()

  if ImGui.BeginTabBar("main_tabs") then
    if ImGui.BeginTabItem("Scripter") then
      _drawTabModuleChild("scripter", RuleBuilder, "DrawTab", "Scripter", RuleBuilderErr, UI.state)
      ImGui.EndTabItem()
    end

    if ImGui.BeginTabItem("Macros") then
      _drawTabModuleChild("macros", MacroBuilder, "DrawTab", "Macros", MacroBuilderErr, UI.state)
      ImGui.EndTabItem()
    end

    if ImGui.BeginTabItem("Created") then
      _drawTabModuleChild("created", CreatedTab, "DrawTab", "Created", CreatedTabErr, UI.state)
      ImGui.EndTabItem()
    end

    if ImGui.BeginTabItem("Conditions") then
      _drawTabModuleChild("conditions", MoveObserver, "DrawTab", "Conditions", MoveObserverErr, UI.state)
      ImGui.EndTabItem()
    end

    if ImGui.BeginTabItem("Player") then
      local currentPlayerSubtab = _drawMiniTabButtons(UI.state, "playerSubtab", {"Stats Editor", "Inventory"}, "player_subtabs")
      ImGui.Separator()
      if currentPlayerSubtab == "Inventory" then
        _drawTabModuleChild("player_inventory", InventoryTab, "DrawTab", "Inventory", InventoryTabErr, UI.state)
      else
        _drawTabModuleChild("player_stats", StatsUI, "DrawTab", "Stats", StatsUIErr, UI.state)
      end
      ImGui.EndTabItem()
    end

    if ImGui.BeginTabItem("Spawn Tools") then
      if ImGui.BeginTabBar("spawn_tools_subtabs") then
        if ImGui.BeginTabItem("Spawner") then
          _drawTabModuleChild("spawn_spawner", SpawnTools, "DrawTab", "Spawn Tools", SpawnToolsErr, UI.state)
          ImGui.EndTabItem()
        end

        if ImGui.BeginTabItem("Shooter") then
          _drawTabModuleChild("spawn_shooter", ShooterTab, "DrawTab", "Shooter", ShooterTabErr, UI.state)
          ImGui.EndTabItem()
        end

        ImGui.EndTabBar()
      end
      ImGui.EndTabItem()
    end


    if ImGui.BeginTabItem("Pose Builder") then
      _drawTabModuleChild("pose_builder", PoseBuilder, "DrawTab", "Pose Builder", PoseBuilderErr, UI.state)
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem("Scenario Builder") then
      _drawTabModuleChild("scenario_builder", ScenarioBuilder, "DrawTab", "Scenario Builder", ScenarioBuilderErr, UI.state)
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem("Target Control") then
      _drawTabModuleChild("target_control", TargetControl, "DrawTab", "Target Control", TargetControlErr, UI.state)
      ImGui.EndTabItem()
    end

    if ImGui.BeginTabItem("Menu Maker") then
      _drawTabModuleChild("menu_maker", MenuMaker, "DrawTab", "Menu Maker", MenuMakerErr, UI.state)
      ImGui.EndTabItem()
    end

    if ImGui.BeginTabItem("Settings") then
      _drawTabModuleChild("settings", SettingsTab, "DrawTab", "Settings", SettingsTabErr, UI.state)
      ImGui.EndTabItem()
    end

    ImGui.EndTabBar()
  end

  ImGui.End()
  _callIfTableMethod(RuleBuilder, "DrawWindows", UI.state)
  _callIfTableMethod(SpawnTools, "DrawWindows", UI.state)
  _callIfTableMethod(MenuMaker, "DrawWindows", UI.state)
end)

return UI
