local MoveObserver = MoveObserver or {}
local TargetService = require("GTS/target_service")
local AssetRegistry = require("GTS/asset_registry")
local _statusActionsCache = false

local function _getStatusActions()
  if _statusActionsCache == false then
    local ok, mod = pcall(require, 'GTS/macro_actions_status')
    _statusActionsCache = ok and mod or nil
  end
  return _statusActionsCache
end
-- Conditions (UI)
-- Loaded by init.lua

local Move = {
  states = {
    running=false,jumping=false,crouched=false,sliding=false,inAir=false,
    reloading=false,shooting=false,swimming=false,dashing=false,dodging=false,
    aiming=false,meleeAttack=false,inVehicle=false,weaponActive=false
  },
  prev = {
    running=false,jumping=false,crouched=false,sliding=false,inAir=false,
    reloading=false,shooting=false,swimming=false,dashing=false,dodging=false,
    aiming=false,meleeAttack=false,inVehicle=false,weaponActive=false
  },
  prevHadVehicle=false,
  prevLabel=nil,
  currentVehicleLabel=nil,
  activeWeaponId=nil,
  shotAt=0,
  shotWin=0.20,
  meleeAt=0,
  meleeWin=0.20,

  -- derived movement
  isMoving=false,
  playerSpeed=0,

  ui={compact=false,colors=true,showSettings=false,maxEvents=18},
  events={},

-- override/sanity system
lastTrueTime = {}, -- rising-edge timestamps (os.clock())
overrideExit = {}, -- state -> reason string for this tick when forced false

motion = {
  inited = false,
  lastPos = nil,
  stillXY = 0,
  stillZ  = 0,
  stillAll = 0,
  epsXY = 0.03,
  epsZ  = 0.03
},

  -- Target Conditions (from TargetingSystem look-at)
  target = {
    exists = false,
    isNPC = false,
    faction = nil,
    hostile = false,
    aggro = false,
    distance = 0,
    speed = 0,
    health = 0,
    className = nil,
    _obj = nil
  },


  ownedVehicles = {
    ids = {},
    refreshEvery = 2.0,
    _nextRefresh = 0,
  },

  itemOwnership = {
    cache = {},
    refreshEvery = 0.25,
  },

  -- Custom Stat Conditions (true/false expressions)
  custom = {
    enabled = true,
    refreshEvery = 0.25,
    _nextRefresh = 0,

    -- stat record cache
    _built = false,
    stats = {}, -- { name, enum }

    -- add/picker UI state
    addKw = "",
    addOp = "==",
    addSrc = "Current Amount", -- Current Amount / Max Amount / Pool Percent / Stat Value
    addCompareMode = "True Number",
    addValueStr = "300",
    addPickIndex = 1,
    _filtered = {},
    _lastFilter = "",

    -- Conditions list
    list = {},
    _nextId = 1,

    -- preset UI state
    presetName = "",
    selectedPresetId = nil,
  }
}


-- Inventory ID database (auto-loaded)
-- Exposes:
--   INV_IDS       (array of item IDs)
local function pushEvent(text,kind)
  local t=os.date("%H:%M:%S")
  table.insert(Move.events,1,{text=t.."  "..text,kind=kind or "INFO"})
  while #Move.events>Move.ui.maxEvents do table.remove(Move.events) end
end

local function safeObserve(c,e,f) pcall(function() Observe(c,e,f) end) end
local function setState(k,v)
  v = v and true or false
  local prev = Move.states[k] and true or false
  Move.states[k] = v
  if v and not prev then
    Move.lastTrueTime[k] = os.clock()
  end
end

-- ===== Custom Stat Observer Helpers =====

local function _pcall(f)
  local ok, r = pcall(f)
  if ok then return r end
  return nil
end

local function _clone(value, seen)
  if type(value) ~= "table" then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do
    out[_clone(k, seen)] = _clone(v, seen)
  end
  return out
end

-- Normalize CET ImGui return conventions.
local function _CheckboxValue(label, value)
  local a, b = ImGui.Checkbox(label, value)
  if type(a) == "boolean" and type(b) == "boolean" then
    if b == (a ~= value) then return a end
    if a == (b ~= value) then return b end
    return b
  end
  if type(a) == "boolean" then return a end
  return value
end

local function _InputTextValue(label, value, bufSize, flags)
  if flags ~= nil then
    local a, b = ImGui.InputText(label, value, bufSize, flags)
    if type(a) == "boolean" and type(b) == "string" then return b end
    if type(a) == "string" then return a end
    if type(b) == "string" then return b end
    return value
  end
  local a, b = ImGui.InputText(label, value, bufSize)
  if type(a) == "boolean" and type(b) == "string" then return b end
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return value
end

local function _ComboSelect(label, currentValue, labels)
  if type(labels) ~= "table" or #labels == 0 then return currentValue end
  local current = currentValue
  local found = false
  for i = 1, #labels do
    if tostring(labels[i]) == tostring(current) then found = true break end
  end
  if not found then current = labels[1] end
  if type(ImGui.SetNextItemWidth) == "function" then ImGui.SetNextItemWidth(-1) end
  if type(ImGui.BeginCombo) == "function" then
    if ImGui.BeginCombo(label, tostring(current or "")) then
      for i = 1, #labels do
        local item = tostring(labels[i] or "")
        local selected = (item == tostring(current or ""))
        if ImGui.Selectable(item, selected) then current = item end
        if selected and type(ImGui.SetItemDefaultFocus) == "function" then ImGui.SetItemDefaultFocus() end
      end
      ImGui.EndCombo()
    end
    return current
  end
  return current
end

local function _getPlayer() return Game.GetPlayer() end
local function _getEID() local p=_getPlayer(); return p and p:GetEntityID() or nil end
local function _getSS() return Game.GetStatsSystem() end

local function _trim(s)
  s = tostring(s or "")
  return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function _extractItemsIdFromAny(x)
  if x == nil then return nil end
  local s = tostring(x)
  if s == nil or s == "" then return nil end
  local m = s:match("%-%-%[%[(Items%.[%w_]+)%]%]")
  if m ~= nil and m ~= "" then return m end
  m = s:match("(Items%.[%w_]+)")
  if m ~= nil and m ~= "" then return m end
  return nil
end

local function _getActiveWeaponKey(player)
  local p = player or _getPlayer()
  if not p then return nil end
  local w = _pcall(function() return p:GetActiveWeapon() end)
  if not w then return nil end

  local itemID = _pcall(function() return w:GetItemID() end)
  local itemKey = _extractItemsIdFromAny(itemID)
  if itemKey then return itemKey end

  local itemData = _pcall(function() return w:GetItemData() end)
  if itemData ~= nil then
    local iid = _pcall(function() return itemData:GetID() end)
    itemKey = _extractItemsIdFromAny(iid)
    if itemKey then return itemKey end
  end

  local rec = _pcall(function() return w:GetRecordID() end)
  if rec then
    local s = tostring(rec)
    local m = s:match("(Items%.[%w_]+)")
    if m then return m end
  end
  return nil
end


local EQUIPPED_SLOT_LABELS = { "Slot 1", "Slot 2", "Slot 3", "Head", "Face", "Outer Torso", "Inner Torso", "Legs", "Feet", "Outfit" }

local function _cleanValueString(value)
  if value == nil then return nil end
  if type(value) == "string" then
    local s = _trim(value)
    if s ~= "" and s ~= "userdata" and s ~= "nil" and s ~= "None" then return s end
    return nil
  end
  if TDBID and TDBID.ToStringDEBUG then
    local out = _pcall(function() return TDBID.ToStringDEBUG(value) end)
    out = _trim(out)
    if out ~= "" and out ~= "userdata" and out ~= "nil" and out ~= "None" and not string.find(out, '0000000000000000', 1, true) then return out end
  end
  if Game and Game.NameToString then
    local out = _pcall(function() return Game.NameToString(value) end)
    out = _trim(out)
    if out ~= "" and out ~= "userdata" and out ~= "nil" and out ~= "None" then return out end
  end
  local out = _trim(tostring(value or ""))
  if out ~= "" and out ~= "userdata" and out ~= "nil" and out ~= "None" then return out end
  return nil
end

local function _firstNonEmpty(...)
  for i = 1, select('#', ...) do
    local v = _cleanValueString(select(i, ...))
    if v ~= nil and v ~= '' then return v end
  end
  return nil
end

local function _callMethod(obj, name, ...)
  if obj == nil or name == nil then return nil end
  local fn = obj[name]
  if type(fn) ~= 'function' then return nil end
  local args = { ... }
  local unpackArgs = (table and table.unpack) or unpack
  return _pcall(function() return fn(obj, unpackArgs(args)) end)
end

local function _callAnyMethod(obj, names, ...)
  if obj == nil or type(names) ~= 'table' then return nil, nil end
  for i = 1, #names do
    local name = names[i]
    local value = _callMethod(obj, name, ...)
    if value ~= nil then return value, name end
  end
  return nil, nil
end

local function _probeBoolMethod(obj, name)
  if obj == nil or type(name) ~= 'string' or name == '' then return nil end
  local fn = obj[name]
  if type(fn) ~= 'function' then return nil end
  local value = _pcall(function() return fn(obj) end)
  if type(value) == 'boolean' then return value end
  if value ~= nil then
    local s = string.lower(tostring(value or ''))
    if s == 'true' then return true end
    if s == 'false' then return false end
  end
  return nil
end

local function _extractQuestLeafId(value)
  local s = _cleanValueString(value)
  if not s then return nil end
  s = s:gsub('\\', '/')
  local token = s:match('([%w_]+)$')
  if token and token ~= '' then return token end
  return s
end

local function _normalizeQuestToken(value)
  local s = _cleanValueString(value)
  if not s then return '' end
  s = s:gsub('\\', '/')
  return string.lower(_trim(s))
end

local function _questTokensFromInfo(info)
  local out, seen = {}, {}
  local function add(v)
    local full = _normalizeQuestToken(v)
    if full ~= '' and not seen[full] then seen[full] = true out[#out + 1] = full end
    local leaf = _normalizeQuestToken(_extractQuestLeafId(v))
    if leaf ~= '' and not seen[leaf] then seen[leaf] = true out[#out + 1] = leaf end
  end
  if type(info) == 'table' then
    add(info.rawId)
    add(info.detail)
    if type(info.parent) == 'table' then for _, v in pairs(info.parent) do add(v) end end
    if type(info.tracked) == 'table' then for _, v in pairs(info.tracked) do add(v) end end
  else
    add(info)
  end
  return out
end

local function _questInputMatches(info, wanted)
  local want = _normalizeQuestToken(wanted)
  if want == '' then return false end
  local leafWant = _normalizeQuestToken(_extractQuestLeafId(want))
  local tokens = _questTokensFromInfo(info)
  for i = 1, #tokens do
    local token = tokens[i]
    if token == want or (leafWant ~= '' and token == leafWant) then return true end
  end
  return false
end

local function _harvestQuestEntryStrings(entry)
  if entry == nil then return {} end
  local out = {}
  local function add(tag, value)
    local s = _cleanValueString(value)
    if s ~= nil and s ~= '' and out[tag] == nil then out[tag] = s end
  end
  add('tostring', tostring(entry))
  local methods = { 'GetId', 'GetHash', 'GetEntryHash', 'GetTitle', 'GetName', 'GetDebugString', 'GetPath', 'GetRecordID', 'GetUniqueName', 'GetDescription', 'ToString' }
  for i = 1, #methods do
    local name = methods[i]
    local value = _callMethod(entry, name)
    if value ~= nil then add(name, value) end
  end
  return out
end

local function _getJournalManagerForRule()
  if Game and Game.GetJournalManager then
    local jm = _pcall(function() return Game.GetJournalManager() end)
    if jm then return jm end
  end
  if Game and Game.GetScriptableSystemsContainer then
    local ssc = _pcall(function() return Game.GetScriptableSystemsContainer() end)
    if ssc then
      local names = { 'JournalManager', 'gameJournalManager', 'JournalSystem' }
      for i = 1, #names do
        local jm = _pcall(function() return ssc:Get(names[i]) end)
        if jm then return jm end
      end
    end
  end
  return nil
end

local function _getTrackedQuestInfoForRule()
  local jm = _getJournalManagerForRule()
  if not jm then return { rawId = nil, detail = nil, tracked = {}, parent = {}, reason = 'Journal manager unavailable' } end

  local tracked = nil
  tracked = _callMethod(jm, 'GetTrackedEntry')
    or _callMethod(jm, 'GetTrackedQuestEntry')
    or _callMethod(jm, 'GetTrackedQuest')
    or _callMethod(jm, 'GetTrackedObjective')
    or _callMethod(jm, 'GetTrackedEntryInJournal')
    or _callMethod(jm, 'GetTrackedJournalEntry')
  if not tracked then
    return { rawId = nil, detail = nil, tracked = {}, parent = {}, reason = 'Tracked journal entry unavailable' }
  end

  local parent = _callMethod(tracked, 'GetParentEntry') or _callMethod(tracked, 'GetParent') or _callMethod(tracked, 'GetQuestEntry')
  if not parent then
    parent = _callMethod(jm, 'GetParentEntry', tracked) or _callMethod(jm, 'GetParent', tracked)
  end

  local rawTracked = _harvestQuestEntryStrings(tracked)
  local rawParent = _harvestQuestEntryStrings(parent)
  local rawId = _firstNonEmpty(rawParent.GetPath, rawParent.GetId, rawParent.GetHash, rawTracked.GetPath, rawTracked.GetId, rawTracked.GetHash)
  local detail = _firstNonEmpty(rawTracked.GetTitle, rawTracked.GetName, rawTracked.GetDebugString, rawTracked.GetPath, rawTracked.GetId, rawTracked.GetHash, rawTracked.tostring)
  return {
    rawId = rawId,
    detail = detail,
    tracked = rawTracked,
    parent = rawParent,
    reason = rawId and nil or 'Tracked quest id unavailable',
  }
end

local function _difficultyLabelFromValue(value)
  local text = tostring(value or '')
  if string.find(text, 'VeryHard', 1, true) or string.find(text, 'Very Hard', 1, true) then return 'VeryHard' end
  if string.find(text, 'Story', 1, true) then return 'Story' end
  if string.find(text, 'Easy', 1, true) then return 'Easy' end
  if string.find(text, 'Normal', 1, true) then return 'Normal' end
  if string.find(text, 'Hard', 1, true) then return 'Hard' end
  local raw = tonumber(value and value.value or value)
  if raw == 0 then return 'Story'
  elseif raw == 1 then return 'Easy'
  elseif raw == 2 then return 'Normal'
  elseif raw == 3 then return 'Hard'
  elseif raw == 4 then return 'VeryHard' end
  return nil
end

local function _getDifficultyLabelForRule()
  local sds = nil
  if Game and Game.GetStatsDataSystem then
    sds = _pcall(function() return Game.GetStatsDataSystem() end)
  end
  if not sds then return nil end
  local diff = _pcall(function() return sds:GetDifficulty() end)
  if diff == nil then return nil end
  local label = _difficultyLabelFromValue(diff)
  if label ~= nil then return label end
  return _difficultyLabelFromValue(diff and diff.value or nil)
end

local function _getPlayerCombatStateForRule()
  local player = _getPlayer()
  if not player then return nil end

  local direct = _probeBoolMethod(player, 'IsInCombat')
  if type(direct) == 'boolean' then return direct end

  local static = nil
  if GameObject and type(GameObject.IsInCombat) == 'function' then
    static = _pcall(function() return GameObject.IsInCombat(player) end)
    if type(static) == 'boolean' then return static end
  end

  local state = _callMethod(player, 'GetCombatState') or _callMethod(player, 'GetCurrentCombatState')
  if state ~= nil then
    local s = string.lower(tostring(state or ''))
    if s:find('combat', 1, true) or s:find('alert', 1, true) then return true end
    if s:find('safe', 1, true) or s:find('peace', 1, true) or s:find('relaxed', 1, true) or s:find('idle', 1, true) then return false end
  end

  return nil
end

local function _zoneLabelFromRaw(value)
  if value == nil then return nil end
  local s = string.lower(tostring(value or ''))
  if s == '' or s == 'nil' or s == 'none' or s == 'userdata' then return nil end
  if s:find('safe', 1, true) then return 'Safe Zone' end
  if s:find('restricted', 1, true) or s:find('hostile', 1, true) or s:find('combat', 1, true) or s:find('danger', 1, true) or s:find('unsafe', 1, true) then
    return 'Combat Zone'
  end
  return nil
end

local function _getZoneLabelForRule()
  local player = _getPlayer()
  local ssc = nil
  if Game and Game.GetScriptableSystemsContainer then
    ssc = _pcall(function() return Game.GetScriptableSystemsContainer() end)
  end
  local prevention = nil
  if ssc then prevention = _pcall(function() return ssc:Get('PreventionSystem') end) end

  local tries = {
    function() return prevention and prevention:GetCurrentSecurityAreaType() or nil end,
    function() return prevention and prevention:GetCurrentSecurityZoneType() or nil end,
    function() return prevention and prevention:GetSecurityAreaType() or nil end,
    function() return prevention and prevention.currentSecurityAreaType or nil end,
    function() return prevention and prevention.securityAreaType or nil end,
    function() return player and player:GetCurrentSecurityAreaType() or nil end,
    function() return player and player:GetSecurityAreaType() or nil end,
    function() return player and player.currentSecurityAreaType or nil end,
    function() return player and player.securityAreaType or nil end,
  }

  for i = 1, #tries do
    local raw = _pcall(tries[i])
    local label = _zoneLabelFromRaw(raw)
    if label ~= nil then return label end
  end
  return nil
end

local function _getTargetEntityIDForRule()
  local obj = Move.target and Move.target._obj or nil
  if obj and obj.GetEntityID then
    local eid = _pcall(function() return obj:GetEntityID() end)
    if eid ~= nil then return eid end
  end
  return nil
end

local function _resolveEquipmentAreaToken(areaName)
  local token = areaName
  if type(areaName) == 'string' and gamedataEquipmentArea and gamedataEquipmentArea[areaName] ~= nil then
    token = gamedataEquipmentArea[areaName]
  end
  return token
end

local function _getEquipmentPlayerData(player)
  local p = player or _getPlayer()
  if not p then return nil end
  local es = nil
  if Game and Game.GetScriptableSystemsContainer then
    local ssc = _pcall(function() return Game.GetScriptableSystemsContainer() end)
    if ssc then es = _pcall(function() return ssc:Get('EquipmentSystem') end) end
  end
  if not es then return nil end
  local pd = _callMethod(es, 'GetPlayerData', p)
  if not pd then return nil end
  if pd['GetItemInEquipSlot2'] == nil and pd['GetItemInEquipSlot;gamedataEquipmentAreaInt32'] ~= nil then
    pd['GetItemInEquipSlot2'] = pd['GetItemInEquipSlot;gamedataEquipmentAreaInt32']
  end
  return pd
end

local function _extractEquippedItemRecordId(item)
  if item == nil then return nil end
  local direct = _extractItemsIdFromAny(item)
  if direct ~= nil then return direct end
  local probes = {
    function() return item.id end,
    function() return item:GetID() end,
    function() return item:GetItemID() end,
    function() return item:GetRecordID() end,
    function() return item:GetTDBID() end,
  }
  for i = 1, #probes do
    local value = _pcall(probes[i])
    local s = _extractItemsIdFromAny(value) or _cleanValueString(value)
    if s ~= nil and s ~= '' then return s end
  end
  return _extractItemsIdFromAny(tostring(item)) or _cleanValueString(item)
end

local function _getItemInEquipSlotForRule(player, areaName, slotIndex)
  local pd = _getEquipmentPlayerData(player)
  if not pd then return nil end
  local areaToken = _resolveEquipmentAreaToken(areaName)
  local tried = {
    { 'GetItemInEquipSlot2', areaToken },
    { 'GetItemInEquipSlot', areaToken },
    { 'GetItemInEquipSlot', areaName },
  }
  if CName and CName.new then
    local cname = _pcall(function() return CName.new(areaName) end)
    if cname ~= nil then tried[#tried + 1] = { 'GetItemInEquipSlot', cname } end
  end
  for i = 1, #tried do
    local fnName, areaArg = tried[i][1], tried[i][2]
    local fn = pd[fnName]
    if type(fn) == 'function' then
      local value = _pcall(function() return fn(pd, areaArg, slotIndex or 0) end)
      if value ~= nil then return value end
    end
  end
  return nil
end

local function _equippedSlotDescriptors(slotKey)
  local slot = tostring(slotKey or '')
  if slot == 'Slot 1' then
    return {
      { area = 'Weapon', index = 0 },
      { area = 'WeaponRight', index = 0 },
      { area = 'RightHand', index = 0 },
    }
  elseif slot == 'Slot 2' then
    return {
      { area = 'Weapon', index = 1 },
      { area = 'WeaponLeft', index = 0 },
      { area = 'LeftHand', index = 0 },
    }
  elseif slot == 'Slot 3' then
    return {
      { area = 'Weapon', index = 2 },
      { area = 'WeaponHeavy', index = 0 },
      { area = 'QuickSlot', index = 0 },
    }
  elseif slot == 'Head' then
    return { { area = 'Head', index = 0 } }
  elseif slot == 'Face' then
    return { { area = 'Face', index = 0 } }
  elseif slot == 'Outer Torso' then
    return { { area = 'OuterChest', index = 0 } }
  elseif slot == 'Inner Torso' then
    return { { area = 'InnerChest', index = 0 } }
  elseif slot == 'Legs' then
    return { { area = 'Legs', index = 0 } }
  elseif slot == 'Feet' then
    return { { area = 'Feet', index = 0 } }
  elseif slot == 'Outfit' then
    return { { area = 'Outfit', index = 0 } }
  end
  return { { area = slot, index = 0 } }
end

local function _getEquippedItemRecordForSlot(slotKey)
  local p = _getPlayer()
  if not p then return nil end
  local descriptors = _equippedSlotDescriptors(slotKey)
  for i = 1, #descriptors do
    local desc = descriptors[i]
    local item = _getItemInEquipSlotForRule(p, desc.area, desc.index or 0)
    local recordId = _extractEquippedItemRecordId(item)
    if recordId ~= nil and recordId ~= '' then return recordId end
  end
  return nil
end

local function _normalizeItemComparable(value)
  local s = _extractItemsIdFromAny(value) or _cleanValueString(value) or ''
  s = _trim(s)
  return string.lower(s)
end

local function _itemIdMatches(currentId, wantedId)
  local current = _normalizeItemComparable(currentId)
  local wanted = _normalizeItemComparable(wantedId)
  if current == '' or wanted == '' then return false end
  if current == wanted then return true end
  local cShort = current:gsub('^items%.', '')
  local wShort = wanted:gsub('^items%.', '')
  return cShort ~= '' and cShort == wShort
end

local function _getOwnedItemQuantity(itemId)
  local id = _trim(itemId)
  if id == "" then return 0 end

  local cache = Move.itemOwnership.cache or {}
  Move.itemOwnership.cache = cache
  local now = os.clock()
  local cached = cache[id]
  if type(cached) == "table" and now < tonumber(cached.nextAt or 0) then
    return tonumber(cached.qty or 0) or 0
  end

  local p = (GetPlayer and GetPlayer()) or (Game.GetPlayer and Game.GetPlayer()) or nil
  local ts = (Game.GetTransactionSystem and Game.GetTransactionSystem()) or nil
  if not p or not ts then
    cache[id] = { qty = 0, nextAt = now + (Move.itemOwnership.refreshEvery or 0.25) }
    return 0
  end

  local qty = 0
  local candidates = { id }
  local function addCandidate(v)
    if v ~= nil then candidates[#candidates + 1] = v end
  end

  if TweakDBID and TweakDBID.new and ItemID and ItemID.FromTDBID then
    pcall(function() addCandidate(ItemID.FromTDBID(TweakDBID.new(id))) end)
  end
  if TweakDBID and TweakDBID.new then
    pcall(function() addCandidate(TweakDBID.new(id)) end)
  end

  for _, candidate in ipairs(candidates) do
    local ok, value = pcall(function() return ts:GetItemQuantity(p, candidate) end)
    if ok and type(value) == "number" then qty = value break end
    ok, value = pcall(function() return ts:GetItemQuantity(candidate) end)
    if ok and type(value) == "number" then qty = value break end
  end

  cache[id] = { qty = qty, nextAt = now + (Move.itemOwnership.refreshEvery or 0.25) }
  return tonumber(qty or 0) or 0
end

local function _vehExtractId(obj)
  if obj == nil then return nil end
  if type(obj) == "string" then
    local s = _trim(obj)
    return (s ~= "") and s or nil
  end
  if type(obj) == "userdata" then
    local probes = {
      function() if obj.GetID then return obj:GetID() end end,
      function() if obj.GetRecordID then return obj:GetRecordID() end end,
      function() if obj.GetVehicleRecordID then return obj:GetVehicleRecordID() end end,
      function() if obj.ToString then return obj:ToString() end end,
      function() return obj.recordID end,
      function() return obj.id end,
    }
    for _, fn in ipairs(probes) do
      local ok, res = pcall(fn)
      if ok and res ~= nil then
        if type(res) == "string" then
          local s = _trim(res)
          if s ~= "" then return s end
        end
        local ts = tostring(res)
        if ts ~= nil and ts ~= "" and ts:find("userdata") == nil then
          local tok = ts:match("(Vehicle%.[%w_]+)")
          if tok ~= nil and tok ~= "" then return tok end
        end
      end
    end
  end
  return nil
end

local function _refreshOwnedVehicleIds()
  local now = os.clock()
  if now < tonumber(Move.ownedVehicles._nextRefresh or 0) then return end
  Move.ownedVehicles._nextRefresh = now + (Move.ownedVehicles.refreshEvery or 2.0)
  Move.ownedVehicles.ids = {}

  local vs = _pcall(function() return Game.GetVehicleSystem() end)
  if not vs then return end

  local list = nil
  if vs.GetPlayerUnlockedVehicles ~= nil then list = _pcall(function() return vs:GetPlayerUnlockedVehicles() end) end
  if list == nil and vs.GetPlayerVehicles ~= nil then list = _pcall(function() return vs:GetPlayerVehicles() end) end
  if list == nil and vs.GetVehicles ~= nil then list = _pcall(function() return vs:GetVehicles() end) end
  if list == nil then return end

  if type(list) == "userdata" then
    local tmp = {}
    pcall(function() for _, it in ipairs(list) do tmp[#tmp + 1] = it end end)
    list = tmp
  end
  if type(list) ~= "table" then return end

  local ids = {}
  for _, v in ipairs(list) do
    local id = _vehExtractId(v)
    if id ~= nil then ids[_trim(id)] = true end
  end
  Move.ownedVehicles.ids = ids
end

local function _isVehicleOwned(vehicleId)
  local id = _trim(vehicleId)
  if id == "" then return false end
  _refreshOwnedVehicleIds()
  return Move.ownedVehicles.ids[id] == true
end

local function _opEval(cur, op, target)
  if type(cur) ~= "number" or type(target) ~= "number" then return nil end
  if op == "==" then return (cur == target)
  elseif op == "~=" then return (cur ~= target)
  elseif op == ">" then return (cur > target)
  elseif op == "<" then return (cur < target)
  elseif op == ">=" then return (cur >= target)
  elseif op == "<=" then return (cur <= target)
  end
  return nil
end


local _statsUiCache = nil
local function _getStatsUI()
  if _statsUiCache == false then return nil end
  if _statsUiCache == nil then
    local ok, mod = pcall(require, "GTS/stats_browser")
    _statsUiCache = ok and mod or false
  end
  return _statsUiCache ~= false and _statsUiCache or nil
end

local function _normalizeCustomObserverSource(src)
  src = tostring(src or "Current Amount")
  if src == "Pool Current" then return "Current Amount" end
  if src == "Pool Max" then return "Max Amount" end
  if src == "Pool %" then return "Pool Percent" end
  if src ~= "Current Amount" and src ~= "Max Amount" and src ~= "Pool Percent" and src ~= "Stat Value" then
    src = "Current Amount"
  end
  return src
end

local function _customObserverSourceOptions()
  return {"Current Amount", "Max Amount", "Pool Percent", "Stat Value"}
end


local function _customObserverCompareModeOptions(source)
  local src = _normalizeCustomObserverSource(source)
  if src == "Current Amount" then return {"True Number", "Percent"} end
  if src == "Pool Percent" then return {"Percent"} end
  return {"True Number"}
end

local function _normalizeCustomObserverCompareMode(source, mode)
  local opts = _customObserverCompareModeOptions(source)
  local wanted = tostring(mode or opts[1] or "True Number")
  for i = 1, #opts do
    if tostring(opts[i]) == wanted then return tostring(opts[i]) end
  end
  return tostring(opts[1] or "True Number")
end

local function _resolveCustomObserverTarget(def, snap)
  local src = _normalizeCustomObserverSource((def or {}).src or "Current Amount")
  local compareMode = _normalizeCustomObserverCompareMode(src, (def or {}).compareMode or "True Number")
  local rawTarget = tonumber((def or {}).value or (def or {}).valueStr)
  if rawTarget == nil then return nil, nil, compareMode end
  if src == "Current Amount" and compareMode == "Percent" then
    local maxValue = type(snap) == "table" and tonumber(snap.max) or nil
    if maxValue == nil then return nil, rawTarget, compareMode end
    return (rawTarget / 100.0) * maxValue, rawTarget, compareMode
  end
  return rawTarget, rawTarget, compareMode
end

local function _customConditionLabel(def)
  def = def or {}
  local src = _normalizeCustomObserverSource(def.src or "Current Amount")
  local compareMode = _normalizeCustomObserverCompareMode(src, def.compareMode or "True Number")
  local valueText = tostring(def.valueStr or def.value or "0")
  local statName = tostring(def.stat or "Stat")
  if compareMode == "Percent" then
    if src == "Current Amount" then
      return string.format("Custom: %s (%s) %s %s%% of Max %s", statName, src, tostring(def.op or "=="), valueText, statName)
    end
    return string.format("Custom: %s (%s) %s %s%%", statName, src, tostring(def.op or "=="), valueText)
  end
  if src ~= "Current Amount" then
    return string.format("Custom: %s (%s) %s %s", statName, src, tostring(def.op or "=="), valueText)
  end
  return string.format("Custom: %s %s %s", statName, tostring(def.op or "=="), valueText)
end

local function _customObserverDefFromObserver(o)
  if type(o) ~= "table" then return nil end
  local src = _normalizeCustomObserverSource(o.src or "Current Amount")
  return {
    id = tostring(o.id or ""),
    stat = tostring(o.stat or ""),
    op = tostring(o.op or "=="),
    src = src,
    compareMode = _normalizeCustomObserverCompareMode(src, o.compareMode or "True Number"),
    valueStr = tostring(o.valueStr or o.value or "0"),
    value = tonumber(o.value or o.valueStr or 0) or 0,
    enabled = (o.enabled ~= false),
  }
end

local function _customFindObserverByKey(key)
  local C = Move.custom
  if not (C and type(C.list) == "table") then return nil end
  local wanted = tostring(key or "")
  if wanted == "" then return nil end
  for i = 1, #C.list do
    local o = C.list[i]
    if tostring(o.id or i) == wanted then return o, i end
  end
  return nil
end

local function _evaluateCustomObserverDef(def)
  def = def or {}
  local statName = tostring(def.stat or "")
  local src = _normalizeCustomObserverSource(def.src or "Current Amount")
  local op = tostring(def.op or "==")
  if statName == "" then
    return { cur = nil, max = nil, poolCur = nil, poolMax = nil, percent = nil, value = nil, target = nil, rawTarget = nil, compareMode = _normalizeCustomObserverCompareMode(src, def.compareMode or "True Number"), result = false }
  end

  local StatsUI = _getStatsUI()
  local snap = (StatsUI and type(StatsUI.GetStatSnapshot) == "function") and StatsUI.GetStatSnapshot(statName) or nil
  if type(snap) ~= "table" then
    return { cur = nil, max = nil, poolCur = nil, poolMax = nil, percent = nil, value = nil, target = nil, rawTarget = nil, compareMode = _normalizeCustomObserverCompareMode(src, def.compareMode or "True Number"), result = false }
  end

  local cur = nil
  if src == "Current Amount" then cur = snap.current
  elseif src == "Max Amount" then cur = snap.max
  elseif src == "Pool Percent" then cur = snap.percent
  else cur = snap.value end

  local target, rawTarget, compareMode = _resolveCustomObserverTarget(def, snap)

  return {
    cur = cur,
    max = snap.max,
    poolCur = snap.poolCur,
    poolMax = snap.poolMax,
    percent = snap.percent,
    value = snap.value,
    target = target,
    rawTarget = rawTarget,
    compareMode = compareMode,
    result = _opEval(cur, op, target) == true,
  }
end


local function _customBuildOnce()
  local C = Move.custom
  if C._built then return end
  C.stats = {}
  local records = _pcall(function() return TweakDB:GetRecords("gamedataStat_Record") end)
  if type(records) ~= "table" then
    C._built = true
    return
  end
  for i=1,#records do
    local rec = records[i]
    local name = _pcall(function() return tostring(rec:EnumName()) end) or ""
    if name ~= "" then
      local enum = gamedataStatType[name]
      C.stats[#C.stats+1] = { name=name, enum=enum }
    end
  end
  table.sort(C.stats, function(a,b) return (a.name or "") < (b.name or "") end)
  C._built = true
end

local function _customFilter()
  local C = Move.custom
  local kw = C.addKw or ""
  local key = kw
  if key == C._lastFilter then return end
  C._lastFilter = key
  C._filtered = {}
  local low = string.lower(kw)
  if low == "" then
    for i=1,#C.stats do C._filtered[#C._filtered+1] = C.stats[i] end
  else
    for i=1,#C.stats do
      local s = C.stats[i]
      local n = string.lower(s.name or "")
      if string.find(n, low, 1, true) then
        C._filtered[#C._filtered+1] = s
      end
    end
  end
  if C.addPickIndex < 1 then C.addPickIndex = 1 end
  if C.addPickIndex > #C._filtered then C.addPickIndex = math.max(1, #C._filtered) end
end

local function _customAddObserver(statName, op, valueStr, src, compareMode)
  local C = Move.custom
  if type(statName) ~= "string" or statName == "" then return false end
  local v = tonumber(valueStr)
  if v == nil then return false end
  local id = C._nextId; C._nextId = C._nextId + 1
  C.list[#C.list+1] = {
    id = id,
    enabled = true,
    stat = statName,
    op = op or "==",
    src = _normalizeCustomObserverSource(src or "Current Amount"),
    compareMode = _normalizeCustomObserverCompareMode(src or "Current Amount", compareMode or "True Number"),
    valueStr = tostring(valueStr or "0"),
    value = v,
    cur = nil,
    max = nil,
    result = nil,
  }
  return true
end

local function _customRefresh(delta)
  local C = Move.custom
  if not C.enabled then return end
  local now = os.clock()
  if now < (C._nextRefresh or 0) then return end
  C._nextRefresh = now + (C.refreshEvery or 0.25)

  local ss = _getSS()
  local eid = _getEID()
  if not ss or not eid then
    for i=1,#C.list do
      local o = C.list[i]
      o.cur = nil
      o.max = nil
      o.result = nil
    end
    return
  end

  for i=1,#C.list do
    local o = C.list[i]
    if o.enabled then
      o.value = tonumber(o.valueStr)
      local eval = _evaluateCustomObserverDef(o)
      o.cur = eval.cur
      o.max = eval.max
      o.poolCur = eval.poolCur
      o.poolMax = eval.poolMax
      o.poolPercent = eval.percent
      o.statValue = eval.value
      o.src = _normalizeCustomObserverSource(o.src)
      o.result = eval.result == true
    else
      o.result = nil
    end
  end
end

local function emitState(k,label)
  local now = Move.states[k]
  if now ~= Move.prev[k] then
    local kind = now and "ENTER" or "EXIT"
    local msg
    if (not now) and Move.overrideExit and Move.overrideExit[k] then
      msg = "[Move] "..label.." "..kind.." [OVERRIDE]"
      Move.overrideExit[k] = nil
    else
      msg = "[Move] "..label.." "..kind
    end
    print(msg)
    pushEvent(msg, kind)
    Move.prev[k] = now
  end
end

-- Vehicle detection
local function getVehicle()
  local p=Game.GetPlayer()
  if not p then return nil end
  local ws=Game.GetWorkspotSystem()
  if not ws or not ws:IsActorInWorkspot(p) then return nil end
  local fn=Game["GetMountedVehicle;GameObject"]
  return fn and fn(p) or nil
end

local function getVehicleLabel(v)
  if not v then return nil end
  local ok,name=pcall(function() return v:GetDisplayName() end)
  if ok and name and tostring(name)~="" then return tostring(name) end
  return tostring(v)
end

-- Target refresh (look-at target)
local function refreshTarget()
  local T = Move.target
  if not T then return end
  local snap = TargetService and TargetService.GetSnapshot and TargetService.GetSnapshot(false) or nil
  if type(snap) ~= "table" then
    T.exists=false; T.isNPC=false; T.faction=nil; T.hostile=false; T.aggro=false
    T.distance=0; T.speed=0; T.health=0; T.className=nil; T._obj=nil
    return
  end
  T.exists = snap.exists == true
  T.isNPC = snap.isNPC == true
  T.faction = snap.faction
  T.hostile = snap.hostile == true
  T.aggro = snap.aggro == true
  T.distance = tonumber(snap.distance or 0) or 0
  T.speed = tonumber(snap.speed or 0) or 0
  T.health = tonumber(snap.health or 0) or 0
  T.className = snap.className
  T._obj = snap.handle
end

-- Conditions
safeObserve("SprintEvents","OnEnter",function() setState("running",true) end)
safeObserve("SprintEvents","OnExit",function() setState("running",false) end)
safeObserve("JumpEvents","OnEnter",function() setState("jumping",true) end)
safeObserve("JumpEvents","OnExit",function() setState("jumping",false) end)
safeObserve("CrouchEvents","OnEnter",function() setState("crouched",true) end)
safeObserve("CrouchEvents","OnExit",function() setState("crouched",false) end)
safeObserve("SlideEvents","OnEnter",function() setState("sliding",true) end)
safeObserve("SlideEvents","OnExit",function() setState("sliding",false) end)
safeObserve("LocomotionAirEvents","OnEnter",function() setState("inAir",true) end)
safeObserve("LocomotionAirEvents","OnExit",function() setState("inAir",false) end)
safeObserve("ReloadEvents","OnEnter",function() setState("reloading",true) end)
safeObserve("ReloadEvents","OnExit",function() setState("reloading",false) end)
safeObserve("DashEvents","OnEnter",function() setState("dashing",true) end)
safeObserve("DashEvents","OnExit",function() setState("dashing",false) end)
safeObserve("DodgeEvents","OnEnter",function() setState("dodging",true) end)
safeObserve("DodgeEvents","OnExit",function() setState("dodging",false) end)
safeObserve("ShootEvents","OnEnter",function() Move.shotAt=os.clock(); setState("shooting",true) end)
safeObserve("AimingStateEvents","OnEnter",function() setState("aiming",true) end)
safeObserve("AimingStateEvents","OnExit",function() setState("aiming",false) end)
safeObserve("MeleeAttackGenericEvents","OnEnter",function() Move.meleeAt=os.clock(); setState("meleeAttack",true) end)
safeObserve("QuickMeleeEvents","OnEnter",function() Move.meleeAt=os.clock(); setState("meleeAttack",true) end)
safeObserve("MeleeStrongAttackEvents","OnEnter",function() Move.meleeAt=os.clock(); setState("meleeAttack",true) end)

-- =========================
-- Sanity / Override Layer
-- =========================
local function stateLabel(k)
  if k=="running" then return "RUNNING"
  elseif k=="jumping" then return "JUMPING"
  elseif k=="crouched" then return "CROUCHED"
  elseif k=="sliding" then return "SLIDING"
  elseif k=="inAir" then return "IN AIR"
  elseif k=="reloading" then return "RELOADING"
  elseif k=="shooting" then return "SHOOTING"
  elseif k=="swimming" then return "SWIMMING"
  elseif k=="dashing" then return "DASHING"
  elseif k=="dodging" then return "DODGING"
  elseif k=="aiming" then return "AIMING"
  elseif k=="meleeAttack" then return "MELEE ATTACK"
  elseif k=="inVehicle" then return "IN VEHICLE"
  elseif k=="weaponActive" then return "WEAPON ACTIVE"
  end
  return string.upper(tostring(k))
end

local function forceFalse(k, reason)
  if Move.states[k] then
    Move.states[k] = false
    Move.overrideExit[k] = reason or true
  end
end

local function updateMotion(dt)
  local p = Game.GetPlayer()
  if not p then return end
  local ok,pos = pcall(function() return p:GetWorldPosition() end)
  if not ok or not pos then return end

  local m = Move.motion
  if not m.inited or not m.lastPos then
    m.inited = true
    m.lastPos = pos
    m.stillXY = 0
    m.stillZ  = 0
    m.stillAll = 0
    return
  end

  local dx = pos.x - m.lastPos.x
  local dy = pos.y - m.lastPos.y
  local dz = pos.z - m.lastPos.z

  local dxy = math.sqrt(dx*dx + dy*dy)
  local adz = math.abs(dz)

  local stillXY = dxy < (m.epsXY or 0.03)
  local stillZ  = adz < (m.epsZ or 0.03)

  m.stillXY  = stillXY and (m.stillXY + dt) or 0
  m.stillZ   = stillZ  and (m.stillZ  + dt) or 0
  m.stillAll = (stillXY and stillZ) and (m.stillAll + dt) or 0

  m.lastPos = pos
end

local function resolveExclusives()
  -- last-activation wins within exclusive pairs/groups
  local function newer(a,b)
    local ta = Move.lastTrueTime[a] or 0
    local tb = Move.lastTrueTime[b] or 0
    return ta > tb
  end

  -- Vehicle gating (hard)
  if Move.prevHadVehicle then
    forceFalse("running","vehicle")
    forceFalse("jumping","vehicle")
    forceFalse("crouched","vehicle")
    forceFalse("sliding","vehicle")
    forceFalse("inAir","vehicle")
    forceFalse("dashing","vehicle")
    forceFalse("dodging","vehicle")
    -- keep shooting/reloading alone; swimming should not be true in a vehicle
    forceFalse("swimming","vehicle")
    return
  end

  -- Movement sanity (no-change evidence)
  local m = Move.motion
  if (m.stillAll or 0) >= 1.0 then
    forceFalse("running","still")
    forceFalse("sliding","still")
    forceFalse("dashing","still")
    forceFalse("dodging","still")
  end
  if (m.stillXY or 0) >= 1.0 then
    forceFalse("running","no_xy")
    forceFalse("sliding","no_xy")
    forceFalse("dashing","no_xy")
    forceFalse("dodging","no_xy")
  end
  if (m.stillZ or 0) >= 2.0 then
    forceFalse("inAir","no_z")
    forceFalse("jumping","no_z")
  end

  -- Mutual exclusives (priority + last-activation overrides)
  -- Crouch overrides Running if it activates after it
  if Move.states.crouched and Move.states.running and newer("crouched","running") then
    forceFalse("running","crouch_override")
  end

  -- InAir beats ground actions
  if Move.states.inAir then
    forceFalse("running","in_air")
    forceFalse("sliding","in_air")
    forceFalse("dashing","in_air")
    forceFalse("dodging","in_air")
  end

  -- Sliding beats dash/dodge/running/crouch
  if Move.states.sliding then
    forceFalse("running","sliding")
    forceFalse("crouched","sliding")
    forceFalse("dashing","sliding")
    forceFalse("dodging","sliding")
  end

  -- Dodging beats dashing/running/crouch
  if Move.states.dodging then
    forceFalse("running","dodging")
    forceFalse("crouched","dodging")
    forceFalse("dashing","dodging")
  end

  -- Dashing beats running/crouch
  if Move.states.dashing then
    forceFalse("running","dashing")
    forceFalse("crouched","dashing")
  end

  -- Crouched beats running (even if crouch flag latches after)
  if Move.states.crouched then
    forceFalse("running","crouched")
  end
end

function MoveObserver.OnUpdate(delta)
  _customRefresh(delta)

  -- derived movement (velocity-based)
  do
    local p = Game.GetPlayer()
    if p and p.GetVelocity then
      local ok, vel = pcall(function() return p:GetVelocity() end)
      if ok and vel then
        local vx = vel.x or 0
        local vy = vel.y or 0
        local vz = vel.z or 0
        local sp = math.sqrt(vx*vx + vy*vy + vz*vz)
        Move.playerSpeed = sp
        Move.isMoving = (sp > 0.05)
      else
        Move.playerSpeed = 0
        Move.isMoving = false
      end
    else
      Move.playerSpeed = 0
      Move.isMoving = false
    end
  end

  local activeWeaponId = _getActiveWeaponKey()
  Move.activeWeaponId = activeWeaponId
  setState("weaponActive", _trim(activeWeaponId) ~= "")

  local v=getVehicle()
  local has=v~=nil
  setState("inVehicle", has)

  if has and not Move.prevHadVehicle then
    local label=getVehicleLabel(v)
    local msg="[Move] VEH ENTER | "..label
    pushEvent(msg,"ENTER")
    Move.prevHadVehicle=true; Move.prevLabel=label; Move.currentVehicleLabel=label
  elseif not has and Move.prevHadVehicle then
    local msg="[Move] VEH EXIT  | "..(Move.prevLabel or "")
    pushEvent(msg,"EXIT")
    Move.prevHadVehicle=false; Move.prevLabel=nil; Move.currentVehicleLabel=nil
  else
    Move.currentVehicleLabel=has and getVehicleLabel(v) or nil
  end

  -- update look-at target observers
  refreshTarget()

  if Move.states.shooting and os.clock()-Move.shotAt>Move.shotWin then
    setState("shooting",false)
  end
  if Move.states.meleeAttack and os.clock()-Move.meleeAt>Move.meleeWin then
    setState("meleeAttack",false)
  end


-- reset override markers for this tick
Move.overrideExit = {}

-- update motion evidence and apply sanity/override rules
updateMotion(delta or 0)
resolveExclusives()
  emitState("running","RUNNING")
  emitState("jumping","JUMPING")
  emitState("crouched","CROUCHED")
  emitState("sliding","SLIDING")
  emitState("inAir","IN AIR")
  emitState("reloading","RELOADING")
  emitState("shooting","SHOOTING")
  emitState("swimming","SWIMMING")
  emitState("dashing","DASHING")
  emitState("dodging","DODGING")
  emitState("aiming","AIMING")
  emitState("meleeAttack","MELEE ATTACK")
  emitState("inVehicle","IN VEHICLE")
  emitState("weaponActive","WEAPON ACTIVE")
end

-- Safe color helpers
local function drawBool(label,val)
  ImGui.TableNextRow()
  ImGui.TableSetColumnIndex(0); ImGui.Text(label)
  ImGui.TableSetColumnIndex(1)

  if Move.ui.colors then
    if val then
      ImGui.PushStyleColor(ImGuiCol.Text,0xFF00FF00)
    else
      ImGui.PushStyleColor(ImGuiCol.Text,0xFF0000FF)
    end
    ImGui.Text(val and "TRUE" or "FALSE")
    ImGui.PopStyleColor(1)
  else
    ImGui.Text(val and "TRUE" or "FALSE")
  end
end





function MoveObserver.GetCustomObservers()
  local C = Move.custom
  local out = {}
  if C and type(C.list) == "table" then
    for i = 1, #C.list do
      out[#out + 1] = _customObserverDefFromObserver(C.list[i])
    end
  end
  return out
end

function MoveObserver.GetCustomObserverByKey(key)
  local o = _customFindObserverByKey(key)
  if not o then return nil end
  return _customObserverDefFromObserver(o)
end

function MoveObserver.MakeConditionFromCustomObserver(observerOrKey)
  local def = nil
  if type(observerOrKey) == "table" then
    def = _customObserverDefFromObserver(observerOrKey) or observerOrKey
  else
    def = MoveObserver.GetCustomObserverByKey(observerOrKey)
  end
  if type(def) ~= "table" then return nil end
  local key = tostring(def.id or observerOrKey or "")
  if key == "" then key = tostring(os.clock()) end
  return {
    kind = "custom_observer",
    key = key,
    label = _customConditionLabel(def),
    expected = true,
    customObserverDef = {
      id = key,
      stat = tostring(def.stat or ""),
      op = tostring(def.op or "=="),
      src = tostring(def.src or "Stat Value"),
      compareMode = tostring(def.compareMode or "True Number"),
      valueStr = tostring(def.valueStr or def.value or "0"),
      value = tonumber(def.value or def.valueStr or 0) or 0,
      enabled = (def.enabled ~= false),
    },
  }
end

function MoveObserver.ListObserverPresets()
  local assets = AssetRegistry and AssetRegistry.List and AssetRegistry.List("observer_preset") or {}
  local out = {}
  for i = 1, #assets do
    local item = assets[i]
    out[#out + 1] = {
      id = tostring(item.id or ""),
      name = tostring(item.name or item.id or ("Condition Preset " .. tostring(i))),
      observers = _clone(item.observers or {}),
    }
  end
  return out
end

function MoveObserver.SaveCurrentObserversPreset(name)
  local trimmed = _trim(name)
  if trimmed == "" then return nil, "Enter a preset name first." end
  local payload = {
    type = "observer_preset",
    name = trimmed,
    observers = MoveObserver.GetCustomObservers(),
  }
  local saved = ((AssetRegistry.UpsertNew and AssetRegistry.UpsertNew(payload, trimmed)) or (AssetRegistry.Upsert and AssetRegistry.Upsert(payload))) or nil
  if not saved then return nil, "Could not save Condition preset." end
  Move.custom.selectedPresetId = tostring(saved.id or "")
  return saved, string.format("Saved Condition preset '%s'.", tostring(saved.name or trimmed))
end

function MoveObserver.LoadObserverPreset(assetId, append)
  local asset = AssetRegistry.Get and AssetRegistry.Get(assetId) or nil
  if type(asset) ~= "table" or tostring(asset.type or "") ~= "observer_preset" then
    return false, "Missing Condition preset."
  end
  local list = {}
  local nextId = tonumber(Move.custom._nextId or 1) or 1
  if append then
    for i = 1, #(Move.custom.list or {}) do list[#list + 1] = Move.custom.list[i] end
  end
  for i = 1, #((asset.observers) or {}) do
    local def = _clone(asset.observers[i]) or {}
    def.id = nextId
    nextId = nextId + 1
    def.enabled = (def.enabled ~= false)
    def.src = _normalizeCustomObserverSource(def.src or "Current Amount")
    def.compareMode = _normalizeCustomObserverCompareMode(def.src, def.compareMode or "True Number")
    def.valueStr = tostring(def.valueStr or def.value or "0")
    def.value = tonumber(def.value or def.valueStr or 0) or 0
    list[#list + 1] = def
  end
  Move.custom.list = list
  Move.custom._nextId = nextId
  Move.custom.selectedPresetId = tostring(asset.id or "")
  return true, string.format("%s Condition preset '%s'.", append and "Appended" or "Loaded", tostring(asset.name or asset.id or "Preset"))
end

function MoveObserver.DrawTab(ui)
  ui = ui or {compact=false, colors=true}
  Move.ui = Move.ui or {compact=false, colors=true}
  Move.ui.compact = ui.compact
  Move.ui.colors  = ui.colors

  local function drawValueText(text, isBoolTrue, isBool)
    if Move.ui.colors then
      if isBool then
        if isBoolTrue then ImGui.PushStyleColor(ImGuiCol.Text, 0xFF00FF00) else ImGui.PushStyleColor(ImGuiCol.Text, 0xFF0000FF) end
      else
        ImGui.PushStyleColor(ImGuiCol.Text, 0xFFAAAAAA)
      end
    end
    ImGui.Text(text)
    if Move.ui.colors then ImGui.PopStyleColor(1) end
  end

  local function drawMiniRows(rows, childId, width, height)
    if ImGui.BeginChild(childId, width, height, false) then
      ImGui.Columns(2, childId .. "_cols", false)
      for i=1,#rows do
        local r = rows[i]
        ImGui.Text(r.label)
        ImGui.NextColumn()
        if r.isBool then
          drawValueText(r.value and "TRUE" or "FALSE", r.value, true)
        else
          drawValueText(tostring(r.value), false, false)
        end
        ImGui.NextColumn()
      end
      ImGui.Columns(1)
      ImGui.EndChild()
    end
  end

  local T = Move.target or {}
  local leftRows = {
    {label="Running", isBool=true, value=Move.states.running},
    {label="Jumping", isBool=true, value=Move.states.jumping},
    {label="Crouched", isBool=true, value=Move.states.crouched},
    {label="Sliding", isBool=true, value=Move.states.sliding},
    {label="In Air", isBool=true, value=Move.states.inAir},
    {label="Reloading", isBool=true, value=Move.states.reloading},
    {label="Shooting", isBool=true, value=Move.states.shooting},
    {label="Swimming", isBool=true, value=Move.states.swimming},
    {label="Dashing", isBool=true, value=Move.states.dashing},
    {label="Dodging", isBool=true, value=Move.states.dodging},
    {label="Aiming", isBool=true, value=Move.states.aiming},
    {label="Melee Attack", isBool=true, value=Move.states.meleeAttack},
    {label="In Vehicle", isBool=true, value=Move.states.inVehicle},
    {label="Weapon Active", isBool=true, value=Move.states.weaponActive},
  }
  local rightRows = {
    {label="IsMoving", isBool=true, value=Move.isMoving},
    {label="Speed", isBool=false, value=string.format("%.2f", tonumber(Move.playerSpeed or 0) or 0)},
    {label="Target Exists", isBool=true, value=T.exists or false},
    {label="Target Is NPC", isBool=true, value=(T.exists and T.isNPC) or false},
    {label="Target Class", isBool=false, value=T.exists and tostring(T.className or "-") or "-"},
    {label="Faction", isBool=false, value=T.exists and tostring(T.faction or "-") or "-"},
    {label="Hostile", isBool=true, value=(T.exists and T.hostile) or false},
    {label="Aggro", isBool=true, value=(T.exists and T.aggro) or false},
    {label="Distance", isBool=false, value=T.exists and string.format("%.2f", tonumber(T.distance or 0) or 0) or "-"},
    {label="Target Speed", isBool=false, value=T.exists and string.format("%.2f", tonumber(T.speed or 0) or 0) or "-"},
    {label="Target Health", isBool=false, value=T.exists and tostring(T.health or 0) or "-"},
  }

  if Move.states.inVehicle and tostring(Move.currentVehicleLabel or "") ~= "" then
    table.insert(rightRows, 3, {label="Vehicle Name", isBool=false, value=tostring(Move.currentVehicleLabel)})
  end
  if Move.states.weaponActive and tostring(Move.activeWeaponId or "") ~= "" then
    table.insert(rightRows, 3 + (Move.states.inVehicle and 1 or 0), {label="Active Weapon ID", isBool=false, value=tostring(Move.activeWeaponId)})
  end

  local C_inline = Move.custom
  if C_inline and C_inline.enabled and C_inline.list and #C_inline.list > 0 then
    for i2=1,#C_inline.list do
      local o = C_inline.list[i2]
      if o and o.enabled then
        rightRows[#rightRows+1] = {
          label = string.format("%s %s %s", tostring(o.stat or "Stat"), tostring(o.op or "=="), tostring(o.valueStr or "0")),
          isBool = true,
          value = o.result == true
        }
      end
    end
  end

  local availW = ImGui.GetContentRegionAvail()
  local totalW = tonumber((type(availW) == "table" and availW.x) or availW) or tonumber(ImGui.GetWindowWidth and (ImGui.GetWindowWidth() - 36) or 0) or 600
  local gap = 20
  local colW = math.max(200, (totalW - gap) * 0.5)
  drawMiniRows(leftRows, "observer_left", colW, 250)
  ImGui.SameLine()
  drawMiniRows(rightRows, "observer_right", 0, 250)

  ImGui.Separator()
  if ImGui.CollapsingHeader("Custom Stat Conditions") then
    local C = Move.custom
    _customBuildOnce()
    _customFilter()

    C.enabled = _CheckboxValue("Enable Custom Conditions", C.enabled)
    ImGui.SameLine()
    if ImGui.SmallButton("Add##custom_add") then
      ImGui.OpenPopup("custom_add_popup")
    end

    local presetAssets = MoveObserver.ListObserverPresets()
    local presetLabels = {}
    local selectedPresetLabel = "No saved presets"
    for pi = 1, #presetAssets do
      local p = presetAssets[pi]
      presetLabels[#presetLabels + 1] = tostring(p.name or p.id or ("Preset " .. tostring(pi)))
      if tostring(C.selectedPresetId or "") == tostring(p.id or "") then
        selectedPresetLabel = presetLabels[#presetLabels]
      end
    end
    if #presetLabels > 0 then
      selectedPresetLabel = _ComboSelect("Preset##custom_observer_preset", selectedPresetLabel, presetLabels)
      for pi = 1, #presetAssets do
        local p = presetAssets[pi]
        if tostring(selectedPresetLabel) == tostring(p.name or p.id or ("Preset " .. tostring(pi))) then
          C.selectedPresetId = tostring(p.id or "")
          break
        end
      end
    else
      ImGui.TextDisabled("No saved Condition presets yet.")
    end

    C.presetName = _InputTextValue("Preset Name##custom_observer_preset_name", C.presetName or "", 128)
    if ImGui.SmallButton("Save Current As Preset##custom_observer_save_preset") then
      local saved, msg = MoveObserver.SaveCurrentObserversPreset(C.presetName or "")
      pushEvent(msg or (saved and "Saved preset.") or "Could not save preset.", saved and "OK" or "WARN")
      if saved then C.presetName = tostring(saved.name or C.presetName or "") end
    end
    ImGui.SameLine()
    if ImGui.SmallButton("Load Preset##custom_observer_load_preset") and tostring(C.selectedPresetId or "") ~= "" then
      local ok, msg = MoveObserver.LoadObserverPreset(C.selectedPresetId, false)
      pushEvent(msg or (ok and "Loaded preset.") or "Could not load preset.", ok and "OK" or "WARN")
    end
    ImGui.SameLine()
    if ImGui.SmallButton("Append Preset##custom_observer_append_preset") and tostring(C.selectedPresetId or "") ~= "" then
      local ok, msg = MoveObserver.LoadObserverPreset(C.selectedPresetId, true)
      pushEvent(msg or (ok and "Appended preset.") or "Could not append preset.", ok and "OK" or "WARN")
    end

    if ImGui.BeginPopup("custom_add_popup") then
      ImGui.Text("Create a new observer")
      ImGui.Separator()
      C.addKw = _InputTextValue("Search Stat", C.addKw or "", 128)
      _customFilter()

      local ops = {"==","~=",">","<",">=","<="}
      if ImGui.BeginCombo("Operator", tostring(C.addOp or "==")) then
        for i=1,#ops do
          local op = ops[i]
          local sel = (op == C.addOp)
          if ImGui.Selectable(op, sel) then C.addOp = op end
          if sel then ImGui.SetItemDefaultFocus() end
        end
        ImGui.EndCombo()
      end

      local srcs = _customObserverSourceOptions()
      if ImGui.BeginCombo("Source", tostring(_normalizeCustomObserverSource(C.addSrc or "Current Amount"))) then
        for i=1,#srcs do
          local s = srcs[i]
          local sel = (s == _normalizeCustomObserverSource(C.addSrc))
          if ImGui.Selectable(s, sel) then C.addSrc = s end
          if sel then ImGui.SetItemDefaultFocus() end
        end
        ImGui.EndCombo()
      end

      C.addCompareMode = _normalizeCustomObserverCompareMode(C.addSrc or "Current Amount", C.addCompareMode or "True Number")
      C.addCompareMode = _ComboSelect("Compare As", C.addCompareMode or "True Number", _customObserverCompareModeOptions(C.addSrc or "Current Amount"))
      C.addValueStr = _InputTextValue((C.addCompareMode == "Percent") and "Compare Percent" or "Compare Value", C.addValueStr or "300", 32)
      ImGui.Text("Stat")
      if ImGui.BeginChild("custom_stat_pick", 0, 180, true) then
        for i=1,#C._filtered do
          local s = C._filtered[i]
          local selected = (i == C.addPickIndex)
          if ImGui.Selectable(tostring(s.name or "?"), selected) then C.addPickIndex = i end
        end
        ImGui.EndChild()
      end

      local picked = C._filtered[C.addPickIndex]
      if picked then ImGui.Text("Picked: " .. tostring(picked.name or "?")) end

      local previewExpr = (picked and tostring(picked.name or "Stat") or "Stat") .. " " .. tostring(C.addOp or "==") .. " " .. tostring(C.addValueStr or "0")
      if _normalizeCustomObserverSource(C.addSrc or "Current Amount") ~= "Current Amount" then
        previewExpr = previewExpr .. " [" .. tostring(_normalizeCustomObserverSource(C.addSrc or "Current Amount")) .. "]"
      end
      ImGui.TextDisabled("Expression: " .. previewExpr)

      if ImGui.Button("Add Condition##do_add_custom") then
        if picked and _customAddObserver(picked.name, C.addOp, C.addValueStr, C.addSrc, C.addCompareMode) then
          ImGui.CloseCurrentPopup()
        end
      end
      ImGui.SameLine()
      if ImGui.Button("Cancel##cancel_add_custom") then ImGui.CloseCurrentPopup() end

      ImGui.EndPopup()
    end

    ImGui.Separator()
    for i=#C.list,1,-1 do
      local o = C.list[i]
      local headerExpr = string.format("[%s] %s", o.enabled and "ON" or "OFF", _customConditionLabel(o))
      if ImGui.CollapsingHeader(string.format("%s##custom_obs_%d", headerExpr, tonumber(o.id or i))) then
        o.enabled = _CheckboxValue("Enabled##custom_enabled_" .. tostring(o.id), o.enabled == true)
        ImGui.TextDisabled("Expression: " .. _customConditionLabel(o))
        if o.cur ~= nil then
          ImGui.TextDisabled(string.format("Live: %s %s %s | Result %s", tostring(o.cur), tostring(o.op or "=="), tostring(o.valueStr or o.value or "0"), (o.result == true) and "TRUE" or "FALSE"))
        end
        o.valueStr = _InputTextValue("Compare Value##custom_value_" .. tostring(o.id), o.valueStr or tostring(o.value or 0), 32)
        o.value = tonumber(o.valueStr or "") or o.value or 0

        local ops2 = {"==","~=",">","<",">=","<="}
        if ImGui.BeginCombo("Operator##custom_op_" .. tostring(o.id), tostring(o.op or "==")) then
          for j=1,#ops2 do
            local op = ops2[j]
            local sel = (op == o.op)
            if ImGui.Selectable(op, sel) then o.op = op end
            if sel then ImGui.SetItemDefaultFocus() end
          end
          ImGui.EndCombo()
        end

        local srcs2 = _customObserverSourceOptions()
        if ImGui.BeginCombo("Source##custom_src_" .. tostring(o.id), tostring(_normalizeCustomObserverSource(o.src or "Current Amount"))) then
          for j=1,#srcs2 do
            local s = srcs2[j]
            local sel = (s == _normalizeCustomObserverSource(o.src))
            if ImGui.Selectable(s, sel) then o.src = s end
            if sel then ImGui.SetItemDefaultFocus() end
          end
          ImGui.EndCombo()
        end

        o.compareMode = _normalizeCustomObserverCompareMode(o.src or "Current Amount", o.compareMode or "True Number")
        o.compareMode = _ComboSelect("Compare As##custom_cmp_" .. tostring(o.id), o.compareMode or "True Number", _customObserverCompareModeOptions(o.src or "Current Amount"))
        ImGui.Text("Current: " .. tostring(o.cur))
        if o.max ~= nil then ImGui.Text("Max: " .. tostring(o.max)) end
        if o.poolPercent ~= nil then ImGui.Text("Pool %: " .. tostring(o.poolPercent)) end
        ImGui.Text("Result: " .. tostring(o.result == true and "TRUE" or "FALSE"))
        if ImGui.Button("Remove##custom_remove_" .. tostring(o.id)) then
          table.remove(C.list, i)
        end
      end
    end
  end
end



local function _isPreGameStateForRule()
  if not GetSingleton then return false end
  local scenario = _pcall(function() return GetSingleton('inkMenuScenario') end)
  if not scenario or type(scenario.GetSystemRequestsHandler) ~= 'function' then return false end
  local handler = _pcall(function() return scenario:GetSystemRequestsHandler() end)
  if not handler or type(handler.IsPreGame) ~= 'function' then return false end
  return _pcall(function() return handler:IsPreGame() end) == true
end

local function _isGameplayReadyForRule()
  local player = (Game and Game.GetPlayer and Game.GetPlayer()) or nil
  if not player or type(player.IsAttached) ~= 'function' then return false end
  if _pcall(function() return player:IsAttached() end) ~= true then return false end
  return not _isPreGameStateForRule()
end

local function _preventionSystemForRule()
  if Game and Game.GetScriptableSystemsContainer then
    local ok, ps = pcall(function() return Game.GetScriptableSystemsContainer():Get('PreventionSystem') end)
    if ok then return ps end
  end
  return nil
end

local function _getWantedLevelForRule()
  local ps = _preventionSystemForRule()
  if not ps then return 0 end
  local attempts = {
    function() return ps:GetHeatStage() end,
    function() return ps:GetCurrentHeatStage() end,
    function() return ps:GetHeatLevel() end,
  }
  local value = nil
  for _, fn in ipairs(attempts) do
    value = _pcall(fn)
    if value ~= nil then break end
  end
  if type(value) == 'number' then
    local lv = math.floor(value)
    if lv < 0 then lv = 0 end
    if lv > 5 then lv = 5 end
    return lv
  end
  local text = tostring(value or '')
  local n = text:match('Heat_(%d)') or text:match('(%d)')
  n = tonumber(n or 0) or 0
  if n < 0 then n = 0 end
  if n > 5 then n = 5 end
  return math.floor(n)
end

function MoveObserver.ListRuleConditions()
  local out = {
    { label = "Condition: Running", kind = "observer_state", key = "running" },
    { label = "Condition: Jumping", kind = "observer_state", key = "jumping" },
    { label = "Condition: Crouched", kind = "observer_state", key = "crouched" },
    { label = "Condition: Sliding", kind = "observer_state", key = "sliding" },
    { label = "Condition: In Air", kind = "observer_state", key = "inAir" },
    { label = "Condition: Reloading", kind = "observer_state", key = "reloading" },
    { label = "Condition: Shooting", kind = "observer_state", key = "shooting" },
    { label = "Condition: Swimming", kind = "observer_state", key = "swimming" },
    { label = "Condition: Dashing", kind = "observer_state", key = "dashing" },
    { label = "Condition: Dodging", kind = "observer_state", key = "dodging" },
    { label = "Condition: Aiming", kind = "observer_state", key = "aiming" },
    { label = "Condition: Melee Attack", kind = "observer_state", key = "meleeAttack" },
    { label = "Condition: In Vehicle", kind = "observer_state", key = "inVehicle" },
    { label = "Condition: Weapon Active", kind = "observer_state", key = "weaponActive" },
    { label = "Condition: Is Item Owned...", kind = "owned_item", key = "owned_item", itemId = "" },
    { label = "Condition: Is Vehicle Owned...", kind = "owned_vehicle", key = "owned_vehicle", vehicleId = "" },
    { label = "Condition: Is Weapon Active...", kind = "active_weapon_id", key = "active_weapon_id", weaponId = "" },
    { label = "Condition: Is Item Active...", kind = "equipped_slot_item", key = "equipped_slot_item", slotKey = "Slot 1", itemId = "" },
    { label = "Condition: Target Exists", kind = "observer_state", key = "target_exists" },
    { label = "Condition: Target Is NPC", kind = "observer_state", key = "target_npc" },
    { label = "Condition: Target Class Is...", kind = "target_class", key = "target_class", targetClass = "NPCPuppet" },
    { label = "Condition: Target Hostile", kind = "observer_state", key = "target_hostile" },
    { label = "Condition: Target Aggro", kind = "observer_state", key = "target_aggro" },
    { label = "Condition: Target Within X Meters...", kind = "target_distance", key = "target_distance", distanceMode = "within", meters = 10 },
    { label = "Condition: Target Farther Than X Meters...", kind = "target_distance", key = "target_distance", distanceMode = "farther", meters = 10 },
    { label = "Condition: In Game", kind = "in_game", key = "in_game" },
    { label = "Condition: In Combat", kind = "observer_state", key = "in_combat" },
    { label = "Condition: Difficulty...", kind = "difficulty_level", key = "difficulty_level", difficulty = "Story" },
    { label = "Condition: Active Quest ID...", kind = "tracked_quest_id", key = "tracked_quest_id", questId = "" },
    { label = "Condition: Wanted Level...", kind = "wanted_level", key = "wanted_level", compareMode = "at_least", level = 1 },
    { label = "Condition: Target Health...", kind = "target_health", key = "target_health", compareOp = "<=", healthValue = 0 },
    { label = "Condition: Target Faction...", kind = "target_faction", key = "target_faction", faction = "" },
  }
  local C = Move.custom
  if C and type(C.list) == "table" then
    for i = 1, #C.list do
      local o = C.list[i]
      out[#out + 1] = {
        label = _customConditionLabel(o),
        kind = "custom_observer",
        key = tostring(o.id or i),
        customObserverDef = _customObserverDefFromObserver(o),
      }
    end
  end
  return out
end

local function _conditionKeyLooksLikeObserverState(key)
  key = tostring(key or "")
  if key == "" then return false end
  if Move.states and Move.states[key] ~= nil then return true end
  if key == "target_exists" or key == "target_npc" or key == "target_hostile" or key == "target_aggro" or key == "in_game" or key == "in_combat" then return true end
  return false
end

local function _inferConditionKind(cond)
  cond = cond or {}
  local kind = tostring(cond.kind or "")
  if kind ~= "" then return kind end

  if tostring(kind) == "saved_stat_condition" or tostring(cond.key or "") == "saved_stat_condition" or cond.ref ~= nil and tostring(cond.label or "") == "Condition: Saved Stat Condition" then return "saved_stat_condition" end
  if type(cond.customObserverDef) == "table" then return "custom_observer" end
  if cond.stat ~= nil and cond.op ~= nil and (cond.value ~= nil or cond.valueStr ~= nil) then return "custom_observer" end
  if cond.slotKey ~= nil and cond.itemId ~= nil then return "equipped_slot_item" end
  if cond.questId ~= nil then return "tracked_quest_id" end
  if cond.difficulty ~= nil then return "difficulty_level" end
  if cond.zoneType ~= nil then return "zone_state" end
  if cond.distanceMode ~= nil and cond.meters ~= nil then return "target_distance" end
  if cond.effectId ~= nil and tostring(cond.scope or '') == 'target' then return "target_status_effect" end
  if cond.effectId ~= nil then return "player_status_effect" end
  if cond.itemId ~= nil then return "owned_item" end
  if cond.vehicleId ~= nil then return "owned_vehicle" end
  if cond.weaponId ~= nil then return "active_weapon_id" end
  if cond.targetClass ~= nil then return "target_class" end
  if cond.compareMode ~= nil and cond.level ~= nil then return "wanted_level" end
  if cond.compareOp ~= nil and cond.healthValue ~= nil then return "target_health" end
  if cond.faction ~= nil then return "target_faction" end
  if _conditionKeyLooksLikeObserverState(cond.key) then return "observer_state" end

  local label = tostring(cond.label or "")
  if label:find("^Custom:") then return "custom_observer" end
  return kind
end

local function _conditionCustomObserverDef(cond)
  cond = cond or {}
  if type(cond.customObserverDef) == "table" then
    local def = _clone(cond.customObserverDef)
    def.stat = tostring(def.stat or cond.stat or "")
    def.op = tostring(def.op or cond.op or "==")
    def.src = tostring(def.src or cond.src or "Stat Value")
    def.valueStr = tostring(def.valueStr or def.value or cond.valueStr or cond.value or "0")
    def.value = tonumber(def.value or def.valueStr or cond.value or cond.valueStr or 0) or 0
    return def
  end
  if cond.stat ~= nil and cond.op ~= nil and (cond.value ~= nil or cond.valueStr ~= nil) then
    return {
      stat = tostring(cond.stat or ""),
      op = tostring(cond.op or "=="),
      src = tostring(cond.src or "Stat Value"),
      valueStr = tostring(cond.valueStr or cond.value or "0"),
      value = tonumber(cond.value or cond.valueStr or 0) or 0,
      enabled = (cond.enabled ~= false),
    }
  end
  return nil
end

local function _evaluateSavedObserverPresetAsset(asset)
  if type(asset) ~= "table" or tostring(asset.type or "") ~= "observer_preset" then
    return { ok = false, reason = "Missing Stat Condition." }
  end
  local observers = type(asset.observers) == "table" and asset.observers or {}
  if #observers == 0 then
    return { ok = false, reason = "Saved Stat Condition has no rows." }
  end
  local allTrue = true
  local parts = {}
  for i = 1, #observers do
    local row = observers[i] or {}
    local def = _customObserverDefFromObserver(row) or row
    local eval = _evaluateCustomObserverDef(def)
    local rowOk = (eval.result == true)
    if row.enabled == false then
      parts[#parts + 1] = string.format("[%d] OFF", i)
    else
      parts[#parts + 1] = string.format("[%d] %s", i, rowOk and "TRUE" or "FALSE")
      if not rowOk then allTrue = false end
    end
  end
  return { ok = allTrue, reason = table.concat(parts, " | "), total = #observers }
end

function MoveObserver.GetConditionDetail(cond)
  cond = cond or {}
  local kind = _inferConditionKind(cond)
  local key = tostring(cond.key or "")
  local detail = {
    label = tostring(cond.label or cond.key or cond.kind or "Qualifier"),
    kind = kind,
    current = false,
    left = nil,
    op = "==",
    right = true,
    reason = "",
    source = "",
  }

  if kind == "observer_state" then
    if key == "target_exists" then
      detail.label = tostring(cond.label or "Condition: Has Target")
      detail.left = Move.target and Move.target.exists == true
      detail.current = detail.left == true
      if detail.current ~= true then detail.reason = "No valid target" end
      return detail
    elseif key == "target_npc" then
      detail.label = tostring(cond.label or "Condition: Target Is NPC")
      detail.left = Move.target and Move.target.isNPC == true
      detail.current = detail.left == true
      if (Move.target and Move.target.exists) ~= true then detail.reason = "No valid target" end
      return detail
    elseif key == "target_hostile" then
      detail.label = tostring(cond.label or "Condition: Target Hostile")
      detail.left = Move.target and Move.target.hostile == true
      detail.current = detail.left == true
      if (Move.target and Move.target.exists) ~= true then detail.reason = "No valid target" end
      return detail
    elseif key == "target_aggro" then
      detail.label = tostring(cond.label or "Condition: Target Aggro")
      detail.left = Move.target and Move.target.aggro == true
      detail.current = detail.left == true
      if (Move.target and Move.target.exists) ~= true then detail.reason = "No valid target" end
      return detail
    elseif key == "in_game" then
      detail.label = tostring(cond.label or "Condition: In Game")
      detail.left = _isGameplayReadyForRule()
      detail.current = detail.left == true
      if detail.current ~= true then detail.reason = "Player not fully in world" end
      return detail
    elseif key == "in_combat" then
      local state = _getPlayerCombatStateForRule()
      detail.label = tostring(cond.label or "Condition: In Combat")
      detail.left = state ~= nil and state or '<unknown>'
      detail.current = state == true
      if state == nil then detail.reason = 'Combat state unavailable' end
      return detail
    end

    detail.left = Move.states and Move.states[key] == true
    detail.current = detail.left == true
    return detail
  elseif kind == "target_class" then
    local current = Move.target and tostring(Move.target.className or "") or ""
    local wanted = tostring(cond.targetClass or "NPCPuppet")
    detail.left = current ~= "" and current or "<none>"
    detail.op = "=="
    detail.right = wanted
    detail.current = current == wanted
    if (Move.target and Move.target.exists) ~= true then detail.reason = "No valid target" end
    return detail
  elseif kind == "wanted_level" then
    local current = _getWantedLevelForRule()
    local wanted = math.max(0, math.min(5, math.floor(tonumber(cond.level or 0) or 0)))
    local mode = tostring(cond.compareMode or 'at_least')
    detail.left = current
    detail.right = wanted
    detail.op = ({ any='>=', at_most='<=', at_least='>=', exactly='==' })[mode] or '>='
    detail.label = tostring(cond.label or 'Condition: Wanted Level')
    if mode == 'any' then
      detail.current = current > 0
      detail.right = 1
      detail.op = '>='
    elseif mode == 'at_most' then
      detail.current = current <= wanted
    elseif mode == 'exactly' then
      detail.current = current == wanted
    else
      detail.current = current >= wanted
    end
    return detail
  elseif kind == "target_health" then
    local current = tonumber((Move.target or {}).health or 0) or 0
    local wanted = tonumber(cond.healthValue or 0) or 0
    local op = tostring(cond.compareOp or '<=')
    detail.left = current
    detail.op = op
    detail.right = wanted
    detail.label = tostring(cond.label or 'Condition: Target Health')
    if op == '<' then detail.current = current < wanted
    elseif op == '>' then detail.current = current > wanted
    elseif op == '>=' then detail.current = current >= wanted
    elseif op == '==' then detail.current = current == wanted
    else detail.current = current <= wanted end
    if (Move.target and Move.target.exists) ~= true then detail.reason = 'No valid target' end
    return detail
  elseif kind == "target_faction" then
    local current = tostring((Move.target or {}).faction or '')
    local wanted = tostring(cond.faction or '')
    detail.left = current ~= '' and current or '<none>'
    detail.op = 'contains'
    detail.right = wanted ~= '' and wanted or '<blank>'
    detail.label = tostring(cond.label or 'Condition: Target Faction')
    detail.current = (wanted ~= '') and string.find(string.lower(current), string.lower(wanted), 1, true) ~= nil
    if (Move.target and Move.target.exists) ~= true then detail.reason = 'No valid target' end
    return detail
  elseif kind == "owned_item" then
    local qty = tonumber(_getOwnedItemQuantity(cond.itemId or "")) or 0
    detail.left = qty
    detail.op = ">"
    detail.right = 0
    detail.current = qty > 0
    detail.label = tostring(cond.label or ("Condition: Owns Item [" .. tostring(cond.itemId or "") .. "]"))
    return detail
  elseif kind == "owned_vehicle" then
    local wanted = _trim(cond.vehicleId or "")
    local owned = _isVehicleOwned(wanted)
    detail.left = owned == true
    detail.op = "=="
    detail.right = true
    detail.current = owned == true
    detail.label = tostring(cond.label or ("Condition: Owns Vehicle [" .. tostring(wanted or "") .. "]"))
    return detail
  elseif kind == "active_weapon_id" then
    local current = _trim(Move.activeWeaponId or _getActiveWeaponKey() or "")
    local wanted = _trim(cond.weaponId or "")
    detail.left = current ~= "" and current or "<none>"
    detail.op = "=="
    detail.right = wanted ~= "" and wanted or "<none>"
    detail.current = (wanted ~= "") and (current == wanted)
    if current == "" then detail.reason = "No active weapon" end
    return detail
  elseif kind == "equipped_slot_item" then
    local slotKey = tostring(cond.slotKey or EQUIPPED_SLOT_LABELS[1])
    local current = _trim(_getEquippedItemRecordForSlot(slotKey) or "")
    local wanted = _trim(cond.itemId or "")
    detail.label = tostring(cond.label or ("Condition: Is Item Active [" .. tostring(slotKey) .. "]"))
    detail.left = current ~= '' and current or '<none>'
    detail.op = '=='
    detail.right = wanted ~= '' and wanted or '<none>'
    detail.current = (wanted ~= '') and _itemIdMatches(current, wanted)
    if current == '' then detail.reason = 'No equipped item in selected slot' end
    return detail
  elseif kind == "target_distance" then
    local current = tonumber((Move.target or {}).distance or 0) or 0
    local wanted = math.max(0, tonumber(cond.meters or 0) or 0)
    local mode = tostring(cond.distanceMode or 'within')
    detail.label = tostring(cond.label or ((mode == 'farther') and 'Condition: Target Farther Than X Meters' or 'Condition: Target Within X Meters'))
    detail.left = current
    detail.right = wanted
    detail.op = (mode == 'farther') and '>' or '<='
    detail.current = ((Move.target and Move.target.exists) == true) and ((mode == 'farther' and current > wanted) or (mode ~= 'farther' and current <= wanted)) or false
    if (Move.target and Move.target.exists) ~= true then detail.reason = 'No valid target' end
    return detail
  elseif kind == "zone_state" then
    local current = _getZoneLabelForRule()
    local wanted = tostring(cond.zoneType or 'Safe Zone')
    detail.label = tostring(cond.label or 'Condition: Zone Type')
    detail.left = current ~= nil and current or '<unknown>'
    detail.op = '=='
    detail.right = wanted
    detail.current = (current ~= nil) and (string.lower(tostring(current)) == string.lower(tostring(wanted)))
    if current == nil then detail.reason = 'Zone state unavailable' end
    return detail
  elseif kind == "player_status_effect" then
    local Status = _getStatusActions()
    local wanted = _trim(cond.effectId or '')
    local active = (Status and type(Status.IsStatusEffectActive) == 'function' and wanted ~= '') and (Status.IsStatusEffectActive(wanted) == true) or false
    detail.label = tostring(cond.label or 'Condition: Player Has Status Effect')
    detail.left = active
    detail.op = '=='
    detail.right = true
    detail.current = active
    if wanted == '' then detail.reason = 'Enter status effect ID' end
    return detail
  elseif kind == "target_status_effect" then
    local Status = _getStatusActions()
    local wanted = _trim(cond.effectId or '')
    local eid = _getTargetEntityIDForRule()
    local active = (Status and type(Status.HasStatusEffectOnEntity) == 'function' and wanted ~= '' and eid ~= nil) and (Status.HasStatusEffectOnEntity(wanted, eid) == true) or false
    detail.label = tostring(cond.label or 'Condition: Target Has Status Effect')
    detail.left = active
    detail.op = '=='
    detail.right = true
    detail.current = active
    if eid == nil then detail.reason = 'No valid target'
    elseif wanted == '' then detail.reason = 'Enter status effect ID' end
    return detail
  elseif kind == "difficulty_level" then
    local current = _getDifficultyLabelForRule()
    local wanted = tostring(cond.difficulty or 'Story')
    detail.label = tostring(cond.label or 'Condition: Difficulty')
    detail.left = current ~= nil and current or '<unknown>'
    detail.op = '=='
    detail.right = wanted
    detail.current = (current ~= nil) and (string.lower(tostring(current)) == string.lower(tostring(wanted)))
    if current == nil then detail.reason = 'Difficulty unavailable' end
    return detail
  elseif kind == "tracked_quest_id" then
    local wanted = _trim(cond.questId or '')
    local quest = _getTrackedQuestInfoForRule()
    local display = _firstNonEmpty(quest.rawId, quest.detail)
    detail.label = tostring(cond.label or 'Condition: Active Quest ID')
    detail.left = display ~= nil and display or '<none>'
    detail.op = '=='
    detail.right = wanted ~= '' and wanted or '<none>'
    detail.current = (wanted ~= '') and _questInputMatches(quest, wanted)
    if display == nil then detail.reason = tostring(quest.reason or 'Tracked quest unavailable') end
    return detail
  elseif kind == "saved_stat_condition" then
    local asset = (tostring(cond.ref or "") ~= "") and AssetRegistry.Get(cond.ref) or nil
    local eval = _evaluateSavedObserverPresetAsset(asset)
    detail.label = tostring(cond.label or "Condition: Saved Stat Condition")
    detail.left = eval.ok == true
    detail.op = "=="
    detail.right = true
    detail.current = eval.ok == true
    detail.reason = tostring(eval.reason or "")
    return detail
  elseif kind == "custom_observer" then
    local def = _conditionCustomObserverDef(cond)
    if type(def) == "table" then
      local eval = _evaluateCustomObserverDef(def)
      detail.label = tostring(cond.label or _customConditionLabel(def))
      detail.left = eval.cur
      detail.op = tostring(def.op or "==")
      detail.right = (eval.compareMode == "Percent") and (tostring(eval.rawTarget or def.value or def.valueStr or 0) .. "%") or (tonumber(def.value or def.valueStr or 0) or 0)
      detail.current = eval.result == true
      detail.source = _normalizeCustomObserverSource(def.src or "Current Amount")
      detail.compareMode = tostring(eval.compareMode or def.compareMode or "True Number")
      if eval.cur == nil then
        detail.reason = "Stat value unavailable"
      elseif detail.source == "Current Amount" and eval.max ~= nil then
        if tostring(detail.compareMode or "") == "Percent" and eval.target ~= nil then
          detail.reason = string.format("Current %.2f / %.2f | Threshold %.2f (%s%% of max)", tonumber(eval.cur or 0) or 0, tonumber(eval.max or 0) or 0, tonumber(eval.target or 0) or 0, tostring(eval.rawTarget or 0))
        else
          detail.reason = string.format("Current %.2f / %.2f", tonumber(eval.cur or 0) or 0, tonumber(eval.max or 0) or 0)
        end
      elseif detail.source == "Max Amount" and eval.max ~= nil then
        detail.reason = string.format("Max %.2f", tonumber(eval.max or 0) or 0)
      elseif detail.source == "Pool Percent" and eval.percent ~= nil then
        detail.reason = string.format("Pool %.1f%%", tonumber(eval.percent or eval.cur or 0) or 0)
      end
      return detail
    end

    local live = _customFindObserverByKey(key)
    if live ~= nil then
      detail.label = tostring(cond.label or _customConditionLabel(live))
      detail.left = live.cur
      detail.op = tostring(live.op or "==")
      detail.right = tonumber(live.value or live.valueStr or 0) or 0
      detail.current = live.result == true
      detail.source = _normalizeCustomObserverSource(live.src or "Current Amount")
      if live.cur == nil then detail.reason = "Stat value unavailable" end
      return detail
    end

    detail.reason = "Custom observer missing"
    return detail
  end

  detail.reason = "Unsupported qualifier"
  return detail
end

function MoveObserver.GetConditionValue(cond)
  local detail = MoveObserver.GetConditionDetail(cond)
  return detail and detail.current == true or false
end

function MoveObserver.EvaluateCondition(cond)
  cond = cond or {}
  local expected = (cond.expected ~= false)
  local value = MoveObserver.GetConditionValue(cond)
  return (value == true) == expected
end

return MoveObserver
