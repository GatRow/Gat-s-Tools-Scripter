local AssetRegistry = require("GTS/asset_registry")
local RuleRunner = require("GTS/rule_runner")
local RuleBuilder = require("GTS/rule_builder")
local Utils = require("GTS/utils")

local MacroBuilder = MacroBuilder or {}
MacroBuilder.state = MacroBuilder.state or {
  subtab = "Macros",
  selectedMacroId = nil,
  selectedCodeId = nil,
  selectedTeleportId = nil,
  selectedLauncherId = nil,
  draftMacro = AssetRegistry.MakeEmptyMacro("toggle"),
  draftCode = AssetRegistry.MakeEmptyCustomCode("button"),
  draftTeleport = AssetRegistry.MakeEmptyTeleportPreset(),
  draftLauncher = AssetRegistry.MakeEmptyLauncher("button"),
  macroDirty = false,
  codeDirty = false,
  teleportDirty = false,
  launcherDirty = false,
  lastMessage = "Build manual macros, saved CET code, teleports, and launchers here.",
  selectedMacroActionGroup = 1,
  selectedMacroActionIndex = 1,
  selectedMacroOffGroup = 1,
  selectedMacroOffActionIndex = 1,
  launcherAssetSearch = "",
}

local _clone = Utils.clone
local _checkboxValue = Utils.checkboxValue
local _inputTextValue = Utils.inputTextValue
local _inputFloatValue = Utils.inputFloatValue
local _comboSelect = Utils.comboSelect

local function _beginChild(id, w, h, border)
  return ImGui.BeginChild(id, w or 0, h or 0, border == true)
end

local function _actionTypeLabel(t)
  local map = {
    run_created_asset = "Run Created Asset",
    custom_cet_code = "Custom CET Code",
    wait = "Wait / Delay",
  }
  return map[tostring(t or "")] or tostring(t or "Action")
end

local function _newAction(t)
  local a = { type = tostring(t or "run_created_asset") }
  if a.type == "run_created_asset" then
    a.ref = nil
    a.desiredState = "run"
  elseif a.type == "custom_cet_code" then
    a.code = ""
  elseif a.type == "wait" then
    a.seconds = 0.50
  end
  return a
end

local function _ensureGroups(groups, defaultName)
  groups = type(groups) == "table" and groups or {}
  if #groups == 0 then
    groups[1] = { id = string.lower((defaultName or "Group"):gsub("%s+", "_")) .. "_1", name = tostring(defaultName or "Group") .. " 1", mode = "ordered", actions = {} }
  end
  for i = 1, #groups do
    local g = groups[i]
    if type(g) ~= "table" then g = {}; groups[i] = g end
    g.id = tostring(g.id or (string.lower((defaultName or "Group"):gsub("%s+", "_")) .. "_" .. tostring(i)))
    g.name = tostring(g.name or ((defaultName or "Group") .. " " .. tostring(i)))
    g.mode = (tostring(g.mode or "ordered") == "parallel") and "parallel" or "ordered"
    g.actions = type(g.actions) == "table" and g.actions or {}
  end
  return groups
end

local function _createdAssetChoices(excludeId)
  local assets = AssetRegistry.ListCreatedAssets and AssetRegistry.ListCreatedAssets() or AssetRegistry.List() or {}
  local labels, byLabel = {}, {}
  for i = 1, #assets do
    local a = assets[i]
    local t = tostring(a.type or "")
    if tostring(a.id or "") ~= tostring(excludeId or "") and t ~= "observer_preset" then
      local label = string.format("[%s] %s", t, tostring(a.name or a.id or "asset"))
      labels[#labels + 1] = label
      byLabel[label] = a.id
    end
  end
  if #labels == 0 then labels[1] = "(none)" end
  return labels, byLabel
end

local function _assetLabel(assetId)
  local a = assetId and AssetRegistry.Get(assetId) or nil
  if type(a) ~= "table" then return "(choose asset)" end
  return string.format("[%s] %s", tostring(a.type or "asset"), tostring(a.name or a.id or "asset"))
end

local function _runStateLabel(v)
  local map = { run = "Run Once", on = "Toggle On", off = "Toggle Off" }
  return map[tostring(v or "run")] or "Run Once"
end

local function _runCreatedAssetSafe(assetId, desiredState)
  local ok, success, msg = pcall(RuleRunner.RunCreatedAssetById, assetId, desiredState)
  if not ok then return false, tostring(success or "Created asset runtime error") end
  return success == true, msg
end

local function _runDraftAssetSafe(draft, desiredState, runtimeKey)
  local ok, success, msg = pcall(RuleRunner.RunCreatedAssetDraft, draft, desiredState, runtimeKey)
  if not ok then return false, tostring(success or "Draft asset runtime error") end
  return success == true, msg
end

local function _groupSummary(groups)
  local total = 0
  groups = type(groups) == "table" and groups or {}
  for i = 1, #groups do total = total + #((groups[i] or {}).actions or {}) end
  return string.format("%d group(s), %d action(s)", #groups, total)
end

local function _syncMacroDraft()
  local st = MacroBuilder.state
  if st.selectedMacroId and st.macroDirty ~= true then
    local asset = AssetRegistry.Get(st.selectedMacroId)
    if asset and asset.type == "macro" then st.draftMacro = asset end
  end
  st.draftMacro = st.draftMacro or AssetRegistry.MakeEmptyMacro("toggle")
  st.draftMacro.data = st.draftMacro.data or {}
  st.draftMacro.data.mode = (tostring(st.draftMacro.data.mode or "toggle") == "button") and "button" or "toggle"
  st.draftMacro.data.offPolicy = tostring(st.draftMacro.data.offPolicy or ((st.draftMacro.data.mode == "toggle") and "restore" or "none"))
  if st.draftMacro.data.offPolicy ~= "run_off_actions" and st.draftMacro.data.offPolicy ~= "restore" then st.draftMacro.data.offPolicy = "none" end
  st.draftMacro.data.onActionGroups = _ensureGroups(st.draftMacro.data.onActionGroups, "Group")
  st.draftMacro.data.offActionGroups = _ensureGroups(st.draftMacro.data.offActionGroups, "Off Group")
end

local function _syncCodeDraft()
  local st = MacroBuilder.state
  if st.selectedCodeId and st.codeDirty ~= true then
    local asset = AssetRegistry.Get(st.selectedCodeId)
    if asset and asset.type == "custom_code" then st.draftCode = asset end
  end
  st.draftCode = st.draftCode or AssetRegistry.MakeEmptyCustomCode("button")
  st.draftCode.data = st.draftCode.data or { mode = "button", onCode = "", offCode = "" }
  st.draftCode.data.mode = (tostring(st.draftCode.data.mode or "button") == "toggle") and "toggle" or "button"
  st.draftCode.data.onCode = tostring(st.draftCode.data.onCode or "")
  st.draftCode.data.offCode = tostring(st.draftCode.data.offCode or "")
end

local function _syncTeleportDraft()
  local st = MacroBuilder.state
  if st.selectedTeleportId and st.teleportDirty ~= true then
    local asset = AssetRegistry.Get(st.selectedTeleportId)
    if asset and asset.type == "teleport_preset" then st.draftTeleport = asset end
  end
  st.draftTeleport = st.draftTeleport or AssetRegistry.MakeEmptyTeleportPreset()
  st.draftTeleport.data = st.draftTeleport.data or { x = 0, y = 0, z = 0, label = "" }
end

local function _syncLauncherDraft()
  local st = MacroBuilder.state
  if st.selectedLauncherId and st.launcherDirty ~= true then
    local asset = AssetRegistry.Get(st.selectedLauncherId)
    if asset and asset.type == "launcher" then st.draftLauncher = asset end
  end
  st.draftLauncher = st.draftLauncher or AssetRegistry.MakeEmptyLauncher("button")
  st.draftLauncher.data = st.draftLauncher.data or { mode = "button", entries = {} }
  st.draftLauncher.data.mode = (tostring(st.draftLauncher.data.mode or "button") == "toggle") and "toggle" or "button"
  st.draftLauncher.data.entries = type(st.draftLauncher.data.entries) == "table" and st.draftLauncher.data.entries or {}
end

local function _saveAsset(draft, selectedKey, dirtyKey, typeName, saveAsNew)
  local st = MacroBuilder.state
  local name = tostring(draft.name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if name == "" then st.lastMessage = "Give the asset a name first."; return nil end
  draft.name = name
  local payload = _clone(draft)
  local saved, err
  if saveAsNew then
    saved, err = ((AssetRegistry.UpsertNew and AssetRegistry.UpsertNew(payload, name)) or AssetRegistry.Upsert(payload))
  else
    saved, err = AssetRegistry.Upsert(payload)
  end
  if saved then
    st[selectedKey] = saved.id
    st[dirtyKey] = false
    if selectedKey == 'selectedMacroId' then st.draftMacro = saved
    elseif selectedKey == 'selectedCodeId' then st.draftCode = saved
    elseif selectedKey == 'selectedTeleportId' then st.draftTeleport = saved
    elseif selectedKey == 'selectedLauncherId' then st.draftLauncher = saved end
    st.lastMessage = string.format(saveAsNew and "Saved copy of %s '%s'." or "Saved %s '%s'.", tostring(typeName or draft.type), tostring(saved.name or saved.id))
    return saved
  end
  st.lastMessage = tostring(err or "Could not save asset.")
  return nil
end

local function _deleteSelected(selectedKey, dirtyKey, emptyFactory, typeName)
  local st = MacroBuilder.state
  local id = st[selectedKey]
  if id then AssetRegistry.Delete(id) end
  st[selectedKey] = nil
  st[dirtyKey] = false
  st.lastMessage = string.format("Deleted %s.", tostring(typeName or "asset"))
  st[emptyFactory] = AssetRegistry[emptyFactory] and AssetRegistry[emptyFactory]() or nil
end

local function _duplicateSelected(selectedKey, dirtyKey)
  local st = MacroBuilder.state
  local id = st[selectedKey]
  if not id then return end
  local copy = AssetRegistry.Duplicate(id)
  if copy then
    st[selectedKey] = copy.id
    st[dirtyKey] = false
    st.lastMessage = string.format("Duplicated '%s'.", tostring(copy.name or copy.id))
  end
end


local function _syncExternalActionStateIntoRuleBuilder(selectedGroupKey, selectedActionKey, isOffSection)
  local rb = RuleBuilder and RuleBuilder.state
  if type(rb) ~= 'table' then return end
  local st = MacroBuilder.state
  if isOffSection then
    rb.selectedFalseActionGroupIndex = tonumber(st[selectedGroupKey] or 1) or 1
    rb.selectedFalseActionIndex = tonumber(st[selectedActionKey] or 1) or 1
    rb.selectedActionList = 'false'
  else
    rb.selectedActionGroupIndex = tonumber(st[selectedGroupKey] or 1) or 1
    rb.selectedActionIndex = tonumber(st[selectedActionKey] or 1) or 1
    rb.selectedActionList = 'do'
  end
end

local function _syncExternalActionStateFromRuleBuilder(selectedGroupKey, selectedActionKey, isOffSection)
  local rb = RuleBuilder and RuleBuilder.state
  if type(rb) ~= 'table' then return end
  local st = MacroBuilder.state
  if isOffSection then
    st[selectedGroupKey] = tonumber(rb.selectedFalseActionGroupIndex or st[selectedGroupKey] or 1) or 1
    st[selectedActionKey] = tonumber(rb.selectedFalseActionIndex or st[selectedActionKey] or 1) or 1
  else
    st[selectedGroupKey] = tonumber(rb.selectedActionGroupIndex or st[selectedGroupKey] or 1) or 1
    st[selectedActionKey] = tonumber(rb.selectedActionIndex or st[selectedActionKey] or 1) or 1
  end
end

local function _drawMacroList()
  local st = MacroBuilder.state
  local items = AssetRegistry.List("macro")
  if ImGui.Button("+ New Toggle Macro") then
    st.selectedMacroId = nil
    st.draftMacro = AssetRegistry.MakeEmptyMacro("toggle")
    st.draftMacro.name = "New Toggle Macro"
    end
  ImGui.SameLine()
  if ImGui.Button("+ New Button Macro") then
    st.selectedMacroId = nil
    st.draftMacro = AssetRegistry.MakeEmptyMacro("button")
    st.draftMacro.name = "New Button Macro"
    end
  ImGui.Separator()
  if _beginChild("macro_list", 220, 0, true) then
    for i = 1, #items do
      local a = items[i]
      local selected = (tostring(st.selectedMacroId or "") == tostring(a.id or ""))
      local label = string.format("%s [%s]", tostring(a.name or a.id), tostring((((a or {}).data or {}).mode) or "toggle"))
      if ImGui.Selectable(label .. "##macro_sel_" .. tostring(a.id), selected) then
        st.selectedMacroId = a.id
        st.draftMacro = a
        st.macroDirty = false
      end
    end
    ImGui.EndChild()
  end
end

local function _drawActionGroups(groups, selectedGroupKey, selectedActionKey, ownerId, isOffSection)
  local st = MacroBuilder.state
  local externalKey = isOffSection and "falseActionGroups" or "actionGroups"
  local shim = { data = {} }
  shim.data[externalKey] = _ensureGroups(groups, isOffSection and "Off Group" or "Group")

  if RuleBuilder and type(RuleBuilder.DrawExternalActionTableSection) == "function" then
    _syncExternalActionStateIntoRuleBuilder(selectedGroupKey, selectedActionKey, isOffSection)
    RuleBuilder.DrawExternalActionTableSection(
      shim,
      externalKey,
      isOffSection and "OFF Actions" or "ON Actions",
      isOffSection and "Any Scripter action can run when this macro turns OFF." or "Any Scripter action can run here, including teleport, weather, stats, camera, grids, target actions, UI messages, and custom CET code.",
      selectedActionKey,
      isOffSection and "false" or "do",
      "No actions yet."
    )
    if type(RuleBuilder.DrawExternalSelectedActionSetup) == "function" then
      RuleBuilder.DrawExternalSelectedActionSetup(shim, isOffSection, MacroBuilder.state[selectedGroupKey], MacroBuilder.state[selectedActionKey])
    end
    _syncExternalActionStateFromRuleBuilder(selectedGroupKey, selectedActionKey, isOffSection)
    return shim.data[externalKey]
  end

  groups = shim.data[externalKey]
  local gidx = math.max(1, math.min(tonumber(st[selectedGroupKey] or 1) or 1, #groups))
  st[selectedGroupKey] = gidx
  local group = groups[gidx]
  if ImGui.Button("+ Group##" .. tostring(ownerId) .. tostring(selectedGroupKey)) then
    groups[#groups + 1] = { id = "group_" .. tostring(#groups + 1), name = "Group " .. tostring(#groups + 1), mode = "ordered", actions = {} }
    st[selectedGroupKey] = #groups
  end
  ImGui.SameLine()
  if ImGui.Button("+ Action##" .. tostring(ownerId) .. tostring(selectedActionKey)) then
    group.actions[#group.actions + 1] = _newAction("run_created_asset")
    st[selectedActionKey] = #group.actions
  end
  return groups
end

local function _drawMacrosSubtab()
  local st = MacroBuilder.state
  _syncMacroDraft()
  local draft = st.draftMacro
  local leftW = 230
  _drawMacroList()
  ImGui.SameLine()
  if _beginChild("macro_builder", 0, 0, true) then
    draft.name = _inputTextValue("Macro Name", draft.name or "", 128)
    local pickedMode = _comboSelect("Type", (((draft.data or {}).mode) == "button") and "Button" or "Toggle", { "Toggle", "Button" })
    draft.data.mode = (pickedMode == "Button") and "button" or "toggle"
    if draft.data.mode == "toggle" then
      local offPick = _comboSelect("Conditions OFF", ({ none = "Do Nothing", restore = "Restore / Reset", run_off_actions = "Run OFF Actions" })[tostring(draft.data.offPolicy or "restore")] or "Restore / Reset", { "Do Nothing", "Restore / Reset", "Run OFF Actions" })
      draft.data.offPolicy = ({ ["Do Nothing"] = "none", ["Restore / Reset"] = "restore", ["Run OFF Actions"] = "run_off_actions" })[offPick] or "restore"
    else
      draft.data.offPolicy = "none"
    end

    ImGui.Separator()
    ImGui.TextDisabled("ON Actions")
    draft.data.onActionGroups = _drawActionGroups(draft.data.onActionGroups, "selectedMacroActionGroup", "selectedMacroActionIndex", tostring(draft.id or "new_macro"), false)
    if draft.data.mode == "toggle" and draft.data.offPolicy == "run_off_actions" then
      ImGui.Separator()
      ImGui.TextDisabled("OFF Actions")
      draft.data.offActionGroups = _drawActionGroups(draft.data.offActionGroups, "selectedMacroOffGroup", "selectedMacroOffActionIndex", tostring(draft.id or "new_macro") .. "_off", true)
    end

    ImGui.Separator()
    ImGui.TextWrapped("Tip: action-only scripts can now be saved in Scripter and added here, so this Macro tab can toggle or launch full Scripter logic without qualifiers.")
    if ImGui.Button("Save Macro") then _saveAsset(draft, "selectedMacroId", "macroDirty", "macro") end
    ImGui.SameLine()
    if ImGui.Button("Save Macro Copy") then _saveAsset(draft, "selectedMacroId", "macroDirty", "macro", true) end
    ImGui.SameLine()
    if ImGui.Button((draft.data.mode == "toggle") and (RuleRunner.IsCreatedAssetEnabled(draft.id or "macro_draft_runtime") and "Turn OFF" or "Turn ON") or "Run Now") then
      local runtimeKey = tostring(draft.id or "macro_draft_runtime")
      local desired = (draft.data.mode == "toggle") and (RuleRunner.IsCreatedAssetEnabled(runtimeKey) and "off" or "on") or "run"
      local ok, msg = _runDraftAssetSafe(draft, desired, runtimeKey)
      st.lastMessage = tostring(msg or (ok and "Macro run." or "Macro failed."))
    end
    ImGui.SameLine()
    if ImGui.Button("Duplicate Macro") then _duplicateSelected("selectedMacroId", "macroDirty") end
    ImGui.SameLine()
    if ImGui.Button("Delete Macro") then
      if st.selectedMacroId then AssetRegistry.Delete(st.selectedMacroId) end
      st.selectedMacroId = nil
      st.draftMacro = AssetRegistry.MakeEmptyMacro("toggle")
      st.macroDirty = false
      st.lastMessage = "Deleted macro."
    end
    ImGui.EndChild()
  end
end

local function _drawCustomCodeSubtab()
  local st = MacroBuilder.state
  _syncCodeDraft()
  local draft = st.draftCode
  local items = AssetRegistry.List("custom_code")
  if _beginChild("code_list", 220, 0, true) then
    if ImGui.Button("+ New Code Button") then st.selectedCodeId = nil; st.draftCode = AssetRegistry.MakeEmptyCustomCode("button"); st.draftCode.name = "New Code Button"; st.codeDirty = true end
    if ImGui.Button("+ New Code Toggle") then st.selectedCodeId = nil; st.draftCode = AssetRegistry.MakeEmptyCustomCode("toggle"); st.draftCode.name = "New Code Toggle"; st.codeDirty = true end
    ImGui.Separator()
    for i = 1, #items do
      local a = items[i]
      if ImGui.Selectable(string.format("%s [%s]##code_%s", tostring(a.name or a.id), tostring((((a or {}).data or {}).mode) or "button"), tostring(a.id)), tostring(st.selectedCodeId or "") == tostring(a.id or "")) then
        st.selectedCodeId = a.id
        st.draftCode = a
        st.codeDirty = false
      end
    end
    ImGui.EndChild()
  end
  ImGui.SameLine()
  if _beginChild("code_builder", 0, 0, true) then
    draft.name = _inputTextValue("Code Name", draft.name or "", 128)
    draft.data.mode = (_comboSelect("Type##code_mode", (tostring((draft.data or {}).mode or "button") == "toggle") and "Toggle" or "Button", { "Button", "Toggle" }) == "Toggle") and "toggle" or "button"
    if ImGui.InputTextMultiline then
      local a, b = ImGui.InputTextMultiline("ON Code", tostring((draft.data or {}).onCode or ""), 8192, -1, 150)
      if type(a) == "string" then draft.data.onCode = a elseif type(b) == "string" then draft.data.onCode = b end
    else
      draft.data.onCode = _inputTextValue("ON Code", tostring((draft.data or {}).onCode or ""), 1024)
    end
    if draft.data.mode == "toggle" then
      if ImGui.InputTextMultiline then
        local a, b = ImGui.InputTextMultiline("OFF Code", tostring((draft.data or {}).offCode or ""), 8192, -1, 120)
        if type(a) == "string" then draft.data.offCode = a elseif type(b) == "string" then draft.data.offCode = b end
      else
        draft.data.offCode = _inputTextValue("OFF Code", tostring((draft.data or {}).offCode or ""), 1024)
      end
    end
    if ImGui.Button("Save Code Asset") then _saveAsset(draft, "selectedCodeId", "codeDirty", "code asset") end
    ImGui.SameLine()
    if ImGui.Button("Save Code Copy") then _saveAsset(draft, "selectedCodeId", "codeDirty", "code asset", true) end
    ImGui.SameLine()
    if ImGui.Button((draft.data.mode == "toggle") and (RuleRunner.IsCreatedAssetEnabled(draft.id or "code_draft_runtime") and "Turn OFF" or "Turn ON") or "Run Code") then
      local runtimeKey = tostring(draft.id or "code_draft_runtime")
      local desired = (draft.data.mode == "toggle") and (RuleRunner.IsCreatedAssetEnabled(runtimeKey) and "off" or "on") or "run"
      local ok, msg = _runDraftAssetSafe(draft, desired, runtimeKey)
      st.lastMessage = tostring(msg or (ok and "Code executed." or "Code failed."))
    end
    ImGui.SameLine()
    if ImGui.Button("Duplicate Code") then _duplicateSelected("selectedCodeId", "codeDirty") end
    ImGui.SameLine()
    if ImGui.Button("Delete Code") then
      if st.selectedCodeId then AssetRegistry.Delete(st.selectedCodeId) end
      st.selectedCodeId = nil
      st.draftCode = AssetRegistry.MakeEmptyCustomCode("button")
      st.codeDirty = false
      st.lastMessage = "Deleted code asset."
    end
    ImGui.EndChild()
  end
end

local function _drawTeleportsSubtab()
  local st = MacroBuilder.state
  _syncTeleportDraft()
  local draft = st.draftTeleport
  local items = AssetRegistry.List("teleport_preset")
  if _beginChild("tp_list", 220, 0, true) then
    if ImGui.Button("+ New Teleport") then st.selectedTeleportId = nil; st.draftTeleport = AssetRegistry.MakeEmptyTeleportPreset(); st.draftTeleport.name = "New Teleport"; st.teleportDirty = true end
    ImGui.Separator()
    for i = 1, #items do
      local a = items[i]
      if ImGui.Selectable(tostring(a.name or a.id) .. "##tp_" .. tostring(a.id), tostring(st.selectedTeleportId or "") == tostring(a.id or "")) then
        st.selectedTeleportId = a.id
        st.draftTeleport = a
        st.teleportDirty = false
      end
    end
    ImGui.EndChild()
  end
  ImGui.SameLine()
  if _beginChild("tp_builder", 0, 0, true) then
    draft.name = _inputTextValue("Preset Name", draft.name or "", 128)
    draft.data.label = _inputTextValue("Label", tostring((draft.data or {}).label or ""), 128)
    draft.data.x = _inputFloatValue("X", tonumber((draft.data or {}).x or 0) or 0, 0.1, 1.0, "%.2f")
    draft.data.y = _inputFloatValue("Y", tonumber((draft.data or {}).y or 0) or 0, 0.1, 1.0, "%.2f")
    draft.data.z = _inputFloatValue("Z", tonumber((draft.data or {}).z or 0) or 0, 0.1, 1.0, "%.2f")
    local World = nil; local okWorld, modWorld = pcall(require, "GTS/macro_actions_world"); if okWorld then World = modWorld end
    if World and type(World.GetPlayerPosition) == "function" and ImGui.Button("Use Player Position") then
      local x, y, z = World.GetPlayerPosition()
      if type(x) == "number" then draft.data.x, draft.data.y, draft.data.z = x, y, z end
    end
    if ImGui.Button("Save Teleport") then _saveAsset(draft, "selectedTeleportId", "teleportDirty", "teleport") end
    ImGui.SameLine()
    if ImGui.Button("Save Teleport Copy") then _saveAsset(draft, "selectedTeleportId", "teleportDirty", "teleport", true) end
    ImGui.SameLine()
    if ImGui.Button("Teleport Now") then
      local ok, msg = _runDraftAssetSafe(draft, "run", tostring(draft.id or "teleport_draft_runtime"))
      st.lastMessage = tostring(msg or (ok and "Teleported." or "Teleport failed."))
    end
    ImGui.SameLine()
    if ImGui.Button("Duplicate Teleport") then _duplicateSelected("selectedTeleportId", "teleportDirty") end
    ImGui.SameLine()
    if ImGui.Button("Delete Teleport") then
      if st.selectedTeleportId then AssetRegistry.Delete(st.selectedTeleportId) end
      st.selectedTeleportId = nil
      st.draftTeleport = AssetRegistry.MakeEmptyTeleportPreset()
      st.teleportDirty = false
      st.lastMessage = "Deleted teleport preset."
    end
    ImGui.EndChild()
  end
end

local function _drawLaunchersSubtab()
  local st = MacroBuilder.state
  _syncLauncherDraft()
  local draft = st.draftLauncher
  local items = AssetRegistry.List("launcher")
  if _beginChild("launcher_list", 220, 0, true) then
    if ImGui.Button("+ New Launcher") then st.selectedLauncherId = nil; st.draftLauncher = AssetRegistry.MakeEmptyLauncher("button"); st.draftLauncher.name = "New Launcher"; st.launcherDirty = true end
    ImGui.Separator()
    for i = 1, #items do
      local a = items[i]
      if ImGui.Selectable(string.format("%s [%s]##launch_%s", tostring(a.name or a.id), tostring((((a or {}).data or {}).mode) or "button"), tostring(a.id)), tostring(st.selectedLauncherId or "") == tostring(a.id or "")) then
        st.selectedLauncherId = a.id
        st.draftLauncher = a
        st.launcherDirty = false
      end
    end
    ImGui.EndChild()
  end
  ImGui.SameLine()
  if _beginChild("launcher_builder", 0, 0, true) then
    draft.name = _inputTextValue("Launcher Name", draft.name or "", 128)
    draft.data.mode = (_comboSelect("Type##launcher_mode", (tostring((draft.data or {}).mode or "button") == "toggle") and "Toggle" or "Button", { "Button", "Toggle" }) == "Toggle") and "toggle" or "button"
    st.launcherAssetSearch = _inputTextValue("Search Created Assets", st.launcherAssetSearch or "", 128)
    local labels, byLabel = _createdAssetChoices(draft.id)
    local filtered = {}
    local needle = string.lower(tostring(st.launcherAssetSearch or ""))
    for i = 1, #labels do
      local label = labels[i]
      if needle == "" or string.find(string.lower(label), needle, 1, true) then filtered[#filtered + 1] = label end
    end
    local pick = _comboSelect("Add Asset", filtered[1] or "(none)", filtered)
    if ImGui.Button("Add To Launcher") then
      local id = byLabel[pick]
      if id then draft.data.entries[#draft.data.entries + 1] = { ref = id, desiredState = "run" } end
    end
    ImGui.Separator()
    if _beginChild("launcher_entries", 0, 180, true) then
      local removeIndex = nil
      for i = 1, #(draft.data.entries or {}) do
        local e = draft.data.entries[i]
        ImGui.PushID(i)
        ImGui.TextUnformatted(_assetLabel(e.ref))
        local modePick = _comboSelect("State", _runStateLabel(e.desiredState), { "Run Once", "Toggle On", "Toggle Off" })
        e.desiredState = ({ ["Run Once"] = "run", ["Toggle On"] = "on", ["Toggle Off"] = "off" })[modePick] or "run"
        ImGui.SameLine()
        if ImGui.SmallButton("Remove") then removeIndex = i end
        ImGui.PopID()
      end
      if removeIndex then table.remove(draft.data.entries, removeIndex) end
      ImGui.EndChild()
    end
    if ImGui.Button("Save Launcher") then _saveAsset(draft, "selectedLauncherId", "launcherDirty", "launcher") end
    ImGui.SameLine()
    if ImGui.Button("Save Launcher Copy") then _saveAsset(draft, "selectedLauncherId", "launcherDirty", "launcher", true) end
    ImGui.SameLine()
    if ImGui.Button((draft.data.mode == "toggle") and (RuleRunner.IsCreatedAssetEnabled(draft.id or "launcher_draft_runtime") and "Turn OFF" or "Turn ON") or "Run Launcher") then
      local runtimeKey = tostring(draft.id or "launcher_draft_runtime")
      local desired = (draft.data.mode == "toggle") and (RuleRunner.IsCreatedAssetEnabled(runtimeKey) and "off" or "on") or "run"
      local ok, msg = _runDraftAssetSafe(draft, desired, runtimeKey)
      st.lastMessage = tostring(msg or (ok and "Launcher run." or "Launcher failed."))
    end
    ImGui.SameLine()
    if ImGui.Button("Duplicate Launcher") then _duplicateSelected("selectedLauncherId", "launcherDirty") end
    ImGui.SameLine()
    if ImGui.Button("Delete Launcher") then
      if st.selectedLauncherId then AssetRegistry.Delete(st.selectedLauncherId) end
      st.selectedLauncherId = nil
      st.draftLauncher = AssetRegistry.MakeEmptyLauncher("button")
      st.launcherDirty = false
      st.lastMessage = "Deleted launcher."
    end
    ImGui.EndChild()
  end
end

function MacroBuilder.OnUpdate(_) end

function MacroBuilder.DrawTab(_)
  local st = MacroBuilder.state
  ImGui.TextWrapped(tostring(st.lastMessage or ""))
  ImGui.Separator()
  if ImGui.BeginTabBar and ImGui.BeginTabBar("macro_builder_tabs") then
    if ImGui.BeginTabItem("Macros") then _drawMacrosSubtab(); ImGui.EndTabItem(); st.subtab = "Macros" end
    if ImGui.BeginTabItem("Custom Code") then _drawCustomCodeSubtab(); ImGui.EndTabItem(); st.subtab = "Custom Code" end
    if ImGui.BeginTabItem("Teleports") then _drawTeleportsSubtab(); ImGui.EndTabItem(); st.subtab = "Teleports" end
    if ImGui.BeginTabItem("Launchers") then _drawLaunchersSubtab(); ImGui.EndTabItem(); st.subtab = "Launchers" end
    ImGui.EndTabBar()
  else
    _drawMacrosSubtab()
  end
end

return MacroBuilder
