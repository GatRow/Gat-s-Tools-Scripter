local AssetRegistry = require("GTS/asset_registry")
local RuleRunner = require("GTS/rule_runner")

local RuleBuilder = RuleBuilder or {}

RuleBuilder.state = RuleBuilder.state or {
  tab = "Rules",
  selectedRuleId = nil,
  selectedAssetId = nil,
  draftRule = AssetRegistry.MakeEmptyRule(),
  lastRuleSyncId = nil,
  draftDirty = false,
  lastMessage = "Create presets in Stats Editor / Spawn Tools, then build readable scripts here. Saved action-only scripts can now be launched from Macros / Created without conditions.",
  showDebugWindow = true,
  observerPresetName = "",
  whenObserverPresetId = nil,
  inventoryBundleName = "",
  selectedActionIndex = 1,
  selectedFalseActionIndex = 1,
  selectedActionGroupIndex = 1,
  selectedFalseActionGroupIndex = 1,
  selectedConditionGroupIndex = 1,
  selectedActionList = "do",
  statusSearch = "",
  statusSelectedIndex = 1,
  targetSpawnSearch = "",
  targetSpawnSelectedIndex = 1,
}


local RULE_DIFFICULTY_OPTIONS = { "Story", "Easy", "Normal", "Hard", "VeryHard" }
local RULE_EQUIPPED_SLOT_OPTIONS = { "Slot 1", "Slot 2", "Slot 3", "Head", "Face", "Outer Torso", "Inner Torso", "Legs", "Feet", "Outfit" }

local function _safeRequire(name)
  local ok, mod = pcall(require, name)
  if ok then return mod end
  print("[GTS] RuleBuilder require failed for '" .. tostring(name) .. "': " .. tostring(mod))
  return nil
end

local function _clone(value, seen)
  if type(value) ~= "table" then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do out[_clone(k, seen)] = _clone(v, seen) end
  return out
end

local function _tabBarOpen(id)
  if type(ImGui.BeginTabBar) ~= "function" then return false end
  local a, b = ImGui.BeginTabBar(id)
  if type(a) == "boolean" then return a end
  if type(b) == "boolean" then return b end
  return false
end

local function _tabItemOpen(label)
  if type(ImGui.BeginTabItem) ~= "function" then return false end
  local a, b = ImGui.BeginTabItem(label)
  if type(a) == "boolean" and type(b) == "boolean" then return a or b end
  if type(a) == "boolean" then return a end
  if type(b) == "boolean" then return b end
  return false
end

local function _checkboxValue(label, current)
  local a, b = ImGui.Checkbox(label, current == true)
  if type(a) == "boolean" and type(b) == "boolean" then
    if b == (a ~= current) then return a == true end
    if a == (b ~= current) then return b == true end
    return b == true
  end
  if type(a) == "boolean" then return a == true end
  if type(b) == "boolean" then return b == true end
  return current == true
end

local function _inputTextValue(label, value, size)
  local a, b = ImGui.InputText(label, value or "", size or 128)
  if type(a) == "boolean" and type(b) == "string" then return b end
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return value or ""
end

local function _inputFloatValue(label, value, step, fast, fmt)
  local a, b = ImGui.InputFloat(label, tonumber(value or 0) or 0, step or 0.05, fast or 0.25, fmt or "%.2f")
  if type(a) == "boolean" and type(b) == "number" then return b end
  if type(a) == "number" then return a end
  if type(b) == "number" then return b end
  return tonumber(value or 0) or 0
end

local function _inputIntValue(label, value, step, fast)
  local a, b = ImGui.InputInt(label, math.floor(tonumber(value or 0) or 0), step or 1, fast or 10)
  if type(a) == "boolean" and type(b) == "number" then return math.floor(b) end
  if type(a) == "number" then return math.floor(a) end
  if type(b) == "number" then return math.floor(b) end
  return math.floor(tonumber(value or 0) or 0)
end

local function _sliderFloatValue(label, value, minv, maxv, fmt)
  if type(ImGui.SliderFloat) == "function" then
    local a, b = ImGui.SliderFloat(label, tonumber(value or minv) or minv, minv, maxv, fmt or "%.2f")
    if type(a) == "boolean" and type(b) == "number" then return b end
    if type(a) == "number" then return a end
    if type(b) == "number" then return b end
  end
  return _inputFloatValue(label, value, 0.05, 0.25, fmt or "%.2f")
end

local function _comboSelect(label, currentValue, labels, fixedWidth)
  if type(labels) ~= "table" or #labels == 0 then return currentValue end
  local current = currentValue
  local found = false
  for i = 1, #labels do if labels[i] == current then found = true break end end
  if not found then current = labels[1] end

  if type(ImGui.SetNextItemWidth) == "function" then
    if type(fixedWidth) == "number" and fixedWidth > 0 then
      ImGui.SetNextItemWidth(fixedWidth)
    else
      ImGui.SetNextItemWidth(-1)
    end
  end

  if type(ImGui.BeginCombo) == "function" then
    if ImGui.BeginCombo(label, tostring(current or "")) then
      for i = 1, #labels do
        local item = labels[i]
        local selected = (item == current)
        if ImGui.Selectable(item, selected) then current = item end
      end
      ImGui.EndCombo()
    end
    return current
  end

  local currentIndex = 0
  for i = 1, #labels do if labels[i] == current then currentIndex = i - 1 break end end
  local r1, r2 = ImGui.Combo(label, currentIndex, labels, #labels)
  local newIndex = nil
  if type(r1) == "boolean" then
    if r1 then newIndex = r2 end
  elseif type(r1) == "number" then
    newIndex = r1
  end
  if type(newIndex) == "number" then return labels[newIndex + 1] or current end
  return current
end

local function _textColored(r, g, b, a, txt)
  if type(ImGui.TextColored) == "function" then
    ImGui.TextColored(r, g, b, a, txt)
  else
    ImGui.TextUnformatted(txt)
  end
end

local function _formatDebugValue(v)
  local tv = type(v)
  if v == nil then return "nil" end
  if tv == "boolean" then return v and "TRUE" or "FALSE" end
  if tv == "number" then
    if math.abs(v - math.floor(v + 0.0000001)) < 0.0000001 then return tostring(math.floor(v + 0.0000001)) end
    return string.format("%.2f", v)
  end
  local s = tostring(v or "")
  if s == "" then return "<empty>" end
  return s
end

local function _debugPassText(res)
  if not res then return "UNKNOWN" end
  return (res.pass == true) and "PASS" or "FAIL"
end

local function _debugPassColor(res)
  if res and res.pass == true then return 0.35, 0.95, 0.45, 1.0 end
  return 1.00, 0.35, 0.35, 1.0
end

local function _clockText(v)
  local n = tonumber(v or 0) or 0
  if n <= 0 then return "never" end
  return string.format("%.3f", n)
end

local function _clockNow()
  return ((os and os.clock and os.clock()) or 0)
end

local function _clockAgoText(now, v)
  local t = tonumber(v or 0) or 0
  if t <= 0 then return "never" end
  local dt = math.max(0, (tonumber(now or 0) or 0) - t)
  if dt < 0.10 then
    return "just now"
  elseif dt < 10.0 then
    return string.format("%.2fs ago", dt)
  elseif dt < 60.0 then
    return string.format("%.1fs ago", dt)
  elseif dt < 3600.0 then
    local m = math.floor(dt / 60.0)
    local s = math.floor(dt % 60.0)
    return string.format("%dm %02ds ago", m, s)
  end
  local h = math.floor(dt / 3600.0)
  local m = math.floor((dt % 3600.0) / 60.0)
  return string.format("%dh %02dm ago", h, m)
end

local function _clockHumanLine(label, now, v)
  local raw = _clockText(v)
  if raw == "never" then return label .. ": never" end
  return string.format("%s: %s (t=%s)", label, _clockAgoText(now, v), raw)
end

local function _debugConditionSummary(res)
  res = res or {}
  local lhs = _formatDebugValue(res.left)
  local op = tostring(res.op or "==")
  local rhs = _formatDebugValue(res.right)
  local observed = tostring(res.current and "TRUE" or "FALSE")
  local expects = tostring(res.expected and "TRUE" or "FALSE")
  local txt = string.format("%s %s %s | observed %s | expects %s | %s", lhs, op, rhs, observed, expects, _debugPassText(res))
  if tostring(res.reason or "") ~= "" then
    txt = txt .. " | " .. tostring(res.reason)
  end
  return txt
end

local TARGET_CLASS_OPTIONS = {
  "NPCPuppet",
  "vehicleCarBaseObject",
  "gameItemObject",
  "FakeDoor",
  "VendingMachine",
  "Door",
  "gameObject",
  "Frame",
  "Wardrobe",
  "Computer",
  "ShardCaseContainer",
  "GenericDevice",
  "LootContainerObjectAnimatedByTransform",
  "TV",
  "Radio",
  "WindowBlinders",
  "DataTerm",
}

local function _conditionLabel(cond)
  cond = cond or {}
  local base = tostring(cond.label or cond.key or cond.kind or "Condition")
  local kind = tostring(cond.kind or "")
  if kind == "saved_stat_condition" then
    local asset = (tostring(cond.ref or "") ~= "") and AssetRegistry.Get(cond.ref) or nil
    local assetName = asset and tostring(asset.name or asset.id) or nil
    return string.format("%s [%s]", base, tostring(assetName or cond.ref or "Unbound"))
  elseif kind == "target_class" then
    return string.format("%s [%s]", base, tostring(cond.targetClass or TARGET_CLASS_OPTIONS[1] or "NPCPuppet"))
  elseif kind == "owned_item" then
    return string.format("%s [%s]", base, tostring(cond.itemId or ""))
  elseif kind == "owned_vehicle" then
    return string.format("%s [%s]", base, tostring(cond.vehicleId or ""))
  elseif kind == "active_weapon_id" then
    return string.format("%s [%s]", base, tostring(cond.weaponId or ""))
  elseif kind == "equipped_slot_item" then
    return string.format("%s [%s = %s]", base, tostring(cond.slotKey or RULE_EQUIPPED_SLOT_OPTIONS[1]), tostring(cond.itemId or ""))
  elseif kind == "target_distance" then
    return string.format("%s [%s %.1fm]", base, tostring(cond.distanceMode or 'within'), tonumber(cond.meters or 0) or 0)
  elseif kind == "zone_state" then
    return string.format("%s [%s]", base, tostring(cond.zoneType or 'Safe Zone'))
  elseif kind == "player_status_effect" or kind == "target_status_effect" then
    return string.format("%s [%s]", base, tostring(cond.effectId or ''))
  elseif kind == "difficulty_level" then
    return string.format("%s [%s]", base, tostring(cond.difficulty or RULE_DIFFICULTY_OPTIONS[1]))
  elseif kind == "tracked_quest_id" then
    return string.format("%s [%s]", base, tostring(cond.questId or ""))
  elseif kind == "wanted_level" then
    return string.format("%s [%s %d]", base, tostring(cond.compareMode or "at_least"), math.floor(tonumber(cond.level or 0) or 0))
  elseif kind == "target_health" then
    return string.format("%s [%s %.1f]", base, tostring(cond.compareOp or "<="), tonumber(cond.healthValue or 0) or 0)
  elseif kind == "target_faction" then
    return string.format("%s [%s]", base, tostring(cond.faction or ""))
  elseif kind == "custom_observer" and type(cond.customObserverDef) == "table" then
    local def = cond.customObserverDef or {}
    local src = tostring(def.src or "Stat Value")
    if src ~= "Stat Value" then
      return tostring(cond.label or string.format("Custom: %s (%s) %s %s", tostring(def.stat or "Stat"), src, tostring(def.op or "=="), tostring(def.valueStr or def.value or "0")))
    end
    return tostring(cond.label or string.format("Custom: %s %s %s", tostring(def.stat or "Stat"), tostring(def.op or "=="), tostring(def.valueStr or def.value or "0")))
  end
  return base
end

local function _assetTypeForAction(actionType)
  if actionType == "apply_stat_preset" then return "stat_preset" end
  if actionType == "spawn_set" then return "spawn_set" end
  if actionType == "spawn_saved_grid" then return "spawn_grid" end
  if actionType == "spawn_saved_grid_at_target" then return "spawn_grid" end
  if actionType == "add_inventory_bundle" then return "inventory_bundle" end
  if actionType == "use_shooter_profile" then return "shooter_profile" end
  return nil
end

local function _actionTypeForAsset(asset)
  if not asset then return nil end
  local t = tostring(asset.type or "")
  if t == "stat_preset" then return "apply_stat_preset" end
  if t == "spawn_set" then return "spawn_set" end
  if t == "spawn_grid" then return "spawn_saved_grid" end
  if t == "inventory_bundle" then return "add_inventory_bundle" end
  if t == "shooter_profile" then return "use_shooter_profile" end
  return nil
end

local function _actionTypeLabel(actionType)
  local map = {
    apply_stat_preset = "Apply Stat Profile",
    spawn_set = "Spawn Preset",
    spawn_saved_grid = "Spawn Saved Grid",
    spawn_saved_grid_at_target = "Spawn Grid at Target",
    add_inventory_bundle = "Add Inventory Bundle",
    use_shooter_profile = "Use Shooter Profile",
    set_time_of_day = "Set Time Of Day",
    set_weather = "Set Weather",
    reset_weather = "Reset Weather",
    set_time_dilation = "Set Time Manipulation",
    reset_time_dilation = "Reset Time Manipulation",
    set_fov = "Set FOV",
    reset_fov = "Remove Zoom / Reset FOV",
    camera = "Camera / No Clip",
    show_ui_message = "Show UI Message",
    toggle_hud = "Toggle HUD",
    johnny_hud = "Johnny HUD",
    arasaka_hud = "Arasaka HUD",
    open_fast_travel = "Open Fast Travel Menu",
    teleport = "Teleport",
    repair_current_vehicle = "Repair Current Vehicle",
    passive_mode = "Passive Mode",
    wanted_system = "Wanted System",
    set_wanted_stars = "Set Wanted Stars",
    clear_wanted_level = "Clear Wanted Level",
    johnny_arm = "Johnny Silverhand Arm",
    force_equip_weapon = "Force Equip Weapon",
    force_equip_clothing = "Force Equip Clothing",
    apply_status_effect = "Apply Status Effect",
    remove_status_effect = "Remove Status Effect",
    force_kill_lookat_npc = "Force Kill Looked-At NPC",
    despawn_target = "Despawn Target",
    move_target = "Move Target",
    spawn_at_target = "Spawn at Target",
    apply_status_effect_to_target = "Apply Status Effect To Target",
    tether_target = "Tether Target",
    cycle_target_appearance = "Cycle Target Appearance",
    apply_animation_to_player = "Apply Animation to Player",
    apply_animation_to_target = "Apply Animation to Target",
    custom_cet_code = "Custom CET Code",
    run_created_asset = "Run Created Asset",
    wait = "Wait / Delay",
  }
  return map[actionType] or tostring(actionType or "Action")
end

local function _normalizeGroupMode(mode)
  mode = tostring(mode or "ordered")
  if mode ~= "parallel" then mode = "ordered" end
  return mode
end

local function _normalizeActionGroups(groups, fallbackActions, defaultName)
  local src = type(groups) == "table" and groups or {}
  if #src == 0 and type(fallbackActions) == "table" and #fallbackActions > 0 then
    src = { { id = string.format("%s_1", tostring(defaultName or "group"):gsub("%s+", "_"):lower()), name = tostring(defaultName or "Group") .. " 1", mode = "ordered", actions = _clone(fallbackActions) } }
  end
  if #src == 0 then
    src = { { id = string.format("%s_1", tostring(defaultName or "group"):gsub("%s+", "_"):lower()), name = tostring(defaultName or "Group") .. " 1", mode = "ordered", actions = {} } }
  end
  local out = {}
  for i = 1, #src do
    local g = type(src[i]) == "table" and _clone(src[i]) or {}
    g.id = tostring(g.id or string.format("%s_%d", tostring(defaultName or "group"):gsub("%s+", "_"):lower(), i))
    g.name = tostring(g.name or string.format("%s %d", tostring(defaultName or "Group"), i))
    g.mode = _normalizeGroupMode(g.mode)
    g.actions = type(g.actions) == "table" and g.actions or {}
    out[#out + 1] = g
  end
  return out
end

local function _normalizeConditionGroupMode(mode)
  mode = tostring(mode or "ALL")
  if mode ~= "ANY" then mode = "ALL" end
  return mode
end

local function _normalizeConditionGroups(groups, defaultName)
  local src = type(groups) == "table" and groups or {}
  if #src == 0 then
    src = { { id = string.format("%s_1", tostring(defaultName or "condition_group"):gsub("%s+", "_"):lower()), name = tostring(defaultName or "Condition Group") .. " 1", mode = "ALL", conditions = {} } }
  end
  local out = {}
  for i = 1, #src do
    local g = type(src[i]) == "table" and _clone(src[i]) or {}
    g.id = tostring(g.id or string.format("%s_%d", tostring(defaultName or "condition_group"):gsub("%s+", "_"):lower(), i))
    g.name = tostring(g.name or string.format("%s %d", tostring(defaultName or "Condition Group"), i))
    g.mode = _normalizeConditionGroupMode(g.mode)
    g.conditions = type(g.conditions) == "table" and g.conditions or {}
    out[#out + 1] = g
  end
  return out
end

local function _countActionsInGroups(groups)
  local total = 0
  groups = type(groups) == "table" and groups or {}
  for i = 1, #groups do
    total = total + #((groups[i] or {}).actions or {})
  end
  return total
end

local function _ensureActionGroupsForDraft(draft, key)
  draft.data = draft.data or {}
  local fallbackKey = (key == "falseActionGroups") and "falseActions" or "actions"
  local defaultName = (key == "falseActionGroups") and "Exit Group" or "Group"
  draft.data[key] = _normalizeActionGroups(draft.data[key], draft.data[fallbackKey], defaultName)
  return draft.data[key]
end

local function _groupsForRule(rule, key)
  local data = ((rule or {}).data) or {}
  local fallbackKey = (key == "falseActionGroups") and "falseActions" or "actions"
  local defaultName = (key == "falseActionGroups") and "Exit Group" or "Group"
  return _normalizeActionGroups(data[key], data[fallbackKey], defaultName)
end

local function _ensureConditionGroupsForDraft(draft)
  draft.data = draft.data or {}
  draft.data.conditionGroups = _normalizeConditionGroups(draft.data.conditionGroups, "Condition Group")
  local groups = draft.data.conditionGroups
  local triggerId = tostring(draft.data.triggerConditionGroupId or "")
  local found = false
  for i = 1, #groups do
    if tostring((groups[i] or {}).id or "") == triggerId then
      found = true
      break
    end
  end
  if not found then
    draft.data.triggerConditionGroupId = tostring(((groups[1] or {}).id) or "")
  end
  return groups
end

local function _syncTriggerConditionsForDraft(draft)
  draft.data = draft.data or {}
  local groups = _ensureConditionGroupsForDraft(draft)
  local triggerId = tostring(draft.data.triggerConditionGroupId or "")
  local triggerGroup = nil
  for i = 1, #groups do
    local group = groups[i] or {}
    if tostring(group.id or "") == triggerId then
      triggerGroup = group
      break
    end
  end
  if not triggerGroup then triggerGroup = groups[1] end
  if triggerGroup then
    draft.data.triggerConditionGroupId = tostring(triggerGroup.id or "")
    draft.data.conditions = _clone(type(triggerGroup.conditions) == "table" and triggerGroup.conditions or {})
    draft.data.conditionMode = tostring(triggerGroup.mode or "ALL")
    if draft.data.conditionMode ~= "ANY" then draft.data.conditionMode = "ALL" end
  else
    draft.data.conditions = {}
    draft.data.conditionMode = "ALL"
    draft.data.triggerConditionGroupId = ""
  end
end

local function _conditionGroupsForRule(rule)
  local data = ((rule or {}).data) or {}
  return _normalizeConditionGroups(data.conditionGroups, "Condition Group")
end

local function _conditionGroupById(draft, groupId)
  local want = tostring(groupId or "")
  if want == "" then return nil end
  local groups = _ensureConditionGroupsForDraft(draft)
  for i = 1, #groups do
    local group = groups[i] or {}
    if tostring(group.id or "") == want then return group end
  end
  return nil
end

local function _normalizeRule(rule)
  if type(rule) ~= "table" then rule = AssetRegistry.MakeEmptyRule() end
  rule.type = "rule"
  rule.data = rule.data or {}
  if type(rule.data.conditions) ~= "table" then
    if type(rule.data.condition) == "table" then rule.data.conditions = { _clone(rule.data.condition) }
    else rule.data.conditions = {} end
  end
  rule.data.conditionMode = tostring(rule.data.conditionMode or "ALL")
  if rule.data.conditionMode ~= "ANY" then rule.data.conditionMode = "ALL" end
  local legacyConditions = _clone(rule.data.conditions or {})
  local legacyMode = tostring(rule.data.conditionMode or "ALL")
  if legacyMode ~= "ANY" then legacyMode = "ALL" end
  rule.data.conditionGroups = _normalizeConditionGroups(rule.data.conditionGroups, "Condition Group")
  rule.data.triggerConditionGroupId = tostring(rule.data.triggerConditionGroupId or "")
  if rule.data.triggerConditionGroupId == "" or not _conditionGroupById(rule, rule.data.triggerConditionGroupId) then
    rule.data.triggerConditionGroupId = tostring((((rule.data.conditionGroups or {})[1] or {}).id) or "")
  end
  local triggerGroup = _conditionGroupById(rule, rule.data.triggerConditionGroupId) or ((rule.data.conditionGroups or {})[1])
  if triggerGroup and #legacyConditions > 0 and #(type(triggerGroup.conditions) == "table" and triggerGroup.conditions or {}) == 0 then
    triggerGroup.conditions = _clone(legacyConditions)
    triggerGroup.mode = legacyMode
  end
  if triggerGroup then
    rule.data.conditions = _clone(type(triggerGroup.conditions) == "table" and triggerGroup.conditions or {})
    rule.data.conditionMode = tostring(triggerGroup.mode or "ALL")
    if rule.data.conditionMode ~= "ANY" then rule.data.conditionMode = "ALL" end
  else
    rule.data.conditions = {}
    rule.data.conditionMode = "ALL"
  end
  rule.data.actions = type(rule.data.actions) == "table" and rule.data.actions or {}
  rule.data.falseActions = type(rule.data.falseActions) == "table" and rule.data.falseActions or {}
  rule.data.actionGroups = _normalizeActionGroups(rule.data.actionGroups, rule.data.actions, "Group")
  rule.data.falseActionGroups = _normalizeActionGroups(rule.data.falseActionGroups, rule.data.falseActions, "Exit Group")
  rule.data.enabled = rule.data.enabled ~= false

  local legacyOnce = rule.data.runOnceUntilFalse ~= false
  local legacyCooldown = tonumber(rule.data.cooldown or 0.25) or 0.25
  local exec = type(rule.data.execution) == "table" and rule.data.execution or {
    triggerMode = legacyOnce and "on_true" or "while_true",
    cadence = "every_time",
    cadenceValue = 2,
    cooldown = legacyCooldown,
    disableAfterFire = false,
    falsePolicy = "do_nothing",
    falseActions = rule.data.falseActions,
  }

  exec.triggerMode = tostring(exec.triggerMode or "on_true")
  if exec.triggerMode ~= "while_true" then exec.triggerMode = "on_true" end

  exec.cadence = tostring(exec.cadence or "every_time")
  if exec.cadence ~= "first_true_only" and exec.cadence ~= "every_nth_true" and exec.cadence ~= "after_nth_true" then
    exec.cadence = "every_time"
  end

  exec.cadenceValue = math.max(1, math.floor(tonumber(exec.cadenceValue or exec.nValue or 2) or 2))
  exec.cooldown = tonumber(exec.cooldown or legacyCooldown) or legacyCooldown
  if exec.cooldown < 0 then exec.cooldown = 0 end
  exec.disableAfterFire = exec.disableAfterFire == true

  exec.falsePolicy = tostring(exec.falsePolicy or "do_nothing")
  if exec.falsePolicy ~= "restore" and exec.falsePolicy ~= "run_exit_actions" and exec.falsePolicy ~= "disable_rule" then
    exec.falsePolicy = "do_nothing"
  end
  exec.falseActions = type(exec.falseActions) == "table" and exec.falseActions or rule.data.falseActions or {}

  rule.data.execution = exec
  rule.data.falseActions = exec.falseActions
  rule.data.runOnceUntilFalse = (exec.triggerMode == "on_true")
  rule.data.cooldown = exec.cooldown
  rule.data.condition = nil
  return rule
end

local function _groupConditionOption(opt)
  local key = tostring((opt or {}).key or "")
  local kind = tostring((opt or {}).kind or "")
  local label = tostring((opt or {}).label or "")
  if kind == "manual_toggle" then return "Manual Test" end
  if kind == "custom_observer" or label:find("^Custom:") then return "Custom Conditions" end
  if kind == "tracked_quest_id" then return "Quest" end
  if kind == "difficulty_level" or kind == "zone_state" then return "Gameplay" end
  if kind == "equipped_slot_item" then return "Equipment" end
  if kind == "target_class" or kind == "target_distance" or kind == "target_status_effect" or key == "target_exists" or key == "target_npc" or key == "target_hostile" or key == "target_aggro" then return "Target" end
  if kind == "owned_item" then return "Inventory" end
  if kind == "owned_vehicle" or key == "inVehicle" then return "Vehicle" end
  if key == "shooting" or key == "reloading" or key == "aiming" or key == "meleeAttack" or key == "weaponActive" or key == "in_combat" or kind == "active_weapon_id" or kind == "player_status_effect" then return "Combat" end
  return "Movement"
end

local function _conditionOptions()
  local out = {}
  local MoveObserver = _safeRequire("GTS/move_observer")
  if MoveObserver and type(MoveObserver.ListRuleConditions) == "function" then
    local ok, list = pcall(MoveObserver.ListRuleConditions)
    if ok and type(list) == "table" then
      for i = 1, #list do
        local item = _clone(list[i])
        item.category = _groupConditionOption(item)
        out[#out + 1] = item
      end
    end
  end
  out[#out + 1] = {
    label = "Condition: Saved Stat Condition",
    kind = "saved_stat_condition",
    key = "saved_stat_condition",
    category = "Custom Conditions",
    ref = "",
  }
  out[#out + 1] = {
    label = "Condition: Custom",
    kind = "custom_observer",
    key = "custom_stat_observer",
    category = "Custom Conditions",
    customObserverDef = { stat = "", op = "==", src = "Stat Value", valueStr = "0", value = 0 }
  }
  out[#out + 1] = { label = "Manual: Toggle 1", kind = "manual_toggle", key = "manual_1", category = "Manual Test" }
  out[#out + 1] = { label = "Manual: Toggle 2", kind = "manual_toggle", key = "manual_2", category = "Manual Test" }
  out[#out + 1] = { label = "Manual: Toggle 3", kind = "manual_toggle", key = "manual_3", category = "Manual Test" }
  return out
end

local function _findConditionOption(label)
  local options = _conditionOptions()
  for i = 1, #options do if tostring(options[i].label) == tostring(label) then return _clone(options[i]) end end
  return _clone(options[1])
end
local function _conditionLabels()
  local options = _conditionOptions()
  local labels = {}
  for i = 1, #options do labels[#labels + 1] = tostring(options[i].label or "Condition") end
  return labels
end

local function _conditionPickerLabel(cond)
  cond = cond or {}
  if tostring(cond.kind or "") == "saved_stat_condition" then
    return "Condition: Saved Stat Condition"
  end
  if type(cond.customObserverDef) == "table" or tostring(cond.kind or "") == "custom_observer" then
    return "Condition: Custom"
  end
  local options = _conditionOptions()
  for i = 1, #options do
    local opt = options[i]
    if tostring(opt.kind or "") == tostring(cond.kind or "") and tostring(opt.key or "") == tostring(cond.key or "") then
      return tostring(opt.label or "Condition")
    end
  end
  return tostring((cond.label and cond.label ~= "") and cond.label or (options[1] and options[1].label) or "Condition")
end

local function _statsCatalogForConditions()
  local StatsUI = _safeRequire("GTS/stats_browser")
  if StatsUI and type(StatsUI.GetStatCatalog) == "function" then
    local ok, list = pcall(StatsUI.GetStatCatalog)
    if ok and type(list) == "table" and #list > 0 then return list end
  end
  local out = {}
  local ok, recs = pcall(function() return TweakDB:GetRecords("gamedataStat_Record") end)
  if ok and type(recs) == "table" then
    for i = 1, #recs do
      local rec = recs[i]
      local okn, nm = pcall(function() return tostring(rec:EnumName()) end)
      local okc, cm = pcall(function() return tostring(rec:EnumComment()) end)
      if okn and nm and nm ~= "" then
        out[#out + 1] = { name = nm, comment = okc and cm or "", hasPool = (gamedataStatPoolType and gamedataStatPoolType[nm] ~= nil) }
      end
    end
  end
  table.sort(out, function(a, b) return tostring(a.name or "") < tostring(b.name or "") end)
  return out
end

local function _filteredStatsCatalog(query)
  local all = _statsCatalogForConditions()
  local trimmed = tostring(query or ""):lower()
  if trimmed == "" then return all end
  local out = {}
  for i = 1, #all do
    local item = all[i]
    local name = tostring(item.name or ""):lower()
    local comment = tostring(item.comment or ""):lower()
    if string.find(name, trimmed, 1, true) or string.find(comment, trimmed, 1, true) then
      out[#out + 1] = item
    end
  end
  return out
end

local function _drawCustomConditionSetup(cond, idSuffix)
  cond.kind = "custom_observer"
  cond.key = "custom_stat_observer"
  cond.label = nil
  cond.customObserverDef = type(cond.customObserverDef) == "table" and cond.customObserverDef or {}
  local def = cond.customObserverDef
  def.stat = tostring(def.stat or "")
  def.op = tostring(def.op or "==")
  def.src = tostring(def.src or "Stat Value")
  def.valueStr = tostring(def.valueStr or def.value or "0")
  def.value = tonumber(def.value or def.valueStr or 0) or 0

  local customTypes = { "Stat Observer" }
  local currentCustomType = "Stat Observer"
  currentCustomType = _comboSelect("Custom Type##custom_type_" .. tostring(idSuffix or "0"), currentCustomType, customTypes)
  if currentCustomType ~= "Stat Observer" then currentCustomType = "Stat Observer" end

  local srcs = { "Stat Value", "Pool Current", "Pool Max" }
  local ops = { "==", "~=", ">", "<", ">=", "<=" }

  local newSrc = _comboSelect("Source##custom_src_" .. tostring(idSuffix or "0"), tostring(def.src or "Stat Value"), srcs)
  if newSrc ~= tostring(def.src or "Stat Value") then
    def.src = newSrc
    _markDraftDirty()
  end
  local newOp = _comboSelect("Operator##custom_op_" .. tostring(idSuffix or "0"), tostring(def.op or "=="), ops)
  if newOp ~= tostring(def.op or "==") then
    def.op = newOp
    _markDraftDirty()
  end
  local newValueStr = _inputTextValue("Compare Value##custom_value_" .. tostring(idSuffix or "0"), tostring(def.valueStr or def.value or "0"), 48)
  if newValueStr ~= tostring(def.valueStr or def.value or "0") then
    def.valueStr = newValueStr
    def.value = tonumber(newValueStr or "") or def.value or 0
    _markDraftDirty()
  end

  RuleBuilder.state.statObserverSearch = _inputTextValue("Search Stat##custom_stat_search_" .. tostring(idSuffix or "0"), RuleBuilder.state.statObserverSearch or def.stat or "", 128)
  local filtered = _filteredStatsCatalog(RuleBuilder.state.statObserverSearch or def.stat or "")
  local previewLabel = (def.stat ~= "") and tostring(def.stat) or "Choose a stat"
  if ImGui.BeginCombo("Stat##custom_stat_pick_" .. tostring(idSuffix or "0"), previewLabel) then
    for si = 1, #filtered do
      local item = filtered[si]
      local label = tostring(item.name or "")
      if item.hasPool then label = label .. "  [pool]" end
      local selected = (tostring(def.stat or "") == tostring(item.name or ""))
      if ImGui.Selectable(label, selected) then
        def.stat = tostring(item.name or "")
        _markDraftDirty()
      end
    end
    ImGui.EndCombo()
  end

  local expression = (def.stat ~= "") and string.format("%s %s %s", tostring(def.stat), tostring(def.op or "=="), tostring(def.valueStr or def.value or "0")) or "Pick a stat"
  if tostring(def.src or "Stat Value") ~= "Stat Value" then
    expression = string.format("%s [%s]", expression, tostring(def.src or "Stat Value"))
  end
  ImGui.TextDisabled("Expression: " .. expression)

  local MoveObserver = _safeRequire("GTS/move_observer")
  local detail = nil
  if MoveObserver and type(MoveObserver.GetConditionDetail) == "function" then
    local ok, dbg = pcall(MoveObserver.GetConditionDetail, { kind = "custom_observer", customObserverDef = _clone(def) })
    if ok and type(dbg) == "table" then detail = dbg end
  end
  if detail then
    local currentTxt = (detail.left ~= nil) and _formatDebugValue(detail.left) or "-"
    local resultTxt = (detail.current == true) and "TRUE" or "FALSE"
    ImGui.TextDisabled(string.format("Live: %s %s %s | Result %s", currentTxt, tostring(detail.op or def.op or "=="), _formatDebugValue(detail.right), resultTxt))
    if tostring(detail.reason or "") ~= "" then
      ImGui.TextDisabled(tostring(detail.reason))
    end
  else
    ImGui.TextDisabled("Live preview unavailable.")
  end
end

local function _actionConditionChoices(draft)
  local labels = { "No Condition", "Delay / Wait" }
  local map = {
    ["No Condition"] = { mode = "none" },
    ["Delay / Wait"] = { mode = "delay" },
  }
  local groups = _ensureConditionGroupsForDraft(draft)
  for i = 1, #groups do
    local group = groups[i] or {}
    local label = tostring(group.name or group.id or ("Condition Group " .. tostring(i)))
    if map[label] then label = label .. " [" .. tostring(group.id or i) .. "]" end
    labels[#labels + 1] = label
    map[label] = { mode = "group", id = tostring(group.id or "") }
  end
  return labels, map
end

local function _actionConditionChoiceLabel(draft, action)
  action = action or {}
  local mode = tostring(action.conditionMode or "none")
  if mode == "delay" then return "Delay / Wait" end
  if mode == "group" then
    local targetId = tostring(action.conditionGroupId or "")
    local labels, map = _actionConditionChoices(draft)
    for i = 1, #labels do
      local entry = map[labels[i]]
      if type(entry) == "table" and tostring(entry.mode or "") == "group" and tostring(entry.id or "") == targetId then
        return labels[i]
      end
    end
  end
  return "No Condition"
end

local function _applyActionConditionChoice(draft, action, pickedLabel)
  action = action or {}
  local _, map = _actionConditionChoices(draft)
  local picked = map[tostring(pickedLabel or "")] or map["No Condition"]
  action.conditionMode = tostring((picked or {}).mode or "none")
  if action.conditionMode == "group" then
    action.conditionGroupId = tostring((picked or {}).id or "")
  else
    action.conditionGroupId = ""
  end
  if action.conditionMode ~= "delay" then
    action.conditionDelaySeconds = tonumber(action.conditionDelaySeconds or 0.50) or 0.50
  end
  return action
end

local function _actionConditionSummary(draft, action)
  action = action or {}
  local mode = tostring(action.conditionMode or "none")
  if mode == "delay" then
    return string.format("Delay / Wait: %.2fs after script start", tonumber(action.conditionDelaySeconds or 0.50) or 0.50)
  elseif mode == "group" then
    local group = _conditionGroupById(draft, action.conditionGroupId)
    if group then
      return string.format("Condition Group: %s [%s]", tostring(group.name or group.id or "Condition Group"), tostring(group.mode or "ALL"))
    end
    return "Condition Group: (missing)"
  end
  return ""
end


local function _observerPresetAssets()
  return AssetRegistry.List("observer_preset")
end

local function _observerPresetLabels()
  local assets = _observerPresetAssets()
  local labels = {}
  for i = 1, #assets do
    local item = assets[i]
    labels[#labels + 1] = tostring(item.name or item.id or ("Condition Preset " .. tostring(i)))
  end
  return labels
end

local function _observerPresetByLabel(label)
  local assets = _observerPresetAssets()
  local target = tostring(label or "")
  for i = 1, #assets do
    local item = assets[i]
    local itemLabel = tostring(item.name or item.id or ("Condition Preset " .. tostring(i)))
    if itemLabel == target then return item end
  end
  return nil
end

local function _ensureFirstObserverPresetRef(cond)
  if type(cond) ~= "table" then return cond end
  local currentRef = tostring(cond.ref or "")
  local currentAsset = (currentRef ~= "") and AssetRegistry.Get(currentRef) or nil
  if type(currentAsset) == "table" and tostring(currentAsset.type or "") == "observer_preset" then
    return cond
  end
  local assets = _observerPresetAssets()
  if #assets > 0 then cond.ref = tostring((assets[1] or {}).id or "") end
  return cond
end

local function _drawSavedObserverPresetSetup(cond, idSuffix)
  cond.kind = "saved_stat_condition"
  cond.key = "saved_stat_condition"
  cond.label = "Condition: Saved Stat Condition"
  _ensureFirstObserverPresetRef(cond)
  local assets = _observerPresetAssets()
  local labels = _observerPresetLabels()
  if #assets <= 0 then
    cond.ref = ""
    ImGui.TextDisabled("No saved Stat Conditions yet. Create one in Stats Editor first.")
    return
  end

  local currentAsset = (tostring(cond.ref or "") ~= "") and AssetRegistry.Get(cond.ref) or nil
  local currentLabel = currentAsset and tostring(currentAsset.name or currentAsset.id) or labels[1]
  local pickedLabel = _comboSelect("Saved Stat Condition##saved_observer_ref_" .. tostring(idSuffix or "0"), currentLabel, labels, 260)
  local picked = _observerPresetByLabel(pickedLabel)
  local newRef = tostring((picked or {}).id or cond.ref or "")
  if newRef ~= tostring(cond.ref or "") then
    cond.ref = newRef
    _markDraftDirty()
  end

  local asset = (tostring(cond.ref or "") ~= "") and AssetRegistry.Get(cond.ref) or nil
  local entries = type((asset or {}).observers) == "table" and asset.observers or {}
  ImGui.TextDisabled(string.format("Rows: %d | Match: ALL", #entries))
  local previewMax = math.min(#entries, 4)
  for pi = 1, previewMax do
    local row = entries[pi] or {}
    local src = tostring(row.src or "Stat Value")
    local expr = tostring(row.stat or "Stat") .. " " .. tostring(row.op or "==") .. " " .. tostring(row.valueStr or row.value or "0")
    if src ~= "Stat Value" then expr = expr .. " [" .. src .. "]" end
    ImGui.TextDisabled(expr)
  end
  if #entries > previewMax then
    ImGui.TextDisabled("...")
  end
end

local function _appendCondition(draft, cond)
  if type(cond) ~= "table" then return false end
  draft.data = draft.data or {}
  local groups = _ensureConditionGroupsForDraft(draft)
  if #groups <= 0 then return false end
  local st = RuleBuilder.state or {}
  local gidx = math.max(1, math.min(tonumber(st.selectedConditionGroupIndex or 1) or 1, #groups))
  st.selectedConditionGroupIndex = gidx
  local group = groups[gidx]
  group.conditions = type(group.conditions) == "table" and group.conditions or {}
  group.conditions[#group.conditions + 1] = _clone(cond)
  _syncTriggerConditionsForDraft(draft)
  return true
end

local function _appendCurrentCustomObserversToDraft(draft)
  local MoveObserver = _safeRequire("GTS/move_observer")
  if not MoveObserver or type(MoveObserver.GetCustomObservers) ~= "function" or type(MoveObserver.MakeConditionFromCustomObserver) ~= "function" then
    return 0
  end
  local list = MoveObserver.GetCustomObservers()
  local added = 0
  for i = 1, #list do
    local cond = MoveObserver.MakeConditionFromCustomObserver(list[i])
    if _appendCondition(draft, cond) then added = added + 1 end
  end
  return added
end

local function _appendObserverPresetToDraft(draft, assetId)
  if tostring(assetId or "") == "" then return 0 end
  local asset = AssetRegistry.Get(assetId)
  if type(asset) ~= "table" or tostring(asset.type or "") ~= "observer_preset" then return 0 end
  local MoveObserver = _safeRequire("GTS/move_observer")
  if not MoveObserver or type(MoveObserver.MakeConditionFromCustomObserver) ~= "function" then return 0 end
  local added = 0
  local observers = asset.observers or {}
  for i = 1, #observers do
    local cond = MoveObserver.MakeConditionFromCustomObserver(observers[i])
    if _appendCondition(draft, cond) then added = added + 1 end
  end
  return added
end

local function _assetListForActionType(actionType)
  local assetType = _assetTypeForAction(actionType)
  if not assetType then return {} end
  return AssetRegistry.List(assetType)
end

local function _assetNameById(assetId)
  local asset = assetId and AssetRegistry.Get(assetId) or nil
  return asset and tostring(asset.name or asset.id) or nil
end

local function _ensureFirstAssetRefForAction(action)
  if type(action) ~= "table" then return action end
  local actionType = tostring(action.type or "")
  local assetType = _assetTypeForAction(actionType)
  if not assetType then return action end
  local currentRef = tostring(action.ref or "")
  local currentAsset = (currentRef ~= "") and AssetRegistry.Get(currentRef) or nil
  if type(currentAsset) == "table" and tostring(currentAsset.type or "") == assetType then
    return action
  end
  local assets = AssetRegistry.List(assetType) or {}
  if #assets > 0 then
    action.ref = tostring((assets[1] or {}).id or action.ref or "")
  end
  return action
end

local function _ensureFirstRunnableAssetRef(action, draft)
  if type(action) ~= "table" then return action end
  local currentRef = tostring(action.ref or "")
  local currentAsset = (currentRef ~= "") and AssetRegistry.Get(currentRef) or nil
  if type(currentAsset) == "table" and tostring(currentAsset.type or "") ~= "observer_preset" and tostring(currentAsset.id or "") ~= tostring((draft or {}).id or "") then
    return action
  end
  local assets = AssetRegistry.ListCreatedAssets and AssetRegistry.ListCreatedAssets() or AssetRegistry.List() or {}
  for i = 1, #assets do
    local asset = assets[i]
    if tostring(asset.type or "") ~= "observer_preset" and tostring(asset.id or "") ~= tostring((draft or {}).id or "") then
      action.ref = tostring(asset.id or action.ref or "")
      break
    end
  end
  return action
end


local function _assetCategories()
  return {
    { type = "stat_preset", label = "Stat Profiles" },
    { type = "spawn_set", label = "Spawn Presets" },
    { type = "spawn_grid", label = "Saved Spawn Grids" },
    { type = "inventory_bundle", label = "Inventory Bundles" },
    { type = "shooter_profile", label = "Shooter Profiles" },
  }
end

local function _makeActionFromAsset(asset)
  if not asset then return nil end
  local actionType = _actionTypeForAsset(asset)
  if not actionType then return nil end
  return {
    type = actionType,
    ref = asset.id,
  }
end

local function _weatherOptions()
  return {
    { label = "Clear", id = "24h_weather_clear" },
    { label = "Rain", id = "24h_weather_rain" },
    { label = "Cloudy", id = "24h_weather_cloudy" },
    { label = "Sunny", id = "24h_weather_sunny" },
    { label = "Storm", id = "24h_weather_storm" },
    { label = "Fog", id = "24h_weather_fog" },
    { label = "Toxic Rain", id = "24h_weather_toxic_rain" },
    { label = "Sandstorm", id = "24h_weather_sandstorm" },
  }
end

local function _actionTypeChoices()
  return {
    "Apply Stat Profile",
    "Spawn Preset",
    "Spawn Saved Grid",
    "Add Inventory Bundle",
    "Use Shooter Profile",
    "Set Time Of Day",
    "Set Weather",
    "Reset Weather",
    "Set Time Manipulation",
    "Reset Time Manipulation",
    "Set FOV",
    "Remove Zoom / Reset FOV",
    "Camera / No Clip",
    "Show UI Message",
    "Toggle HUD",
    "Johnny HUD",
    "Arasaka HUD",
    "Open Fast Travel Menu",
    "Teleport",
    "Repair Current Vehicle",
    "Passive Mode",
    "Wanted System",
    "Set Wanted Stars",
    "Clear Wanted Level",
    "Johnny Silverhand Arm",
    "Force Equip Weapon",
    "Force Equip Clothing",
    "Apply Status Effect",
    "Remove Status Effect",
    "Force Kill Looked-At NPC",
    "Despawn Target",
    "Move Target",
    "Spawn Grid at Target",
    "Spawn at Target",
    "Apply Status Effect To Target",
    "Tether Target",
    "Cycle Target Appearance",
    "Apply Animation to Player",
    "Apply Animation to Target",
    "Custom CET Code",
    "Run Created Asset",
    "Wait / Delay",
  }
end

local function _actionTypeFromLabel(label)
  local map = {
    ["Apply Stat Profile"] = "apply_stat_preset",
    ["Spawn Preset"] = "spawn_set",
    ["Spawn Saved Grid"] = "spawn_saved_grid",
    ["Add Inventory Bundle"] = "add_inventory_bundle",
    ["Use Shooter Profile"] = "use_shooter_profile",
    ["Set Time Of Day"] = "set_time_of_day",
    ["Set Weather"] = "set_weather",
    ["Reset Weather"] = "reset_weather",
    ["Set Time Manipulation"] = "set_time_dilation",
    ["Reset Time Manipulation"] = "reset_time_dilation",
    ["Set FOV"] = "set_fov",
    ["Remove Zoom / Reset FOV"] = "reset_fov",
    ["Camera / No Clip"] = "camera",
    ["Show UI Message"] = "show_ui_message",
    ["Toggle HUD"] = "toggle_hud",
    ["Johnny HUD"] = "johnny_hud",
    ["Arasaka HUD"] = "arasaka_hud",
    ["Open Fast Travel Menu"] = "open_fast_travel",
    ["Teleport"] = "teleport",
    ["Repair Current Vehicle"] = "repair_current_vehicle",
    ["Passive Mode"] = "passive_mode",
    ["Wanted System"] = "wanted_system",
    ["Set Wanted Stars"] = "set_wanted_stars",
    ["Clear Wanted Level"] = "clear_wanted_level",
    ["Johnny Silverhand Arm"] = "johnny_arm",
    ["Force Equip Weapon"] = "force_equip_weapon",
    ["Force Equip Clothing"] = "force_equip_clothing",
    ["Apply Status Effect"] = "apply_status_effect",
    ["Remove Status Effect"] = "remove_status_effect",
    ["Force Kill Looked-At NPC"] = "force_kill_lookat_npc",
    ["Despawn Target"] = "despawn_target",
    ["Move Target"] = "move_target",
    ["Spawn Grid at Target"] = "spawn_saved_grid_at_target",
    ["Spawn at Target"] = "spawn_at_target",
    ["Apply Status Effect To Target"] = "apply_status_effect_to_target",
    ["Tether Target"] = "tether_target",
    ["Cycle Target Appearance"] = "cycle_target_appearance",
    ["Apply Animation to Player"] = "apply_animation_to_player",
    ["Apply Animation to Target"] = "apply_animation_to_target",
    ["Custom CET Code"] = "custom_cet_code",
    ["Run Created Asset"] = "run_created_asset",
    ["Wait / Delay"] = "wait",
  }
  return map[label] or nil
end

local function _actionNeedsAsset(actionType)
  return _assetTypeForAction(actionType) ~= nil
end

local function _ensureActionDefaults(action)
  action = action or {}
  action.conditionMode = tostring(action.conditionMode or "none")
  if action.conditionMode ~= "group" and action.conditionMode ~= "delay" then action.conditionMode = "none" end
  action.conditionGroupId = tostring(action.conditionGroupId or "")
  action.conditionDelaySeconds = tonumber(action.conditionDelaySeconds or action.delayAfterStartSeconds or 0.50) or 0.50
  if action.conditionDelaySeconds < 0 then action.conditionDelaySeconds = 0 end
  if action.conditionDelaySeconds > 300 then action.conditionDelaySeconds = 300 end
  local t = tostring(action.type or "apply_stat_preset")
  action.type = t
  _ensureFirstAssetRefForAction(action)
  if t == "set_time_of_day" then
    action.hour = math.max(0, math.min(23, math.floor(tonumber(action.hour or 12) or 12)))
    action.minute = math.max(0, math.min(59, math.floor(tonumber(action.minute or 0) or 0)))
  elseif t == "set_weather" then
    local opts = _weatherOptions()
    action.weatherId = tostring(action.weatherId or opts[1].id)
  elseif t == "show_ui_message" then
    action.messageMode = tostring(action.messageMode or "screen")
    action.messageText = tostring(action.messageText or "Script activated")
    action.messageDuration = tonumber(action.messageDuration or 8.0) or 8.0
    if action.messageDuration < 1 then action.messageDuration = 1 end
    if action.messageDuration > 30 then action.messageDuration = 30 end
  elseif t == "set_time_dilation" then
    action.timeTarget = tostring(action.timeTarget or "world_only")
    if action.timeTarget ~= "world_and_v" then action.timeTarget = "world_only" end
    action.timeScale = tonumber(action.timeScale or 0.20) or 0.20
    if action.timeScale < 0.01 then action.timeScale = 0.01 end
    if action.timeScale > 3.00 then action.timeScale = 3.00 end
  elseif t == "set_fov" then
    action.fovValue = tonumber(action.fovValue or 80.0) or 80.0
    if action.fovValue < 50.0 then action.fovValue = 50.0 end
    if action.fovValue > 120.0 then action.fovValue = 120.0 end
  elseif t == "camera" then
    action.command = tostring(action.command or "on")
    if action.command ~= "off" and action.command ~= "toggle" then action.command = "on" end
    action.mode = tostring(action.mode or "detached")
    if action.mode ~= "noclip" then action.mode = "detached" end
    action.speed = tonumber(action.speed or 0.18) or 0.18
    if action.speed < 0.02 then action.speed = 0.02 end
    if action.speed > 1.00 then action.speed = 1.00 end
    action.noClipZOffset = tonumber(action.noClipZOffset or 0.0) or 0.0
    if action.noClipZOffset < -2.0 then action.noClipZOffset = -2.0 end
    if action.noClipZOffset > 2.0 then action.noClipZOffset = 2.0 end
    action.fov = tonumber(action.fov or 60.0) or 60.0
    if action.fov < 20.0 then action.fov = 20.0 end
    if action.fov > 120.0 then action.fov = 120.0 end
    action.disableMode = tostring(action.disableMode or "manual")
    if action.disableMode ~= "after_time" and action.disableMode ~= "while_still" and action.disableMode ~= "either" then action.disableMode = "manual" end
    action.disableAfterSeconds = tonumber(action.disableAfterSeconds or 5.0) or 5.0
    if action.disableAfterSeconds < 0.10 then action.disableAfterSeconds = 0.10 end
    if action.disableAfterSeconds > 3600.0 then action.disableAfterSeconds = 3600.0 end
    action.disableStillSeconds = tonumber(action.disableStillSeconds or 3.0) or 3.0
    if action.disableStillSeconds < 0.10 then action.disableStillSeconds = 0.10 end
    if action.disableStillSeconds > 3600.0 then action.disableStillSeconds = 3600.0 end
  elseif t == "toggle_hud" or t == "johnny_hud" or t == "arasaka_hud" then
    if action.enabled == nil then action.enabled = true end
  elseif t == "johnny_arm" then
    action.mode = tostring(action.mode or "toggle")
    if action.mode ~= "on" and action.mode ~= "off" then action.mode = "toggle" end
  elseif t == "teleport" then
    action.label = tostring(action.label or "")
    action.x = tonumber(action.x or 0) or 0
    action.y = tonumber(action.y or 0) or 0
    action.z = tonumber(action.z or 0) or 0
  elseif t == "passive_mode" or t == "wanted_system" then
    if action.enabled == nil then action.enabled = true end
  elseif t == "set_wanted_stars" then
    action.level = math.max(0, math.min(5, math.floor(tonumber(action.level or 1) or 1)))
  elseif t == "force_equip_weapon" or t == "force_equip_clothing" then
    action.itemId = tostring(action.itemId or "")
  elseif t == "apply_status_effect" or t == "remove_status_effect" then
    action.effectId = tostring(action.effectId or "")
  elseif t == "use_shooter_profile" then
    action.applyTo = tostring(action.applyTo or "global")
    if action.applyTo ~= "active_override" then action.applyTo = "global" end
    if action.forceEnabled == nil then action.forceEnabled = true end
  elseif t == "move_target" then
    action.moveMode = tostring(action.moveMode or "offset")
    if action.moveMode ~= "absolute" then action.moveMode = "offset" end
    action.x = tonumber(action.x or 0) or 0
    action.y = tonumber(action.y or 0) or 0
    action.z = tonumber(action.z or 0) or 0
  elseif t == "spawn_at_target" then
    action.spawnMode = tostring(action.spawnMode or "Character")
    if action.spawnMode ~= "Vehicle" and action.spawnMode ~= "Prop" and action.spawnMode ~= "FX" and action.spawnMode ~= "Attack" and action.spawnMode ~= "Entity" then action.spawnMode = "Character" end
    action.recordId = tostring(action.recordId or action.record or "")
    action.despawnAfterSeconds = tonumber(action.despawnAfterSeconds or 0) or 0
  elseif t == "apply_status_effect_to_target" then
    action.effectId = tostring(action.effectId or "")
  elseif t == "tether_target" then
    action.offsetX = tonumber(action.offsetX or 0) or 0
    action.offsetY = tonumber(action.offsetY or 0) or 0
    action.offsetZ = tonumber(action.offsetZ or 0) or 0
    action.refreshEvery = tonumber(action.refreshEvery or 0.03) or 0.03
    action.endMode = tostring(action.endMode or "manual")
    action.endAfterSeconds = tonumber(action.endAfterSeconds or 5.0) or 5.0
    action.endStillSeconds = tonumber(action.endStillSeconds or 3.0) or 3.0
  elseif t == "cycle_target_appearance" then
    action.step = tonumber(action.step or 1) or 1
    if action.step < 0 then action.step = -1 else action.step = 1 end
  elseif t == "apply_animation_to_player" or t == "apply_animation_to_target" then
    action.sourceMode = tostring(action.sourceMode or "pose_db")
    if action.sourceMode ~= "saved_sequence" then action.sourceMode = "pose_db" end
    action.rig = tostring(action.rig or ((t == "apply_animation_to_player") and "Player Man" or "Man Average"))
    action.poseName = tostring(action.poseName or action.name or "")
    action.poseSearch = tostring(action.poseSearch or "")
    action.sequenceRef = action.sequenceRef
    if action.instant == nil then action.instant = true end
    action.freezeAfterSeconds = tonumber(action.freezeAfterSeconds or 0) or 0
    action.stopAfterSeconds = tonumber(action.stopAfterSeconds or 0) or 0
  elseif t == "custom_cet_code" then
    action.code = tostring(action.code or "")
  elseif t == "run_created_asset" then
    action.ref = action.ref
    action.desiredState = tostring(action.desiredState or "run")
    if action.desiredState ~= "on" and action.desiredState ~= "off" then action.desiredState = "run" end
  elseif t == "wait" then
    action.seconds = tonumber(action.seconds or 0.50) or 0.50
    if action.seconds < 0 then action.seconds = 0 end
    if action.seconds > 300 then action.seconds = 300 end
  end
  return action
end

local function _newAction(actionType)
  local a = { type = tostring(actionType or "apply_stat_preset"), ref = nil }
  return _ensureActionDefaults(a)
end

local function _weatherLabelById(weatherId)
  local opts = _weatherOptions()
  for i = 1, #opts do if tostring(opts[i].id) == tostring(weatherId) then return tostring(opts[i].label) end end
  return tostring(weatherId or "Weather")
end

local function _actionTargetSummary(action)
  action = _ensureActionDefaults(action or {})
  if tostring(action.type or "") == "spawn_saved_grid_at_target" then
    local asset = (action.ref and AssetRegistry.Get(action.ref)) or action.embeddedAsset or nil
    return (asset and tostring(asset.name or asset.id) or "(choose saved asset)") .. " @ target"
  end
  if _actionNeedsAsset(action.type) then
    local asset = (action.ref and AssetRegistry.Get(action.ref)) or action.embeddedAsset or nil
    return asset and tostring(asset.name or asset.id) or "(choose saved asset)"
  end
  local t = tostring(action.type or "")
  if t == "apply_animation_to_player" or t == "apply_animation_to_target" then
    local PoseBuilder = _safeRequire("GTS/pose_builder")
    if PoseBuilder and type(PoseBuilder.DescribeActionTarget) == "function" then
      return PoseBuilder.DescribeActionTarget(action)
    end
    return tostring(action.poseName or action.name or "(choose animation)")
  elseif t == "custom_cet_code" then
    if ImGui.InputTextMultiline then
      local a, b = ImGui.InputTextMultiline("CET Code##setup_custom_cet_code", tostring(action.code or ""), 4096, -1, 120)
      if type(a) == "string" then action.code = a elseif type(b) == "string" then action.code = b end
    else
      action.code = _inputTextValue("CET Code##setup_custom_cet_code", action.code or "", 512)
    end
    ImGui.TextDisabled("Runs the entered CET Lua snippet inside a protected pcall.")
  elseif t == "run_created_asset" then
    _ensureFirstRunnableAssetRef(action, draft)
    local assets = AssetRegistry.ListCreatedAssets and AssetRegistry.ListCreatedAssets() or AssetRegistry.List() or {}
    local labels, byLabel = {}, {}
    for i = 1, #assets do
      local asset = assets[i]
      if tostring(asset.type or "") ~= "observer_preset" and tostring(asset.id or "") ~= tostring((draft or {}).id or "") then
        local label = string.format("[%s] %s", tostring(asset.type or "asset"), tostring(asset.name or asset.id))
        labels[#labels + 1] = label
        byLabel[label] = tostring(asset.id or "")
      end
    end
    if #labels <= 0 then labels[1] = "(none)" end
    local curAsset = (action.ref and AssetRegistry.Get(action.ref)) or action.embeddedAsset or nil
    if not curAsset and #assets > 0 then
      action.ref = tostring(byLabel[labels[1]] or action.ref or "")
      curAsset = (action.ref and AssetRegistry.Get(action.ref)) or action.embeddedAsset or nil
      _markDraftDirty()
    end
    local currentLabel = curAsset and string.format("[%s] %s", tostring(curAsset.type or "asset"), tostring(curAsset.name or curAsset.id)) or labels[1]
    local picked = _comboSelect("Created Asset##setup_run_created_asset_ref", currentLabel, labels)
    action.ref = byLabel[picked] or action.ref
    local desired = _comboSelect("Run Mode##setup_run_created_asset_mode", ({ run = "Run Once", on = "Toggle On", off = "Toggle Off" })[tostring(action.desiredState or "run")] or "Run Once", { "Run Once", "Toggle On", "Toggle Off" })
    action.desiredState = ({ ["Run Once"] = "run", ["Toggle On"] = "on", ["Toggle Off"] = "off" })[desired] or "run"
    ImGui.TextDisabled("Use this to launch any saved script, macro, custom code asset, preset, grid, launcher, or teleport preset.")
  elseif t == "set_time_of_day" then
    return string.format("%02d:%02d", tonumber(action.hour or 0) or 0, tonumber(action.minute or 0) or 0)
  elseif t == "set_weather" then
    return _weatherLabelById(action.weatherId)
  elseif t == "reset_weather" then
    return "Restore default weather"
  elseif t == "set_time_dilation" then
    local mode = (tostring(action.timeTarget or "world_only") == "world_and_v") and "world + V" or "world only"
    return string.format("%s | %.2f", mode, tonumber(action.timeScale or 0.20) or 0.20)
  elseif t == "reset_time_dilation" then
    return "Reset time manipulation"
  elseif t == "set_fov" then
    return string.format("FOV %.1f", tonumber(action.fovValue or 80.0) or 80.0)
  elseif t == "reset_fov" then
    return "Reset FOV / remove zoom"
  elseif t == "camera" then
    local cmd = tostring(action.command or "on")
    local mode = (tostring(action.mode or "detached") == "noclip") and "No Clip" or "Detached"
    local disableMode = tostring(action.disableMode or "manual")
    local disableText = "manual"
    if disableMode == "after_time" then
      disableText = string.format("off after %.1fs", tonumber(action.disableAfterSeconds or 5.0) or 5.0)
    elseif disableMode == "while_still" then
      disableText = string.format("off still %.1fs", tonumber(action.disableStillSeconds or 3.0) or 3.0)
    elseif disableMode == "either" then
      disableText = string.format("off %.1fs / still %.1fs", tonumber(action.disableAfterSeconds or 5.0) or 5.0, tonumber(action.disableStillSeconds or 3.0) or 3.0)
    end
    return string.format("%s | %s | %.2f | %s", string.upper(cmd), mode, tonumber(action.speed or 0.18) or 0.18, disableText)
  elseif t == "show_ui_message" then
    local txt = tostring(action.messageText or "")
    if txt == "" then txt = "(enter custom text)" end
    return tostring(action.messageMode or "screen") .. ": " .. txt
  elseif t == "toggle_hud" then
    return (action.enabled == false) and "HUD ON" or "HUD OFF"
  elseif t == "johnny_hud" then
    return (action.enabled == false) and "OFF" or "ON"
  elseif t == "arasaka_hud" then
    return (action.enabled == false) and "OFF" or "ON"
  elseif t == "open_fast_travel" then
    return "Open menu"
  elseif t == "teleport" then
    local label = tostring(action.label or "")
    if label ~= "" then return label end
    return string.format("X %.2f | Y %.2f | Z %.2f", tonumber(action.x or 0) or 0, tonumber(action.y or 0) or 0, tonumber(action.z or 0) or 0)
  elseif t == "repair_current_vehicle" then
    return "Repairs the mounted vehicle"
  elseif t == "passive_mode" then
    return (action.enabled == false) and "Turn OFF" or "Turn ON"
  elseif t == "wanted_system" then
    return (action.enabled == false) and "Turn OFF" or "Turn ON"
  elseif t == "set_wanted_stars" then
    return string.format("Set to %d star(s)", tonumber(action.level or 0) or 0)
  elseif t == "clear_wanted_level" then
    return "Set wanted level to 0"
  elseif t == "johnny_arm" then
    local mode = tostring(action.mode or "toggle")
    if mode == "on" then return "Force ON" end
    if mode == "off" then return "Force OFF" end
    return "Toggle"
  elseif t == "force_equip_weapon" or t == "force_equip_clothing" then
    return tostring(action.itemId ~= "" and action.itemId or "(enter item record ID)")
  elseif t == "apply_status_effect" or t == "remove_status_effect" then
    return tostring(action.effectId ~= "" and action.effectId or "(enter status effect ID)")
  elseif t == "force_kill_lookat_npc" then
    return "Looked-at NPC"
  elseif t == "despawn_target" then
    return "Current target"
  elseif t == "move_target" then
    local mode = (tostring(action.moveMode or "offset") == "absolute") and "To" or "By"
    return string.format("%s X %.2f | Y %.2f | Z %.2f", mode, tonumber(action.x or 0) or 0, tonumber(action.y or 0) or 0, tonumber(action.z or 0) or 0)
  elseif t == "spawn_saved_grid_at_target" then
    local asset = (action.ref and AssetRegistry.Get(action.ref)) or action.embeddedAsset or nil
    return (asset and tostring(asset.name or asset.id) or "(choose saved asset)") .. " @ target"
  elseif t == "spawn_at_target" then
    local mode = tostring(action.spawnMode or "Character")
    local modeLabel = (mode == "Character") and "NPC" or ((mode == "Entity") and ".ENT" or string.upper(mode))
    local rec = tostring(action.recordId or "")
    if rec == "" then rec = "(choose record)" end
    return string.format("%s | %s @ target", modeLabel, rec)
  elseif t == "apply_status_effect_to_target" then
    return tostring(action.effectId ~= "" and action.effectId or "(enter target status effect ID)")
  elseif t == "tether_target" then
    local mode = tostring(action.endMode or "manual")
    if mode == "after_time" then
      return string.format("End after %.2f sec", tonumber(action.endAfterSeconds or 0) or 0)
    elseif mode == "while_still" then
      return string.format("End after target still %.2f sec", tonumber(action.endStillSeconds or 0) or 0)
    elseif mode == "either" then
      return string.format("End at %.2f sec or still %.2f sec", tonumber(action.endAfterSeconds or 0) or 0, tonumber(action.endStillSeconds or 0) or 0)
    end
    return "Manual stop"
  elseif t == "custom_cet_code" then
    return (tostring(action.code or "") ~= "") and "Inline CET code" or "(enter CET code)"
  elseif t == "run_created_asset" then
    local asset = (action.ref and AssetRegistry.Get(action.ref)) or action.embeddedAsset or nil
    local name = asset and tostring(asset.name or asset.id) or "(choose created asset)"
    local mode = ({ run = "Run", on = "Toggle On", off = "Toggle Off" })[tostring(action.desiredState or "run")] or "Run"
    return string.format("%s | %s", mode, name)
  elseif t == "use_shooter_profile" then
    return (tostring(action.applyTo or "global") == "active_override") and "Apply to active weapon" or "Apply to global shooter"
  elseif t == "wait" then
    return string.format("Pause %.2f sec", tonumber(action.seconds or 0) or 0)
  end
  return _actionTypeLabel(action.type)
end

local function _loadPlayerPositionIntoAction(action)
  local World = _safeRequire("GTS/macro_actions_world")
  if not World or type(World.GetPlayerPosition) ~= "function" then return false end
  local x, y, z = World.GetPlayerPosition()
  if type(x) ~= "number" or type(y) ~= "number" or type(z) ~= "number" then return false end
  action.x, action.y, action.z = x, y, z
  return true
end

local function _loadTargetPositionIntoAction(action)
  local Target = _safeRequire("GTS/macro_actions_target")
  if not Target or type(Target.GetTargetPosition) ~= "function" then return false end
  local pos = Target.GetTargetPosition(true)
  if type(pos) ~= "table" then return false end
  action.x, action.y, action.z = tonumber(pos.x or 0) or 0, tonumber(pos.y or 0) or 0, tonumber(pos.z or 0) or 0
  return true
end


local function _selectedRuleMutable()
  return RuleBuilder.state.selectedRuleId and AssetRegistry.GetMutable(RuleBuilder.state.selectedRuleId) or nil
end

local function _selectedSavedRule()
  local st = RuleBuilder.state
  if not st.selectedRuleId then return nil end
  local rule = AssetRegistry.Get(st.selectedRuleId)
  if rule and rule.type == "rule" then return _normalizeRule(rule) end
  return nil
end

local function _markDraftDirty()
  RuleBuilder.state.draftDirty = true
end

local function _ensureSelectedRule()
  local st = RuleBuilder.state
  if st.selectedRuleId then return end
  if type(st.draftRule) ~= "table" then
    st.draftRule = AssetRegistry.MakeEmptyRule()
  else
    st.draftRule = _normalizeRule(st.draftRule)
  end
end

local function _syncDraftFromSelectedRule()
  local st = RuleBuilder.state
  _ensureSelectedRule()
  local selected = _selectedSavedRule()
  if selected then
    if st.lastRuleSyncId ~= selected.id or st.draftRule == nil or st.draftDirty ~= true then
      st.draftRule = _normalizeRule(_clone(selected))
      st.lastRuleSyncId = selected.id
      st.draftDirty = false
    end
  elseif type(st.draftRule) ~= "table" then
    st.draftRule = AssetRegistry.MakeEmptyRule()
  else
    st.draftRule = _normalizeRule(st.draftRule)
  end
end

local function _createNewRule()
  local st = RuleBuilder.state
  st.selectedRuleId = nil
  st.lastRuleSyncId = nil
  st.draftRule = AssetRegistry.MakeEmptyRule()
  st.draftRule.name = "New Script"
  st.selectedActionIndex = 1
  st.selectedFalseActionIndex = 1
  st.selectedActionGroupIndex = 1
  st.selectedFalseActionGroupIndex = 1
  st.selectedActionList = "do"
  st.draftDirty = true
  st.lastMessage = "New script ready. Add Conditions, then actions under DO."
end

local function _saveDraftRule(saveAsNew)
  local st = RuleBuilder.state
  local draft = _normalizeRule(_clone(st.draftRule))
  local trimmed = tostring(draft.name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if trimmed == "" then
    st.lastMessage = "Give the script a name first."
    return
  end
  draft.name = trimmed
  local saved
  if saveAsNew then
    saved = ((AssetRegistry.UpsertNew and AssetRegistry.UpsertNew(draft, trimmed)) or AssetRegistry.Upsert(draft))
  else
    saved = AssetRegistry.Upsert(draft)
  end
  if not saved then
    st.lastMessage = "Could not save script."
    return
  end
  st.selectedRuleId = saved.id
  st.lastRuleSyncId = saved.id
  st.draftRule = _clone(saved)
  st.draftDirty = false
  local savedData = ((saved or {}).data) or {}
  st.lastMessage = string.format(saveAsNew and "Saved script copy with %d condition(s), %d group(s), and %d action(s)." or "Saved script with %d condition(s), %d group(s), and %d action(s).", #((savedData.conditions) or {}), #(_groupsForRule(saved, "actionGroups") or {}), _countActionsInGroups(_groupsForRule(saved, "actionGroups")))
end

local function _deleteSelectedRule()
  local st = RuleBuilder.state
  if not st.selectedRuleId then return end
  AssetRegistry.Delete(st.selectedRuleId)
  st.selectedRuleId = nil
  st.lastRuleSyncId = nil
  st.draftRule = AssetRegistry.MakeEmptyRule()
  st.draftDirty = false
  st.lastMessage = "Deleted script."
  _ensureSelectedRule()
end

local function _duplicateSelectedRule()
  local st = RuleBuilder.state
  if not st.selectedRuleId then return end
  local copy = AssetRegistry.Duplicate(st.selectedRuleId)
  if copy then
    st.selectedRuleId = copy.id
    st.lastRuleSyncId = nil
    st.draftDirty = false
    st.lastMessage = "Duplicated script."
  end
end

local function _hasAnyActions(actions)
  return type(actions) == "table" and #actions > 0
end

local function _actionIsStateful(action)
  local t = tostring(((action or {}).type) or "")
  return t == "apply_stat_preset" or t == "set_time_dilation" or t == "set_fov" or t == "camera"
    or t == "toggle_hud" or t == "johnny_hud" or t == "arasaka_hud"
    or t == "passive_mode" or t == "wanted_system" or t == "set_wanted_stars"
    or t == "apply_status_effect" or t == "remove_status_effect" or t == "use_shooter_profile"
end

local function _ruleHasStatefulActions(rule)
  local groups = _groupsForRule(rule, "actionGroups")
  for gi = 1, #groups do
    local actions = (groups[gi] or {}).actions or {}
    for i = 1, #actions do if _actionIsStateful(actions[i]) then return true end end
  end
  return false
end

local function _triggerModeLabel(mode)
  return (tostring(mode or "on_true") == "while_true") and "While True" or "On Change To True"
end

local function _cadenceLabel(exec)
  exec = exec or {}
  local cadence = tostring(exec.cadence or "every_time")
  local n = math.max(1, math.floor(tonumber(exec.cadenceValue or 2) or 2))
  if cadence == "first_true_only" then return "First True Only" end
  if cadence == "every_nth_true" then return string.format("Every %dth True", n) end
  if cadence == "after_nth_true" then return string.format("After %d Trues", n) end
  return "Every Time"
end

local function _falsePolicyLabel(policy)
  local map = {
    do_nothing = "Do Nothing",
    restore = "Restore / Reset",
    run_exit_actions = "Run Exit Actions",
    disable_rule = "Disable Rule",
  }
  return map[tostring(policy or "do_nothing")] or "Do Nothing"
end

local function _behaviorSummary(exec, includeFalse)
  exec = exec or {}
  local parts = { _triggerModeLabel(exec.triggerMode) }
  local cadence = _cadenceLabel(exec)
  if cadence ~= "Every Time" then parts[#parts + 1] = cadence end
  local cooldown = tonumber(exec.cooldown or 0) or 0
  if cooldown > 0 then parts[#parts + 1] = string.format("Cooldown %.2fs", cooldown) end
  if exec.disableAfterFire == true then parts[#parts + 1] = "Disable After Fire" end
  if includeFalse and tostring(exec.falsePolicy or "do_nothing") ~= "do_nothing" then
    parts[#parts + 1] = "Conditions False = " .. _falsePolicyLabel(exec.falsePolicy)
  end
  return table.concat(parts, " · ")
end

local function _ruleSummary(rule)
  rule = _normalizeRule(_clone(rule or {}))
  local condCount = #((rule.data or {}).conditions or {})
  local groups = _groupsForRule(rule, "actionGroups")
  local actCount = _countActionsInGroups(groups)
  local mode = tostring((rule.data or {}).conditionMode or "ALL")
  local exec = ((rule.data or {}).execution) or {}
  return string.format("%s | %d Conditions | %d group(s) | %d DO | %s", mode, condCount, #groups, actCount, _behaviorSummary(exec, _ruleHasStatefulActions(rule)))
end

local function _drawManualTogglesInline()
  local m1 = _checkboxValue("Toggle 1##macro_manual_1", RuleRunner.GetManualToggle("manual_1"))
  ImGui.SameLine()
  local m2 = _checkboxValue("Toggle 2##macro_manual_2", RuleRunner.GetManualToggle("manual_2"))
  ImGui.SameLine()
  local m3 = _checkboxValue("Toggle 3##macro_manual_3", RuleRunner.GetManualToggle("manual_3"))
  RuleRunner.SetManualToggle("manual_1", m1)
  RuleRunner.SetManualToggle("manual_2", m2)
  RuleRunner.SetManualToggle("manual_3", m3)
end

local function _drawConditionPickerPopup(popupId, onPick)
  if type(ImGui.BeginPopup) ~= "function" then return end
  if ImGui.BeginPopup(popupId) then
    local cats = { "Movement", "Combat", "Vehicle", "Inventory", "Target", "Custom Conditions", "Manual Test" }
    local options = _conditionOptions()
    for _, cat in ipairs(cats) do
      local items = {}
      for i = 1, #options do
        if tostring(options[i].category) == cat then items[#items + 1] = options[i] end
      end
      if #items > 0 and ImGui.BeginMenu(cat) then
        for i = 1, #items do
          local opt = items[i]
          if ImGui.MenuItem(tostring(opt.label)) then
            onPick(_clone(opt))
            if type(ImGui.CloseCurrentPopup) == "function" then ImGui.CloseCurrentPopup() end
          end
        end
        ImGui.EndMenu()
      end
    end
    ImGui.EndPopup()
  end
end

local function _drawActionPickerPopup(popupId, onPick)
  if type(ImGui.BeginPopup) ~= "function" then return end
  if ImGui.BeginPopup(popupId) then
    local cats = _assetCategories()
    for _, cat in ipairs(cats) do
      local assets = AssetRegistry.List(cat.type)
      if #assets > 0 and ImGui.BeginMenu(cat.label) then
        for i = 1, #assets do
          local asset = assets[i]
          local preview = tostring(asset.name or asset.id)
          if ImGui.MenuItem(preview) then
            onPick(_clone(asset))
            if type(ImGui.CloseCurrentPopup) == "function" then ImGui.CloseCurrentPopup() end
          end
        end
        ImGui.EndMenu()
      end
    end
    ImGui.EndPopup()
  end
end

local function _drawMacroListColumn(width)
  local st = RuleBuilder.state
  ImGui.BeginChild("macros_list_column", width, 0, true)
  _textColored(0.92, 0.82, 0.28, 1.0, "My Scripts")
  ImGui.TextDisabled("Saved rules you can enable, duplicate, and debug.")
  if ImGui.Button("New Script") then _createNewRule() end
  ImGui.Separator()

  local rules = AssetRegistry.ListMutable("rule")
  if #rules == 0 then
    ImGui.TextDisabled("No scripts saved yet.")
    ImGui.TextWrapped("Create one in the Builder. A new script starts empty on purpose: no hidden conditions, no hidden actions.")
    ImGui.EndChild()
    return
  end

  for i = 1, #rules do
    local rule = rules[i]
    local isSelected = (st.selectedRuleId == rule.id)
    local enabled = ((rule.data or {}).enabled) ~= false
    local newEnabled = _checkboxValue("##macro_enable_" .. tostring(rule.id), enabled)
    if newEnabled ~= enabled then
      rule.data.enabled = newEnabled
    end
    ImGui.SameLine()
    if ImGui.Selectable(tostring(rule.name or rule.id) .. "##macro_pick_" .. tostring(rule.id), isSelected) then
      st.selectedRuleId = rule.id
      st.lastRuleSyncId = nil
      st.draftDirty = false
    end
    local status = RuleRunner.GetStatus(rule.id)
  local keepDebugOpen = (type(uiState) == "table" and uiState.keepMacroDebugOpenWhenOverlayClosed == true)
    if status.lastEval then
      _textColored(0.35, 0.95, 0.45, 1.0, "  READY")
    else
      _textColored(1.00, 0.35, 0.35, 1.0, "  WAIT")
    end
    ImGui.TextDisabled(_ruleSummary(rule))
    ImGui.TextDisabled(tostring(status.lastMessage or "Idle"))
    ImGui.Separator()
  end

  ImGui.EndChild()
end

local function _drawConditionRowsTable(conditions, tableKeyPrefix)
  if ImGui.BeginTable("macro_when_table_" .. tostring(tableKeyPrefix or "cond"), 6, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 24)
    ImGui.TableSetupColumn("Condition")
    ImGui.TableSetupColumn("Must Be", ImGuiTableColumnFlags.WidthFixed, 120)
    ImGui.TableSetupColumn("Setup", ImGuiTableColumnFlags.WidthFixed, 220)
    ImGui.TableSetupColumn("Move", ImGuiTableColumnFlags.WidthFixed, 120)
    ImGui.TableSetupColumn("Remove", ImGuiTableColumnFlags.WidthFixed, 90)
    ImGui.TableHeadersRow()

    local deleteIndex = nil
    local labels = _conditionLabels()
    for i = 1, #conditions do
      local cond = conditions[i]
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(tostring(i))

      ImGui.TableSetColumnIndex(1)
      local currentLabel = _conditionPickerLabel(cond)
      local newLabel = _comboSelect("##pick_" .. tostring(tableKeyPrefix or "cond") .. "_when_" .. tostring(i), currentLabel, labels)
      if newLabel ~= currentLabel then
        local opt = _findConditionOption(newLabel)
        cond.kind = opt.kind
        cond.key = opt.key
        cond.label = (tostring(opt.kind or "") == "custom_observer") and nil or opt.label
        cond.targetClass = opt.targetClass
        cond.itemId = opt.itemId
        cond.vehicleId = opt.vehicleId
        cond.weaponId = opt.weaponId
        cond.slotKey = opt.slotKey
        cond.questId = opt.questId
        cond.difficulty = opt.difficulty
        cond.distanceMode = opt.distanceMode
        cond.meters = opt.meters
        cond.zoneType = opt.zoneType
        cond.effectId = opt.effectId
        cond.scope = opt.scope
        cond.ref = tostring(opt.ref or "")
        cond.customObserverDef = _clone(opt.customObserverDef)
        if tostring(opt.kind or "") ~= "custom_observer" then cond.customObserverDef = nil end
        if tostring(opt.kind or "") ~= "saved_stat_condition" then cond.ref = nil end
        if tostring(opt.kind or "") == "saved_stat_condition" then _ensureFirstObserverPresetRef(cond) end
        _markDraftDirty()
      end

      ImGui.TableSetColumnIndex(2)
      local expectLabel = (cond.expected ~= false) and "TRUE" or "FALSE"
      local expectNew = _comboSelect("##when_expect_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), expectLabel, { "TRUE", "FALSE" })
      local expectBool = (expectNew == "TRUE")
      if expectBool ~= (cond.expected ~= false) then
        cond.expected = expectBool
        _markDraftDirty()
      end

      ImGui.TableSetColumnIndex(3)
      local kind = tostring(cond.kind or "")
      if kind == "target_class" then
        local selectedClass = _comboSelect("##when_target_class_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.targetClass or TARGET_CLASS_OPTIONS[1]), TARGET_CLASS_OPTIONS)
        if selectedClass ~= tostring(cond.targetClass or TARGET_CLASS_OPTIONS[1]) then
          cond.targetClass = selectedClass
          _markDraftDirty()
        end
      elseif kind == "owned_item" then
        local newValue = _inputTextValue("##when_owned_item_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.itemId or ""), 256)
        if newValue ~= tostring(cond.itemId or "") then
          cond.itemId = newValue
          _markDraftDirty()
        end
      elseif kind == "owned_vehicle" then
        local newValue = _inputTextValue("##when_owned_vehicle_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.vehicleId or ""), 256)
        if newValue ~= tostring(cond.vehicleId or "") then
          cond.vehicleId = newValue
          _markDraftDirty()
        end
      elseif kind == "active_weapon_id" then
        local newValue = _inputTextValue("##when_active_weapon_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.weaponId or ""), 256)
        if newValue ~= tostring(cond.weaponId or "") then
          cond.weaponId = newValue
          _markDraftDirty()
        end
      elseif kind == "equipped_slot_item" then
        local selectedSlot = _comboSelect("##when_equipped_slot_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.slotKey or RULE_EQUIPPED_SLOT_OPTIONS[1]), RULE_EQUIPPED_SLOT_OPTIONS)
        if selectedSlot ~= tostring(cond.slotKey or RULE_EQUIPPED_SLOT_OPTIONS[1]) then
          cond.slotKey = selectedSlot
          _markDraftDirty()
        end
        ImGui.SameLine()
        local newValue = _inputTextValue("##when_equipped_item_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.itemId or ""), 256)
        if newValue ~= tostring(cond.itemId or "") then
          cond.itemId = newValue
          _markDraftDirty()
        end
      elseif kind == "target_distance" then
        local selectedMode = _comboSelect("##when_target_distance_mode_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.distanceMode or 'within'), { 'within', 'farther' })
        if selectedMode ~= tostring(cond.distanceMode or 'within') then
          cond.distanceMode = selectedMode
          _markDraftDirty()
        end
        ImGui.SameLine()
        local newMeters = _inputFloatValue("##when_target_distance_meters_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tonumber(cond.meters or 10) or 10, 0.5, 5.0, "%.1f")
        if newMeters ~= tonumber(cond.meters or 10) then
          cond.meters = math.max(0, tonumber(newMeters or 0) or 0)
          _markDraftDirty()
        end
      elseif kind == "difficulty_level" then
        local selectedDifficulty = _comboSelect("##when_difficulty_level_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.difficulty or RULE_DIFFICULTY_OPTIONS[1]), RULE_DIFFICULTY_OPTIONS)
        if selectedDifficulty ~= tostring(cond.difficulty or RULE_DIFFICULTY_OPTIONS[1]) then
          cond.difficulty = selectedDifficulty
          _markDraftDirty()
        end
      elseif kind == "tracked_quest_id" then
        local newValue = _inputTextValue("##when_active_quest_id_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.questId or ""), 256)
        if newValue ~= tostring(cond.questId or "") then
          cond.questId = newValue
          _markDraftDirty()
        end
      elseif kind == "wanted_level" then
        local modeLabel = _comboSelect("##when_wanted_mode_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.compareMode or "at_least"), { "any", "at_most", "at_least", "exactly" })
        cond.compareMode = modeLabel
        ImGui.SameLine()
        local lv = _comboSelect("##when_wanted_level_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(math.floor(tonumber(cond.level or 1) or 1)), { "0", "1", "2", "3", "4", "5" })
        cond.level = tonumber(lv) or 1
      elseif kind == "target_health" then
        cond.compareOp = _comboSelect("##when_target_hp_op_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.compareOp or "<="), { "<=", ">=", "<", ">", "==" })
        ImGui.SameLine()
        cond.healthValue = tonumber(_inputTextValue("##when_target_hp_val_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.healthValue or 0), 32) or cond.healthValue or 0) or 0
      elseif kind == "target_faction" then
        cond.faction = _inputTextValue("##when_target_faction_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i), tostring(cond.faction or ""), 128)
      elseif kind == "saved_stat_condition" then
        _drawSavedObserverPresetSetup(cond, tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i))
      elseif kind == "custom_observer" then
        _drawCustomConditionSetup(cond, tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i))
      else
        ImGui.TextDisabled("-")
      end

      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton("Up##when_up_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i)) and i > 1 then
        conditions[i], conditions[i - 1] = conditions[i - 1], conditions[i]
        _markDraftDirty()
      end
      ImGui.SameLine()
      if ImGui.SmallButton("Down##when_dn_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i)) and i < #conditions then
        conditions[i], conditions[i + 1] = conditions[i + 1], conditions[i]
        _markDraftDirty()
      end

      ImGui.TableSetColumnIndex(5)
      if ImGui.SmallButton("Remove##when_del_" .. tostring(tableKeyPrefix or "cond") .. "_" .. tostring(i)) then deleteIndex = i end
    end

    ImGui.EndTable()
    if deleteIndex then
      table.remove(conditions, deleteIndex)
      _markDraftDirty()
    end
  end
end

local function _drawWhenSection(draft)
  local conditions = draft.data.conditions or {}
  draft.data.conditions = conditions

  _textColored(0.92, 0.82, 0.28, 1.0, "Conditions")
  ImGui.SameLine()
  ImGui.TextDisabled("Add conditions that must be TRUE or FALSE before the script can fire.")
  draft.data.conditionMode = _comboSelect("Match Mode##macro_when_mode", draft.data.conditionMode or "ALL", { "ALL", "ANY" })

  if ImGui.Button("+ Add Condition") then
    local options = _conditionOptions()
    local first = options[1] or { kind = "manual_toggle", key = "manual_1", label = "Manual: Toggle 1" }
    conditions[#conditions + 1] = {
      kind = first.kind,
      key = first.key,
      label = first.label,
      expected = true,
      targetClass = first.targetClass,
      itemId = first.itemId,
      vehicleId = first.vehicleId,
      weaponId = first.weaponId,
      ref = first.ref,
      customObserverDef = _clone(first.customObserverDef),
    }
    _markDraftDirty()
  end
  ImGui.SameLine()
  ImGui.TextDisabled("Each row can be changed inline. Add multiple rows for AND / OR logic.")

  if #conditions == 0 then
    ImGui.TextDisabled("No Conditions yet. Example: Running = TRUE and Shooting = TRUE.")
    return
  end

  _drawConditionRowsTable(conditions, "rule_root")
end

local function _drawConditionGroupsSection(draft)
  local st = RuleBuilder.state
  local groups = _ensureConditionGroupsForDraft(draft)
  _syncTriggerConditionsForDraft(draft)
  groups = _ensureConditionGroupsForDraft(draft)

  _textColored(0.92, 0.82, 0.28, 1.0, "Condition Groups")
  ImGui.SameLine()
  ImGui.TextDisabled("All conditions live inside a group. Pick one trigger group for the script, then reuse groups on action rows.")

  if ImGui.Button("+ Add Group##macro_condition_group_add") then
    groups[#groups + 1] = {
      id = string.format("condition_group_%d", #groups + 1),
      name = string.format("Condition Group %d", #groups + 1),
      mode = "ALL",
      conditions = {},
    }
    st.selectedConditionGroupIndex = #groups
    if tostring(draft.data.triggerConditionGroupId or "") == "" then
      draft.data.triggerConditionGroupId = tostring((groups[#groups] or {}).id or "")
    end
    _syncTriggerConditionsForDraft(draft)
    _markDraftDirty()
  end
  ImGui.SameLine()
  if ImGui.Button("+ Add Condition##macro_condition_group_add_condition") then
    if #groups <= 0 then
      groups[1] = { id = "condition_group_1", name = "Condition Group 1", mode = "ALL", conditions = {} }
    end
    local gidx = math.max(1, math.min(tonumber(st.selectedConditionGroupIndex or 1) or 1, #groups))
    st.selectedConditionGroupIndex = gidx
    local options = _conditionOptions()
    local first = options[1] or { kind = "manual_toggle", key = "manual_1", label = "Manual: Toggle 1" }
    local group = groups[gidx]
    group.conditions = type(group.conditions) == "table" and group.conditions or {}
    group.conditions[#group.conditions + 1] = {
      kind = first.kind,
      key = first.key,
      label = first.label,
      expected = true,
      targetClass = first.targetClass,
      itemId = first.itemId,
      vehicleId = first.vehicleId,
      weaponId = first.weaponId,
      ref = first.ref,
      customObserverDef = _clone(first.customObserverDef),
    }
    _syncTriggerConditionsForDraft(draft)
    _markDraftDirty()
  end
  ImGui.SameLine()
  if #groups == 0 then
    ImGui.TextDisabled("No condition groups yet.")
    return
  end

  if st.selectedConditionGroupIndex < 1 or st.selectedConditionGroupIndex > #groups then st.selectedConditionGroupIndex = 1 end

  local triggerLabels = {}
  local triggerMap = {}
  local currentTriggerLabel = nil
  for gi = 1, #groups do
    local group = groups[gi] or {}
    local label = tostring(group.name or string.format("Condition Group %d", gi))
    if triggerMap[label] then label = string.format("%s [%s]", label, tostring(group.id or gi)) end
    triggerLabels[#triggerLabels + 1] = label
    triggerMap[label] = tostring(group.id or "")
    if tostring(group.id or "") == tostring(draft.data.triggerConditionGroupId or "") then currentTriggerLabel = label end
  end
  currentTriggerLabel = _comboSelect("Script Trigger Group##macro_condition_trigger_group", currentTriggerLabel or triggerLabels[1], triggerLabels)
  local pickedTriggerId = triggerMap[currentTriggerLabel] or tostring(((groups[1] or {}).id) or "")
  if tostring(pickedTriggerId or "") ~= tostring(draft.data.triggerConditionGroupId or "") then
    draft.data.triggerConditionGroupId = tostring(pickedTriggerId or "")
    _syncTriggerConditionsForDraft(draft)
    _markDraftDirty()
  end
  ImGui.SameLine()
  ImGui.TextDisabled("This group decides when the script is true / false.")

  if ImGui.BeginTable("macro_condition_groups_table", 5, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 26)
    ImGui.TableSetupColumn("Group")
    ImGui.TableSetupColumn("Match", ImGuiTableColumnFlags.WidthFixed, 120)
    ImGui.TableSetupColumn("Move", ImGuiTableColumnFlags.WidthFixed, 120)
    ImGui.TableSetupColumn("Remove", ImGuiTableColumnFlags.WidthFixed, 80)
    ImGui.TableHeadersRow()

    local deleteGroupIndex = nil
    for gi = 1, #groups do
      local group = groups[gi]
      group.conditions = type(group.conditions) == "table" and group.conditions or {}
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      if ImGui.Selectable(tostring(gi) .. "##pick_condition_group_" .. tostring(gi), st.selectedConditionGroupIndex == gi) then
        st.selectedConditionGroupIndex = gi
      end
      ImGui.TableSetColumnIndex(1)
      local newName = _inputTextValue("##condition_group_name_" .. tostring(gi), tostring(group.name or string.format("Condition Group %d", gi)), 128)
      if newName ~= tostring(group.name or "") then
        group.name = newName
        _markDraftDirty()
      end
      ImGui.SameLine()
      ImGui.TextDisabled(string.format("(%d condition%s)%s", #group.conditions, (#group.conditions == 1) and "" or "s", tostring(group.id or "") == tostring(draft.data.triggerConditionGroupId or "") and " [TRIGGER]" or ""))

      ImGui.TableSetColumnIndex(2)
      local newMode = _comboSelect("##condition_group_mode_" .. tostring(gi), tostring(group.mode or "ALL"), { "ALL", "ANY" })
      if tostring(newMode or "ALL") ~= tostring(group.mode or "ALL") then
        group.mode = tostring(newMode or "ALL")
        _syncTriggerConditionsForDraft(draft)
        _markDraftDirty()
      end

      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton("Up##condition_group_up_" .. tostring(gi)) and gi > 1 then
        groups[gi], groups[gi - 1] = groups[gi - 1], groups[gi]
        if st.selectedConditionGroupIndex == gi then st.selectedConditionGroupIndex = gi - 1 elseif st.selectedConditionGroupIndex == gi - 1 then st.selectedConditionGroupIndex = gi end
        _syncTriggerConditionsForDraft(draft)
        _markDraftDirty()
      end
      ImGui.SameLine()
      if ImGui.SmallButton("Down##condition_group_dn_" .. tostring(gi)) and gi < #groups then
        groups[gi], groups[gi + 1] = groups[gi + 1], groups[gi]
        if st.selectedConditionGroupIndex == gi then st.selectedConditionGroupIndex = gi + 1 elseif st.selectedConditionGroupIndex == gi + 1 then st.selectedConditionGroupIndex = gi end
        _syncTriggerConditionsForDraft(draft)
        _markDraftDirty()
      end

      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton("Remove##condition_group_del_" .. tostring(gi)) then deleteGroupIndex = gi end
    end

    ImGui.EndTable()
    if deleteGroupIndex then
      local deletedWasTrigger = tostring((groups[deleteGroupIndex] or {}).id or "") == tostring(draft.data.triggerConditionGroupId or "")
      table.remove(groups, deleteGroupIndex)
      if #groups == 0 then
        groups[1] = { id = "condition_group_1", name = "Condition Group 1", mode = "ALL", conditions = {} }
      end
      if st.selectedConditionGroupIndex > #groups then st.selectedConditionGroupIndex = #groups end
      if st.selectedConditionGroupIndex < 1 then st.selectedConditionGroupIndex = 1 end
      if deletedWasTrigger or not _conditionGroupById(draft, draft.data.triggerConditionGroupId) then
        draft.data.triggerConditionGroupId = tostring(((groups[1] or {}).id) or "")
      end
      _syncTriggerConditionsForDraft(draft)
      _markDraftDirty()
    end
  end

  local gidx = math.max(1, math.min(tonumber(st.selectedConditionGroupIndex or 1) or 1, #groups))
  st.selectedConditionGroupIndex = gidx
  local group = groups[gidx]
  group.conditions = type(group.conditions) == "table" and group.conditions or {}

  ImGui.Spacing()
  _textColored(0.92, 0.82, 0.28, 1.0, string.format("Conditions in %s (%s)", tostring(group.name or string.format("Condition Group %d", gidx)), tostring(group.mode or "ALL")))
  ImGui.TextDisabled("Every condition belongs to a group. Pick this group from an action row if that action should only fire when these conditions pass.")
  if #group.conditions == 0 then
    ImGui.TextDisabled("No conditions in this group yet.")
  else
    _drawConditionRowsTable(group.conditions, "group_" .. tostring(gidx))
  end

  _syncTriggerConditionsForDraft(draft)
end

local function _selectedActionContext(draft)
  local st = RuleBuilder.state
  draft.data.actions = draft.data.actions or {}
  draft.data.falseActions = draft.data.falseActions or {}

  local wantFalse = (st.selectedActionList == "false")
  local groupKey = wantFalse and "falseActionGroups" or "actionGroups"
  local selectedGroupKey = wantFalse and "selectedFalseActionGroupIndex" or "selectedActionGroupIndex"
  local selectedKey = wantFalse and "selectedFalseActionIndex" or "selectedActionIndex"
  local label = wantFalse and "ON FALSE" or "DO"
  local groups = _ensureActionGroupsForDraft(draft, groupKey)

  if #groups == 0 and wantFalse then
    groupKey = "actionGroups"
    selectedGroupKey = "selectedActionGroupIndex"
    selectedKey = "selectedActionIndex"
    label = "DO"
    st.selectedActionList = "do"
    groups = _ensureActionGroupsForDraft(draft, groupKey)
  end

  if #groups == 0 then return nil end

  local gidx = math.max(1, math.min(tonumber(st[selectedGroupKey] or 1) or 1, #groups))
  st[selectedGroupKey] = gidx
  local group = groups[gidx]
  group.actions = group.actions or {}
  local actions = group.actions

  local idx = 0
  local action = nil
  if #actions > 0 then
    idx = math.max(1, math.min(tonumber(st[selectedKey] or 1) or 1, #actions))
    st[selectedKey] = idx
    action = _ensureActionDefaults(actions[idx])
    actions[idx] = action
  else
    st[selectedKey] = 1
  end

  return {
    groupKey = groupKey,
    selectedGroupKey = selectedGroupKey,
    selectedKey = selectedKey,
    label = label,
    groups = groups,
    groupIndex = gidx,
    group = group,
    groupName = tostring(group.name or (wantFalse and "Exit Group" or "Group")),
    actions = actions,
    index = idx,
    action = action,
  }
end

local function _drawSelectedActionSetup(draft)
  local st = RuleBuilder.state
  local ctx = _selectedActionContext(draft)
  if not ctx then
    st.selectedActionIndex = 1
    st.selectedFalseActionIndex = 1
    st.selectedActionList = "do"
    return
  end

  local action = ctx.action
  local idx = ctx.index

  ImGui.Spacing()
  _textColored(0.92, 0.82, 0.28, 1.0, "Selected Action Setup")
  if not action then
    ImGui.TextDisabled(string.format("Selected %s / %s has no actions yet.", ctx.label, ctx.groupName or "Group"))
    ImGui.Separator()
    return
  end
  ImGui.TextDisabled(string.format("Editing %s / %s line %d: %s", ctx.label, ctx.groupName or "Group", idx, _actionTypeLabel(action.type)))
  local condSummary = _actionConditionSummary(draft, action)
  if condSummary ~= "" then ImGui.TextDisabled("Action condition: " .. condSummary) end
  if tostring(action.conditionMode or "none") == "delay" then
    local beforeDelay = tonumber(action.conditionDelaySeconds or 0.50) or 0.50
    local delayLabel = "Delay After Script Start (sec)##selected_action_delay_" .. tostring(ctx.groupKey or "group") .. "_" .. tostring(idx)
    local newDelay = _inputFloatValue(delayLabel, beforeDelay, 0.05, 0.25, "%.2f")
    newDelay = math.max(0, math.min(300, tonumber(newDelay or beforeDelay) or beforeDelay))
    if math.abs(newDelay - beforeDelay) > 0.0001 then
      action.conditionDelaySeconds = newDelay
      _markDraftDirty()
    end
  end
  ImGui.Separator()

  if _actionNeedsAsset(action.type) then
    local assets = _assetListForActionType(action.type)
    if tostring(action.type or "") == "spawn_saved_grid_at_target" then
      local asset = (action.ref and AssetRegistry.Get(action.ref)) or action.embeddedAsset or nil
      ImGui.TextDisabled("This action uses a saved grid asset. Pick the grid directly in the action table above.")
      ImGui.TextWrapped("Current target: " .. tostring(asset and (asset.name or asset.id) or "(none selected)") .. " @ target center")
    elseif #assets > 0 then
      local labels = {}
      local idByLabel = {}
      local currentLabel = nil
      for j = 1, #assets do
        local a = assets[j]
        local lbl = tostring(a.name or a.id)
        if idByLabel[lbl] then lbl = lbl .. " [" .. tostring(a.id) .. "]" end
        labels[#labels + 1] = lbl
        idByLabel[lbl] = a.id
        if a.id == action.ref then currentLabel = lbl end
      end
      if currentLabel == nil then
        action.ref = tostring((assets[1] or {}).id or action.ref or "")
        currentLabel = labels[1]
        _markDraftDirty()
      end
      local assetTypeLabel = _assetTypeForAction(action.type) or action.type
      ImGui.TextDisabled("Select the saved " .. tostring(assetTypeLabel) .. " to use for this action:")
      local newLabel = _comboSelect("##setup_asset_ref_" .. tostring(action.type), currentLabel, labels)
      local newRef = idByLabel[newLabel]
      if newRef and newRef ~= action.ref then
        action.ref = newRef
        _markDraftDirty()
      end
      local asset = (action.ref and AssetRegistry.Get(action.ref)) or nil
      if asset then
        ImGui.TextDisabled("Selected: " .. tostring(asset.name or asset.id))
        local entries = (((asset.data or {}).entries) or asset.observers) or {}
        if #entries > 0 then
          ImGui.TextDisabled(string.format("(%d entries)", #entries))
        end
      end
    else
      ImGui.TextDisabled("No saved assets of this type yet. Create one in the Stats Editor or relevant tab first.")
    end
    return
  end

  local t = tostring(action.type or "")
  if t == "apply_animation_to_player" or t == "apply_animation_to_target" then
    local PoseBuilder = _safeRequire("GTS/pose_builder")
    if PoseBuilder and type(PoseBuilder.DrawActionSetup) == "function" then
      PoseBuilder.DrawActionSetup(action, (t == "apply_animation_to_player") and "player" or "target", tostring(draft and draft.id or "draft") .. "_" .. tostring(ctx.groupKey or "group") .. "_" .. tostring(idx))
    else
      ImGui.TextDisabled("Pose Builder module unavailable.")
    end
  elseif t == "custom_cet_code" then
    if ImGui.InputTextMultiline then
      local a, b = ImGui.InputTextMultiline("CET Code##setup_custom_cet_code", tostring(action.code or ""), 4096, -1, 120)
      if type(a) == "string" then action.code = a elseif type(b) == "string" then action.code = b end
    else
      action.code = _inputTextValue("CET Code##setup_custom_cet_code", action.code or "", 512)
    end
    ImGui.TextDisabled("Runs the entered CET Lua snippet inside a protected pcall.")
  elseif t == "run_created_asset" then
    _ensureFirstRunnableAssetRef(action, draft)
    local assets = AssetRegistry.ListCreatedAssets and AssetRegistry.ListCreatedAssets() or AssetRegistry.List() or {}
    local labels, byLabel = {}, {}
    for i = 1, #assets do
      local asset = assets[i]
      if tostring(asset.type or "") ~= "observer_preset" and tostring(asset.id or "") ~= tostring((draft or {}).id or "") then
        local label = string.format("[%s] %s", tostring(asset.type or "asset"), tostring(asset.name or asset.id))
        labels[#labels + 1] = label
        byLabel[label] = tostring(asset.id or "")
      end
    end
    if #labels <= 0 then labels[1] = "(none)" end
    local curAsset = (action.ref and AssetRegistry.Get(action.ref)) or action.embeddedAsset or nil
    if not curAsset and #assets > 0 then
      action.ref = tostring(byLabel[labels[1]] or action.ref or "")
      curAsset = (action.ref and AssetRegistry.Get(action.ref)) or action.embeddedAsset or nil
      _markDraftDirty()
    end
    local currentLabel = curAsset and string.format("[%s] %s", tostring(curAsset.type or "asset"), tostring(curAsset.name or curAsset.id)) or labels[1]
    local picked = _comboSelect("Created Asset##setup_run_created_asset_ref", currentLabel, labels)
    action.ref = byLabel[picked] or action.ref
    local desired = _comboSelect("Run Mode##setup_run_created_asset_mode", ({ run = "Run Once", on = "Toggle On", off = "Toggle Off" })[tostring(action.desiredState or "run")] or "Run Once", { "Run Once", "Toggle On", "Toggle Off" })
    action.desiredState = ({ ["Run Once"] = "run", ["Toggle On"] = "on", ["Toggle Off"] = "off" })[desired] or "run"
    ImGui.TextDisabled("Use this to launch any saved script, macro, custom code asset, preset, grid, launcher, or teleport preset.")
  elseif t == "set_time_of_day" then
    action.hour = _inputIntValue("Hour##setup_hour", action.hour or 12, 1, 4)
    action.minute = _inputIntValue("Minute##setup_minute", action.minute or 0, 1, 5)
    if action.hour < 0 then action.hour = 0 end
    if action.hour > 23 then action.hour = 23 end
    if action.minute < 0 then action.minute = 0 end
    if action.minute > 59 then action.minute = 59 end
    ImGui.TextDisabled(string.format("Preview: %02d:%02d", action.hour, action.minute))
  elseif t == "set_weather" then
    local opts = _weatherOptions()
    local labels, idByLabel = {}, {}
    local cur = nil
    for i = 1, #opts do
      labels[#labels + 1] = opts[i].label
      idByLabel[opts[i].label] = opts[i].id
      if tostring(opts[i].id) == tostring(action.weatherId or "") then cur = opts[i].label end
    end
    local picked = _comboSelect("Weather Preset##setup_weather", cur or labels[1], labels)
    action.weatherId = idByLabel[picked] or action.weatherId
    ImGui.TextDisabled("Weather ID: " .. tostring(action.weatherId or ""))
  elseif t == "reset_weather" then
    ImGui.TextDisabled("No extra setup needed. This clears the forced weather and returns the game to its default weather cycle.")
  elseif t == "set_time_dilation" then
    action.timeTarget = _comboSelect("Target##setup_time_target", tostring(action.timeTarget or "world_only") == "world_and_v" and "World + V" or "World Only", { "World Only", "World + V" })
    action.timeTarget = (action.timeTarget == "World + V") and "world_and_v" or "world_only"
    action.timeScale = _sliderFloatValue("Time Scale##setup_time_scale", action.timeScale or 0.20, 0.01, 3.00, "%.2f")
    if action.timeScale < 0.01 then action.timeScale = 0.01 end
    if action.timeScale > 3.00 then action.timeScale = 3.00 end
    ImGui.TextDisabled(string.format("Preview: %s | %.2f", action.timeTarget == "world_and_v" and "world + V" or "world only", action.timeScale))
  elseif t == "reset_time_dilation" then
    ImGui.TextDisabled("No extra setup needed. This clears the active script time manipulation.")
  elseif t == "set_fov" then
    action.fovValue = _sliderFloatValue("FOV##setup_fov_value", action.fovValue or 80.0, 50.0, 120.0, "%.1f")
    if action.fovValue < 50.0 then action.fovValue = 50.0 end
    if action.fovValue > 120.0 then action.fovValue = 120.0 end
    ImGui.TextDisabled(string.format("Preview: %.1f", action.fovValue))
  elseif t == "reset_fov" then
    ImGui.TextDisabled("No extra setup needed. This restores the default FOV value and removes zoom.")
  elseif t == "camera" then
    local pickedCommand = _comboSelect("Camera Action##setup_camera_command", ({ on = "ON / SPAWN", off = "OFF / DISPOSE", toggle = "TOGGLE" })[tostring(action.command or "on")] or "ON / SPAWN", { "ON / SPAWN", "OFF / DISPOSE", "TOGGLE" })
    if pickedCommand == "OFF / DISPOSE" then action.command = "off" elseif pickedCommand == "TOGGLE" then action.command = "toggle" else action.command = "on" end
    action.mode = _comboSelect("Camera Mode##setup_camera_mode", tostring(action.mode or "detached") == "noclip" and "No Clip" or "Detached Camera", { "Detached Camera", "No Clip" })
    action.mode = (action.mode == "No Clip") and "noclip" or "detached"
    action.speed = _sliderFloatValue("Camera Speed##setup_camera_speed", action.speed or 0.18, 0.02, 1.00, "%.2f")
    if action.speed < 0.02 then action.speed = 0.02 end
    if action.speed > 1.00 then action.speed = 1.00 end
    action.fov = _sliderFloatValue("Camera FOV##setup_camera_fov", action.fov or 60.0, 20.0, 120.0, "%.1f")
    if action.fov < 20.0 then action.fov = 20.0 end
    if action.fov > 120.0 then action.fov = 120.0 end
    action.noClipZOffset = _sliderFloatValue("No Clip Z Offset##setup_camera_zoff", action.noClipZOffset or 0.0, -2.0, 2.0, "%.2f")
    if action.noClipZOffset < -2.0 then action.noClipZOffset = -2.0 end
    if action.noClipZOffset > 2.0 then action.noClipZOffset = 2.0 end
    if tostring(action.command or "on") ~= "off" then
      local disableLabel = ({ manual = "Manual Only", after_time = "Disable After Time", while_still = "Disable When Still", either = "Disable On Either" })[tostring(action.disableMode or "manual")] or "Manual Only"
      action.disableMode = _comboSelect("Disable Camera##setup_camera_disable_mode", disableLabel, { "Manual Only", "Disable After Time", "Disable When Still", "Disable On Either" })
      action.disableMode = ({ ["Disable After Time"] = "after_time", ["Disable When Still"] = "while_still", ["Disable On Either"] = "either" })[action.disableMode] or "manual"
      if action.disableMode == "after_time" or action.disableMode == "either" then
        action.disableAfterSeconds = _inputFloatValue("Disable After (sec)##setup_camera_disable_after", action.disableAfterSeconds or 5.0, 0.5, 2.0, "%.2f")
        if action.disableAfterSeconds < 0.10 then action.disableAfterSeconds = 0.10 end
        if action.disableAfterSeconds > 3600.0 then action.disableAfterSeconds = 3600.0 end
      end
      if action.disableMode == "while_still" or action.disableMode == "either" then
        action.disableStillSeconds = _inputFloatValue("Disable When Still For (sec)##setup_camera_disable_still", action.disableStillSeconds or 3.0, 0.5, 2.0, "%.2f")
        if action.disableStillSeconds < 0.10 then action.disableStillSeconds = 0.10 end
        if action.disableStillSeconds > 3600.0 then action.disableStillSeconds = 3600.0 end
      end
    else
      ImGui.TextDisabled("Auto-disable settings only apply when this action turns the camera on.")
    end
    ImGui.TextWrapped("Spawns the detached camera from your reference Lua. While active it uses the same freecam controls and can run in detached or no-clip tether mode.")
    local disablePreview = "manual disable only"
    if tostring(action.command or "on") == "off" then
      disablePreview = "disposes current camera"
    elseif action.disableMode == "after_time" then
      disablePreview = string.format("auto off after %.2f sec", tonumber(action.disableAfterSeconds or 5.0) or 5.0)
    elseif action.disableMode == "while_still" then
      disablePreview = string.format("auto off if still for %.2f sec", tonumber(action.disableStillSeconds or 3.0) or 3.0)
    elseif action.disableMode == "either" then
      disablePreview = string.format("auto off after %.2f sec or still %.2f sec", tonumber(action.disableAfterSeconds or 5.0) or 5.0, tonumber(action.disableStillSeconds or 3.0) or 3.0)
    end
    ImGui.TextDisabled(string.format("Preview: %s | %s | speed %.2f | FOV %.1f | %s", string.upper(tostring(action.command or "on")), action.mode == "noclip" and "No Clip" or "Detached", tonumber(action.speed or 0.18) or 0.18, tonumber(action.fov or 60.0) or 60.0, disablePreview))
  elseif t == "show_ui_message" then
    action.messageMode = _comboSelect("Message Mode##setup_msg_mode", tostring(action.messageMode or "screen"), { "screen", "shard", "alert", "neutral", "relic", "money" })
    action.messageText = _inputTextValue("Custom Text##setup_msg_text", action.messageText or "", 256)
    action.messageDuration = _inputFloatValue("Duration (sec)##setup_msg_duration", action.messageDuration or 8.0, 0.5, 2.0, "%.1f")
    if action.messageDuration < 1 then action.messageDuration = 1 end
    if action.messageDuration > 30 then action.messageDuration = 30 end
    ImGui.TextWrapped("Preview: [" .. tostring(action.messageMode) .. "] " .. tostring(action.messageText or ""))
  elseif t == "toggle_hud" or t == "johnny_hud" or t == "arasaka_hud" then
    local label = (t == "toggle_hud") and "HUD" or ((t == "johnny_hud") and "Johnny HUD" or "Arasaka HUD")
    local pick = _comboSelect(label .. "##setup_interface_toggle", (action.enabled == false) and "OFF" or "ON", { "ON", "OFF" })
    action.enabled = (pick == "ON")
  elseif t == "open_fast_travel" then
    ImGui.TextDisabled("No extra setup needed. This opens the Fast Travel menu immediately.")
  elseif t == "teleport" then
    action.label = _inputTextValue("Location Label##setup_tp_label", action.label or "", 128)
    action.x = _inputFloatValue("X##setup_tp_x", action.x or 0, 0.1, 1.0, "%.2f")
    action.y = _inputFloatValue("Y##setup_tp_y", action.y or 0, 0.1, 1.0, "%.2f")
    action.z = _inputFloatValue("Z##setup_tp_z", action.z or 0, 0.1, 1.0, "%.2f")
    if ImGui.Button("Use Player Position##setup_tp_player") then
      if _loadPlayerPositionIntoAction(action) then
        RuleBuilder.state.lastMessage = "Loaded current player position into teleport action."
      else
        RuleBuilder.state.lastMessage = "Could not read current player position."
      end
    end
    ImGui.TextDisabled(string.format("Preview: %.2f, %.2f, %.2f", tonumber(action.x or 0) or 0, tonumber(action.y or 0) or 0, tonumber(action.z or 0) or 0))
  elseif t == "repair_current_vehicle" then
    ImGui.TextDisabled("No extra setup needed. When this action fires it repairs the vehicle you are currently mounted in.")
  elseif t == "passive_mode" or t == "wanted_system" then
    local label = (t == "passive_mode") and "Mode" or "Wanted System"
    local pick = _comboSelect(label .. "##setup_toggle", (action.enabled == false) and "OFF" or "ON", { "ON", "OFF" })
    action.enabled = (pick == "ON")
  elseif t == "set_wanted_stars" then
    action.level = _inputIntValue("Wanted Stars##setup_stars", action.level or 1, 1, 1)
    if action.level < 0 then action.level = 0 end
    if action.level > 5 then action.level = 5 end
  elseif t == "clear_wanted_level" then
    ImGui.TextDisabled("No extra setup needed. This action clears the wanted level completely.")
  elseif t == "johnny_arm" then
    local picked = _comboSelect("Johnny Silverhand Arm##setup_johnny_arm", ({ on = "ON", off = "OFF", toggle = "TOGGLE" })[tostring(action.mode or "toggle")] or "TOGGLE", { "TOGGLE", "ON", "OFF" })
    if picked == "ON" then action.mode = "on" elseif picked == "OFF" then action.mode = "off" else action.mode = "toggle" end
    ImGui.TextDisabled("Uses the exact Johnny arm equip / unequip logic from your working CET snippet.")
  elseif t == "force_equip_weapon" or t == "force_equip_clothing" then
    local hint = (t == "force_equip_weapon") and "Weapon Item Record ID" or "Clothing Item Record ID"
    action.itemId = _inputTextValue(hint .. "##setup_item", action.itemId or "", 192)
    local InventoryTab = _safeRequire("GTS/inventory_tab")
    if InventoryTab and type(InventoryTab.GetSelectedItemInfo) == "function" then
      if ImGui.Button("Use Inventory Selection##setup_use_inv") then
        local info = InventoryTab.GetSelectedItemInfo()
        if info and info.id and info.id ~= "" then
          action.itemId = tostring(info.id)
          RuleBuilder.state.lastMessage = "Loaded selected inventory item into the equip action."
        else
          RuleBuilder.state.lastMessage = "Select an item in the Inventory tab first."
        end
      end
      local info = InventoryTab.GetSelectedItemInfo()
      if info and info.id and info.id ~= "" then
        ImGui.TextDisabled("Inventory selection: " .. tostring(info.label or info.id))
      end
    else
      ImGui.TextDisabled("Tip: select an item in Inventory tab, then come back here and use that selection.")
    end
  elseif t == "despawn_target" then
    ImGui.TextDisabled("No extra setup needed. This tries to despawn the current live target when the action fires.")
    ImGui.TextDisabled("Works on any valid target the engine allows to be removed.")
  elseif t == "move_target" then
    local pickedMode = _comboSelect("Move Mode##setup_move_target_mode", (tostring(action.moveMode or "offset") == "absolute") and "Absolute XYZ" or "Offset XYZ", { "Offset XYZ", "Absolute XYZ" })
    action.moveMode = (pickedMode == "Absolute XYZ") and "absolute" or "offset"
    action.x = _inputFloatValue("X##setup_move_target_x", action.x or 0, 0.1, 1.0, "%.2f")
    action.y = _inputFloatValue("Y##setup_move_target_y", action.y or 0, 0.1, 1.0, "%.2f")
    action.z = _inputFloatValue("Z##setup_move_target_z", action.z or 0, 0.1, 1.0, "%.2f")
    if action.moveMode == "absolute" then
      if ImGui.Button("Use Target Position##setup_move_target_use_target") then
        if _loadTargetPositionIntoAction(action) then
          RuleBuilder.state.lastMessage = "Loaded current target position into Move Target."
        else
          RuleBuilder.state.lastMessage = "Could not read current target position."
        end
      end
      ImGui.TextDisabled(string.format("Preview: move target to %.2f, %.2f, %.2f", tonumber(action.x or 0) or 0, tonumber(action.y or 0) or 0, tonumber(action.z or 0) or 0))
    else
      ImGui.TextDisabled(string.format("Preview: add X %.2f | Y %.2f | Z %.2f to target position", tonumber(action.x or 0) or 0, tonumber(action.y or 0) or 0, tonumber(action.z or 0) or 0))
    end
  elseif t == "spawn_saved_grid_at_target" then
    ImGui.TextDisabled("No extra setup needed. Pick a saved grid in the action table above.")
    ImGui.TextDisabled("When this fires, the target's location becomes the center of that saved grid.")
  elseif t == "spawn_at_target" then
    local SpawnTools = _safeRequire("GTS/spawn_tools")
    local pickedCategory = _comboSelect("Category##setup_spawn_at_target_mode", ({ Character = "NPC", Vehicle = "VEHICLE", Prop = "PROP", FX = "FX", Attack = "ATTACK", Entity = ".ENT" })[tostring(action.spawnMode or "Character")] or "NPC", { "NPC", "VEHICLE", "PROP", "FX", "ATTACK", ".ENT" })
    if pickedCategory == "VEHICLE" then action.spawnMode = "Vehicle" elseif pickedCategory == "PROP" then action.spawnMode = "Prop" elseif pickedCategory == "FX" then action.spawnMode = "FX" elseif pickedCategory == "ATTACK" then action.spawnMode = "Attack" elseif pickedCategory == ".ENT" then action.spawnMode = "Entity" else action.spawnMode = "Character" end
    st.targetSpawnSearch = _inputTextValue("Search Records##setup_spawn_at_target_search", st.targetSpawnSearch or "", 192)
    if SpawnTools and type(SpawnTools.RefreshDB) == "function" then
      ImGui.SameLine()
      if ImGui.Button("Refresh DB##setup_spawn_at_target_refresh") then
        local counts = SpawnTools.RefreshDB() or {}
        RuleBuilder.state.lastMessage = string.format("Refreshed spawn DB | NPC %d | Vehicle %d | Prop %d | FX %d | Attack %d | .ent %d", tonumber(counts.characters or 0) or 0, tonumber(counts.vehicles or 0) or 0, tonumber(counts.props or 0) or 0, tonumber(counts.fx or 0) or 0, tonumber(counts.attacks or 0) or 0, tonumber(counts.entities or 0) or 0)
      end
    end
    local records = {}
    if SpawnTools and type(SpawnTools.GetRecordsForMode) == "function" then
      records = SpawnTools.GetRecordsForMode(action.spawnMode, st.targetSpawnSearch or "") or {}
    end
    ImGui.TextDisabled(string.format("Matches: %d", #records))
    if #records > 0 then
      local currentRecord = tostring(action.recordId or "")
      if ImGui.BeginChild("spawn_at_target_records", 0, 180, true) then
        for i = 1, #records do
          local rec = tostring(records[i])
          local label = rec
          if tostring(action.spawnMode or "") == "Entity" then label = rec:match("([^\\/]+)$") or rec end
          local selected = (rec == currentRecord)
          if ImGui.Selectable(label .. "##setup_spawn_at_target_" .. tostring(i), selected) then
            action.recordId = rec
            currentRecord = rec
          end
          if tostring(action.spawnMode or "") == "Entity" and ImGui.IsItemHovered() then
            ImGui.BeginTooltip()
            ImGui.TextWrapped(rec)
            ImGui.EndTooltip()
          end
        end
        ImGui.EndChild()
      end
    else
      ImGui.TextDisabled("No records match the current category and search.")
    end
    action.recordId = _inputTextValue("Record ID##setup_spawn_at_target_record_id", action.recordId or "", 256)
    action.despawnAfterSeconds = tonumber(_inputTextValue("Despawn After Seconds##setup_spawn_at_target_despawn", tostring(action.despawnAfterSeconds or 0), 32) or action.despawnAfterSeconds or 0) or 0
    ImGui.TextDisabled("This spawns the selected NPC / vehicle / prop / FX / attack / .ent at the target's current location.")
  elseif t == "apply_status_effect_to_target" then
    local Status = _safeRequire("GTS/macro_actions_status")
    local currentSearch = tostring(st.targetStatusSearch or "")
    local newSearch = _inputTextValue("Search Target Status Effects##setup_target_status_search", currentSearch, 192)
    if newSearch ~= currentSearch then
      st.targetStatusSearch = newSearch
      st.targetStatusSelectedIndex = 1
    end

    action.effectId = _inputTextValue("Target Status Effect ID##setup_target_status_id", action.effectId or "", 256)

    if ImGui.Button("Refresh Target Status List##setup_target_status_refresh") then
      if Status and type(Status.RebuildStatusEffectCache) == "function" then
        Status.RebuildStatusEffectCache()
      end
    end

    local filtered = {}
    if Status and type(Status.ListStatusEffectIds) == "function" then
      filtered = Status.ListStatusEffectIds(st.targetStatusSearch or "") or {}
    end

    if st.targetStatusSelectedIndex < 1 then st.targetStatusSelectedIndex = 1 end
    if st.targetStatusSelectedIndex > #filtered then st.targetStatusSelectedIndex = #filtered end
    if st.targetStatusSelectedIndex < 1 then st.targetStatusSelectedIndex = 1 end

    ImGui.TextDisabled(string.format("Matches: %d", #filtered))
    if #filtered > 0 then
      ImGui.BeginChild("target_status_effect_picker##setup_target_status_picker", 0, 220, true)
      local limit = #filtered
      if limit > 800 then limit = 800 end
      for i = 1, limit do
        local id = filtered[i]
        local selected = (i == st.targetStatusSelectedIndex)
        if ImGui.Selectable(id .. "##setup_target_status_pick_" .. tostring(i), selected) then
          st.targetStatusSelectedIndex = i
          action.effectId = id
        end
      end
      ImGui.EndChild()
      if #filtered > limit then
        ImGui.TextDisabled(string.format("Showing first %d results. Narrow the search to reduce the list.", limit))
      end
    else
      ImGui.TextDisabled("No status effects match the current search.")
    end

    if Status and type(Status.NormalizeEffectId) == "function" then
      local normalized = Status.NormalizeEffectId(action.effectId or "")
      if normalized ~= "" then
        ImGui.TextDisabled("Normalized ID: " .. tostring(normalized))
      end
    end
  elseif t == "tether_target" then
    action.offsetX = _inputFloatValue("Offset X##setup_tether_x", action.offsetX or 0, 0.1, 1.0, "%.2f")
    action.offsetY = _inputFloatValue("Offset Y##setup_tether_y", action.offsetY or 0, 0.1, 1.0, "%.2f")
    action.offsetZ = _inputFloatValue("Offset Z##setup_tether_z", action.offsetZ or 0, 0.1, 1.0, "%.2f")
    action.refreshEvery = _inputFloatValue("Refresh Seconds##setup_tether_refresh", action.refreshEvery or 0.03, 0.005, 0.05, "%.3f")
    local endLabel = _comboSelect("End Mode##setup_tether_endmode", tostring(action.endMode or "manual"), { "manual", "after_time", "while_still", "either" })
    action.endMode = endLabel
    action.endAfterSeconds = _inputFloatValue("End After Seconds##setup_tether_after", action.endAfterSeconds or 5.0, 0.1, 1.0, "%.2f")
    action.endStillSeconds = _inputFloatValue("End Still Seconds##setup_tether_still", action.endStillSeconds or 3.0, 0.1, 1.0, "%.2f")
    ImGui.TextDisabled("Tethers the current target to the player with optional auto-stop rules.")
  elseif t == "cycle_target_appearance" then
    local picked = _comboSelect("Direction##setup_cycle_target_appearance_dir", (tonumber(action.step or 1) or 1) < 0 and "Previous" or "Next", { "Next", "Previous" })
    action.step = (picked == "Previous") and -1 or 1
    ImGui.TextDisabled("Uses the same appearance cycling path as the Target Control tab.")
  elseif t == "wait" then
    action.seconds = _inputFloatValue("Delay Seconds##setup_wait_seconds", action.seconds or 0.50, 0.05, 0.25, "%.2f")
    if action.seconds < 0 then action.seconds = 0 end
    if action.seconds > 300 then action.seconds = 300 end
    ImGui.TextDisabled("This pauses the sequence before continuing to the next action line.")
    ImGui.TextDisabled(string.format("Preview: %.2f sec", tonumber(action.seconds or 0) or 0))
  elseif t == "apply_status_effect" or t == "remove_status_effect" then
    local Status = _safeRequire("GTS/macro_actions_status")
    local currentSearch = tostring(st.statusSearch or "")
    local newSearch = _inputTextValue("Search Status Effects##setup_status_search", currentSearch, 192)
    if newSearch ~= currentSearch then
      st.statusSearch = newSearch
      st.statusSelectedIndex = 1
    end

    action.effectId = _inputTextValue("Status Effect ID##setup_status_id", action.effectId or "", 256)

    if ImGui.Button("Refresh Status List##setup_status_refresh") then
      if Status and type(Status.RebuildStatusEffectCache) == "function" then
        Status.RebuildStatusEffectCache()
      end
    end

    local filtered = {}
    if Status and type(Status.ListStatusEffectIds) == "function" then
      filtered = Status.ListStatusEffectIds(st.statusSearch or "") or {}
    end

    if st.statusSelectedIndex < 1 then st.statusSelectedIndex = 1 end
    if st.statusSelectedIndex > #filtered then st.statusSelectedIndex = #filtered end
    if st.statusSelectedIndex < 1 then st.statusSelectedIndex = 1 end

    ImGui.TextDisabled(string.format("Matches: %d", #filtered))
    if #filtered > 0 then
      ImGui.BeginChild("status_effect_picker##setup_status_picker", 0, 220, true)
      local limit = #filtered
      if limit > 800 then limit = 800 end
      for i = 1, limit do
        local id = filtered[i]
        local selected = (i == st.statusSelectedIndex)
        if ImGui.Selectable(id .. "##setup_status_pick_" .. tostring(i), selected) then
          st.statusSelectedIndex = i
          action.effectId = id
        end
      end
      ImGui.EndChild()
      if #filtered > limit then
        ImGui.TextDisabled(string.format("Showing first %d results. Narrow the search to reduce the list.", limit))
      end
    else
      ImGui.TextDisabled("No status effects match the current search.")
    end

    if Status and type(Status.NormalizeEffectId) == "function" then
      local normalized = Status.NormalizeEffectId(action.effectId or "")
      if normalized ~= "" then
        ImGui.TextDisabled("Normalized ID: " .. tostring(normalized))
      end
    end
  elseif t == "force_kill_lookat_npc" then
    ImGui.TextDisabled("No extra setup needed. Look at an NPC when this action fires.")
    ImGui.TextDisabled("This uses your ForceKill status-effect snippet on the looked-at NPC.")
  elseif t == "spawn_saved_grid" then
    ImGui.TextDisabled("No extra setup needed. This spawns the saved grid around the player using the grid you built and saved in Spawn Tools.")
  elseif t == "use_shooter_profile" then
    local picked = _comboSelect("Apply To##setup_shooter_profile_to", (tostring(action.applyTo or "global") == "active_override") and "Active Weapon Override" or "Global Shooter", { "Global Shooter", "Active Weapon Override" })
    action.applyTo = (picked == "Active Weapon Override") and "active_override" or "global"
    local forcePick = _comboSelect("Force Enable##setup_shooter_profile_enable", (action.forceEnabled ~= false) and "ON" or "Preserve Saved State", { "ON", "Preserve Saved State" })
    action.forceEnabled = (forcePick == "ON")
    ImGui.TextDisabled("Build and save the shooter in the Shooter tab once, then apply that saved profile from a script.")
  end
  _markDraftDirty()
end

local function _drawActionTableSection(draft, groupKey, heading, helpText, selectedIndexKey, actionListFlag, emptyText)
  local st = RuleBuilder.state
  local defaultGroupName = (groupKey == "falseActionGroups") and "Exit Group" or "Group"
  local selectedGroupIndexKey = (groupKey == "falseActionGroups") and "selectedFalseActionGroupIndex" or "selectedActionGroupIndex"
  local groups = _ensureActionGroupsForDraft(draft, groupKey)

  _textColored(0.92, 0.82, 0.28, 1.0, heading)
  ImGui.SameLine()
  ImGui.TextDisabled(helpText)

  if ImGui.Button("+ Add Group##" .. tostring(groupKey) .. "_group_add") then
    groups[#groups + 1] = {
      id = string.format("%s_%d", tostring(defaultGroupName):gsub("%s+", "_"):lower(), #groups + 1),
      name = string.format("%s %d", defaultGroupName, #groups + 1),
      mode = "ordered",
      actions = {},
    }
    st[selectedGroupIndexKey] = #groups
    st[selectedIndexKey] = 1
    st.selectedActionList = actionListFlag
    _markDraftDirty()
  end
  ImGui.SameLine()
  if ImGui.Button(((actionListFlag == "false") and "+ Add Exit Action" or "+ Add Action") .. "##" .. tostring(groupKey) .. "_add_action") then
    if #groups <= 0 then
      groups[1] = { id = string.format("%s_1", tostring(defaultGroupName):gsub("%s+", "_"):lower()), name = defaultGroupName .. " 1", mode = "ordered", actions = {} }
    end
    local gidx = math.max(1, math.min(tonumber(st[selectedGroupIndexKey] or 1) or 1, #groups))
    st[selectedGroupIndexKey] = gidx
    local group = groups[gidx]
    group.actions = group.actions or {}
    group.actions[#group.actions + 1] = _newAction("apply_stat_preset")
    st[selectedIndexKey] = #group.actions
    st.selectedActionList = actionListFlag
    _markDraftDirty()
  end
  ImGui.SameLine()
  ImGui.TextDisabled("Groups run top-to-bottom. Each group can be Ordered or Parallel.")

  if #groups == 0 then
    ImGui.TextDisabled(emptyText)
    return
  end

  if st[selectedGroupIndexKey] < 1 or st[selectedGroupIndexKey] > #groups then st[selectedGroupIndexKey] = 1 end

  if ImGui.BeginTable("macro_groups_table_" .. tostring(groupKey), 5, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 26)
    ImGui.TableSetupColumn("Group")
    ImGui.TableSetupColumn("Mode", ImGuiTableColumnFlags.WidthFixed, 140)
    ImGui.TableSetupColumn("Move", ImGuiTableColumnFlags.WidthFixed, 120)
    ImGui.TableSetupColumn("Remove", ImGuiTableColumnFlags.WidthFixed, 80)
    ImGui.TableHeadersRow()

    local deleteGroupIndex = nil
    for gi = 1, #groups do
      local group = groups[gi]
      group.actions = group.actions or {}
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      if ImGui.Selectable(tostring(gi) .. "##pick_group_" .. tostring(groupKey) .. "_" .. tostring(gi), st[selectedGroupIndexKey] == gi) then
        st[selectedGroupIndexKey] = gi
        st.selectedActionList = actionListFlag
      end
      ImGui.TableSetColumnIndex(1)
      local newName = _inputTextValue("##group_name_" .. tostring(groupKey) .. "_" .. tostring(gi), tostring(group.name or string.format("%s %d", defaultGroupName, gi)), 128)
      if newName ~= tostring(group.name or "") then
        group.name = newName
        _markDraftDirty()
      end
      ImGui.SameLine()
      ImGui.TextDisabled(string.format("(%d action%s)", #group.actions, (#group.actions == 1) and "" or "s"))

      ImGui.TableSetColumnIndex(2)
      local modeLabel = (tostring(group.mode or "ordered") == "parallel") and "Parallel" or "Ordered"
      local pickedMode = _comboSelect("##group_mode_" .. tostring(groupKey) .. "_" .. tostring(gi), modeLabel, { "Ordered", "Parallel" })
      local newMode = (pickedMode == "Parallel") and "parallel" or "ordered"
      if newMode ~= tostring(group.mode or "ordered") then
        group.mode = newMode
        _markDraftDirty()
      end

      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton("Up##group_up_" .. tostring(groupKey) .. "_" .. tostring(gi)) and gi > 1 then
        groups[gi], groups[gi - 1] = groups[gi - 1], groups[gi]
        if st[selectedGroupIndexKey] == gi then st[selectedGroupIndexKey] = gi - 1 elseif st[selectedGroupIndexKey] == gi - 1 then st[selectedGroupIndexKey] = gi end
        _markDraftDirty()
      end
      ImGui.SameLine()
      if ImGui.SmallButton("Down##group_dn_" .. tostring(groupKey) .. "_" .. tostring(gi)) and gi < #groups then
        groups[gi], groups[gi + 1] = groups[gi + 1], groups[gi]
        if st[selectedGroupIndexKey] == gi then st[selectedGroupIndexKey] = gi + 1 elseif st[selectedGroupIndexKey] == gi + 1 then st[selectedGroupIndexKey] = gi end
        _markDraftDirty()
      end

      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton("Remove##group_del_" .. tostring(groupKey) .. "_" .. tostring(gi)) then deleteGroupIndex = gi end
    end

    ImGui.EndTable()
    if deleteGroupIndex then
      table.remove(groups, deleteGroupIndex)
      if #groups == 0 then
        groups[1] = { id = string.format("%s_1", tostring(defaultGroupName):gsub("%s+", "_"):lower()), name = defaultGroupName .. " 1", mode = "ordered", actions = {} }
      end
      if st[selectedGroupIndexKey] > #groups then st[selectedGroupIndexKey] = #groups end
      if st[selectedGroupIndexKey] < 1 then st[selectedGroupIndexKey] = 1 end
      st[selectedIndexKey] = 1
      _markDraftDirty()
    end
  end

  local gidx = math.max(1, math.min(tonumber(st[selectedGroupIndexKey] or 1) or 1, #groups))
  st[selectedGroupIndexKey] = gidx
  local group = groups[gidx]
  group.actions = group.actions or {}
  local actions = group.actions

  ImGui.Spacing()
  _textColored(0.92, 0.82, 0.28, 1.0, string.format("Actions in %s (%s)", tostring(group.name or string.format("%s %d", defaultGroupName, gidx)), (tostring(group.mode or "ordered") == "parallel") and "Parallel" or "Ordered"))
  ImGui.TextDisabled("Ordered = one line at a time. Parallel = fire all lines now, then wait for pending actions like Wait / Delay or auto-disabling camera to finish.")

  if #actions == 0 then
    ImGui.TextDisabled(emptyText)
    return
  end

  if st[selectedIndexKey] < 1 or st[selectedIndexKey] > #actions then st[selectedIndexKey] = 1 end

  if ImGui.BeginTable("macro_actions_table_" .. tostring(groupKey) .. "_g_" .. tostring(gidx), 7, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 26)
    ImGui.TableSetupColumn("Action", ImGuiTableColumnFlags.WidthFixed, 220)
    ImGui.TableSetupColumn("Condition", ImGuiTableColumnFlags.WidthFixed, 190)
    ImGui.TableSetupColumn("Target / Setup")
    ImGui.TableSetupColumn("Edit", ImGuiTableColumnFlags.WidthFixed, 72)
    ImGui.TableSetupColumn("Move", ImGuiTableColumnFlags.WidthFixed, 120)
    ImGui.TableSetupColumn("Remove", ImGuiTableColumnFlags.WidthFixed, 90)
    ImGui.TableHeadersRow()

    local deleteIndex = nil
    local actionTypeLabels = _actionTypeChoices()

    for i = 1, #actions do
      local action = _ensureActionDefaults(actions[i])
      actions[i] = action
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      if ImGui.Selectable(tostring(i) .. "##pick_" .. tostring(groupKey) .. "_row_" .. tostring(gidx) .. "_" .. tostring(i), st[selectedIndexKey] == i) then
        st[selectedIndexKey] = i
        st[selectedGroupIndexKey] = gidx
        st.selectedActionList = actionListFlag
      end

      ImGui.TableSetColumnIndex(1)
      local currentActionLabel = _actionTypeLabel(action.type)
      local newActionLabel = _comboSelect("##pick_" .. tostring(groupKey) .. "_type_" .. tostring(gidx) .. "_" .. tostring(i), currentActionLabel, actionTypeLabels)
      local newType = _actionTypeFromLabel(newActionLabel) or action.type
      if newType ~= action.type then
        local oldRef = action.ref
        actions[i] = _newAction(newType)
        if _actionNeedsAsset(newType) then actions[i].ref = oldRef end
        action = actions[i]
        st[selectedIndexKey] = i
        st[selectedGroupIndexKey] = gidx
        st.selectedActionList = actionListFlag
        _markDraftDirty()
      end

      ImGui.TableSetColumnIndex(2)
      local conditionLabels = nil
      local currentConditionLabel = _actionConditionChoiceLabel(draft, action)
      conditionLabels = select(1, _actionConditionChoices(draft))
      local pickedConditionLabel = _comboSelect("##pick_" .. tostring(groupKey) .. "_cond_" .. tostring(gidx) .. "_" .. tostring(i), currentConditionLabel, conditionLabels)
      if pickedConditionLabel ~= currentConditionLabel then
        _applyActionConditionChoice(draft, action, pickedConditionLabel)
        _markDraftDirty()
      end

      ImGui.TableSetColumnIndex(3)
      if _actionNeedsAsset(action.type) then
        local assets = _assetListForActionType(action.type)
        if #assets == 0 then
          ImGui.TextDisabled("No matching saved assets")
        else
          local labels = {}
          local idByLabel = {}
          local currentLabel = nil
          for j = 1, #assets do
            local asset = assets[j]
            local label = tostring(asset.name or asset.id)
            if idByLabel[label] then label = label .. " [" .. tostring(asset.id) .. "]" end
            labels[#labels + 1] = label
            idByLabel[label] = asset.id
            if asset.id == action.ref then currentLabel = label end
          end
          if currentLabel == nil and #assets > 0 then
            action.ref = tostring((assets[1] or {}).id or action.ref or "")
            currentLabel = labels[1]
            _markDraftDirty()
          else
            currentLabel = currentLabel or labels[1]
          end
          local newLabel = _comboSelect("##pick_" .. tostring(groupKey) .. "_asset_" .. tostring(gidx) .. "_" .. tostring(i), currentLabel, labels)
          local newRef = idByLabel[newLabel]
          if newRef ~= action.ref then
            action.ref = newRef
            _markDraftDirty()
          end
        end
      else
        ImGui.TextUnformatted(_actionTargetSummary(action))
      end

      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton("Setup##" .. tostring(groupKey) .. "_setup_" .. tostring(gidx) .. "_" .. tostring(i)) then
        st[selectedIndexKey] = i
        st[selectedGroupIndexKey] = gidx
        st.selectedActionList = actionListFlag
      end

      ImGui.TableSetColumnIndex(5)
      if ImGui.SmallButton("Up##" .. tostring(groupKey) .. "_up_" .. tostring(gidx) .. "_" .. tostring(i)) and i > 1 then
        actions[i], actions[i - 1] = actions[i - 1], actions[i]
        if st[selectedIndexKey] == i then st[selectedIndexKey] = i - 1 elseif st[selectedIndexKey] == i - 1 then st[selectedIndexKey] = i end
        st.selectedActionList = actionListFlag
        _markDraftDirty()
      end
      ImGui.SameLine()
      if ImGui.SmallButton("Down##" .. tostring(groupKey) .. "_dn_" .. tostring(gidx) .. "_" .. tostring(i)) and i < #actions then
        actions[i], actions[i + 1] = actions[i + 1], actions[i]
        if st[selectedIndexKey] == i then st[selectedIndexKey] = i + 1 elseif st[selectedIndexKey] == i + 1 then st[selectedIndexKey] = i end
        st.selectedActionList = actionListFlag
        _markDraftDirty()
      end

      ImGui.TableSetColumnIndex(6)
      if ImGui.SmallButton("Remove##" .. tostring(groupKey) .. "_del_" .. tostring(gidx) .. "_" .. tostring(i)) then deleteIndex = i end
    end

    ImGui.EndTable()
    if deleteIndex then
      table.remove(actions, deleteIndex)
      if st[selectedIndexKey] > #actions then st[selectedIndexKey] = #actions end
      if st[selectedIndexKey] < 1 then st[selectedIndexKey] = 1 end
      _markDraftDirty()
    end
  end
end

local function _drawBehaviorSection(draft)
  local exec = (((draft or {}).data or {}).execution) or {}
  local before = table.concat({
    tostring(exec.triggerMode or ""),
    tostring(exec.cadence or ""),
    tostring(exec.cadenceValue or ""),
    tostring(exec.cooldown or ""),
    tostring(exec.disableAfterFire or false),
    tostring(exec.falsePolicy or ""),
  }, "|")

  _textColored(0.92, 0.82, 0.28, 1.0, "Behavior")
  ImGui.SameLine()
  ImGui.TextDisabled("Control when this script is allowed to fire, and what happens when Conditions become false.")
  ImGui.TextDisabled(_behaviorSummary(exec, _ruleHasStatefulActions(draft)))

  local firePick = _comboSelect("Fire##macro_behavior_trigger", _triggerModeLabel(exec.triggerMode), { "On Change To True", "While True" })
  exec.triggerMode = (firePick == "While True") and "while_true" or "on_true"

  local cadenceMap = {
    ["Every Time"] = "every_time",
    ["First True Only"] = "first_true_only",
    ["Every Nth True"] = "every_nth_true",
    ["After N Trues"] = "after_nth_true",
  }
  local cadenceLabel = ({ every_time = "Every Time", first_true_only = "First True Only", every_nth_true = "Every Nth True", after_nth_true = "After N Trues" })[tostring(exec.cadence or "every_time")] or "Every Time"
  local cadencePick = _comboSelect("Cadence##macro_behavior_cadence", cadenceLabel, { "Every Time", "First True Only", "Every Nth True", "After N Trues" })
  exec.cadence = cadenceMap[cadencePick] or "every_time"
  if exec.cadence == "every_nth_true" or exec.cadence == "after_nth_true" then
    exec.cadenceValue = _inputIntValue("N Value##macro_behavior_n", exec.cadenceValue or 2, 1, 5)
    if exec.cadenceValue < 1 then exec.cadenceValue = 1 end
  end

  exec.cooldown = _inputFloatValue("Cooldown (sec)##macro_behavior_cooldown", exec.cooldown or 0.25, 0.05, 0.25, "%.2f")
  if exec.cooldown < 0 then exec.cooldown = 0 end
  exec.disableAfterFire = _checkboxValue("Disable after fire##macro_behavior_disable", exec.disableAfterFire == true)

  if _ruleHasStatefulActions(draft) then
    local falseLabel = _falsePolicyLabel(exec.falsePolicy)
    local falsePick = _comboSelect("Conditions False##macro_behavior_false", falseLabel, { "Do Nothing", "Restore / Reset", "Run Exit Actions", "Disable Rule" })
    local falseMap = {
      ["Do Nothing"] = "do_nothing",
      ["Restore / Reset"] = "restore",
      ["Run Exit Actions"] = "run_exit_actions",
      ["Disable Rule"] = "disable_rule",
    }
    exec.falsePolicy = falseMap[falsePick] or "do_nothing"
    if exec.falsePolicy == "restore" then
      ImGui.TextDisabled("Restore / Reset supports Stat Profiles, time dilation, FOV, status effects, wanted stars, and simple ON/OFF toggles.")
    elseif exec.falsePolicy == "run_exit_actions" then
      ImGui.TextDisabled("Build a separate ON FALSE action list below. Use it for custom off values or special cleanup steps.")
    end
  else
    exec.falsePolicy = "do_nothing"
    ImGui.TextDisabled("No stateful actions in DO yet, so Conditions false handling stays hidden.")
  end

  draft.data.execution = exec
  draft.data.falseActions = exec.falseActions or draft.data.falseActions or {}
  draft.data.runOnceUntilFalse = (exec.triggerMode == "on_true")
  draft.data.cooldown = exec.cooldown

  local after = table.concat({
    tostring(exec.triggerMode or ""),
    tostring(exec.cadence or ""),
    tostring(exec.cadenceValue or ""),
    tostring(exec.cooldown or ""),
    tostring(exec.disableAfterFire or false),
    tostring(exec.falsePolicy or ""),
  }, "|")
  if after ~= before then _markDraftDirty() end
end

local function _drawDoSection(draft)
  _drawActionTableSection(
    draft,
    "actionGroups",
    "DO",
    "Build one or more action groups. Groups run top-to-bottom, and each group can be Ordered or Parallel.",
    "selectedActionIndex",
    "do",
    "No actions yet. Example: Show UI Message -> Wait / Delay -> Apply Status Effect."
  )
end
local function _drawBuilderColumn(width)
  local st = RuleBuilder.state
  _syncDraftFromSelectedRule()
  local draft = _normalizeRule(st.draftRule)
  st.draftRule = draft

  ImGui.BeginChild("macros_builder_column", width, 0, true)
  _textColored(0.92, 0.82, 0.28, 1.0, "Builder")
  ImGui.TextDisabled("Use saved presets and observers to build no-code scripts with ordered or parallel action groups.")
  if ImGui.Button("Save Script") then _saveDraftRule() end
  ImGui.SameLine()
  if ImGui.Button("Save Script Copy") then _saveDraftRule(true) end
  ImGui.SameLine()
  if ImGui.Button("Run Now") then
    if st.draftDirty then _saveDraftRule() end
    if st.selectedRuleId then
      local _, msg = RuleRunner.RunRuleNow(st.selectedRuleId)
      st.lastMessage = tostring(msg or "Ran selected script.")
    else
      st.lastMessage = "Save the script before running it."
    end
  end
  ImGui.SameLine()
  if ImGui.Button("Duplicate") then _duplicateSelectedRule() end
  ImGui.SameLine()
  if ImGui.Button("Delete") then _deleteSelectedRule() end
  ImGui.SameLine()
  if ImGui.Button(st.showDebugWindow and "Hide Scripter Debug" or "Open Scripter Debug") then
    st.showDebugWindow = not st.showDebugWindow
  end

  local beforeName = tostring(draft.name or "")
  local beforeEnabled = (draft.data.enabled ~= false)
  draft.name = _inputTextValue("Script Name", draft.name or "", 160)
  draft.data.enabled = _checkboxValue("Enabled##macro_enabled", draft.data.enabled ~= false)
  ImGui.SameLine()
  ImGui.TextDisabled(_behaviorSummary((draft.data or {}).execution or {}, _ruleHasStatefulActions(draft)))
  if tostring(draft.name or "") ~= beforeName or (draft.data.enabled ~= false) ~= beforeEnabled then _markDraftDirty() end

  if st.draftDirty then
    _textColored(0.92, 0.82, 0.28, 1.0, "Draft changed. Save Script to make it live.")
  else
    ImGui.TextDisabled("Builder and live script are synced.")
  end
  ImGui.Separator()

  _drawBehaviorSection(draft)
  ImGui.Separator()
  _drawConditionGroupsSection(draft)
  ImGui.Separator()
  _drawDoSection(draft)
  if tostring((((draft.data or {}).execution) or {}).falsePolicy or "do_nothing") == "run_exit_actions" then
    ImGui.Separator()
    _drawActionTableSection(
      draft,
      "falseActionGroups",
      "ON FALSE",
      "Optional exit groups. These run once when Conditions stop being true.",
      "selectedFalseActionIndex",
      "false",
      "No exit actions yet. Add lines here if you want a custom restore, off value, or cleanup sequence."
    )
  end
  _drawSelectedActionSetup(draft)
  ImGui.EndChild()
end

local function _summaryConditionLine(cond)
  return string.format("%s = %s", _conditionLabel(cond), (cond.expected ~= false) and "TRUE" or "FALSE")
end

local function _summaryActionLine(draft, action)
  local base = string.format("%s: %s", _actionTypeLabel(action.type), _actionTargetSummary(action))
  local cond = _actionConditionSummary(draft, action)
  if cond ~= "" then base = base .. " | " .. cond end
  return base
end

local function _drawSummaryColumn()
  local st = RuleBuilder.state
  local draft = _normalizeRule(_clone(st.draftRule))
  local saved = _selectedSavedRule()
  local liveStatus = saved and RuleRunner.GetStatus(saved.id) or nil

  ImGui.BeginChild("macros_summary_column", 0, 0, true)
  _textColored(0.92, 0.82, 0.28, 1.0, "Summary")
  ImGui.TextUnformatted(tostring(draft.name ~= "" and draft.name or "New Script"))
  ImGui.TextDisabled(_ruleSummary(draft))
  if st.draftDirty then
    _textColored(0.92, 0.82, 0.28, 1.0, "Unsaved changes are not live yet.")
  elseif saved then
    if liveStatus and liveStatus.lastEval then
      _textColored(0.35, 0.95, 0.45, 1.0, "LIVE STATUS: READY")
    else
      _textColored(1.00, 0.35, 0.35, 1.0, "LIVE STATUS: WAITING / BLOCKED")
    end
    ImGui.TextDisabled(tostring((liveStatus and liveStatus.lastMessage) or "Idle"))
  else
    ImGui.TextDisabled("Save this script to make it live.")
  end

  ImGui.Separator()
  _textColored(0.92, 0.82, 0.28, 1.0, "BEHAVIOR")
  ImGui.BulletText(_behaviorSummary(((draft.data or {}).execution) or {}, _ruleHasStatefulActions(draft)))

  ImGui.Spacing()
  local triggerGroup = _conditionGroupById(draft, ((draft.data or {}).triggerConditionGroupId)) or ((_conditionGroupsForRule(draft) or {})[1])
  _textColored(0.92, 0.82, 0.28, 1.0, "SCRIPT TRIGGER")
  if not triggerGroup then
    ImGui.TextDisabled("No trigger group set.")
  else
    ImGui.TextDisabled(string.format("%s [%s]", tostring(triggerGroup.name or triggerGroup.id or "Condition Group"), tostring(triggerGroup.mode or "ALL")))
    local conditions = type(triggerGroup.conditions) == "table" and triggerGroup.conditions or {}
    if #conditions == 0 then
      ImGui.TextDisabled("No Conditions in trigger group yet.")
    else
      for i = 1, #conditions do ImGui.BulletText(_summaryConditionLine(conditions[i])) end
    end
  end

  ImGui.Spacing()
  _textColored(0.92, 0.82, 0.28, 1.0, "DO")
  local groups = _groupsForRule(draft, "actionGroups")
  if _countActionsInGroups(groups) == 0 then
    ImGui.TextDisabled("No actions yet.")
  else
    for gi = 1, #groups do
      local group = groups[gi] or {}
      local actions = group.actions or {}
      if #actions > 0 then
        ImGui.TextDisabled(string.format("%s [%s]", tostring(group.name or ("Group " .. tostring(gi))), (tostring(group.mode or "ordered") == "parallel") and "Parallel" or "Ordered"))
        for i = 1, #actions do ImGui.BulletText(_summaryActionLine(draft, actions[i])) end
      end
    end
  end

  local exec = ((draft.data or {}).execution) or {}
  local falseGroups = _groupsForRule(draft, "falseActionGroups")
  if tostring(exec.falsePolicy or "do_nothing") == "run_exit_actions" then
    ImGui.Spacing()
    _textColored(0.92, 0.82, 0.28, 1.0, "ON FALSE")
    if _countActionsInGroups(falseGroups) == 0 then
      ImGui.TextDisabled("No exit actions yet.")
    else
      for gi = 1, #falseGroups do
        local group = falseGroups[gi] or {}
        local actions = group.actions or {}
        if #actions > 0 then
          ImGui.TextDisabled(string.format("%s [%s]", tostring(group.name or ("Exit Group " .. tostring(gi))), (tostring(group.mode or "ordered") == "parallel") and "Parallel" or "Ordered"))
          for i = 1, #actions do ImGui.BulletText(_summaryActionLine(draft, actions[i])) end
        end
      end
    end
  end

  ImGui.Spacing()
  if saved and liveStatus and type(liveStatus.lastConditionResults) == "table" and #liveStatus.lastConditionResults > 0 then
    _textColored(0.92, 0.82, 0.28, 1.0, "Why it is or is not firing")
    for i = 1, #liveStatus.lastConditionResults do
      local item = liveStatus.lastConditionResults[i]
      local txt = string.format("%s | %s", tostring(item.label or "Condition"), _debugConditionSummary(item))
      local r, g, b, a = _debugPassColor(item)
      _textColored(r, g, b, a, txt)
    end
  else
    ImGui.TextDisabled("Save the script and watch Scripter Debug for live condition tracking.")
  end

  ImGui.EndChild()
end

local function _drawRulesTab()
  local ww = ImGui.GetWindowWidth and ImGui.GetWindowWidth() or 960
  local leftW = math.max(175, math.floor(ww * 0.18))
  local midW = math.max(520, math.floor(ww * 0.52))

  ImGui.TextWrapped("BFM-style clarity, GTS-style power: build saved scripts on the left, edit readable Conditions / DO logic in the center, and keep a live summary on the right.")
  ImGui.Separator()
  if ww < 1320 then
    _drawMacroListColumn(0)
    ImGui.Separator()
    _drawBuilderColumn(0)
    ImGui.Separator()
    _drawSummaryColumn()
  else
    _drawMacroListColumn(leftW)
    ImGui.SameLine()
    _drawBuilderColumn(midW)
    ImGui.SameLine()
    _drawSummaryColumn()
  end
end

local function _drawAssetSection(label, assetType, actionLabel, onRun)
  if not ImGui.CollapsingHeader(label .. "##asset_section") then return end
  local assets = AssetRegistry.List(assetType)
  if #assets == 0 then
    ImGui.TextDisabled("None yet.")
    return
  end
  if ImGui.BeginTable("assets_tbl_" .. assetType, 4, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("Name")
    ImGui.TableSetupColumn("Source", ImGuiTableColumnFlags.WidthFixed, 120)
    ImGui.TableSetupColumn("Preview")
    ImGui.TableSetupColumn(actionLabel, ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableHeadersRow()
    for i = 1, #assets do
      local asset = assets[i]
      local entries = (((asset or {}).data or {}).entries) or {}
      if assetType == "observer_preset" then entries = (asset and asset.observers) or {} end
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(tostring(asset.name or asset.id))
      ImGui.TableSetColumnIndex(1)
      local sourceLabel = tostring((((asset or {}).data or {}).source) or asset.type or "asset")
      if assetType == "observer_preset" then sourceLabel = "stats_condition_builder" end
      ImGui.TextUnformatted(sourceLabel)
      ImGui.TableSetColumnIndex(2)
      local preview = tostring(#entries) .. " entries"
      if assetType == "stat_preset" then preview = tostring(#entries) .. " stat value(s)" end
      if assetType == "observer_preset" then preview = tostring(#entries) .. " condition(s)" end
      if assetType == "spawn_set" then preview = tostring(#entries) .. " record(s)" end
      if assetType == "inventory_bundle" then preview = tostring(#entries) .. " item(s)" end
      ImGui.TextUnformatted(preview)
      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton(actionLabel .. "##asset_run_" .. tostring(asset.id)) and onRun then onRun(asset) end
    end
    ImGui.EndTable()
  end
end

local function _upsertAssetFromHomeTab(asset)
  if type(asset) ~= "table" then return nil, "Missing asset" end
  return (AssetRegistry.UpsertNew and AssetRegistry.UpsertNew(asset, asset.name)) or AssetRegistry.Upsert(asset)
end

local function _drawAssetsTab()
  local st = RuleBuilder.state
  ImGui.TextWrapped("Home tabs create the main presets automatically. This page is the clean browser for what the Scripter system can use, plus quick capture for inventory bundles.")
  ImGui.Separator()

  ImGui.Text("Quick Capture")

  st.inventoryBundleName = _inputTextValue("Inventory Bundle Name", st.inventoryBundleName or "", 128)
  if ImGui.Button("Save Selected Inventory Item as Bundle") then
    local InventoryTab = _safeRequire("GTS/inventory_tab")
    if InventoryTab and type(InventoryTab.ExportCurrentBundle) == "function" then
      local asset, err = InventoryTab.ExportCurrentBundle(st.inventoryBundleName)
      if asset then
        _upsertAssetFromHomeTab(asset)
        st.lastMessage = "Saved selected inventory item as a bundle."
      else
        st.lastMessage = tostring(err or "Could not save inventory bundle.")
      end
    end
  end

  ImGui.Separator()
  _drawAssetSection("Stat Profiles", "stat_preset", "Use", function(asset)
    local StatsUI = _safeRequire("GTS/stats_browser")
    if StatsUI and type(StatsUI.ApplyPresetEntries) == "function" then
      StatsUI.ApplyPresetEntries((((asset or {}).data or {}).entries) or {})
      st.lastMessage = "Applied Stat Profile."
    end
  end)
  _drawAssetSection("Stat Conditions", "observer_preset", "Load", function(asset)
    local draft = st.draftRule
    if type(draft) ~= "table" then
      st.lastMessage = "Open or create a script first."
      return
    end
    local added = _appendObserverPresetToDraft(draft, asset and asset.id)
    if added > 0 then
      st.lastMessage = string.format("Loaded %d condition(s) from '%s' into the selected condition group.", added, tostring((asset or {}).name or (asset or {}).id or "Condition Preset"))
      _markDraftDirty()
    else
      st.lastMessage = "Could not load Stat Condition into the current script."
    end
  end)
  _drawAssetSection("Spawn Presets", "spawn_set", "Spawn", function(asset)
    local SpawnTools = _safeRequire("GTS/spawn_tools")
    if SpawnTools and type(SpawnTools.ApplySpawnSet) == "function" then
      SpawnTools.ApplySpawnSet((((asset or {}).data or {}).entries) or {})
      st.lastMessage = "Applied spawn preset."
    end
  end)
  _drawAssetSection("Inventory Bundles", "inventory_bundle", "Add", function(asset)
    local InventoryTab = _safeRequire("GTS/inventory_tab")
    if InventoryTab and type(InventoryTab.ApplyInventoryBundle) == "function" then
      InventoryTab.ApplyInventoryBundle((((asset or {}).data or {}).entries) or {})
      st.lastMessage = "Applied inventory bundle."
    end
  end)
end

local function _drawLiveTab()
  ImGui.TextWrapped("Live view shows each saved script like a dashboard: enabled, waiting, ready, or cooling down. Open Scripter Debug for the full why-is-it-blocked view.")
  ImGui.Separator()
  ImGui.Text("Manual Test Toggles")
  _drawManualTogglesInline()
  ImGui.Separator()

  local rules = AssetRegistry.ListMutable("rule")
  if #rules == 0 then
    ImGui.TextDisabled("No scripts saved yet.")
    return
  end

  if ImGui.BeginTable("macro_live_table", 6, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("On", ImGuiTableColumnFlags.WidthFixed, 30)
    ImGui.TableSetupColumn("Script")
    ImGui.TableSetupColumn("Summary")
    ImGui.TableSetupColumn("State", ImGuiTableColumnFlags.WidthFixed, 130)
    ImGui.TableSetupColumn("Select", ImGuiTableColumnFlags.WidthFixed, 60)
    ImGui.TableSetupColumn("Run", ImGuiTableColumnFlags.WidthFixed, 60)
    ImGui.TableHeadersRow()
    for i = 1, #rules do
      local rule = rules[i]
      local status = RuleRunner.GetStatus(rule.id)
  local keepDebugOpen = (type(uiState) == "table" and uiState.keepMacroDebugOpenWhenOverlayClosed == true)
      local enabled = ((rule.data or {}).enabled) ~= false
      local newEnabled = _checkboxValue("##live_enable_" .. tostring(rule.id), enabled)
      if newEnabled ~= enabled then rule.data.enabled = newEnabled end
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(newEnabled and "ON" or "OFF")
      ImGui.TableSetColumnIndex(1)
      ImGui.TextUnformatted(tostring(rule.name or rule.id))
      ImGui.TableSetColumnIndex(2)
      ImGui.TextUnformatted(_ruleSummary(rule))
      ImGui.TableSetColumnIndex(3)
      if status.lastEval then _textColored(0.35, 0.95, 0.45, 1.0, tostring(status.lastMessage or "Ready"))
      else _textColored(1.00, 0.35, 0.35, 1.0, tostring(status.lastMessage or "Waiting")) end
      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton("Pick##live_pick_" .. tostring(rule.id)) then
        RuleBuilder.state.selectedRuleId = rule.id
        RuleBuilder.state.lastRuleSyncId = nil
        RuleBuilder.state.draftDirty = false
        RuleBuilder.state.tab = "Rules"
      end
      ImGui.TableSetColumnIndex(5)
      if ImGui.SmallButton("Run##live_run_" .. tostring(rule.id)) then RuleRunner.RunRuleNow(rule.id) end
    end
    ImGui.EndTable()
  end
end

local function _drawHelpTab()
  ImGui.TextUnformatted("1. Create the building blocks in the home tabs")
  ImGui.BulletText("Stats Editor -> save Stat Profiles from your edited values or Impact Analyzer results.")
  ImGui.BulletText("Spawn Tools -> save Spawn Presets from a selected record or from spawned records.")
  ImGui.BulletText("Conditions -> create custom Conditions and use them directly in Scripter Conditions lines.")
  ImGui.BulletText("Inventory -> select an item, then save it as a bundle from the Assets page here.")
  ImGui.Spacing()
  ImGui.TextUnformatted("2. Build a script in plain language")
  ImGui.BulletText("Conditions = the checks that must be true or false.")
  ImGui.BulletText("Behavior = when it fires (On Change To True / While True), cadence, cooldown, and false handling.")
  ImGui.BulletText("Leave Conditions empty if you want a saved action-only script that you launch manually from Macros or Created.")
  ImGui.BulletText("DO = one or more action groups. Groups run top-to-bottom, and each group can be ordered or parallel.")
  ImGui.BulletText("Use ALL for AND logic. Use ANY for OR logic.")
  ImGui.Spacing()
  ImGui.TextUnformatted("3. Debug it live")
  ImGui.BulletText("Open Scripter Debug to see live condition status, waiting reasons, and action results.")
  ImGui.BulletText("The main Summary panel is the readable script description. Scripter Debug is the deep runtime explanation.")
  ImGui.BulletText("Status effects can be picked from the live TweakDB list or typed manually as BaseStatusEffect.Whatever.")
  ImGui.BulletText("Use Wait / Delay inside ordered groups for pacing, or inside parallel groups as a timed barrier before the next group starts.")
end

local function _drawDebugStatusTab(rule, status)
  local nowClock = _clockNow()
  ImGui.TextUnformatted(tostring(rule.name or rule.id))
  ImGui.TextDisabled(_ruleSummary(rule))
  local exec = (((rule or {}).data or {}).execution) or {}
  local currentWhen = (status.lastEval == true)
  ImGui.Text("Enabled: " .. ((((rule.data or {}).enabled) ~= false) and "TRUE" or "FALSE"))
  ImGui.Text("Conditions now: " .. (currentWhen and "TRUE" or "FALSE"))
  ImGui.Text("Trigger mode: " .. tostring(exec.triggerMode or "on_true"))
  ImGui.TextWrapped("Behavior: " .. _behaviorSummary(exec, _ruleHasStatefulActions(rule)))
  ImGui.Text(string.format("Eval Count: %d", tonumber(status.evalCount or 0) or 0))
  ImGui.Text(string.format("Fire Count: %d", tonumber(status.totalFireCount or 0) or 0))
  ImGui.Text(string.format("Last plan actions run: %d", tonumber(status.lastTriggeredCount or 0) or 0))
  ImGui.Text(string.format("Pending actions: %d", tonumber(status.pendingCount or 0) or 0))
  ImGui.Text(string.format("True Count: %d", tonumber(status.trueCount or 0) or 0))
  ImGui.Text("First True Used: " .. ((status.hasFiredEver == true) and "TRUE" or "FALSE"))
  ImGui.TextDisabled(_clockHumanLine("Last eval", nowClock, status.lastEvalAt))
  ImGui.TextDisabled(_clockHumanLine("Condition changed", nowClock, status.lastConditionChangeAt))
  ImGui.TextDisabled(_clockHumanLine("Last fired", nowClock, status.lastRunAt))
  ImGui.TextDisabled("Runtime now: t=" .. _clockText(nowClock))
  ImGui.Separator()
  if status.lastEval then _textColored(0.35, 0.95, 0.45, 1.0, "Script is currently READY / TRUE")
  else _textColored(1.00, 0.35, 0.35, 1.0, "Script is currently WAITING / BLOCKED") end
  ImGui.TextWrapped("State: " .. tostring(status.lastMessage or "Idle"))
  if status.lastBlockedReason and status.lastBlockedReason ~= "" then
    ImGui.TextUnformatted("WAITING FOR:")
    _textColored(1.00, 0.35, 0.35, 1.0, tostring(status.lastBlockedReason))
  end
  if status.lastActionError and status.lastActionError ~= "" then
    ImGui.TextUnformatted("LAST ACTION ERROR:")
    _textColored(1.00, 0.35, 0.35, 1.0, tostring(status.lastActionError))
  end
  if status.sequenceActive then
    local kind = tostring(status.sequenceKind or "main")
    local activeGroupName = tostring(status.activeGroupName or "Group")
    local activeGroupMode = tostring(status.activeGroupMode or "ordered")
    ImGui.TextUnformatted(string.format("Plan: ACTIVE (%s) | group %d/%d | %s [%s]", kind, math.max(1, tonumber(status.sequenceIndex or 1) or 1), math.max(0, tonumber(status.sequenceTotal or 0) or 0), activeGroupName, (activeGroupMode == "parallel") and "Parallel" or "Ordered"))
    local remain = math.max(0, (tonumber(status.sequenceWaitUntil or 0) or 0) - nowClock)
    ImGui.TextDisabled(string.format("Active action: %d | next wake in %.2f sec | pending %d", math.max(0, tonumber(status.activeActionIndex or 0) or 0), remain, math.max(0, tonumber(status.pendingCount or 0) or 0)))
  else
    ImGui.TextUnformatted("Plan: idle")
  end
end

local function _drawDebugQualifiersTab(rule, status)
  ImGui.TextDisabled("Live condition status with actual measured values.")
  local conds = (((rule or {}).data or {}).conditions) or {}
  if #conds == 0 then
    ImGui.TextDisabled("No conditions on this script.")
    return
  end
  if ImGui.BeginTable("macro_dbg_qualifiers", 8, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 26)
    ImGui.TableSetupColumn("Condition")
    ImGui.TableSetupColumn("Left")
    ImGui.TableSetupColumn("Op", ImGuiTableColumnFlags.WidthFixed, 42)
    ImGui.TableSetupColumn("Right")
    ImGui.TableSetupColumn("Observed", ImGuiTableColumnFlags.WidthFixed, 64)
    ImGui.TableSetupColumn("Expects", ImGuiTableColumnFlags.WidthFixed, 64)
    ImGui.TableSetupColumn("Result / Reason")
    ImGui.TableHeadersRow()
    for i = 1, #conds do
      local res = status.lastConditionResults and status.lastConditionResults[i] or RuleRunner.GetConditionDebug(conds[i])
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(tostring(i))
      ImGui.TableSetColumnIndex(1)
      ImGui.TextWrapped(tostring((res or {}).label or _conditionLabel(conds[i])))
      ImGui.TableSetColumnIndex(2)
      ImGui.TextWrapped(_formatDebugValue((res or {}).left))
      ImGui.TableSetColumnIndex(3)
      ImGui.TextUnformatted(tostring((res or {}).op or "=="))
      ImGui.TableSetColumnIndex(4)
      ImGui.TextWrapped(_formatDebugValue((res or {}).right))
      ImGui.TableSetColumnIndex(5)
      ImGui.TextUnformatted(((res or {}).current == true) and "TRUE" or "FALSE")
      ImGui.TableSetColumnIndex(6)
      ImGui.TextUnformatted(((res or {}).expected == true) and "TRUE" or "FALSE")
      ImGui.TableSetColumnIndex(7)
      local msg = _debugPassText(res)
      if tostring((res or {}).reason or "") ~= "" then msg = msg .. " | " .. tostring(res.reason) end
      local r, g, b, a = _debugPassColor(res)
      _textColored(r, g, b, a, msg)
    end
    ImGui.EndTable()
  end
end

local function _drawDebugActionsTab(rule, status)
  ImGui.TextDisabled("Action groups and their live runtime status.")
  local groups = _groupsForRule(rule, "actionGroups")
  if _countActionsInGroups(groups) == 0 then
    ImGui.TextDisabled("No actions on this script.")
    return
  end
  local resultsByGroup = status.lastActionResults or {}
  local activeGroupIndex = tonumber(status.activeGroupIndex or 0) or 0
  local activeActionIndex = tonumber(status.activeActionIndex or 0) or 0
  local groupState = status.groupState or {}
  local pendingByIndex = groupState.pendingByIndex or {}
  local completedByIndex = groupState.completedByIndex or {}
  for gi = 1, #groups do
    local group = groups[gi] or {}
    local actions = group.actions or {}
    if #actions > 0 then
      ImGui.Separator()
      local groupHeader = string.format("%s [%s]", tostring(group.name or ("Group " .. tostring(gi))), (tostring(group.mode or "ordered") == "parallel") and "Parallel" or "Ordered")
      if status.sequenceActive and gi == activeGroupIndex then
        _textColored(0.92, 0.82, 0.28, 1.0, groupHeader .. " | ACTIVE")
      else
        ImGui.TextDisabled(groupHeader)
      end
      local resultsByIndex = resultsByGroup[gi] or {}
      for i = 1, #actions do
        local action = actions[i]
        local result = resultsByIndex[i]
        local runtime = "NOT RUN"
        if result then
          runtime = result.success and "DONE" or "FAILED"
        end
        if status.sequenceActive and gi == activeGroupIndex then
          if pendingByIndex[i] ~= nil then runtime = "PENDING"
          elseif completedByIndex[i] == true then runtime = result and (result.success and "DONE" or "FAILED") or "DONE"
          elseif activeActionIndex == i then runtime = "ACTIVE" end
        elseif status.sequenceActive and gi > activeGroupIndex then
          runtime = "WAITING"
        elseif status.sequenceActive ~= true and gi < activeGroupIndex then
          runtime = result and (result.success and "DONE" or "FAILED") or runtime
        end
        local prefix = string.format("%d.%d %s", gi, i, _actionTypeLabel(action.type))
        local target = tostring(_actionTargetSummary(action) or "")
        ImGui.TextWrapped(prefix .. " -> " .. target)
        if runtime == "DONE" then
          _textColored(0.35, 0.95, 0.45, 1.0, "Status: " .. runtime .. ((result and result.message) and (" | " .. tostring(result.message)) or ""))
        elseif runtime == "FAILED" then
          _textColored(1.00, 0.35, 0.35, 1.0, "Status: " .. runtime .. ((result and result.message) and (" | " .. tostring(result.message)) or ""))
        elseif runtime == "ACTIVE" or runtime == "PENDING" then
          _textColored(0.92, 0.82, 0.28, 1.0, "Status: " .. runtime .. ((result and result.message) and (" | " .. tostring(result.message)) or ""))
        else
          ImGui.TextDisabled("Status: " .. runtime .. ((result and result.message) and (" | " .. tostring(result.message)) or ""))
        end
      end
    end
  end

  local exec = (((rule or {}).data or {}).execution) or {}
  if tostring(exec.falsePolicy or "do_nothing") == "run_exit_actions" then
    ImGui.Separator()
    ImGui.TextDisabled("ON FALSE groups")
    local falseGroups = _groupsForRule(rule, "falseActionGroups")
    if _countActionsInGroups(falseGroups) == 0 then
      ImGui.TextDisabled("No exit actions configured.")
    else
      for gi = 1, #falseGroups do
        local group = falseGroups[gi] or {}
        local actions = group.actions or {}
        if #actions > 0 then
          ImGui.TextDisabled(string.format("%s [%s]", tostring(group.name or ("Exit Group " .. tostring(gi))), (tostring(group.mode or "ordered") == "parallel") and "Parallel" or "Ordered"))
          for i = 1, #actions do ImGui.BulletText(_summaryActionLine(rule, actions[i])) end
        end
      end
    end
  end
end

local function _drawDebugEventLogTab(rule)
  ImGui.TextDisabled("Latest script runtime events. Newest entries appear first.")
  local logs = RuleRunner.GetEventLog(rule.id, 150)
  if type(logs) ~= "table" or #logs == 0 then
    ImGui.TextDisabled("No runtime events recorded yet.")
    return
  end
  if ImGui.BeginChild("macro_debug_event_log", 0, 0, true) then
    for i = 1, #logs do
      local entry = logs[i] or {}
      local line = string.format("[%s] %s (t=%s)  %s", string.upper(tostring(entry.level or "info")), _clockAgoText(_clockNow(), entry.t), _clockText(entry.t), tostring(entry.msg or ""))
      if tostring(entry.level or "info") == "error" then
        _textColored(1.00, 0.35, 0.35, 1.0, line)
      else
        ImGui.TextWrapped(line)
      end
    end
    ImGui.EndChild()
  end
end

local function _drawDebugTestTab(rule)
  ImGui.TextUnformatted("Manual test controls")
  _drawManualTogglesInline()
  ImGui.Spacing()
  if ImGui.Button("Run Selected Script Now##dbg_run_now") then
    RuleRunner.RunRuleNow(rule.id)
  end
  ImGui.SameLine()
  if ImGui.Button("Hide Debug Window##dbg_hide") then
    RuleBuilder.state.showDebugWindow = false
  end
end

local function _drawMacroDebugWindow(uiState)
  local st = RuleBuilder.state
  if not st.showDebugWindow then return end

  local rule = _selectedSavedRule()
  if type(ImGui.SetNextWindowSize) == "function" then
    ImGui.SetNextWindowSize(780, 540, ImGuiCond.FirstUseEver)
  end
  if not ImGui.Begin("Scripter Debug", true) then
    ImGui.End()
    return
  end

  if not rule then
    ImGui.TextDisabled("Select and save a script in the Scripter tab to inspect it here.")
    if ImGui.Button("Hide Debug Window##dbg_hide_empty") then st.showDebugWindow = false end
    ImGui.End()
    return
  end

  local status = RuleRunner.GetStatus(rule.id)
  local keepDebugOpen = (type(uiState) == "table" and uiState.keepMacroDebugOpenWhenOverlayClosed == true)
  if ImGui.Button("Run Script##dbg_run") then RuleRunner.RunRuleNow(rule.id) end
  ImGui.SameLine()
  if ImGui.Button("Hide Debug##dbg_hide_top") then st.showDebugWindow = false end
  ImGui.SameLine()
  if type(uiState) == "table" then
    uiState.keepMacroDebugOpenWhenOverlayClosed = _checkboxValue("Keep Open w/ Overlay Closed##dbg_keep_open", keepDebugOpen)
    keepDebugOpen = (uiState.keepMacroDebugOpenWhenOverlayClosed == true)
    ImGui.SameLine()
  end
  ImGui.TextDisabled("Separate runtime window inspired by BFM's Scripter Debug, powered by GTS's deeper rule engine.")
  ImGui.Separator()

  if _tabBarOpen("macro_debug_tabs") then
    if _tabItemOpen("Rule Status") then
      _drawDebugStatusTab(rule, status)
      ImGui.EndTabItem()
    end
    if _tabItemOpen("Condition Status") then
      _drawDebugQualifiersTab(rule, status)
      ImGui.EndTabItem()
    end
    if _tabItemOpen("Action Status") then
      _drawDebugActionsTab(rule, status)
      ImGui.EndTabItem()
    end
    if _tabItemOpen("Event Log") then
      _drawDebugEventLogTab(rule)
      ImGui.EndTabItem()
    end
    if _tabItemOpen("Test") then
      _drawDebugTestTab(rule)
      ImGui.EndTabItem()
    end
    ImGui.EndTabBar()
  else
    _drawDebugStatusTab(rule, status)
  end

  ImGui.End()
end

function RuleBuilder.OnUpdate(delta)
  RuleRunner.Update(delta)
end

function RuleBuilder.DrawTab(_)
  local st = RuleBuilder.state
  ImGui.TextWrapped(tostring(st.lastMessage or ""))
  ImGui.Separator()
  if _tabBarOpen("macros_main_tabs") then
    if _tabItemOpen("Rules") then
      _drawRulesTab()
      ImGui.EndTabItem()
      st.tab = "Rules"
    end
    if _tabItemOpen("Assets") then
      _drawAssetsTab()
      ImGui.EndTabItem()
      st.tab = "Assets"
    end
    if _tabItemOpen("Live") then
      _drawLiveTab()
      ImGui.EndTabItem()
      st.tab = "Live"
    end
    if _tabItemOpen("Help") then
      _drawHelpTab()
      ImGui.EndTabItem()
      st.tab = "Help"
    end
    ImGui.EndTabBar()
  else
    _drawRulesTab()
  end
end

function RuleBuilder.DrawWindows(uiState)
  _drawMacroDebugWindow(uiState)
end


function RuleBuilder.DrawExternalActionTableSection(draft, groupKey, heading, helpText, selectedIndexKey, actionListFlag, emptyText)
  return _drawActionTableSection(draft, groupKey, heading, helpText, selectedIndexKey, actionListFlag, emptyText)
end

function RuleBuilder.EnsureExternalActionDefaults(action)
  return _ensureActionDefaults(action)
end

function RuleBuilder.NewExternalAction(actionType)
  return _newAction(actionType)
end


function RuleBuilder.DrawExternalSelectedActionSetup(draft, isFalseSection, groupIndex, actionIndex)
  local st = RuleBuilder.state
  local prevGroup = st.selectedActionGroupIndex
  local prevFalseGroup = st.selectedFalseActionGroupIndex
  local prevIndex = st.selectedActionIndex
  local prevFalseIndex = st.selectedFalseActionIndex
  local prevList = st.selectedActionList

  if isFalseSection then
    st.selectedFalseActionGroupIndex = tonumber(groupIndex or st.selectedFalseActionGroupIndex or 1) or 1
    st.selectedFalseActionIndex = tonumber(actionIndex or st.selectedFalseActionIndex or 1) or 1
    st.selectedActionList = 'false'
  else
    st.selectedActionGroupIndex = tonumber(groupIndex or st.selectedActionGroupIndex or 1) or 1
    st.selectedActionIndex = tonumber(actionIndex or st.selectedActionIndex or 1) or 1
    st.selectedActionList = 'do'
  end

  _drawSelectedActionSetup(draft)

  st.selectedActionGroupIndex = prevGroup
  st.selectedFalseActionGroupIndex = prevFalseGroup
  st.selectedActionIndex = prevIndex
  st.selectedFalseActionIndex = prevFalseIndex
  st.selectedActionList = prevList
end

return RuleBuilder
