local World = World or {}

local function _getPlayer()
  if Game and Game.GetPlayer then return Game.GetPlayer() end
  return nil
end

local function _getTimeSystem()
  if Game and Game.GetTimeSystem then return Game.GetTimeSystem() end
  return nil
end

function World.ListWeatherPresets()
  return {
    { label = "Clear", id = "24h_weather_clear" },
    { label = "Rain", id = "24h_weather_rain" },
    { label = "Cloudy", id = "24h_weather_cloudy" },
    { label = "Sunny", id = "24h_weather_sunny" },
    { label = "Storm", id = "24h_weather_storm" },
    { label = "Fog", id = "24h_weather_fog" },
    { label = "Toxic Rain", id = "24h_weather_toxic_rain" },
    { label = "Sandstorm", id = "24h_weather_sandstorm" },
  }
end

function World.SetTimeOfDay(hour, minute)
  local ts = _getTimeSystem()
  if not ts or not ts.SetGameTimeByHMS then return false, "TimeSystem unavailable" end
  local h = math.floor(tonumber(hour or 0) or 0)
  local m = math.floor(tonumber(minute or 0) or 0)
  if h < 0 then h = 0 end
  if h > 23 then h = 23 end
  if m < 0 then m = 0 end
  if m > 59 then m = 59 end
  local ok, err = pcall(function() ts:SetGameTimeByHMS(h, m, 0) end)
  if not ok then return false, tostring(err) end
  return true, string.format("Set time to %02d:%02d", h, m)
end

function World.SetWeather(id)
  id = tostring(id or "")
  if id == "" then return false, "Choose a weather preset" end
  local ok, err = pcall(function()
    local ws = (Game and Game.GetWeatherSystem and Game.GetWeatherSystem()) or nil
    if ws ~= nil then
      local cname = (CName and CName.new and CName.new(id)) or id
      if ws.SetWeather ~= nil then
        local ok2 = pcall(function() ws:SetWeather(cname) end)
        if not ok2 then pcall(function() ws:SetWeather(cname, 0.0, true) end) end
        return
      end
      if ws.OverrideWeather ~= nil then
        pcall(function() ws:OverrideWeather(cname) end)
        return
      end
    end
    if Game and Game.SetWeather then
      local cname = (CName and CName.new and CName.new(id)) or id
      Game.SetWeather(cname)
      return
    end
    error("Weather system unavailable")
  end)
  if not ok then return false, tostring(err) end
  return true, "Weather set"
end

function World.ResetWeather()
  local ok, err = pcall(function()
    local ws = (Game and Game.GetWeatherSystem and Game.GetWeatherSystem()) or nil
    if ws ~= nil then
      if ws.ResetWeather ~= nil then pcall(function() ws:ResetWeather() end) end
      if ws.ClearOverride ~= nil then pcall(function() ws:ClearOverride() end) end
      if ws.RemoveOverride ~= nil then pcall(function() ws:RemoveOverride() end) end
      if ws.ClearWeatherOverride ~= nil then pcall(function() ws:ClearWeatherOverride() end) end
      if ws.RemoveWeatherOverride ~= nil then pcall(function() ws:RemoveWeatherOverride() end) end
      if ws.SetWeather ~= nil then
        local cname = (CName and CName.new and CName.new("24h_weather_clear")) or "24h_weather_clear"
        pcall(function() ws:SetWeather(cname) end)
        pcall(function() ws:SetWeather(cname, 0.0, true) end)
      end
      return
    end
    if Game and Game.SetWeather then
      local cname = (CName and CName.new and CName.new("24h_weather_clear")) or "24h_weather_clear"
      Game.SetWeather(cname)
      return
    end
    error("Weather system unavailable")
  end)
  if not ok then return false, tostring(err) end
  return true, "Weather reset"
end

function World.GetPlayerPosition()
  local p = _getPlayer()
  if not p then return nil end
  local ok, pos = pcall(function()
    if p.GetWorldPosition then return p:GetWorldPosition() end
    if p.GetPosition then return p:GetPosition() end
    return nil
  end)
  if not ok or not pos then return nil end
  local x = pos.x or pos.X
  local y = pos.y or pos.Y
  local z = pos.z or pos.Z
  if type(x) ~= "number" or type(y) ~= "number" or type(z) ~= "number" then return nil end
  return x, y, z
end

function World.Teleport(tp)
  local tf = Game and Game.GetTeleportationFacility and Game.GetTeleportationFacility() or nil
  local p = _getPlayer()
  if not tf or not p then return false, "Teleportation facility unavailable" end
  local x = tonumber((tp or {}).x)
  local y = tonumber((tp or {}).y)
  local z = tonumber((tp or {}).z)
  if type(x) ~= "number" or type(y) ~= "number" or type(z) ~= "number" then return false, "Set X, Y, and Z first" end
  local ok, err = pcall(function()
    tf:Teleport(p, ToVector4{ x = x, y = y, z = z, w = 1 }, ToEulerAngles{ roll = 0, pitch = 0, yaw = 0 })
  end)
  if not ok then return false, tostring(err) end
  return true, tostring((tp or {}).label or "Teleported")
end

function World.ShowUIMessage(mode, text, duration)
  local txt = tostring(text or "")
  if txt == "" then return false, "Enter custom text first" end
  local msgMode = tostring(mode or "screen")
  local secs = tonumber(duration or 8) or 8
  if secs < 1 then secs = 1 end
  if secs > 30 then secs = 30 end
  local p = _getPlayer()
  local ok, err = pcall(function()
    if msgMode == "screen" then
      local MSG = SimpleScreenMessage.new()
      MSG.message = txt
      MSG.isShown = true
      MSG.duration = secs
      Game.GetBlackboardSystem():Get(GetAllBlackboardDefs().UI_Notifications):SetVariant(
        GetAllBlackboardDefs().UI_Notifications.OnscreenMessage,
        ToVariant(MSG),
        true
      )
    elseif msgMode == "shard" then
      Game.GetUISystem():QueueEvent(NotifyShardRead.new({ title = "Message", text = txt }))
    elseif msgMode == "neutral" or msgMode == "relic" or msgMode == "money" then
      if not p or not p.SetWarningMessage then error("Player warning API unavailable") end
      if msgMode == "neutral" then
        p:SetWarningMessage(txt, gameSimpleMessageType.Neutral)
      elseif msgMode == "relic" then
        p:SetWarningMessage(txt, gameSimpleMessageType.Relic)
      else
        p:SetWarningMessage(txt, "Money")
      end
    else
      local ps = Game and Game.GetScriptableSystemsContainer and Game.GetScriptableSystemsContainer():Get("PreventionSystem") or nil
      if ps and ps.ShowMessage then
        ps:ShowMessage(txt, secs)
      elseif p and p.SetWarningMessage then
        p:SetWarningMessage(txt, gameSimpleMessageType.Neutral)
      else
        error("UI message API unavailable")
      end
    end
  end)
  if not ok then return false, tostring(err) end
  return true, "Displayed message"
end


function World.SetTimeDilation(mode, scale)
  local ts = _getTimeSystem()
  if not ts or not ts.SetTimeDilation then return false, "TimeSystem unavailable" end
  local tagName = "GTS_WorldOnly"
  local worldOnly = (tostring(mode or "world_only") == "world_only")
  if not worldOnly then tagName = "GTS_WorldAndV" end
  local value = tonumber(scale or 0.20) or 0.20
  if value < 0.01 then value = 0.01 end
  if value > 3.00 then value = 3.00 end
  local ok, err = pcall(function()
    local tag1 = (CName and CName.new and CName.new("GTS_WorldOnly")) or "GTS_WorldOnly"
    local tag2 = (CName and CName.new and CName.new("GTS_WorldAndV")) or "GTS_WorldAndV"
    local tag  = (CName and CName.new and CName.new(tagName)) or tagName
    if ts.UnsetTimeDilation ~= nil then
      pcall(function() ts:UnsetTimeDilation(tag1) end)
      pcall(function() ts:UnsetTimeDilation(tag2) end)
    end
    if ts.SetIgnoreTimeDilationOnLocalPlayerZero ~= nil then
      ts:SetIgnoreTimeDilationOnLocalPlayerZero(worldOnly)
    end
    ts:SetTimeDilation(tag, value)
  end)
  if not ok then return false, tostring(err) end
  return true, string.format("Time scale %.2f (%s)", value, worldOnly and "world only" or "world + V")
end

function World.ResetTimeDilation()
  local ts = _getTimeSystem()
  if not ts then return false, "TimeSystem unavailable" end
  local ok, err = pcall(function()
    local tag1 = (CName and CName.new and CName.new("GTS_WorldOnly")) or "GTS_WorldOnly"
    local tag2 = (CName and CName.new and CName.new("GTS_WorldAndV")) or "GTS_WorldAndV"
    if ts.UnsetTimeDilation ~= nil then
      pcall(function() ts:UnsetTimeDilation(tag1) end)
      pcall(function() ts:UnsetTimeDilation(tag2) end)
    end
    if ts.SetIgnoreTimeDilationOnLocalPlayerZero ~= nil then
      ts:SetIgnoreTimeDilationOnLocalPlayerZero(false)
    end
  end)
  if not ok then return false, tostring(err) end
  return true, "Time scale reset"
end

function World.SetFOV(value)
  local fov = tonumber(value or 80.0) or 80.0
  if fov < 50.0 then fov = 50.0 end
  if fov > 120.0 then fov = 120.0 end
  local p = _getPlayer()
  if not p or not p.GetFPPCameraComponent then return false, "FPP camera unavailable" end
  local ok, err = pcall(function()
    local cam = p:GetFPPCameraComponent()
    if not cam then error("FPP camera unavailable") end
    if cam.SetZoom ~= nil then pcall(function() cam:SetZoom(0.0) end) end
    if cam.SetFOV == nil then error("FPP camera FOV setter unavailable") end
    cam:SetFOV(fov)
  end)
  if not ok then return false, tostring(err) end
  return true, string.format("FOV set to %.1f", fov)
end

function World.ResetFOV()
  local p = _getPlayer()
  if not p or not p.GetFPPCameraComponent then return false, "FPP camera unavailable" end
  local ok, err = pcall(function()
    local cam = p:GetFPPCameraComponent()
    if not cam then error("FPP camera unavailable") end
    if cam.SetZoom ~= nil then pcall(function() cam:SetZoom(0.0) end) end
    if cam.SetFOV == nil then error("FPP camera FOV setter unavailable") end
    cam:SetFOV(80.0)
  end)
  if not ok then return false, tostring(err) end
  return true, "FOV reset"
end

return World
