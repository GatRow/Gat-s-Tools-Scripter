local AssetRegistry = AssetRegistry or {}
local Persistence = require("GTS/persistence")
local Utils = require("GTS/utils")

AssetRegistry.state = AssetRegistry.state or {
  nextId = 1,
  items = {},
  order = {},
  selectedId = nil,
}

local _clone = Utils.clone

local function _nowText()
  if os and os.date then return os.date("%Y-%m-%d %H:%M:%S") end
  return "-"
end

local function _nextId(prefix)
  local st = AssetRegistry.state
  local id = string.format("%s_%03d", tostring(prefix or "asset"), tonumber(st.nextId or 1))
  st.nextId = (tonumber(st.nextId or 1) or 1) + 1
  return id
end

local function _typePrefix(assetType)
  local map = {
    stat_preset = "preset",
    observer_preset = "observer",
    spawn_set = "spawn",
    spawn_grid = "grid",
    inventory_bundle = "bundle",
    shooter_profile = "shooter",
    rule = "rule",
    macro = "macro",
    custom_code = "code",
    teleport_preset = "tele",
    launcher = "launch",
    scenario = "scenario",
  }
  return map[assetType] or "asset"
end

local function _normalizeGroupMode(mode)
  mode = tostring(mode or "ordered")
  if mode ~= "parallel" then mode = "ordered" end
  return mode
end

local function _normalizeActionGroups(groups, fallbackActions, defaultName)
  local src = type(groups) == "table" and groups or {}
  if #src == 0 and type(fallbackActions) == "table" and #fallbackActions > 0 then
    src = { { id = string.format("%s_1", tostring(defaultName or "group"):gsub("%s+", "_"):lower()), name = tostring(defaultName or "Group") .. " 1", mode = "ordered", actions = _clone(fallbackActions) } }
  end
  local out = {}
  for i = 1, #src do
    local g = type(src[i]) == "table" and _clone(src[i]) or {}
    g.id = tostring(g.id or string.format("%s_%d", tostring(defaultName or "group"):gsub("%s+", "_"):lower(), i))
    g.name = tostring(g.name or string.format("%s %d", tostring(defaultName or "Group"), i))
    g.mode = _normalizeGroupMode(g.mode)
    g.actions = type(g.actions) == "table" and g.actions or {}
    out[#out + 1] = g
  end
  return out
end

local function _normalizeConditionGroupMode(mode)
  mode = tostring(mode or "ALL")
  if mode ~= "ANY" then mode = "ALL" end
  return mode
end

local function _normalizeConditionGroups(groups, defaultName)
  local src = type(groups) == "table" and groups or {}
  if #src == 0 then
    src = { { id = string.format("%s_1", tostring(defaultName or "condition_group"):gsub("%s+", "_"):lower()), name = tostring(defaultName or "Condition Group") .. " 1", mode = "ALL", conditions = {} } }
  end
  local out = {}
  for i = 1, #src do
    local g = type(src[i]) == "table" and _clone(src[i]) or {}
    g.id = tostring(g.id or string.format("%s_%d", tostring(defaultName or "condition_group"):gsub("%s+", "_"):lower(), i))
    g.name = tostring(g.name or string.format("%s %d", tostring(defaultName or "Condition Group"), i))
    g.mode = _normalizeConditionGroupMode(g.mode)
    g.conditions = type(g.conditions) == "table" and g.conditions or {}
    out[#out + 1] = g
  end
  return out
end

local function _normalizeRule(rule)
  if type(rule) ~= "table" then return end
  rule.type = "rule"
  rule.data = rule.data or {}
  if type(rule.data.conditions) ~= "table" then
    local single = rule.data.condition
    if type(single) == "table" then
      rule.data.conditions = { _clone(single) }
    else
      rule.data.conditions = {}
    end
  end
  rule.data.conditionMode = tostring(rule.data.conditionMode or "ALL")
  if rule.data.conditionMode ~= "ANY" then rule.data.conditionMode = "ALL" end
  local legacyConditions = _clone(rule.data.conditions or {})
  local legacyMode = tostring(rule.data.conditionMode or "ALL")
  if legacyMode ~= "ANY" then legacyMode = "ALL" end
  rule.data.conditionGroups = _normalizeConditionGroups(rule.data.conditionGroups, "Condition Group")
  rule.data.triggerConditionGroupId = tostring(rule.data.triggerConditionGroupId or "")
  local triggerGroup = nil
  for i = 1, #(rule.data.conditionGroups or {}) do
    local group = (rule.data.conditionGroups or {})[i] or {}
    if tostring(group.id or "") == tostring(rule.data.triggerConditionGroupId or "") then
      triggerGroup = group
      break
    end
  end
  if not triggerGroup then
    triggerGroup = (rule.data.conditionGroups or {})[1]
    rule.data.triggerConditionGroupId = tostring((triggerGroup or {}).id or "")
  end
  if triggerGroup and #legacyConditions > 0 and #(type(triggerGroup.conditions) == "table" and triggerGroup.conditions or {}) == 0 then
    triggerGroup.conditions = _clone(legacyConditions)
    triggerGroup.mode = legacyMode
  end
  if triggerGroup then
    rule.data.conditions = _clone(type(triggerGroup.conditions) == "table" and triggerGroup.conditions or {})
    rule.data.conditionMode = tostring(triggerGroup.mode or "ALL")
    if rule.data.conditionMode ~= "ANY" then rule.data.conditionMode = "ALL" end
  else
    rule.data.conditions = {}
    rule.data.conditionMode = "ALL"
  end
  rule.data.actions = type(rule.data.actions) == "table" and rule.data.actions or {}
  rule.data.falseActions = type(rule.data.falseActions) == "table" and rule.data.falseActions or {}
  rule.data.actionGroups = _normalizeActionGroups(rule.data.actionGroups, rule.data.actions, "Group")
  rule.data.falseActionGroups = _normalizeActionGroups(rule.data.falseActionGroups, rule.data.falseActions, "Exit Group")
  rule.data.enabled = rule.data.enabled ~= false

  local legacyOnce = rule.data.runOnceUntilFalse ~= false
  local legacyCooldown = tonumber(rule.data.cooldown or 0.25) or 0.25
  local exec = type(rule.data.execution) == "table" and rule.data.execution or {
    triggerMode = legacyOnce and "on_true" or "while_true",
    cadence = "every_time",
    cadenceValue = 2,
    cooldown = legacyCooldown,
    disableAfterFire = false,
    falsePolicy = "do_nothing",
    falseActions = rule.data.falseActions,
  }

  exec.triggerMode = tostring(exec.triggerMode or "on_true")
  if exec.triggerMode ~= "while_true" then exec.triggerMode = "on_true" end

  exec.cadence = tostring(exec.cadence or "every_time")
  if exec.cadence ~= "first_true_only" and exec.cadence ~= "every_nth_true" and exec.cadence ~= "after_nth_true" then
    exec.cadence = "every_time"
  end

  exec.cadenceValue = math.max(1, math.floor(tonumber(exec.cadenceValue or exec.nValue or 2) or 2))
  exec.cooldown = tonumber(exec.cooldown or legacyCooldown) or legacyCooldown
  if exec.cooldown < 0 then exec.cooldown = 0 end
  exec.disableAfterFire = exec.disableAfterFire == true

  exec.falsePolicy = tostring(exec.falsePolicy or "do_nothing")
  if exec.falsePolicy ~= "restore" and exec.falsePolicy ~= "run_exit_actions" and exec.falsePolicy ~= "disable_rule" then
    exec.falsePolicy = "do_nothing"
  end
  exec.falseActions = type(exec.falseActions) == "table" and exec.falseActions or rule.data.falseActions or {}

  rule.data.execution = exec
  rule.data.falseActions = exec.falseActions
  rule.data.runOnceUntilFalse = (exec.triggerMode == "on_true")
  rule.data.cooldown = exec.cooldown
  rule.data.condition = nil
end

local function _syncNextIdForState(st)
  st = type(st) == 'table' and st or AssetRegistry.state
  local maxNum = 0
  for _, id in ipairs(st.order or {}) do
    local n = tostring(id or ''):match('_(%d+)$')
    n = tonumber(n)
    if n and n > maxNum then maxNum = n end
  end
  st.nextId = math.max(tonumber(st.nextId or 1) or 1, maxNum + 1)
end

local function _syncNextId()
  _syncNextIdForState(AssetRegistry.state)
end

local function _normalizeLoadedState(st)
  if type(st) ~= 'table' then return nil end
  st.nextId = tonumber(st.nextId or 1) or 1
  st.items = type(st.items) == 'table' and st.items or {}
  st.order = type(st.order) == 'table' and st.order or {}
  local seen, order = {}, {}
  for i = 1, #st.order do
    local id = st.order[i]
    if type(id) == 'string' and st.items[id] ~= nil and not seen[id] then
      seen[id] = true
      order[#order + 1] = id
    end
  end
  for id, item in pairs(st.items) do
    if type(id) == 'string' and type(item) == 'table' and not seen[id] then
      order[#order + 1] = id
      seen[id] = true
    end
    if type(item) == 'table' and tostring(item.type or '') == 'rule' then _normalizeRule(item) end
  end
  st.order = order
  if st.selectedId ~= nil and st.items[st.selectedId] == nil then st.selectedId = order[1] end
  _syncNextIdForState(st)
  return st
end

function AssetRegistry.SaveToDisk()
  _syncNextId()
  local ok, msg = Persistence.SaveAssetRegistryState(_clone(AssetRegistry.state))
  return ok == true, msg
end

function AssetRegistry.ReloadFromDisk()
  local loaded, err = Persistence.LoadAssetRegistryState()
  if not loaded then return false, err end
  local norm = _normalizeLoadedState(loaded)
  if not norm then return false, 'Invalid registry state on disk' end
  AssetRegistry.state = norm
  return true, 'Loaded assets from disk.'
end

function AssetRegistry.GetPersistenceInfo()
  return {
    userDir = Persistence.GetUserDir and Persistence.GetUserDir() or nil,
    lastSaveAt = Persistence.state and Persistence.state.lastSaveAt or nil,
    lastLoadAt = Persistence.state and Persistence.state.lastLoadAt or nil,
    lastError = Persistence.state and Persistence.state.lastError or nil,
  }
end

function AssetRegistry.MakeEmptyRule()
  return {
    type = "rule",
    name = "",
    data = {
      enabled = true,
      runOnceUntilFalse = true,
      cooldown = 0.25,
      conditionMode = "ALL",
      conditions = {},
      triggerConditionGroupId = "condition_group_1",
      conditionGroups = { { id = "condition_group_1", name = "Condition Group 1", mode = "ALL", conditions = {} } },
      actions = {},
      falseActions = {},
      actionGroups = { { id = "group_1", name = "Group 1", mode = "ordered", actions = {} } },
      falseActionGroups = { { id = "exit_group_1", name = "Exit Group 1", mode = "ordered", actions = {} } },
      execution = {
        triggerMode = "on_true",
        cadence = "every_time",
        cadenceValue = 2,
        cooldown = 0.25,
        disableAfterFire = false,
        falsePolicy = "do_nothing",
        falseActions = {},
      },
    }
  }
end

function AssetRegistry.MakeEmptyMacro(mode)
  local resolved = tostring(mode or "toggle")
  if resolved ~= "button" then resolved = "toggle" end
  return {
    type = "macro",
    name = "",
    data = {
      mode = resolved,
      offPolicy = (resolved == "toggle") and "restore" or "none",
      onActionGroups = { { id = "group_1", name = "Group 1", mode = "ordered", actions = {} } },
      offActionGroups = { { id = "off_group_1", name = "Off Group 1", mode = "ordered", actions = {} } },
    }
  }
end

function AssetRegistry.MakeEmptyCustomCode(mode)
  local resolved = tostring(mode or "button")
  if resolved ~= "toggle" then resolved = "button" end
  return {
    type = "custom_code",
    name = "",
    data = {
      mode = resolved,
      onCode = "",
      offCode = "",
    }
  }
end

function AssetRegistry.MakeEmptyAnimationSequence()
  return {
    type = "animation_sequence",
    name = "",
    data = { steps = {} }
  }
end

function AssetRegistry.MakeEmptyScenario()
  return {
    type = "scenario",
    name = "",
    data = {
      mode = "relative",
      teleportPlayer = false,
      origin = { x = 0, y = 0, z = 0, yaw = 0 },
      entities = {},
      playerState = {},
    }
  }
end

function AssetRegistry.MakeEmptyTeleportPreset()
  return {
    type = "teleport_preset",
    name = "",
    data = { x = 0, y = 0, z = 0, label = "" }
  }
end

function AssetRegistry.MakeEmptyLauncher(mode)
  local resolved = tostring(mode or "button")
  if resolved ~= "toggle" then resolved = "button" end
  return {
    type = "launcher",
    name = "",
    data = {
      mode = resolved,
      entries = {},
    }
  }
end

function AssetRegistry.ListCreatedAssets()
  local out = {}
  for _, id in ipairs(AssetRegistry.state.order or {}) do
    local item = AssetRegistry.state.items[id]
    if type(item) == "table" then out[#out + 1] = _clone(item) end
  end
  return out
end

function AssetRegistry.Upsert(asset)
  if type(asset) ~= "table" then return nil, "Asset must be a table" end
  local st = AssetRegistry.state
  local item = _clone(asset)
  item.type = tostring(item.type or "asset")
  if item.type == "rule" then _normalizeRule(item) end
  if item.id == nil or item.id == "" then
    item.id = _nextId(_typePrefix(item.type))
    item.createdAtText = _nowText()
    st.order[#st.order + 1] = item.id
  else
    item.createdAtText = item.createdAtText or _nowText()
    local found = false
    for i = 1, #st.order do
      if st.order[i] == item.id then found = true break end
    end
    if not found then st.order[#st.order + 1] = item.id end
  end
  item.updatedAtText = _nowText()
  if item.name == nil or item.name == "" then
    item.name = string.format("%s %s", tostring(item.type), tostring(item.id))
  end
  st.items[item.id] = item
  st.selectedId = item.id
  _syncNextId()
  local ok, msg
  if Persistence.UpsertAsset then
    ok, msg = Persistence.UpsertAsset(_clone(item), _clone(st))
  else
    ok, msg = AssetRegistry.SaveToDisk()
  end
  if not ok then return nil, msg end
  return _clone(item), msg
end

function AssetRegistry.Delete(id)
  local st = AssetRegistry.state
  if id == nil or st.items[id] == nil then return false, "Missing asset" end
  local doomed = _clone(st.items[id])
  st.items[id] = nil
  for i = #st.order, 1, -1 do
    if st.order[i] == id then table.remove(st.order, i) end
  end
  if st.selectedId == id then st.selectedId = st.order[1] end
  local ok, msg
  if Persistence.DeleteAsset then
    ok, msg = Persistence.DeleteAsset(doomed, _clone(st))
  else
    ok, msg = AssetRegistry.SaveToDisk()
  end
  if not ok then return false, msg end
  return true, msg
end

function AssetRegistry.Get(id)
  local item = AssetRegistry.state.items[id]
  if item == nil then return nil end
  return _clone(item)
end

function AssetRegistry.GetMutable(id)
  return AssetRegistry.state.items[id]
end

function AssetRegistry.List(assetType)
  local out = {}
  for _, id in ipairs(AssetRegistry.state.order) do
    local item = AssetRegistry.state.items[id]
    if item ~= nil and (assetType == nil or item.type == assetType) then
      out[#out + 1] = _clone(item)
    end
  end
  return out
end

function AssetRegistry.ListMutable(assetType)
  local out = {}
  for _, id in ipairs(AssetRegistry.state.order) do
    local item = AssetRegistry.state.items[id]
    if item ~= nil and (assetType == nil or item.type == assetType) then
      out[#out + 1] = item
    end
  end
  return out
end

function AssetRegistry.Duplicate(id)
  local item = AssetRegistry.Get(id)
  if item == nil then return nil, "Missing asset" end
  item.id = nil
  item.name = tostring(item.name or "Asset") .. " Copy"
  return AssetRegistry.Upsert(item)
end


function AssetRegistry.FindByTypeAndName(assetType, name)
  local targetType = tostring(assetType or "")
  local targetName = tostring(name or "")
  if targetType == "" or targetName == "" then return nil end
  for _, id in ipairs(AssetRegistry.state.order) do
    local item = AssetRegistry.state.items[id]
    if item ~= nil and tostring(item.type or "") == targetType and tostring(item.name or "") == targetName then
      return _clone(item)
    end
  end
  return nil
end

function AssetRegistry.MakeUniqueName(assetType, desiredName, excludeId)
  local base = tostring(desiredName or "")
  base = base:gsub("^%s+", ""):gsub("%s+$", "")
  if base == "" then base = tostring(assetType or "asset") end

  local used = {}
  for _, id in ipairs(AssetRegistry.state.order or {}) do
    local item = AssetRegistry.state.items[id]
    if type(item) == "table" and tostring(item.type or "") == tostring(assetType or "") and tostring(item.id or "") ~= tostring(excludeId or "") then
      used[tostring(item.name or "")] = true
    end
  end

  if not used[base] then return base end

  local idx = 2
  while true do
    local candidate = string.format("%s %d", base, idx)
    if not used[candidate] then return candidate end
    idx = idx + 1
  end
end

function AssetRegistry.UpsertNew(asset, desiredName)
  if type(asset) ~= "table" then return nil, "Asset must be a table" end
  local item = _clone(asset)
  item.id = nil
  item.createdAtText = nil
  item.updatedAtText = nil
  item.type = tostring(item.type or "asset")
  item.name = AssetRegistry.MakeUniqueName(item.type, desiredName or item.name, nil)
  return AssetRegistry.Upsert(item)
end

do
  local loaded = Persistence.LoadAssetRegistryState and Persistence.LoadAssetRegistryState() or nil
  if loaded and type(loaded) == "table" then
    local norm = _normalizeLoadedState(loaded)
    if norm then AssetRegistry.state = norm end
  else
    _syncNextId()
  end
end

return AssetRegistry
