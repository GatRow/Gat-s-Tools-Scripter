
local ScenarioBuilder = ScenarioBuilder or {}

local AssetRegistry = require("GTS/asset_registry")
local SpawnTools = require("GTS/spawn_tools")
local TargetService = require("GTS/target_service")
local TargetControl = require("GTS/target_control")
local PoseBuilder = require("GTS/pose_builder")
local StatusActions = require("GTS/macro_actions_status")
local Equip = require("GTS/macro_actions_equipment")
local PlayerActions = require("GTS/macro_actions_player")
local World = require("GTS/macro_actions_world")
local Utils = require("GTS/utils")

ScenarioBuilder.state = ScenarioBuilder.state or {
  name = "",
  mode = "relative", -- relative / absolute / anchored
  teleportPlayer = false,
  captureClothing = false,
  forceEquipCurrentWeapon = false,
  forceEquipWeapon = false,
  customWeaponId = "",
  captureTimeOfDay = false,
  frozenTime = false,
  captureJohnnyArm = false,
  playerState = {
    clothing = {},
    currentWeapon = "",
    weaponId = "",
    hour = 12,
    minute = 0,
    johnnyArmOn = false,
  },
  origin = { x = 0, y = 0, z = 0, yaw = 0 },
  entities = {},
  selectedIndex = 0,
  savedSelectedId = nil,
  loadedAssetId = nil,
  status = "Ready.",
  pendingFinalize = {},
  runtimeJobs = {},
  liveNudge = 0.10,
  yawNudge = 15,
  appendCapture = false,
  targetForge = {
    pos = { x = 0, y = 0, z = 0, w = 1 },
    yaw = 0,
    appearanceSearch = '',
    appearanceSelected = '',
    statusSearch = '',
    statusSelected = '',
    manualStatusId = '',
    action = { sourceMode = 'pose_db', rig = 'Man Average', poseSearch = '', poseName = '', instant = true, freezeAfterSeconds = 0, stopAfterSeconds = 0 },
    previewResetAnimation = false,
    previewResetAnimationAfter = 2.0,
    previewRestoreAppearance = false,
    previewRestoreAppearanceAfter = 2.0,
    previewRemoveStatus = false,
    previewRemoveStatusAfter = 2.0,
  },
  timeline = { playing = false, startedAt = 0, duration = 0, playhead = 0, events = {} },
  quickSpawn = {
    mode = 'Character',
    search = '',
    selectedIndex = 1,
    spawnLocation = 'in_front',
    customXYZ = { x = '0', y = '0', z = '0' },
    dangerPopupOpen = false,
    pendingDanger = nil,
  },
}

local sb_clone = Utils.clone
local sb_inputText = Utils.inputTextValue
local sb_checkbox = Utils.checkboxValue

local function sb_combo(label, current, values)
  local idx = 0
  for i = 1, #values do
    if values[i].id == current or values[i] == current then idx = i - 1 break end
  end
  local labels = {}
  for i = 1, #values do labels[i] = values[i].label or values[i] end
  local changed, newIdx = ImGui.Combo(label, idx, labels, #labels)
  local outIdx = nil
  if type(changed) == 'boolean' then
    if not changed then return current end
    outIdx = (newIdx or idx) + 1
  elseif type(changed) == 'number' then
    outIdx = changed + 1
  end
  local chosen = values[outIdx or (idx + 1)]
  return (type(chosen) == 'table' and chosen.id) or chosen or current
end

local function sb_safePlayer()
  local ok, p = pcall(function() return Game.GetPlayer() end)
  return ok and p or nil
end

local function sb_sameEntity(a, b)
  if not a or not b then return false end
  local okA, ida = pcall(function() return a:GetEntityID() end)
  local okB, idb = pcall(function() return b:GetEntityID() end)
  return okA and okB and tostring(ida) == tostring(idb)
end

local function sb_getQuaternion()
  if not GetSingleton then return nil end
  local ok, q = pcall(function() return GetSingleton('Quaternion') end)
  return ok and q or nil
end

local function sb_readEuler(handle)
  if not handle then return EulerAngles.new(0, 0, 0) end
  local ok, ori = pcall(function() return handle:GetWorldOrientation() end)
  if ok and ori then
    local q = sb_getQuaternion()
    if q and q.ToEulerAngles then
      local ok2, ea = pcall(function() return q:ToEulerAngles(ori) end)
      if ok2 and ea then return ea end
    end
  end
  return EulerAngles.new(0, 0, 0)
end

local function sb_yaw(handle)
  local ea = sb_readEuler(handle)
  return tonumber(ea and ea.yaw or 0) or 0
end

local function sb_pos(handle)
  if not handle then return nil end
  local ok, pos = pcall(function()
    if handle.GetWorldPosition then return handle:GetWorldPosition() end
    if handle.GetPosition then return handle:GetPosition() end
    return nil
  end)
  if not ok or not pos then return nil end
  return {
    x = tonumber(pos.x or pos.X or 0) or 0,
    y = tonumber(pos.y or pos.Y or 0) or 0,
    z = tonumber(pos.z or pos.Z or 0) or 0,
    w = tonumber(pos.w or pos.W or 1) or 1,
  }
end

local function sb_entityId(handle)
  if not handle or not handle.GetEntityID then return nil end
  local ok, eid = pcall(function() return handle:GetEntityID() end)
  return ok and eid or nil
end

local function sb_teleportHandle(handle, pos, yaw)
  if not handle or not pos then return false, "Missing handle or position" end
  local tf = (Game and Game.GetTeleportationFacility and Game.GetTeleportationFacility()) or nil
  local dest = Vector4.new(tonumber(pos.x or 0) or 0, tonumber(pos.y or 0) or 0, tonumber(pos.z or 0) or 0, tonumber(pos.w or 1) or 1)
  local ori = EulerAngles.new(0, 0, tonumber(yaw or 0) or 0)
  local moved = false
  if tf and tf.Teleport then
    local ok = pcall(function() tf:Teleport(handle, dest, ori) end)
    if ok then moved = true end
  end
  if handle.SetWorldPosition then pcall(function() handle:SetWorldPosition(dest) end) end
  return moved or handle.SetWorldPosition ~= nil, nil
end

local function sb_teleportPlayer(pos, yaw)
  local p = sb_safePlayer()
  if not p then return false, "Player unavailable" end
  return sb_teleportHandle(p, pos, yaw)
end

local function sb_rotateOffset(dx, dy, yawDeg)
  local r = math.rad(tonumber(yawDeg or 0) or 0)
  local c, s = math.cos(r), math.sin(r)
  return (dx * c) - (dy * s), (dx * s) + (dy * c)
end

local function sb_worldFromRelative(origin, rel)
  local rx, ry = sb_rotateOffset(tonumber(rel.x or 0) or 0, tonumber(rel.y or 0) or 0, tonumber(origin.yaw or 0) or 0)
  return {
    x = (tonumber(origin.x or 0) or 0) + rx,
    y = (tonumber(origin.y or 0) or 0) + ry,
    z = (tonumber(origin.z or 0) or 0) + (tonumber(rel.z or 0) or 0),
    w = 1,
  }
end

local function sb_relativeFromWorld(origin, world)
  local dx = (tonumber(world.x or 0) or 0) - (tonumber(origin.x or 0) or 0)
  local dy = (tonumber(world.y or 0) or 0) - (tonumber(origin.y or 0) or 0)
  local r = math.rad(-(tonumber(origin.yaw or 0) or 0))
  local c, s = math.cos(r), math.sin(r)
  return {
    x = (dx * c) - (dy * s),
    y = (dx * s) + (dy * c),
    z = (tonumber(world.z or 0) or 0) - (tonumber(origin.z or 0) or 0),
  }
end

local function sb_currentPlayerOrigin()
  local p = sb_safePlayer()
  if not p then return { x = 0, y = 0, z = 0, yaw = 0 } end
  local pos = sb_pos(p) or { x = 0, y = 0, z = 0, w = 1 }
  return { x = pos.x, y = pos.y, z = pos.z, yaw = sb_yaw(p) }
end

local function sb_sequenceAssets()
  local assets = (AssetRegistry.List and AssetRegistry.List('animation_sequence')) or {}
  table.sort(assets, function(a, b) return tostring(a.name or a.id or ''):lower() < tostring(b.name or b.id or ''):lower() end)
  return assets
end

local function sb_captureSequenceAsset(ref)
  if not ref or not AssetRegistry.Get then return nil end
  local asset = AssetRegistry.Get(ref)
  if type(asset) == 'table' and tostring(asset.type or '') == 'animation_sequence' then
    return sb_clone(asset)
  end
  return nil
end

local function sb_guessModeFromRecord(record, className)
  local s = tostring(record or '')
  if s:match('^Character%.') then return 'Character' end
  if s:match('^Vehicle%.') then return 'Vehicle' end
  if s:match('^Attacks%.') then return 'Attack' end
  if s:match('%.ent$') or s:find('\\', 1, true) or s:find('/', 1, true) then return 'Entity' end
  if tostring(className or '') == 'vehicle' then return 'Vehicle' end
  return 'Character'
end


local function sb_cleanEntry(entry)
  local action = type(entry.action) == 'table' and sb_clone(entry.action) or nil
  local out = {
    id = tostring(entry.id or ('scenario_entry_' .. tostring(os.clock()))),
    label = tostring(entry.label or entry.record or entry.id or 'Entry'),
    enabled = entry.enabled ~= false,
    mode = tostring(entry.mode or 'Character'),
    record = tostring(entry.record or ''),
    worldPos = {
      x = tonumber((((entry.worldPos or {}).x) or entry.x) or 0) or 0,
      y = tonumber((((entry.worldPos or {}).y) or entry.y) or 0) or 0,
      z = tonumber((((entry.worldPos or {}).z) or entry.z) or 0) or 0,
      w = 1,
    },
    worldYaw = tonumber(entry.worldYaw or entry.yaw or 0) or 0,
    relPos = {
      x = tonumber((((entry.relPos or {}).x) or 0)) or 0,
      y = tonumber((((entry.relPos or {}).y) or 0)) or 0,
      z = tonumber((((entry.relPos or {}).z) or 0)) or 0,
    },
    relYaw = tonumber(entry.relYaw or 0) or 0,
    appearance = tostring(entry.appearance or ''),
    appearanceApplyDelaySeconds = tonumber(entry.appearanceApplyDelaySeconds or 0) or 0,
    sequenceRef = entry.sequenceRef,
    sequenceAsset = type(entry.sequenceAsset) == 'table' and sb_clone(entry.sequenceAsset) or nil,
    action = action,
    spawnDelaySeconds = tonumber(entry.spawnDelaySeconds or 0) or 0,
    freezeOnSpawn = entry.freezeOnSpawn ~= false,
    unfreezeAfterSeconds = tonumber(entry.unfreezeAfterSeconds or 0) or 0,
    actionDelaySeconds = tonumber(entry.actionDelaySeconds or 0) or 0,
    statusEffectId = tostring(entry.statusEffectId or ''),
    statusApplyDelaySeconds = tonumber(entry.statusApplyDelaySeconds or 0) or 0,
    statusRemoveDelaySeconds = tonumber(entry.statusRemoveDelaySeconds or 0) or 0,
    despawnAfterSeconds = tonumber(entry.despawnAfterSeconds or 0) or 0,
    sourceSpawnId = entry.sourceSpawnId,
    sourceEntityID = entry.sourceEntityID,
  }
  return out
end



local function sb_inputNumber(label, current, size)
  local text = sb_inputText(label, tostring(current or ''), size or 24)
  local num = tonumber(text)
  if num == nil then return current end
  return num
end

local function sb_modeSupportsTargetActions(mode)
  local m = tostring(mode or '')
  return m ~= 'FX' and m ~= 'Attack'
end

local function sb_scheduleJob(job)
  local st = ScenarioBuilder.state
  st.runtimeJobs = st.runtimeJobs or {}
  st.runtimeJobs[#st.runtimeJobs + 1] = job
end

local function sb_stopPoseOnHandle(handle)
  if not handle then return false, 'Missing handle' end
  local ws = Game and Game.GetWorkspotSystem and Game.GetWorkspotSystem() or nil
  if not ws then return false, 'WorkspotSystem unavailable' end
  local ok, err = pcall(function() ws:StopInDevice(handle) end)
  if PoseBuilder and type(PoseBuilder.SetFrozen) == 'function' then
    pcall(function() PoseBuilder:SetFrozen(handle, false, false) end)
  end
  return ok == true, ok and 'Stopped current animation' or tostring(err or 'StopInDevice failed')
end

local function sb_applyAppearanceToHandle(handle, appearance)
  if not handle then return false, 'Missing handle' end
  if not TargetControl or type(TargetControl.ApplyAppearanceToHandle) ~= 'function' then
    return false, 'Appearance handle apply unavailable'
  end
  return TargetControl.ApplyAppearanceToHandle(handle, appearance)
end

local function sb_clearLiveSpawnedScene()
  local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
  for i = #spawned, 1, -1 do
    local item = spawned[i]
    pcall(function() sb_despawnHandle(item and item.handle or nil, item and item.entityID or nil) end)
  end
  return true
end

local function sb_rebuildDraftSceneLater(seconds)
  sb_scheduleJob({ kind = 'rebuild_draft_scene', dueAt = os.clock() + math.max(0.05, tonumber(seconds or 0.35) or 0.35) })
end

local function sb_spawnScenarioQuickPayload(payload, resetScene)
  local st = ScenarioBuilder.state
  if type(payload) ~= 'table' then return false, 'Missing quick-spawn payload' end
  local ok, itemOrErr = SpawnTools.SpawnRecordAtPoint(payload.record, payload.mode, payload.point, 0)
  if ok and resetScene == true then
    sb_rebuildDraftSceneLater(0.40)
  end
  if ok then
    if resetScene == true then
      return true, 'Spawned ' .. tostring(sb_basename(payload.record)) .. ' and queued scene reset.'
    end
    return true, 'Spawned ' .. tostring(sb_basename(payload.record))
  end
  return false, tostring(itemOrErr or 'Spawn failed.')
end

local function sb_entryAction(entry)
  if type(entry) == 'table' and type(entry.action) == 'table' then
    return entry.action
  end
  if type(entry) == 'table' and (entry.sequenceRef or entry.sequenceAsset) then
    return {
      sourceMode = 'saved_sequence',
      sequenceRef = entry.sequenceRef,
      sequenceAsset = type(entry.sequenceAsset) == 'table' and sb_clone(entry.sequenceAsset) or nil,
      instant = true,
    }
  end
  return nil
end

local function sb_actionSummary(action)
  if type(action) ~= 'table' then return '(none)' end
  if PoseBuilder and type(PoseBuilder.DescribeActionTarget) == 'function' then
    local ok, out = pcall(function() return PoseBuilder.DescribeActionTarget(action) end)
    if ok and type(out) == 'string' and out ~= '' then return out end
  end
  if tostring(action.sourceMode or 'pose_db') == 'saved_sequence' then
    local asset = action.sequenceAsset or (action.sequenceRef and AssetRegistry.Get and AssetRegistry.Get(action.sequenceRef)) or nil
    return asset and tostring(asset.name or asset.id or 'Saved Sequence') or 'Saved Sequence'
  end
  return tostring(action.poseName or action.name or '(choose animation)')
end

local function sb_copyForgeActionIntoEntry(entry)
  local forge = (ScenarioBuilder.state or {}).targetForge or {}
  if type(forge.action) ~= 'table' then return false end
  entry.action = sb_clone(forge.action)
  if tostring((entry.action or {}).sourceMode or 'pose_db') == 'saved_sequence' then
    entry.sequenceRef = entry.action.sequenceRef
    if entry.action.sequenceRef and not entry.action.sequenceAsset then
      entry.action.sequenceAsset = sb_captureSequenceAsset(entry.action.sequenceRef)
    end
    entry.sequenceAsset = type(entry.action.sequenceAsset) == 'table' and sb_clone(entry.action.sequenceAsset) or sb_captureSequenceAsset(entry.sequenceRef)
  end
  return true
end

local function sb_removeStatusEffectFromEntity(rawEffectId, entityID)
  local effectId = sb_trim(rawEffectId)
  if effectId == '' or entityID == nil then return false, 'Missing status effect or target' end
  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  if not ses then return false, 'StatusEffectSystem unavailable' end
  local attempts = {
    function() ses:RemoveStatusEffect(entityID, effectId) end,
  }
  if TweakDB and TweakDB.GetRecord then
    attempts[#attempts + 1] = function()
      local rec = TweakDB:GetRecord(effectId)
      local tok = rec and rec:GetID() or nil
      if tok then ses:RemoveStatusEffect(entityID, tok) end
    end
  end
  local lastErr = 'RemoveStatusEffect failed'
  for i = 1, #attempts do
    local ok, err = pcall(attempts[i])
    if ok then return true, 'Removed ' .. tostring(effectId) end
    lastErr = tostring(err)
  end
  return false, lastErr
end

local function sb_findSpawnedEntryByEntityID(entityID)
  local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
  if entityID == nil then return nil end
  for i = 1, #spawned do
    if tostring((spawned[i] or {}).entityID) == tostring(entityID) then return spawned[i], i end
  end
  return nil, nil
end

local function sb_despawnHandle(handle, entityID)
  local des = (Game and Game.GetDynamicEntitySystem and Game.GetDynamicEntitySystem()) or nil
  if handle then pcall(function() handle:Dispose() end) end
  if des and entityID then pcall(function() des:DeleteEntity(entityID) end) end
  local entry, idx = sb_findSpawnedEntryByEntityID(entityID)
  if idx then table.remove((((SpawnTools or {}).state or {}).spawned) or {}, idx) end
  return true
end

local function sb_buildTimelineEventsFromEntries(entities)
  local events = {}
  for i = 1, #(entities or {}) do
    local e = sb_cleanEntry(entities[i])
    if e.enabled ~= false and e.record ~= '' then
      local spawnAt = math.max(0, tonumber(e.spawnDelaySeconds or 0) or 0)
      events[#events + 1] = { time = spawnAt, kind = 'spawn', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' spawn' }
      if e.freezeOnSpawn then
        events[#events + 1] = { time = spawnAt, kind = 'freeze', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' freeze on spawn' }
      end
      local unfreezeAt = tonumber(e.unfreezeAfterSeconds or 0) or 0
      if unfreezeAt > 0 then
        events[#events + 1] = { time = spawnAt + unfreezeAt, kind = 'unfreeze', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' unfreeze' }
      end
      local appearanceId = sb_trim(e.appearance or '')
      local appearanceAt = tonumber(e.appearanceApplyDelaySeconds or 0) or 0
      if appearanceId ~= '' then
        events[#events + 1] = { time = spawnAt + appearanceAt, kind = 'appearance_apply', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' appearance: ' .. appearanceId }
      end
      local action = sb_entryAction(e)
      local actionDelay = tonumber(e.actionDelaySeconds or 0) or 0
      if action then
        events[#events + 1] = { time = spawnAt + actionDelay, kind = 'animation', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' animation: ' .. sb_actionSummary(action) }
      end
      local statusId = sb_trim(e.statusEffectId or '')
      if statusId ~= '' then
        local applyAt = tonumber(e.statusApplyDelaySeconds or 0) or 0
        events[#events + 1] = { time = spawnAt + applyAt, kind = 'status_apply', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' apply ' .. statusId }
        local removeAt = tonumber(e.statusRemoveDelaySeconds or 0) or 0
        if removeAt > 0 then
          events[#events + 1] = { time = spawnAt + removeAt, kind = 'status_remove', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' remove ' .. statusId }
        end
      end
      local despawnAt = tonumber(e.despawnAfterSeconds or 0) or 0
      if despawnAt > 0 then
        events[#events + 1] = { time = spawnAt + despawnAt, kind = 'despawn', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' despawn' }
      end
    end
  end
  table.sort(events, function(a, b)
    if tonumber(a.time or 0) == tonumber(b.time or 0) then return tostring(a.label or '') < tostring(b.label or '') end
    return tonumber(a.time or 0) < tonumber(b.time or 0)
  end)
  return events
end

local function sb_refreshTimelineFromDraft()
  local st = ScenarioBuilder.state
  st.timeline = st.timeline or { playing = false, startedAt = 0, duration = 0, playhead = 0, events = {} }
  st.timeline.events = sb_buildTimelineEventsFromEntries(st.entities or {})
  local maxT = 0
  for i = 1, #(st.timeline.events or {}) do
    maxT = math.max(maxT, tonumber((st.timeline.events[i] or {}).time or 0) or 0)
  end
  st.timeline.duration = maxT
  if st.timeline.playing ~= true then
    st.timeline.playhead = math.min(tonumber(st.timeline.playhead or 0) or 0, maxT)
  end
end

local function sb_findLiveHandleForEntry(entry)
  if type(entry) ~= 'table' then return nil end
  local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
  for i = 1, #spawned do
    local e = spawned[i]
    if type(entry.sourceSpawnId) == 'number' and tonumber(e.id) == tonumber(entry.sourceSpawnId) then
      return e.handle or (e.entityID and Game.FindEntityByID and Game.FindEntityByID(e.entityID)) or nil
    end
    if entry.sourceEntityID ~= nil and e.entityID ~= nil and tostring(e.entityID) == tostring(entry.sourceEntityID) then
      return e.handle or (e.entityID and Game.FindEntityByID and Game.FindEntityByID(e.entityID)) or nil
    end
  end
  return nil
end

local function sb_recomputeRelativeForAll()
  local st = ScenarioBuilder.state
  for i = 1, #st.entities do
    local e = st.entities[i]
    e.relPos = sb_relativeFromWorld(st.origin, e.worldPos or {})
    e.relYaw = (tonumber(e.worldYaw or 0) or 0) - (tonumber(st.origin.yaw or 0) or 0)
  end
end

local function sb_addCapturedEntry(entry, append)
  local st = ScenarioBuilder.state
  if not append then st.entities = {} end
  st.entities[#st.entities + 1] = sb_cleanEntry(entry)
  st.selectedIndex = #st.entities > 0 and #st.entities or 0
end

local function sb_captureSpawnedScene(append)
  local st = ScenarioBuilder.state
  local origin = sb_currentPlayerOrigin()
  st.origin = sb_clone(origin)
  if not append then st.entities = {} end
  local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
  local added = 0
  for i = 1, #spawned do
    local s = spawned[i]
    if s and s.exists ~= false and tostring(s.record or '') ~= '' then
      local handle = s.handle or (s.entityID and Game.FindEntityByID and Game.FindEntityByID(s.entityID)) or nil
      local pos = (handle and sb_pos(handle)) or { x = tonumber(((s.xyz or {}).x) or 0) or 0, y = tonumber(((s.xyz or {}).y) or 0) or 0, z = tonumber(((s.xyz or {}).z) or 0) or 0, w = 1 }
      local yaw = handle and sb_yaw(handle) or 0
      st.entities[#st.entities + 1] = sb_cleanEntry({
        id = 'spawned_' .. tostring(s.id or i),
        label = sb_basename(s.record or ('Spawn ' .. tostring(i))),
        mode = tostring(s.mode or 'Character'),
        record = tostring(s.record or ''),
        worldPos = pos,
        worldYaw = yaw,
        relPos = sb_relativeFromWorld(origin, pos),
        relYaw = yaw - (tonumber(origin.yaw or 0) or 0),
        freezeOnSpawn = true,
        sourceSpawnId = s.id,
        sourceEntityID = s.entityID,
      })
      added = added + 1
    end
  end
  st.selectedIndex = (#st.entities > 0) and 1 or 0
  sb_refreshTimelineFromDraft()
  st.status = string.format('Captured %d spawned entr%s.', added, added == 1 and 'y' or 'ies')
end

local function sb_captureCurrentTarget()
  local st = ScenarioBuilder.state
  local snap = TargetService.GetSnapshot and TargetService.GetSnapshot(true) or nil
  if not snap or not snap.exists or not snap.handle then
    st.status = 'No current target to capture.'
    return false
  end
  local record = tostring(snap.recordId or '')
  if record == '' then
    st.status = 'Current target has no usable record id.'
    return false
  end
  local origin = sb_currentPlayerOrigin()
  st.origin = sb_clone(origin)
  local pos = sb_pos(snap.handle) or { x = tonumber(((snap.xyz or {}).x) or 0) or 0, y = tonumber(((snap.xyz or {}).y) or 0) or 0, z = tonumber(((snap.xyz or {}).z) or 0) or 0, w = 1 }
  local yaw = sb_yaw(snap.handle)
  st.entities[#st.entities + 1] = sb_cleanEntry({
    id = 'target_' .. tostring(#st.entities + 1),
    label = sb_basename(record),
    mode = sb_guessModeFromRecord(record, snap.className),
    record = record,
    worldPos = pos,
    worldYaw = yaw,
    relPos = sb_relativeFromWorld(origin, pos),
    relYaw = yaw - (tonumber(origin.yaw or 0) or 0),
    appearance = tostring(snap.appearance or ''),
    freezeOnSpawn = true,
    sourceEntityID = snap.entityID,
  })
  st.selectedIndex = #st.entities
  sb_refreshTimelineFromDraft()
  st.status = 'Captured current target into scenario.'
  return true
end

local function sb_resolveEquipmentPlayerData()
  local p = sb_safePlayer()
  if not p then return nil end
  local ssc = Game and Game.GetScriptableSystemsContainer and Game.GetScriptableSystemsContainer() or nil
  if not ssc then return nil end
  local ok, es = pcall(function() return ssc:Get('EquipmentSystem') end)
  if not ok or not es or not es.GetPlayerData then return nil end
  local ok2, pd = pcall(function() return es:GetPlayerData(p) end)
  return ok2 and pd or nil
end

local function sb_getItemInSlot(areaName, index)
  local pd = sb_resolveEquipmentPlayerData()
  if not pd then return nil end
  local areaToken = areaName
  if type(areaName) == 'string' and gamedataEquipmentArea and gamedataEquipmentArea[areaName] ~= nil then
    areaToken = gamedataEquipmentArea[areaName]
  end
  local attempts = {
    function() if pd.GetItemInEquipSlot2 then return pd:GetItemInEquipSlot2(areaToken, index or 0) end end,
    function() if pd.GetItemInEquipSlot then return pd:GetItemInEquipSlot(areaToken, index or 0) end end,
    function() if pd.GetItemInEquipSlot then return pd:GetItemInEquipSlot(areaName, index or 0) end end,
  }
  for i = 1, #attempts do
    local ok, value = pcall(attempts[i])
    if ok and value ~= nil then return value end
  end
  return nil
end

local function sb_extractItemId(value)
  if value == nil then return nil end
  local probes = {
    function() return value.id end,
    function() if value.GetID then return value:GetID() end end,
    function() if value.GetItemID then return value:GetItemID() end end,
    function() if value.GetRecordID then return value:GetRecordID() end end,
    function() if value.GetTDBID then return value:GetTDBID() end end,
  }
  for i = 1, #probes do
    local ok, v = pcall(probes[i])
    if ok and v ~= nil then
      local s = tostring(v)
      local items = s:match('(Items%.[%w_%.%-]+)')
      if items and items ~= '' then return items end
    end
  end
  local s = tostring(value)
  return s:match('(Items%.[%w_%.%-]+)')
end

local function sb_captureClothing()
  local slots = {
    { key = 'Head', area = 'Head' },
    { key = 'Face', area = 'Face' },
    { key = 'Outer Torso', area = 'OuterChest' },
    { key = 'Inner Torso', area = 'InnerChest' },
    { key = 'Legs', area = 'Legs' },
    { key = 'Feet', area = 'Feet' },
    { key = 'Outfit', area = 'Outfit' },
  }
  local out = {}
  for i = 1, #slots do
    local slot = slots[i]
    out[slot.key] = sb_extractItemId(sb_getItemInSlot(slot.area, 0)) or ''
  end
  ScenarioBuilder.state.playerState.clothing = out
  ScenarioBuilder.state.status = 'Captured equipped clothing.'
end

local function sb_captureCurrentWeapon()
  local candidates = {
    sb_getItemInSlot('Weapon', 0),
    sb_getItemInSlot('WeaponRight', 0),
    sb_getItemInSlot('RightHand', 0),
  }
  local itemId = ''
  for i = 1, #candidates do
    itemId = sb_extractItemId(candidates[i]) or ''
    if itemId ~= '' then break end
  end
  ScenarioBuilder.state.playerState.currentWeapon = itemId
  if itemId ~= '' then
    ScenarioBuilder.state.status = 'Captured current weapon: ' .. tostring(itemId)
  else
    ScenarioBuilder.state.status = 'Could not capture current weapon.'
  end
end

local function sb_captureJohnnyArm()
  local item = sb_extractItemId(sb_getItemInSlot('ArmsCW', 0)) or ''
  local enabled = string.find(string.lower(item), 'silverhandarm', 1, true) ~= nil
  ScenarioBuilder.state.playerState.johnnyArmOn = enabled
  ScenarioBuilder.state.status = enabled and 'Captured Johnny arm as ON.' or 'Captured Johnny arm as OFF.'
end

local function sb_tryCaptureTimeOfDay()
  local ts = Game and Game.GetTimeSystem and Game.GetTimeSystem() or nil
  local st = ScenarioBuilder.state
  if not ts then st.status = 'TimeSystem unavailable.' return false end
  local probes = {
    function() return ts:GetGameTime() end,
    function() return ts:GetGameTimeStamp() end,
    function() return ts:GetGameTimeByHMS() end,
  }
  local raw = nil
  for i = 1, #probes do
    local ok, value = pcall(probes[i])
    if ok and value ~= nil then raw = value break end
  end
  local h, m = nil, nil
  if type(raw) == 'table' then
    h = tonumber(raw.hour or raw.hours or raw.Hours)
    m = tonumber(raw.minute or raw.minutes or raw.Minutes)
  else
    local s = tostring(raw or '')
    h, m = s:match('(%d+):(%d+)')
    h = tonumber(h)
    m = tonumber(m)
  end
  if h == nil or m == nil then
    st.status = 'Could not capture current time; set it manually if needed.'
    return false
  end
  st.playerState.hour = math.max(0, math.min(23, math.floor(h)))
  st.playerState.minute = math.max(0, math.min(59, math.floor(m)))
  st.status = string.format('Captured time of day: %02d:%02d', st.playerState.hour, st.playerState.minute)
  return true
end

local function sb_applyPlayerState(ps)
  if type(ps) ~= 'table' then return true, nil end
  if ps.captureClothing == true and type(ps.clothing) == 'table' then
    for _, itemId in pairs(ps.clothing) do
      if tostring(itemId or '') ~= '' and Equip and type(Equip.EquipItemRecord) == 'function' then
        pcall(function() Equip.EquipItemRecord(itemId) end)
      end
    end
  end
  if ps.forceEquipCurrentWeapon == true and tostring(ps.currentWeapon or '') ~= '' and Equip and type(Equip.EquipItemRecord) == 'function' then
    pcall(function() Equip.EquipItemRecord(ps.currentWeapon) end)
  end
  if ps.forceEquipWeapon == true and tostring(ps.weaponId or '') ~= '' and Equip and type(Equip.EquipItemRecord) == 'function' then
    pcall(function() Equip.EquipItemRecord(ps.weaponId) end)
  end
  if ps.captureTimeOfDay == true and World and type(World.SetTimeOfDay) == 'function' then
    pcall(function() World.SetTimeOfDay(ps.hour or 12, ps.minute or 0) end)
  end
  if ps.frozenTime == true and World and type(World.SetTimeDilation) == 'function' then
    pcall(function() World.SetTimeDilation('world_only', 0.01) end)
  end
  if ps.captureJohnnyArm == true and PlayerActions and type(PlayerActions.SetJohnnySilverhandArm) == 'function' then
    pcall(function() PlayerActions.SetJohnnySilverhandArm(ps.johnnyArmOn and 'on' or 'off') end)
  end
  return true, nil
end

local function sb_buildScenarioAsset(name, existing)
  local st = ScenarioBuilder.state
  local asset = type(existing) == 'table' and sb_clone(existing) or ((AssetRegistry.MakeEmptyScenario and AssetRegistry.MakeEmptyScenario()) or { type = 'scenario', data = {} })
  asset.type = 'scenario'
  asset.name = sb_trim(name)
  if asset.name == '' then asset.name = 'Scenario' end
  asset.data = asset.data or {}
  asset.data.mode = tostring(st.mode or 'relative')
  asset.data.teleportPlayer = st.teleportPlayer == true
  asset.data.origin = sb_clone(st.origin)
  asset.data.playerState = {
    captureClothing = st.captureClothing == true,
    clothing = sb_clone((st.playerState or {}).clothing or {}),
    forceEquipCurrentWeapon = st.forceEquipCurrentWeapon == true,
    currentWeapon = tostring((st.playerState or {}).currentWeapon or ''),
    forceEquipWeapon = st.forceEquipWeapon == true,
    weaponId = tostring(st.customWeaponId or ''),
    captureTimeOfDay = st.captureTimeOfDay == true,
    hour = tonumber((st.playerState or {}).hour or 12) or 12,
    minute = tonumber((st.playerState or {}).minute or 0) or 0,
    frozenTime = st.frozenTime == true,
    captureJohnnyArm = st.captureJohnnyArm == true,
    johnnyArmOn = (st.playerState or {}).johnnyArmOn == true,
  }
  asset.data.entities = {}
  for i = 1, #st.entities do
    local e = sb_cleanEntry(st.entities[i])
    if e.sequenceRef and not e.sequenceAsset then
      e.sequenceAsset = sb_captureSequenceAsset(e.sequenceRef)
    end
    if type(e.action) == 'table' and tostring((e.action or {}).sourceMode or 'pose_db') == 'saved_sequence' then
      if e.action.sequenceRef and not e.action.sequenceAsset then
        e.action.sequenceAsset = sb_captureSequenceAsset(e.action.sequenceRef)
      end
    end
    e.sourceSpawnId = nil
    e.sourceEntityID = nil
    asset.data.entities[#asset.data.entities + 1] = e
  end
  return asset
end

function ScenarioBuilder.SaveScenarioAsset(name, existingId)
  local existing = existingId and AssetRegistry.Get and AssetRegistry.Get(existingId) or nil
  local asset = sb_buildScenarioAsset(name, existing)
  local saved, err
  if existingId and existing then
    saved, err = AssetRegistry.Upsert and AssetRegistry.Upsert(asset)
  else
    saved, err = (AssetRegistry.UpsertNew and AssetRegistry.UpsertNew(asset, name)) or (AssetRegistry.Upsert and AssetRegistry.Upsert(asset))
  end
  if not saved then return nil, err end
  ScenarioBuilder.state.loadedAssetId = saved.id
  return saved, nil
end

function ScenarioBuilder.GetScenarioAssets()
  local items = (AssetRegistry.List and AssetRegistry.List('scenario')) or {}
  table.sort(items, function(a, b) return tostring(a.name or a.id or ''):lower() < tostring(b.name or b.id or ''):lower() end)
  return items
end

function ScenarioBuilder.LoadScenarioAssetIntoBuilder(assetOrId)
  local asset = assetOrId
  if type(assetOrId) ~= 'table' then
    asset = AssetRegistry.Get and AssetRegistry.Get(assetOrId) or nil
  end
  if type(asset) ~= 'table' or tostring(asset.type or '') ~= 'scenario' then
    return false, 'Missing scenario asset'
  end
  local st = ScenarioBuilder.state
  local data = asset.data or {}
  st.name = tostring(asset.name or '')
  st.mode = tostring(data.mode or 'relative')
  st.teleportPlayer = data.teleportPlayer == true
  st.origin = sb_clone(data.origin or sb_currentPlayerOrigin())
  local ps = data.playerState or {}
  st.captureClothing = ps.captureClothing == true
  st.forceEquipCurrentWeapon = ps.forceEquipCurrentWeapon == true
  st.forceEquipWeapon = ps.forceEquipWeapon == true
  st.customWeaponId = tostring(ps.weaponId or '')
  st.captureTimeOfDay = ps.captureTimeOfDay == true
  st.frozenTime = ps.frozenTime == true
  st.captureJohnnyArm = ps.captureJohnnyArm == true
  st.playerState = {
    clothing = sb_clone(ps.clothing or {}),
    currentWeapon = tostring(ps.currentWeapon or ''),
    weaponId = tostring(ps.weaponId or ''),
    hour = tonumber(ps.hour or 12) or 12,
    minute = tonumber(ps.minute or 0) or 0,
    johnnyArmOn = ps.johnnyArmOn == true,
  }
  st.entities = {}
  local entities = type(data.entities) == 'table' and data.entities or {}
  for i = 1, #entities do st.entities[#st.entities + 1] = sb_cleanEntry(entities[i]) end
  st.selectedIndex = (#st.entities > 0) and 1 or 0
  st.loadedAssetId = asset.id
  sb_refreshTimelineFromDraft()
  st.status = 'Loaded scenario: ' .. tostring(asset.name or asset.id)
  return true
end


function ScenarioBuilder.ApplyScenarioAsset(assetOrId)
  local asset = assetOrId
  if type(assetOrId) ~= 'table' then asset = AssetRegistry.Get and AssetRegistry.Get(assetOrId) or nil end
  if type(asset) ~= 'table' or tostring(asset.type or '') ~= 'scenario' then return false, 'Missing scenario asset' end
  local data = asset.data or {}
  local mode = tostring(data.mode or 'relative')
  local origin = sb_clone(data.origin or sb_currentPlayerOrigin())
  if mode == 'relative' then origin = sb_currentPlayerOrigin() end
  if data.teleportPlayer == true and (mode == 'anchored' or mode == 'absolute') then
    sb_teleportPlayer(origin, tonumber(origin.yaw or 0) or 0)
  end
  sb_applyPlayerState(data.playerState or {})
  local entities = type(data.entities) == 'table' and data.entities or {}
  local st = ScenarioBuilder.state
  st.pendingFinalize = {}
  st.runtimeJobs = {}
  st.timeline = st.timeline or { playing = false, startedAt = 0, duration = 0, playhead = 0, events = {} }
  st.timeline.events = sb_buildTimelineEventsFromEntries(entities)
  local maxT = 0
  for i = 1, #(st.timeline.events or {}) do
    maxT = math.max(maxT, tonumber((st.timeline.events[i] or {}).time or 0) or 0)
  end
  st.timeline.duration = maxT
  st.timeline.playhead = 0
  st.timeline.startedAt = os.clock()
  st.timeline.playing = true

  local spawned = 0
  local now = os.clock()
  for i = 1, #entities do
    local e = sb_cleanEntry(entities[i])
    if e.enabled ~= false and e.record ~= '' then
      local spawnPos = nil
      local spawnYaw = 0
      if mode == 'relative' then
        spawnPos = sb_worldFromRelative(origin, e.relPos or {})
        spawnYaw = (tonumber(origin.yaw or 0) or 0) + (tonumber(e.relYaw or 0) or 0)
      else
        spawnPos = sb_clone(e.worldPos or {})
        spawnYaw = tonumber(e.worldYaw or 0) or 0
      end
      st.runtimeJobs[#st.runtimeJobs + 1] = {
        kind = 'spawn',
        dueAt = now + math.max(0, tonumber(e.spawnDelaySeconds or 0) or 0),
        entry = e,
        spawnPos = spawnPos,
        spawnYaw = spawnYaw,
      }
      spawned = spawned + 1
    end
  end
  st.status = string.format('Applied scenario "%s" (%d scheduled).', tostring(asset.name or asset.id or 'Scenario'), spawned)
  return spawned > 0, st.status
end

function ScenarioBuilder.OnUpdate(delta)
  local st = ScenarioBuilder.state
  local now = os.clock()
  if st.timeline and st.timeline.playing == true then
    st.timeline.playhead = math.max(0, now - (tonumber(st.timeline.startedAt or now) or now))
    if st.timeline.playhead >= (tonumber(st.timeline.duration or 0) or 0) + 0.50 and #((st.runtimeJobs or {})) == 0 then
      st.timeline.playing = false
    end
  end

  local jobs = st.runtimeJobs or {}
  for i = #jobs, 1, -1 do
    local job = jobs[i]
    if now >= (tonumber(job.dueAt or 0) or 0) then
      if job.kind == 'spawn' then
        local okSpawn, itemOrErr = false, 'SpawnRecordAtPoint unavailable'
        if SpawnTools and type(SpawnTools.SpawnRecordAtPoint) == 'function' then
          okSpawn, itemOrErr = SpawnTools.SpawnRecordAtPoint(job.entry.record, job.entry.mode, job.spawnPos, 0)
        end
        if okSpawn == true and type(itemOrErr) == 'table' then
          local mode = tostring((job.entry or {}).mode or '')
          local supportsTargetActions = sb_modeSupportsTargetActions(mode)
          local handle = (itemOrErr or {}).handle or (((itemOrErr or {}).entityID and Game.FindEntityByID and Game.FindEntityByID((itemOrErr or {}).entityID)) or nil)
          if supportsTargetActions and (handle or (itemOrErr or {}).entityID) then
            jobs[#jobs + 1] = {
              kind = 'post_spawn',
              dueAt = now + 0.10,
              tries = 0,
              item = itemOrErr,
              entry = job.entry,
              pos = job.spawnPos,
              yaw = job.spawnYaw,
            }
          else
            local entry = sb_cleanEntry(job.entry or {})
            local eid = (itemOrErr or {}).entityID or nil
            local spawnAt = tonumber(entry.spawnDelaySeconds or 0) or 0
            local despawnAt = tonumber(entry.despawnAfterSeconds or 0) or 0
            if despawnAt > 0 then
              jobs[#jobs + 1] = { kind = 'despawn', dueAt = (tonumber(st.timeline.startedAt or now) or now) + spawnAt + despawnAt, handle = handle, entityID = eid }
            end
          end
        end
        table.remove(jobs, i)
      elseif job.kind == 'post_spawn' then
        local handle = ((job.item or {}).handle) or (((job.item or {}).entityID and Game.FindEntityByID and Game.FindEntityByID((job.item or {}).entityID)) or nil)
        if handle then
          local entry = sb_cleanEntry(job.entry or {})
          sb_teleportHandle(handle, job.pos, job.yaw)
          if entry.freezeOnSpawn ~= false and PoseBuilder and type(PoseBuilder.SetFrozen) == 'function' then
            pcall(function() PoseBuilder:SetFrozen(handle, true, false) end)
          end
          local eid = (job.item or {}).entityID or (handle.GetEntityID and handle:GetEntityID()) or nil
          local rid = nil
          pcall(function() if handle.GetRecordID then rid = handle:GetRecordID() end end)
          local spawnAt = tonumber(entry.spawnDelaySeconds or 0) or 0
          local appearanceId = sb_trim(entry.appearance or '')
          if appearanceId ~= '' then
            jobs[#jobs + 1] = { kind = 'appearance_apply', dueAt = (tonumber(st.timeline.startedAt or now) or now) + spawnAt + math.max(0, tonumber(entry.appearanceApplyDelaySeconds or 0) or 0), handle = handle, appearance = appearanceId }
          end
          local action = sb_entryAction(entry)
          if action and sb_modeSupportsTargetActions(entry.mode) then
            jobs[#jobs + 1] = { kind = 'action', dueAt = (tonumber(st.timeline.startedAt or now) or now) + spawnAt + math.max(0, tonumber(entry.actionDelaySeconds or 0) or 0), handle = handle, entityID = eid, action = sb_clone(action) }
          end
          local statusId = sb_trim(entry.statusEffectId or '')
          if statusId ~= '' and sb_modeSupportsTargetActions(entry.mode) then
            jobs[#jobs + 1] = { kind = 'status_apply', dueAt = (tonumber(st.timeline.startedAt or now) or now) + spawnAt + math.max(0, tonumber(entry.statusApplyDelaySeconds or 0) or 0), handle = handle, entityID = eid, recordID = rid, effectId = statusId }
            local removeAt = tonumber(entry.statusRemoveDelaySeconds or 0) or 0
            if removeAt > 0 then
              jobs[#jobs + 1] = { kind = 'status_remove', dueAt = (tonumber(st.timeline.startedAt or now) or now) + spawnAt + removeAt, handle = handle, entityID = eid, effectId = statusId }
            end
          end
          local unfreezeAt = tonumber(entry.unfreezeAfterSeconds or 0) or 0
          if unfreezeAt > 0 then
            jobs[#jobs + 1] = { kind = 'unfreeze', dueAt = (tonumber(st.timeline.startedAt or now) or now) + spawnAt + unfreezeAt, handle = handle, entityID = eid }
          end
          local despawnAt = tonumber(entry.despawnAfterSeconds or 0) or 0
          if despawnAt > 0 then
            jobs[#jobs + 1] = { kind = 'despawn', dueAt = (tonumber(st.timeline.startedAt or now) or now) + spawnAt + despawnAt, handle = handle, entityID = eid }
          end
          table.remove(jobs, i)
        else
          job.tries = (tonumber(job.tries or 0) or 0) + 1
          if job.tries > 40 then
            table.remove(jobs, i)
          else
            job.dueAt = now + 0.10
          end
        end
      elseif job.kind == 'action' then
        if job.handle and PoseBuilder and type(PoseBuilder.SetFrozen) == 'function' then
          pcall(function() PoseBuilder:SetFrozen(job.handle, false, false) end)
        end
        if job.handle and PoseBuilder and type(PoseBuilder.ExecuteActionOnHandle) == 'function' then
          pcall(function() PoseBuilder.ExecuteActionOnHandle(job.action or {}, job.handle) end)
        elseif job.handle and PoseBuilder and type(PoseBuilder.ExecuteSequenceAssetOnHandle) == 'function' and tostring(((job.action or {}).sourceMode or '')) == 'saved_sequence' then
          pcall(function() PoseBuilder.ExecuteSequenceAssetOnHandle((job.action or {}).sequenceAsset or (job.action or {}).sequenceRef, job.handle, true) end)
        end
        table.remove(jobs, i)
      elseif job.kind == 'status_apply' then
        if StatusActions and type(StatusActions.ApplyStatusEffectToEntity) == 'function' then
          pcall(function() StatusActions.ApplyStatusEffectToEntity(job.effectId, job.entityID, job.recordID) end)
        end
        table.remove(jobs, i)
      elseif job.kind == 'status_remove' then
        pcall(function() sb_removeStatusEffectFromEntity(job.effectId, job.entityID) end)
        table.remove(jobs, i)
      elseif job.kind == 'appearance_apply' then
        pcall(function() sb_applyAppearanceToHandle(job.handle, job.appearance) end)
        table.remove(jobs, i)
      elseif job.kind == 'preview_restore_appearance' then
        pcall(function() sb_applyAppearanceToHandle(job.handle, job.appearance) end)
        table.remove(jobs, i)
      elseif job.kind == 'preview_reset_animation' then
        pcall(function() sb_stopPoseOnHandle(job.handle) end)
        table.remove(jobs, i)
      elseif job.kind == 'preview_remove_status' then
        pcall(function() sb_removeStatusEffectFromEntity(job.effectId, job.entityID) end)
        table.remove(jobs, i)
      elseif job.kind == 'rebuild_draft_scene' then
        pcall(function() sb_clearLiveSpawnedScene() end)
        local draft = sb_buildScenarioAsset((ScenarioBuilder.state or {}).name or 'Scenario')
        pcall(function() ScenarioBuilder.ApplyScenarioAsset(draft) end)
        table.remove(jobs, i)
      elseif job.kind == 'unfreeze' then
        if job.handle and PoseBuilder and type(PoseBuilder.SetFrozen) == 'function' then
          pcall(function() PoseBuilder:SetFrozen(job.handle, false, false) end)
        end
        table.remove(jobs, i)
      elseif job.kind == 'despawn' then
        pcall(function() sb_despawnHandle(job.handle, job.entityID) end)
        table.remove(jobs, i)
      else
        table.remove(jobs, i)
      end
    end
  end
end

local function sb_selectedEntry()
  local st = ScenarioBuilder.state
  local idx = tonumber(st.selectedIndex or 0) or 0
  if idx < 1 or idx > #st.entities then return nil end
  return st.entities[idx], idx
end

local function sb_pushSelectedToLive()
  local st = ScenarioBuilder.state
  local entry, idx = sb_selectedEntry()
  if not entry then st.status = 'Select a captured entry first.' return end
  local handle = sb_findLiveHandleForEntry(entry)
  if not handle then st.status = 'Selected entry has no live spawned handle bound.' return end
  sb_teleportHandle(handle, entry.worldPos, entry.worldYaw)
  st.status = 'Applied selected entry transform to live object.'
end

local function sb_pullSelectedFromLive()
  local st = ScenarioBuilder.state
  local entry = sb_selectedEntry()
  if not entry then st.status = 'Select a captured entry first.' return end
  local handle = sb_findLiveHandleForEntry(entry)
  if not handle then st.status = 'Selected entry has no live spawned handle bound.' return end
  entry.worldPos = sb_pos(handle) or entry.worldPos
  entry.worldYaw = sb_yaw(handle)
  entry.relPos = sb_relativeFromWorld(st.origin, entry.worldPos or {})
  entry.relYaw = (tonumber(entry.worldYaw or 0) or 0) - (tonumber(st.origin.yaw or 0) or 0)
  st.status = 'Pulled live transform back into selected entry.'
end

local function sb_snapSelectedToTarget()
  local st = ScenarioBuilder.state
  local entry = sb_selectedEntry()
  if not entry then st.status = 'Select a captured entry first.' return end
  local snap = TargetService.GetSnapshot and TargetService.GetSnapshot(true) or nil
  if not snap or not snap.exists or not snap.handle then st.status = 'No target to snap to.' return end
  entry.worldPos = sb_pos(snap.handle) or entry.worldPos
  entry.worldYaw = sb_yaw(snap.handle)
  entry.relPos = sb_relativeFromWorld(st.origin, entry.worldPos or {})
  entry.relYaw = (tonumber(entry.worldYaw or 0) or 0) - (tonumber(st.origin.yaw or 0) or 0)
  st.status = 'Snapped selected entry to current target transform.'
end

local function sb_removeSelected()
  local st = ScenarioBuilder.state
  local _, idx = sb_selectedEntry()
  if not idx then st.status = 'Select a captured entry first.' return end
  table.remove(st.entities, idx)
  if idx > #st.entities then idx = #st.entities end
  st.selectedIndex = idx > 0 and idx or 0
  st.status = 'Removed captured entry.'
end

local function sb_currentTargetSnapshot(force)
  if TargetControl and type(TargetControl.GetCurrentTargetSnapshot) == 'function' then
    local snap = TargetControl.GetCurrentTargetSnapshot(force == true)
    if snap and snap.exists then return snap end
  end
  return (TargetService and TargetService.GetSnapshot and TargetService.GetSnapshot(force == true)) or nil
end

local function sb_syncTargetForgeFromTarget()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local snap = sb_currentTargetSnapshot(true)
  if not snap or not snap.exists or not snap.handle then
    st.status = 'No current target to load into Target Forge.'
    return nil
  end
  forge.pos = sb_pos(snap.handle) or forge.pos or { x = 0, y = 0, z = 0, w = 1 }
  forge.yaw = sb_yaw(snap.handle)
  forge.appearanceSelected = tostring(snap.appearance or forge.appearanceSelected or '')
  st.targetForge = forge
  return snap
end

local function sb_applyTargetForgeToTarget()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local snap = sb_currentTargetSnapshot(true)
  if not snap or not snap.exists or not snap.handle then
    st.status = 'No current target to move.'
    return false
  end
  local ok, err = sb_teleportHandle(snap.handle, forge.pos or {}, forge.yaw or 0)
  if ok then
    st.status = 'Applied Target Forge transform to current target.'
    return true
  end
  st.status = tostring(err or 'Could not move current target.')
  return false
end

local function sb_nudgeCurrentTarget(dx, dy, dz, dyaw)
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  forge.pos = forge.pos or { x = 0, y = 0, z = 0, w = 1 }
  forge.pos.x = (tonumber(forge.pos.x or 0) or 0) + (tonumber(dx or 0) or 0)
  forge.pos.y = (tonumber(forge.pos.y or 0) or 0) + (tonumber(dy or 0) or 0)
  forge.pos.z = (tonumber(forge.pos.z or 0) or 0) + (tonumber(dz or 0) or 0)
  forge.yaw = (tonumber(forge.yaw or 0) or 0) + (tonumber(dyaw or 0) or 0)
  st.targetForge = forge
  sb_applyTargetForgeToTarget()
end

local function sb_filteredTargetAppearanceOptions()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local options = {}
  if TargetControl and type(TargetControl.GetAppearanceOptionsForCurrentTarget) == 'function' then
    local raw = TargetControl.GetAppearanceOptionsForCurrentTarget(false) or {}
    if type(raw) == 'table' then options = raw end
  end
  local q = string.lower(sb_trim(forge.appearanceSearch or ''))
  if q == '' then return options end
  local out = {}
  for i = 1, #options do
    local name = tostring(options[i] or '')
    if string.find(string.lower(name), q, 1, true) then out[#out + 1] = name end
  end
  return out
end

local function sb_currentTargetPoint()
  local snap = sb_currentTargetSnapshot(true)
  if not snap or not snap.exists or not snap.handle then return nil end
  local pos = sb_pos(snap.handle)
  if not pos then return nil end
  return Vector4.new(pos.x or 0, pos.y or 0, pos.z or 0, 1)
end

local function sb_playerForwardPoint(distance)
  local p = sb_safePlayer()
  if not p then return nil end
  local pos = p.GetWorldPosition and p:GetWorldPosition() or nil
  local fwd = p.GetWorldForward and p:GetWorldForward() or nil
  if not pos or not fwd then return nil end
  local dist = tonumber(distance or 4.0) or 4.0
  return Vector4.new((pos.x or 0) + (fwd.x or 0) * dist, (pos.y or 0) + (fwd.y or 0) * dist, (pos.z or 0) + 0.20, 1)
end

local function sb_quickSpawnPoint()
  local st = ScenarioBuilder.state
  local qs = st.quickSpawn or {}
  local mode = tostring(qs.spawnLocation or 'in_front')
  if mode == 'at_target' then
    return sb_currentTargetPoint()
  elseif mode == 'scenario_origin' then
    return Vector4.new(tonumber(st.origin.x or 0) or 0, tonumber(st.origin.y or 0) or 0, tonumber(st.origin.z or 0) or 0, 1)
  elseif mode == 'custom' then
    local x = tonumber((qs.customXYZ or {}).x or '')
    local y = tonumber((qs.customXYZ or {}).y or '')
    local z = tonumber((qs.customXYZ or {}).z or '')
    if not x or not y or not z then return nil end
    return Vector4.new(x, y, z, 1)
  end
  return sb_playerForwardPoint(4.0)
end

local function sb_drawQuickSpawn()
  local st = ScenarioBuilder.state
  local qs = st.quickSpawn or {}
  ImGui.Separator()
  ImGui.Text('Quick Spawn')
  qs.mode = sb_combo('Spawn Mode##scenario_quick_mode', qs.mode, {
    { id = 'Character', label = 'Character' },
    { id = 'Vehicle', label = 'Vehicle' },
    { id = 'Prop', label = 'Prop' },
    { id = 'FX', label = 'FX' },
    { id = 'Attack', label = 'Attack' },
    { id = 'Entity', label = 'Entity' },
  })
  qs.search = sb_inputText('Search Spawn DB##scenario_quick_search', qs.search or '', 128)
  local records = (SpawnTools and SpawnTools.GetRecordsForMode and SpawnTools.GetRecordsForMode(qs.mode, qs.search)) or {}
  if qs.selectedIndex < 1 then qs.selectedIndex = 1 end
  if qs.selectedIndex > #records then qs.selectedIndex = math.max(1, #records) end
  local preview = records[qs.selectedIndex] or '(none)'
  if ImGui.BeginCombo('Spawn Record##scenario_quick_record', sb_basename(preview)) then
    local maxRows = math.min(#records, 250)
    for i = 1, maxRows do
      local rec = records[i]
      local selected = (qs.selectedIndex == i)
      if ImGui.Selectable(tostring(rec), selected) then qs.selectedIndex = i end
      if selected then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  qs.spawnLocation = sb_combo('Spawn At##scenario_quick_loc', qs.spawnLocation, {
    { id = 'in_front', label = 'In Front of Player' },
    { id = 'at_target', label = 'At Current Target' },
    { id = 'scenario_origin', label = 'Scenario Origin' },
    { id = 'custom', label = 'Custom XYZ' },
  })
  if tostring(qs.spawnLocation or '') == 'custom' then
    ImGui.PushItemWidth(90)
    qs.customXYZ.x = sb_inputText('X##scenario_quick_x', tostring((qs.customXYZ or {}).x or '0'), 18)
    ImGui.SameLine()
    qs.customXYZ.y = sb_inputText('Y##scenario_quick_y', tostring((qs.customXYZ or {}).y or '0'), 18)
    ImGui.SameLine()
    qs.customXYZ.z = sb_inputText('Z##scenario_quick_z', tostring((qs.customXYZ or {}).z or '0'), 18)
    ImGui.PopItemWidth()
  end
  if ImGui.Button('Spawn Selected##scenario_quick_spawn') then
    local rec = records[qs.selectedIndex]
    if not rec or rec == '' then
      st.status = 'No spawn record selected.'
    else
      local point = sb_quickSpawnPoint()
      if not point then
        st.status = 'Could not resolve quick-spawn point.'
      else
        if tostring(qs.mode or '') == 'FX' or tostring(qs.mode or '') == 'Attack' then
          qs.pendingDanger = { record = rec, mode = qs.mode, point = point }
          qs.dangerPopupOpen = true
          if ImGui.OpenPopup then ImGui.OpenPopup('scenario_danger_spawn_confirm') end
        else
          local ok, itemOrErr = sb_spawnScenarioQuickPayload({ record = rec, mode = qs.mode, point = point }, false)
          st.status = tostring(itemOrErr or (ok and ('Spawned ' .. tostring(sb_basename(rec))) or 'Spawn failed.'))
        end
      end
    end
  end
  ImGui.SameLine()
  if ImGui.Button('Capture Spawned Scene Now##scenario_quick_capture') then
    sb_captureSpawnedScene(true)
  end

  local popupOpen = false
  if qs.dangerPopupOpen == true and ImGui.BeginPopupModal then
    local ok1, ok2 = ImGui.BeginPopupModal('scenario_danger_spawn_confirm', true)
    popupOpen = (type(ok1) == 'boolean' and ok1) or (type(ok2) == 'boolean' and ok2) or false
  elseif ImGui.BeginPopup then
    popupOpen = ImGui.BeginPopup('scenario_danger_spawn_confirm')
  end
  if popupOpen then
    ImGui.TextWrapped('Spawning FX and Attacks can kill NPCs, damage vehicles, and may interfere with the editing of your Scenario. If you wish to spawn the FX now you can do so with these two options.')
    ImGui.Spacing()
    if ImGui.Button('Spawn Now##scenario_spawn_danger_now') then
      local ok, msg = sb_spawnScenarioQuickPayload(qs.pendingDanger, false)
      st.status = tostring(msg or (ok and 'Spawned dangerous effect.' or 'Spawn failed.'))
      qs.pendingDanger = nil
      qs.dangerPopupOpen = false
      if ImGui.CloseCurrentPopup then ImGui.CloseCurrentPopup() end
    end
    ImGui.SameLine()
    if ImGui.Button('Spawn Now But Reset Scene##scenario_spawn_danger_reset') then
      local ok, msg = sb_spawnScenarioQuickPayload(qs.pendingDanger, true)
      st.status = tostring(msg or (ok and 'Spawned dangerous effect and reset queued.' or 'Spawn failed.'))
      qs.pendingDanger = nil
      qs.dangerPopupOpen = false
      if ImGui.CloseCurrentPopup then ImGui.CloseCurrentPopup() end
    end
    ImGui.SameLine()
    if ImGui.Button('Cancel##scenario_spawn_danger_cancel') then
      qs.pendingDanger = nil
      qs.dangerPopupOpen = false
      if ImGui.CloseCurrentPopup then ImGui.CloseCurrentPopup() end
    end
    if ImGui.EndPopup then ImGui.EndPopup() end
  end

  st.quickSpawn = qs
end

local function sb_drawTargetForge()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  ImGui.Separator()
  ImGui.Text('Target Forge')
  local snap = sb_currentTargetSnapshot(false)
  if snap and snap.exists then
    ImGui.TextWrapped('Current Target: ' .. tostring(snap.recordId or snap.className or 'Target'))
    ImGui.TextWrapped('Appearance: ' .. tostring(snap.appearance or '-'))
  else
    ImGui.TextDisabled('No current target. Look at something spawnable or manipulable.')
  end
  if ImGui.Button('Pull Current Target##scenario_target_pull') then sb_syncTargetForgeFromTarget() end
  ImGui.SameLine()
  if ImGui.Button('Capture Current Target Into Scenario##scenario_target_capture') then sb_captureCurrentTarget() end
  ImGui.SameLine()
  if ImGui.Button('Snap Selected Entry To Current Target##scenario_target_snap_entry') then sb_snapSelectedToTarget() end

  forge.pos = forge.pos or { x = 0, y = 0, z = 0, w = 1 }
  ImGui.PushItemWidth(95)
  forge.pos.x = tonumber(sb_inputText('Target X##scenario_target_x', string.format('%.2f', tonumber(forge.pos.x or 0) or 0), 24)) or forge.pos.x or 0
  ImGui.SameLine()
  forge.pos.y = tonumber(sb_inputText('Target Y##scenario_target_y', string.format('%.2f', tonumber(forge.pos.y or 0) or 0), 24)) or forge.pos.y or 0
  ImGui.SameLine()
  forge.pos.z = tonumber(sb_inputText('Target Z##scenario_target_z', string.format('%.2f', tonumber(forge.pos.z or 0) or 0), 24)) or forge.pos.z or 0
  ImGui.SameLine()
  forge.yaw = tonumber(sb_inputText('Target Yaw##scenario_target_yaw', string.format('%.2f', tonumber(forge.yaw or 0) or 0), 24)) or forge.yaw or 0
  ImGui.PopItemWidth()
  if ImGui.SmallButton('-X##scenario_target_nx') then sb_nudgeCurrentTarget(-(tonumber(st.liveNudge or 0.10) or 0.10), 0, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+X##scenario_target_px') then sb_nudgeCurrentTarget((tonumber(st.liveNudge or 0.10) or 0.10), 0, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Y##scenario_target_ny') then sb_nudgeCurrentTarget(0, -(tonumber(st.liveNudge or 0.10) or 0.10), 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Y##scenario_target_py') then sb_nudgeCurrentTarget(0, (tonumber(st.liveNudge or 0.10) or 0.10), 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Z##scenario_target_nz') then sb_nudgeCurrentTarget(0, 0, -(tonumber(st.liveNudge or 0.10) or 0.10), 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Z##scenario_target_pz') then sb_nudgeCurrentTarget(0, 0, (tonumber(st.liveNudge or 0.10) or 0.10), 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Yaw##scenario_target_nyaw') then sb_nudgeCurrentTarget(0, 0, 0, -(tonumber(st.yawNudge or 15) or 15)) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Yaw##scenario_target_pyaw') then sb_nudgeCurrentTarget(0, 0, 0, (tonumber(st.yawNudge or 15) or 15)) end
  if ImGui.Button('Apply Forge Transform To Current Target##scenario_target_apply') then sb_applyTargetForgeToTarget() end

  ImGui.Text('Animation')
  if PoseBuilder and type(PoseBuilder.DrawActionSetup) == 'function' then
    PoseBuilder.DrawActionSetup(forge.action, 'target', 'scenario_targetforge')
    if ImGui.Button('Apply Animation To Current Target##scenario_target_apply_anim') then
      local ok, msg = PoseBuilder.ExecuteAction and PoseBuilder.ExecuteAction(forge.action, 'target')
      st.status = tostring(msg or (ok and 'Applied animation to current target.' or 'Animation apply failed.'))
    end
  else
    ImGui.TextDisabled('Pose Builder runtime unavailable.')
  end

  ImGui.Text('Appearance')
  forge.appearanceSearch = sb_inputText('Appearance Search##scenario_target_app_search', forge.appearanceSearch or '', 128)
  local appOptions = sb_filteredTargetAppearanceOptions()
  local appPreview = forge.appearanceSelected ~= '' and forge.appearanceSelected or '(none)'
  if ImGui.BeginCombo('Appearance##scenario_target_app_combo', appPreview) then
    for i = 1, #appOptions do
      local opt = tostring(appOptions[i])
      local selected = (tostring(forge.appearanceSelected or '') == opt)
      if ImGui.Selectable(opt, selected) then forge.appearanceSelected = opt end
      if selected then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  if ImGui.Button('Apply Appearance##scenario_target_app_apply') then
    local ok, msg = TargetControl and TargetControl.ApplyAppearanceToCurrentTarget and TargetControl.ApplyAppearanceToCurrentTarget(forge.appearanceSelected or '')
    st.status = tostring(msg or (ok and 'Applied appearance.' or 'Appearance apply failed.'))
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Prev Appearance##scenario_target_app_prev') then
    local ok, msg = TargetControl and TargetControl.CycleAppearance and TargetControl.CycleAppearance(-1)
    st.status = tostring(msg or (ok and 'Cycled appearance.' or 'Appearance cycle failed.'))
    sb_syncTargetForgeFromTarget()
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Next Appearance##scenario_target_app_next') then
    local ok, msg = TargetControl and TargetControl.CycleAppearance and TargetControl.CycleAppearance(1)
    st.status = tostring(msg or (ok and 'Cycled appearance.' or 'Appearance cycle failed.'))
    sb_syncTargetForgeFromTarget()
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Reset Appearance##scenario_target_app_reset') then
    local ok, msg = TargetControl and TargetControl.RestoreOriginalAppearance and TargetControl.RestoreOriginalAppearance()
    st.status = tostring(msg or (ok and 'Restored original appearance.' or 'Reset appearance failed.'))
    sb_syncTargetForgeFromTarget()
  end

  ImGui.Text('Status / Tether / Tools')
  forge.statusSearch = sb_inputText('Status Search##scenario_target_status_search', forge.statusSearch or '', 128)
  local statusIds = (TargetControl and TargetControl.GetStatusEffectIds and TargetControl.GetStatusEffectIds(forge.statusSearch or '')) or {}
  local statusPreview = tostring(forge.statusSelected or '(none)')
  if ImGui.BeginCombo('Status Effect##scenario_target_status_combo', statusPreview) then
    for i = 1, math.min(#statusIds, 250) do
      local id = tostring(statusIds[i])
      local selected = (tostring(forge.statusSelected or '') == id)
      if ImGui.Selectable(id, selected) then forge.statusSelected = id end
      if selected then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  forge.manualStatusId = sb_inputText('Manual Status ID##scenario_target_status_manual', forge.manualStatusId or '', 128)
  if ImGui.Button('Apply Status Effect##scenario_target_status_apply') then
    local id = sb_trim(forge.manualStatusId or '')
    if id == '' then id = sb_trim(forge.statusSelected or '') end
    local ok, msg = TargetControl and TargetControl.ApplyStatusEffectToCurrentTarget and TargetControl.ApplyStatusEffectToCurrentTarget(id)
    st.status = tostring(msg or (ok and 'Applied status effect.' or 'Status effect apply failed.'))
  end
  ImGui.SameLine()
  if (TargetControl and TargetControl.IsTetherActive and TargetControl.IsTetherActive()) then
    if ImGui.SmallButton('Stop Tether##scenario_target_stop_tether') then
      local ok, msg = TargetControl.StopTether()
      st.status = tostring(msg or (ok and 'Stopped tether.' or 'Stop tether failed.'))
    end
  else
    if ImGui.SmallButton('Tether To Player##scenario_target_start_tether') then
      local ok, msg = TargetControl and TargetControl.StartTetherToPlayer and TargetControl.StartTetherToPlayer()
      st.status = tostring(msg or (ok and 'Started tether.' or 'Tether failed.'))
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Despawn Current Target##scenario_target_despawn') then
    local ok, msg = TargetControl and TargetControl.DespawnCurrentTarget and TargetControl.DespawnCurrentTarget()
    st.status = tostring(msg or (ok and 'Despawned current target.' or 'Despawn failed.'))
  end
  st.targetForge = forge
end

local function sb_drawPlayerState()
  local st = ScenarioBuilder.state
  ImGui.Separator()
  ImGui.Text('Player State')
  st.captureClothing = sb_checkbox('Capture Equipped Clothing', st.captureClothing)
  ImGui.SameLine()
  if ImGui.SmallButton('Capture Clothing Now') then sb_captureClothing() end
  st.forceEquipCurrentWeapon = sb_checkbox('Force Equip Current Weapon', st.forceEquipCurrentWeapon)
  ImGui.SameLine()
  if ImGui.SmallButton('Capture Current Weapon') then sb_captureCurrentWeapon() end
  if tostring(st.playerState.currentWeapon or '') ~= '' then
    ImGui.TextWrapped('Captured Weapon: ' .. tostring(st.playerState.currentWeapon or ''))
  end
  st.forceEquipWeapon = sb_checkbox('Force Equip Weapon', st.forceEquipWeapon)
  if st.forceEquipWeapon then
    st.customWeaponId = sb_inputText('Weapon ID##scenario_weapon_id', st.customWeaponId or '', 160)
  end
  st.captureTimeOfDay = sb_checkbox('Capture Time of Day', st.captureTimeOfDay)
  ImGui.SameLine()
  if ImGui.SmallButton('Capture Time Now') then sb_tryCaptureTimeOfDay() end
  ImGui.PushItemWidth(80)
  st.playerState.hour = tonumber(sb_inputText('Hour##scenario_hour', tostring(st.playerState.hour or 12), 8)) or st.playerState.hour or 12
  ImGui.SameLine()
  st.playerState.minute = tonumber(sb_inputText('Minute##scenario_minute', tostring(st.playerState.minute or 0), 8)) or st.playerState.minute or 0
  ImGui.PopItemWidth()
  st.frozenTime = sb_checkbox('Freeze Time', st.frozenTime)
  st.captureJohnnyArm = sb_checkbox('Capture Johnny Arm State', st.captureJohnnyArm)
  ImGui.SameLine()
  if ImGui.SmallButton('Capture Johnny Arm') then sb_captureJohnnyArm() end
  if st.captureJohnnyArm then
    ImGui.SameLine()
    ImGui.TextDisabled((st.playerState.johnnyArmOn and 'ON') or 'OFF')
  end
end

local function sb_drawTopBar()
  local st = ScenarioBuilder.state
  st.name = sb_inputText('Scenario Name', st.name or '', 128)
  st.mode = sb_combo('Scenario Mode', st.mode, {
    { id = 'relative', label = 'Relative To Player' },
    { id = 'absolute', label = 'Absolute World XYZ' },
    { id = 'anchored', label = 'Anchored / Optional Teleport' },
  })
  st.teleportPlayer = sb_checkbox('Teleport Player To Scenario Origin', st.teleportPlayer)
  if ImGui.Button('Capture Spawned Scene') then sb_captureSpawnedScene(false) end
  ImGui.SameLine()
  if ImGui.Button('Append Spawned Scene') then sb_captureSpawnedScene(true) end
  ImGui.SameLine()
  if ImGui.Button('Capture Current Target') then sb_captureCurrentTarget() end
  ImGui.SameLine()
  if ImGui.Button('Set Origin To Player') then st.origin = sb_currentPlayerOrigin(); sb_recomputeRelativeForAll(); st.status = 'Scenario origin updated from player.' end
  ImGui.SameLine()
  if ImGui.Button('Clear Scenario') then st.entities = {}; st.selectedIndex = 0; sb_refreshTimelineFromDraft(); st.status = 'Cleared current scenario draft.' end

  ImGui.PushItemWidth(90)
  st.origin.x = tonumber(sb_inputText('Origin X##scenario_origin_x', string.format('%.2f', tonumber(st.origin.x or 0) or 0), 24)) or st.origin.x or 0
  ImGui.SameLine()
  st.origin.y = tonumber(sb_inputText('Origin Y##scenario_origin_y', string.format('%.2f', tonumber(st.origin.y or 0) or 0), 24)) or st.origin.y or 0
  ImGui.SameLine()
  st.origin.z = tonumber(sb_inputText('Origin Z##scenario_origin_z', string.format('%.2f', tonumber(st.origin.z or 0) or 0), 24)) or st.origin.z or 0
  ImGui.SameLine()
  st.origin.yaw = tonumber(sb_inputText('Origin Yaw##scenario_origin_yaw', string.format('%.2f', tonumber(st.origin.yaw or 0) or 0), 24)) or st.origin.yaw or 0
  ImGui.PopItemWidth()
  if ImGui.SmallButton('Recompute Relative Offsets') then sb_recomputeRelativeForAll(); sb_refreshTimelineFromDraft(); st.status = 'Recomputed relative offsets from origin.' end
  if ImGui.SmallButton('Apply Draft') then
    local ok, msg = ScenarioBuilder.ApplyScenarioAsset(sb_buildScenarioAsset(st.name or 'Scenario'))
    st.status = tostring(msg or (ok and 'Applied scenario draft.' or 'Scenario apply failed.'))
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Save New') then
    local saved, err = ScenarioBuilder.SaveScenarioAsset(st.name or 'Scenario', nil)
    st.status = saved and ('Saved scenario: ' .. tostring(saved.name or saved.id)) or ('Save failed: ' .. tostring(err))
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Update Loaded') then
    if st.loadedAssetId then
      local saved, err = ScenarioBuilder.SaveScenarioAsset(st.name or 'Scenario', st.loadedAssetId)
      st.status = saved and ('Updated scenario: ' .. tostring(saved.name or saved.id)) or ('Update failed: ' .. tostring(err))
    else
      st.status = 'No loaded scenario to update.'
    end
  end
end

local function sb_drawEntityList()
  local st = ScenarioBuilder.state
  ImGui.BeginChild('scenario_entities', 300, 340, true)
  for i = 1, #st.entities do
    local e = st.entities[i]
    local label = string.format('[%s] %s##scenario_entity_%d', (e.enabled ~= false and 'ON' or 'OFF'), tostring(e.label or e.record or ('Entry ' .. tostring(i))), i)
    if ImGui.Selectable(label, st.selectedIndex == i) then st.selectedIndex = i end
  end
  ImGui.EndChild()
end

local function sb_drawSelectedEditor()
  local st = ScenarioBuilder.state
  local entry = sb_selectedEntry()
  ImGui.BeginGroup()
  if not entry then
    ImGui.TextDisabled('Select a captured entry to edit it.')
    ImGui.EndGroup()
    return
  end
  entry.enabled = sb_checkbox('Enabled##scenario_entry_enabled', entry.enabled ~= false)
  entry.label = sb_inputText('Label##scenario_entry_label', entry.label or '', 128)
  ImGui.TextWrapped('Record: ' .. tostring(entry.record or ''))
  ImGui.TextWrapped('Mode: ' .. tostring(entry.mode or ''))
  ImGui.PushItemWidth(100)
  entry.worldPos.x = tonumber(sb_inputText('World X##scenario_world_x', string.format('%.2f', tonumber((entry.worldPos or {}).x or 0) or 0), 24)) or entry.worldPos.x
  ImGui.SameLine()
  entry.worldPos.y = tonumber(sb_inputText('World Y##scenario_world_y', string.format('%.2f', tonumber((entry.worldPos or {}).y or 0) or 0), 24)) or entry.worldPos.y
  ImGui.SameLine()
  entry.worldPos.z = tonumber(sb_inputText('World Z##scenario_world_z', string.format('%.2f', tonumber((entry.worldPos or {}).z or 0) or 0), 24)) or entry.worldPos.z
  entry.worldYaw = tonumber(sb_inputText('World Yaw##scenario_world_yaw', string.format('%.2f', tonumber(entry.worldYaw or 0) or 0), 24)) or entry.worldYaw
  ImGui.Separator()
  entry.relPos.x = tonumber(sb_inputText('Relative X##scenario_rel_x', string.format('%.2f', tonumber((entry.relPos or {}).x or 0) or 0), 24)) or entry.relPos.x
  ImGui.SameLine()
  entry.relPos.y = tonumber(sb_inputText('Relative Y##scenario_rel_y', string.format('%.2f', tonumber((entry.relPos or {}).y or 0) or 0), 24)) or entry.relPos.y
  ImGui.SameLine()
  entry.relPos.z = tonumber(sb_inputText('Relative Z##scenario_rel_z', string.format('%.2f', tonumber((entry.relPos or {}).z or 0) or 0), 24)) or entry.relPos.z
  entry.relYaw = tonumber(sb_inputText('Relative Yaw##scenario_rel_yaw', string.format('%.2f', tonumber(entry.relYaw or 0) or 0), 24)) or entry.relYaw
  ImGui.PopItemWidth()


ImGui.Separator()
ImGui.Text('Scenario Timing')
entry.spawnDelaySeconds = sb_inputNumber('Spawn after seconds##scenario_spawn_delay', entry.spawnDelaySeconds or 0, 18) or 0
ImGui.SameLine()
entry.unfreezeAfterSeconds = sb_inputNumber('Unfreeze after seconds##scenario_unfreeze_after', entry.unfreezeAfterSeconds or 0, 18) or 0
ImGui.SameLine()
entry.despawnAfterSeconds = sb_inputNumber('Despawn after seconds##scenario_despawn_after', entry.despawnAfterSeconds or 0, 18) or 0
entry.freezeOnSpawn = sb_checkbox('Freeze on spawn', entry.freezeOnSpawn ~= false)

ImGui.Separator()
ImGui.Text('Appearance Event')
entry.appearance = sb_inputText('Appearance##scenario_entry_appearance', entry.appearance or '', 128)
ImGui.SameLine()
if ImGui.SmallButton('Use selected target appearance##scenario_use_selected_appearance') then
  entry.appearance = tostring(((st.targetForge or {}).appearanceSelected) or '')
end
entry.appearanceApplyDelaySeconds = sb_inputNumber('Apply appearance after seconds##scenario_appearance_apply_delay', entry.appearanceApplyDelaySeconds or 0, 18) or 0

ImGui.Separator()
ImGui.Text('Animation Event')
entry.actionDelaySeconds = sb_inputNumber('Animation fires after seconds##scenario_action_delay', entry.actionDelaySeconds or 0, 18) or 0
if ImGui.SmallButton('Use current animation setup##scenario_use_forge_action') then
  if sb_copyForgeActionIntoEntry(entry) then st.status = 'Copied current animation setup into selected entry.' end
end
ImGui.SameLine()
if ImGui.SmallButton('Clear animation event##scenario_clear_action') then
  entry.action = nil
  entry.sequenceRef = nil
  entry.sequenceAsset = nil
end
entry.action = type(entry.action) == 'table' and entry.action or sb_entryAction(entry) or { sourceMode = 'pose_db', rig = 'Man Average', poseSearch = '', poseName = '', instant = true, freezeAfterSeconds = 0, stopAfterSeconds = 0 }
if PoseBuilder and type(PoseBuilder.DrawActionSetup) == 'function' then
  PoseBuilder.DrawActionSetup(entry.action, 'target', 'scenario_entry_action_' .. tostring(idx or 0))
  if tostring((entry.action or {}).sourceMode or 'pose_db') == 'saved_sequence' then
    entry.sequenceRef = entry.action.sequenceRef
    entry.sequenceAsset = type(entry.action.sequenceAsset) == 'table' and sb_clone(entry.action.sequenceAsset) or sb_captureSequenceAsset(entry.sequenceRef)
  end
else
  ImGui.TextDisabled('Pose Builder runtime unavailable.')
end

ImGui.Separator()
ImGui.Text('Status Effect Event')
entry.statusEffectId = sb_inputText('Status Effect ID##scenario_entry_status', entry.statusEffectId or '', 128)
ImGui.SameLine()
if ImGui.SmallButton('Use selected target status##scenario_use_selected_status') then
  local id = sb_trim(((st.targetForge or {}).manualStatusId or ''))
  if id == '' then id = sb_trim(((st.targetForge or {}).statusSelected or '')) end
  entry.statusEffectId = id
end
entry.statusApplyDelaySeconds = sb_inputNumber('Apply status after seconds##scenario_status_apply_delay', entry.statusApplyDelaySeconds or 0, 18) or 0
ImGui.SameLine()
entry.statusRemoveDelaySeconds = sb_inputNumber('Remove status after seconds##scenario_status_remove_delay', entry.statusRemoveDelaySeconds or 0, 18) or 0

sb_refreshTimelineFromDraft()
ImGui.TextDisabled('Target-tab preview buttons are temporary. Use the copy buttons above when you want the scenario to keep the animation, appearance, or status setup.')

ImGui.Text('Forge Tools')
  ImGui.PushItemWidth(90)
  st.liveNudge = tonumber(sb_inputText('Move Step##scenario_move_step', tostring(st.liveNudge or 0.10), 24)) or st.liveNudge or 0.10
  ImGui.SameLine()
  st.yawNudge = tonumber(sb_inputText('Yaw Step##scenario_yaw_step', tostring(st.yawNudge or 15), 24)) or st.yawNudge or 15
  ImGui.PopItemWidth()

  if ImGui.SmallButton('-X##scenario_nx') then entry.worldPos.x = (tonumber(entry.worldPos.x or 0) or 0) - (tonumber(st.liveNudge or 0.10) or 0.10) end
  ImGui.SameLine()
  if ImGui.SmallButton('+X##scenario_px') then entry.worldPos.x = (tonumber(entry.worldPos.x or 0) or 0) + (tonumber(st.liveNudge or 0.10) or 0.10) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Y##scenario_ny') then entry.worldPos.y = (tonumber(entry.worldPos.y or 0) or 0) - (tonumber(st.liveNudge or 0.10) or 0.10) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Y##scenario_py') then entry.worldPos.y = (tonumber(entry.worldPos.y or 0) or 0) + (tonumber(st.liveNudge or 0.10) or 0.10) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Z##scenario_nz') then entry.worldPos.z = (tonumber(entry.worldPos.z or 0) or 0) - (tonumber(st.liveNudge or 0.10) or 0.10) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Z##scenario_pz') then entry.worldPos.z = (tonumber(entry.worldPos.z or 0) or 0) + (tonumber(st.liveNudge or 0.10) or 0.10) end
  if ImGui.SmallButton('-Yaw##scenario_nyaw') then entry.worldYaw = (tonumber(entry.worldYaw or 0) or 0) - (tonumber(st.yawNudge or 15) or 15) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Yaw##scenario_pyaw') then entry.worldYaw = (tonumber(entry.worldYaw or 0) or 0) + (tonumber(st.yawNudge or 15) or 15) end

  if ImGui.Button('Apply To Live Spawn') then sb_pushSelectedToLive() end
  ImGui.SameLine()
  if ImGui.Button('Pull From Live Spawn') then sb_pullSelectedFromLive() end
  ImGui.SameLine()
  if ImGui.Button('Snap To Current Target') then sb_snapSelectedToTarget() end
  ImGui.SameLine()
  if ImGui.Button('Remove Entry') then sb_removeSelected() end
  ImGui.EndGroup()
end

local function sb_drawSavedScenarios()
  local st = ScenarioBuilder.state
  local items = ScenarioBuilder.GetScenarioAssets()
  ImGui.Separator()
  ImGui.Text('Saved Scenarios')
  if #items == 0 then
    ImGui.TextDisabled('No saved scenarios yet.')
    return
  end
  if ImGui.BeginTable('scenario_saved_tbl', 5, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn('Scenario')
    ImGui.TableSetupColumn('Mode', ImGuiTableColumnFlags.WidthFixed, 90)
    ImGui.TableSetupColumn('Entities', ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableSetupColumn('Load / Run', ImGuiTableColumnFlags.WidthFixed, 130)
    ImGui.TableSetupColumn('Delete', ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableHeadersRow()
    for i = 1, #items do
      local a = items[i]
      local data = a.data or {}
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(tostring(a.name or a.id))
      ImGui.TableSetColumnIndex(1)
      ImGui.TextUnformatted(tostring(data.mode or 'relative'))
      ImGui.TableSetColumnIndex(2)
      ImGui.TextUnformatted(tostring(#(data.entities or {})))
      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton('Load##scenario_load_' .. tostring(a.id)) then ScenarioBuilder.LoadScenarioAssetIntoBuilder(a.id) end
      ImGui.SameLine()
      if ImGui.SmallButton('Run##scenario_run_' .. tostring(a.id)) then
        local ok, msg = ScenarioBuilder.ApplyScenarioAsset(a.id)
        st.status = tostring(msg or (ok and 'Applied scenario.' or 'Apply failed.'))
      end
      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton('Delete##scenario_delete_' .. tostring(a.id)) then AssetRegistry.Delete(a.id) end
    end
    ImGui.EndTable()
  end
end

local function sb_drawHomeTab()
  local st = ScenarioBuilder.state
  sb_drawTopBar()
  ImGui.Separator()
  ImGui.Text('Scenario Summary')
  ImGui.BulletText('Captured Entries: ' .. tostring(#(st.entities or {})))
  ImGui.BulletText('Mode: ' .. tostring(st.mode or 'relative'))
  ImGui.BulletText('Loaded Asset: ' .. tostring(st.loadedAssetId or '(draft only)'))
  local entry = sb_selectedEntry()
  ImGui.BulletText('Selected Entry: ' .. tostring((entry and (entry.label or entry.record)) or '(none)'))
  ImGui.TextWrapped('Home keeps the scenario-specific controls small. Use Scene for forge editing, Animations for pose tools, Spawn for quick spawning, Target for live target manipulation, Player for captured player state, Timeline for timed events and preview, and Saved for loading older scenarios.')
end

local function sb_drawSceneTab()
  local ww = ImGui.GetWindowWidth and ImGui.GetWindowWidth() or 960
  ImGui.TextDisabled('Captured entries and forge editing.')
  if ww < 1280 then
    sb_drawEntityList()
    ImGui.Separator()
    sb_drawSelectedEditor()
  else
    ImGui.Columns(2, 'scenario_scene_cols', false)
    sb_drawEntityList()
    ImGui.NextColumn()
    sb_drawSelectedEditor()
    ImGui.Columns(1)
  end
end

local function sb_drawAnimationTab()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local snap = sb_currentTargetSnapshot(false)
  ImGui.Text('Current Target Animation')
  if snap and snap.exists then
    ImGui.TextWrapped('Target: ' .. tostring(snap.recordId or snap.className or 'Target'))
    ImGui.TextWrapped('Appearance: ' .. tostring(snap.appearance or '-'))
  else
    ImGui.TextDisabled('No current target. Look at something before applying animation.')
  end
  if ImGui.SmallButton('Pull Current Target##scenario_anim_pull') then sb_syncTargetForgeFromTarget() end
  ImGui.SameLine()
  if ImGui.SmallButton('Capture Current Target Into Scenario##scenario_anim_capture') then sb_captureCurrentTarget() end
  ImGui.SameLine()
  if ImGui.SmallButton('Snap Selected Entry To Current Target##scenario_anim_snap') then sb_snapSelectedToTarget() end
  ImGui.Separator()
  if PoseBuilder and type(PoseBuilder.DrawActionSetup) == 'function' then
    PoseBuilder.DrawActionSetup(forge.action, 'target', 'scenario_animation_tab')
    forge.previewResetAnimation = sb_checkbox('Reset preview animation after seconds', forge.previewResetAnimation == true)
    ImGui.SameLine()
    forge.previewResetAnimationAfter = sb_inputNumber('Preview reset seconds##scenario_animation_preview_reset', forge.previewResetAnimationAfter or 2.0, 18) or 2.0
    if ImGui.Button('Apply Animation Preview##scenario_animation_apply') then
      local ok, msg = PoseBuilder.ExecuteAction and PoseBuilder.ExecuteAction(forge.action, 'target')
      st.status = tostring(msg or (ok and 'Applied animation preview to current target.' or 'Animation apply failed.'))
      if ok and forge.previewResetAnimation == true then
        local handle = TargetControl and TargetControl.GetCurrentTargetHandle and TargetControl.GetCurrentTargetHandle(true) or nil
        if handle then
          sb_scheduleJob({ kind = 'preview_reset_animation', dueAt = os.clock() + math.max(0.05, tonumber(forge.previewResetAnimationAfter or 2.0) or 2.0), handle = handle })
        end
      end
    end
    ImGui.SameLine()
    if ImGui.SmallButton('Copy Animation To Selected Entry##scenario_animation_copy_entry') then
      local entry = sb_selectedEntry()
      if entry and sb_copyForgeActionIntoEntry(entry) then
        sb_refreshTimelineFromDraft()
        st.status = 'Copied current animation setup into selected entry.'
      else
        st.status = 'Select a captured entry first.'
      end
    end
    ImGui.TextDisabled('Preview buttons do not change the scenario asset until you copy the setup into a selected entry.')
  else
    ImGui.TextDisabled('Pose Builder runtime unavailable.')
  end
  st.targetForge = forge
end

local function sb_drawTargetTransformPane()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local snap = sb_currentTargetSnapshot(false)
  ImGui.Text('Live Target Transform')
  if snap and snap.exists then
    ImGui.TextWrapped('Current Target: ' .. tostring(snap.recordId or snap.className or 'Target'))
    ImGui.TextWrapped('Appearance: ' .. tostring(snap.appearance or '-'))
  else
    ImGui.TextDisabled('No current target. Look at something spawnable or manipulable.')
  end
  if ImGui.Button('Pull Current Target##scenario_target_pull2') then sb_syncTargetForgeFromTarget() end
  ImGui.SameLine()
  if ImGui.Button('Capture Current Target Into Scenario##scenario_target_capture2') then sb_captureCurrentTarget() end
  ImGui.SameLine()
  if ImGui.Button('Snap Selected Entry To Current Target##scenario_target_snap_entry2') then sb_snapSelectedToTarget() end

  forge.pos = forge.pos or { x = 0, y = 0, z = 0, w = 1 }
  ImGui.PushItemWidth(95)
  forge.pos.x = tonumber(sb_inputText('Target X##scenario_target_x2', string.format('%.2f', tonumber(forge.pos.x or 0) or 0), 24)) or forge.pos.x or 0
  ImGui.SameLine()
  forge.pos.y = tonumber(sb_inputText('Target Y##scenario_target_y2', string.format('%.2f', tonumber(forge.pos.y or 0) or 0), 24)) or forge.pos.y or 0
  ImGui.SameLine()
  forge.pos.z = tonumber(sb_inputText('Target Z##scenario_target_z2', string.format('%.2f', tonumber(forge.pos.z or 0) or 0), 24)) or forge.pos.z or 0
  ImGui.SameLine()
  forge.yaw = tonumber(sb_inputText('Target Yaw##scenario_target_yaw2', string.format('%.2f', tonumber(forge.yaw or 0) or 0), 24)) or forge.yaw or 0
  ImGui.PopItemWidth()

  ImGui.PushItemWidth(90)
  st.liveNudge = tonumber(sb_inputText('Move Step##scenario_target_move_step2', tostring(st.liveNudge or 0.10), 24)) or st.liveNudge or 0.10
  ImGui.SameLine()
  st.yawNudge = tonumber(sb_inputText('Yaw Step##scenario_target_yaw_step2', tostring(st.yawNudge or 15), 24)) or st.yawNudge or 15
  ImGui.PopItemWidth()

  if ImGui.SmallButton('-X##scenario_target_nx2') then sb_nudgeCurrentTarget(-(tonumber(st.liveNudge or 0.10) or 0.10), 0, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+X##scenario_target_px2') then sb_nudgeCurrentTarget((tonumber(st.liveNudge or 0.10) or 0.10), 0, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Y##scenario_target_ny2') then sb_nudgeCurrentTarget(0, -(tonumber(st.liveNudge or 0.10) or 0.10), 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Y##scenario_target_py2') then sb_nudgeCurrentTarget(0, (tonumber(st.liveNudge or 0.10) or 0.10), 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Z##scenario_target_nz2') then sb_nudgeCurrentTarget(0, 0, -(tonumber(st.liveNudge or 0.10) or 0.10), 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Z##scenario_target_pz2') then sb_nudgeCurrentTarget(0, 0, (tonumber(st.liveNudge or 0.10) or 0.10), 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Yaw##scenario_target_nyaw2') then sb_nudgeCurrentTarget(0, 0, 0, -(tonumber(st.yawNudge or 15) or 15)) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Yaw##scenario_target_pyaw2') then sb_nudgeCurrentTarget(0, 0, 0, (tonumber(st.yawNudge or 15) or 15)) end
  if ImGui.Button('Apply Forge Transform To Current Target##scenario_target_apply2') then sb_applyTargetForgeToTarget() end
  st.targetForge = forge
end

local function sb_drawTargetAppearancePane()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  ImGui.Text('Appearance')
  forge.appearanceSearch = sb_inputText('Appearance Search##scenario_target_app_search2', forge.appearanceSearch or '', 128)
  local appOptions = sb_filteredTargetAppearanceOptions()
  local appPreview = forge.appearanceSelected ~= '' and forge.appearanceSelected or '(none)'
  if ImGui.BeginCombo('Appearance##scenario_target_app_combo2', appPreview) then
    for i = 1, #appOptions do
      local opt = tostring(appOptions[i])
      local selected = (tostring(forge.appearanceSelected or '') == opt)
      if ImGui.Selectable(opt, selected) then forge.appearanceSelected = opt end
      if selected then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  forge.previewRestoreAppearance = sb_checkbox('Restore preview appearance after seconds', forge.previewRestoreAppearance == true)
  ImGui.SameLine()
  forge.previewRestoreAppearanceAfter = sb_inputNumber('Appearance reset seconds##scenario_target_app_preview_reset', forge.previewRestoreAppearanceAfter or 2.0, 18) or 2.0
  if ImGui.Button('Apply Appearance Preview##scenario_target_app_apply2') then
    local snap2 = sb_currentTargetSnapshot(true)
    local originalAppearance = snap2 and tostring(snap2.appearance or '') or ''
    local handle = snap2 and snap2.handle or nil
    local ok, msg = TargetControl and TargetControl.ApplyAppearanceToCurrentTarget and TargetControl.ApplyAppearanceToCurrentTarget(forge.appearanceSelected or '')
    st.status = tostring(msg or (ok and 'Applied appearance preview.' or 'Appearance apply failed.'))
    if ok and forge.previewRestoreAppearance == true and handle and originalAppearance ~= '' then
      sb_scheduleJob({ kind = 'preview_restore_appearance', dueAt = os.clock() + math.max(0.05, tonumber(forge.previewRestoreAppearanceAfter or 2.0) or 2.0), handle = handle, appearance = originalAppearance })
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Copy Appearance To Selected Entry##scenario_target_app_copy2') then
    local entry = sb_selectedEntry()
    if entry then
      entry.appearance = tostring(forge.appearanceSelected or '')
      sb_refreshTimelineFromDraft()
      st.status = 'Copied selected appearance into selected entry.'
    else
      st.status = 'Select a captured entry first.'
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Prev Appearance##scenario_target_app_prev2') then
    local ok, msg = TargetControl and TargetControl.CycleAppearance and TargetControl.CycleAppearance(-1)
    st.status = tostring(msg or (ok and 'Cycled appearance.' or 'Appearance cycle failed.'))
    sb_syncTargetForgeFromTarget()
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Next Appearance##scenario_target_app_next2') then
    local ok, msg = TargetControl and TargetControl.CycleAppearance and TargetControl.CycleAppearance(1)
    st.status = tostring(msg or (ok and 'Cycled appearance.' or 'Appearance cycle failed.'))
    sb_syncTargetForgeFromTarget()
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Reset Appearance##scenario_target_app_reset2') then
    local ok, msg = TargetControl and TargetControl.RestoreOriginalAppearance and TargetControl.RestoreOriginalAppearance()
    st.status = tostring(msg or (ok and 'Restored original appearance.' or 'Reset appearance failed.'))
    sb_syncTargetForgeFromTarget()
  end
  st.targetForge = forge
end

local function sb_drawTargetStatusPane()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  ImGui.Text('Status / Tether / Tools')
  forge.statusSearch = sb_inputText('Status Search##scenario_target_status_search2', forge.statusSearch or '', 128)
  local statusIds = (TargetControl and TargetControl.GetStatusEffectIds and TargetControl.GetStatusEffectIds(forge.statusSearch or '')) or {}
  local statusPreview = tostring(forge.statusSelected or '(none)')
  if ImGui.BeginCombo('Status Effect##scenario_target_status_combo2', statusPreview) then
    for i = 1, math.min(#statusIds, 250) do
      local id = tostring(statusIds[i])
      local selected = (tostring(forge.statusSelected or '') == id)
      if ImGui.Selectable(id, selected) then forge.statusSelected = id end
      if selected then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  forge.manualStatusId = sb_inputText('Manual Status ID##scenario_target_status_manual2', forge.manualStatusId or '', 128)
  forge.previewRemoveStatus = sb_checkbox('Remove preview status after seconds', forge.previewRemoveStatus == true)
  ImGui.SameLine()
  forge.previewRemoveStatusAfter = sb_inputNumber('Status remove seconds##scenario_target_status_preview_reset', forge.previewRemoveStatusAfter or 2.0, 18) or 2.0
  if ImGui.Button('Apply Status Preview##scenario_target_status_apply2') then
    local id = sb_trim(forge.manualStatusId or '')
    if id == '' then id = sb_trim(forge.statusSelected or '') end
    local snap2 = sb_currentTargetSnapshot(true)
    local ok, msg = TargetControl and TargetControl.ApplyStatusEffectToCurrentTarget and TargetControl.ApplyStatusEffectToCurrentTarget(id)
    st.status = tostring(msg or (ok and 'Applied status preview.' or 'Status effect apply failed.'))
    if ok and forge.previewRemoveStatus == true and snap2 and snap2.entityID ~= nil and id ~= '' then
      sb_scheduleJob({ kind = 'preview_remove_status', dueAt = os.clock() + math.max(0.05, tonumber(forge.previewRemoveStatusAfter or 2.0) or 2.0), entityID = snap2.entityID, effectId = id })
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Copy Status To Selected Entry##scenario_target_status_copy2') then
    local entry = sb_selectedEntry()
    local id = sb_trim(forge.manualStatusId or '')
    if id == '' then id = sb_trim(forge.statusSelected or '') end
    if entry then
      entry.statusEffectId = id
      sb_refreshTimelineFromDraft()
      st.status = 'Copied selected status effect into selected entry.'
    else
      st.status = 'Select a captured entry first.'
    end
  end
  ImGui.SameLine()
  if (TargetControl and TargetControl.IsTetherActive and TargetControl.IsTetherActive()) then
    if ImGui.SmallButton('Stop Tether##scenario_target_stop_tether2') then
      local ok, msg = TargetControl.StopTether()
      st.status = tostring(msg or (ok and 'Stopped tether.' or 'Stop tether failed.'))
    end
  else
    if ImGui.SmallButton('Tether To Player##scenario_target_start_tether2') then
      local ok, msg = TargetControl and TargetControl.StartTetherToPlayer and TargetControl.StartTetherToPlayer()
      st.status = tostring(msg or (ok and 'Started tether.' or 'Tether failed.'))
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Despawn Current Target##scenario_target_despawn2') then
    local ok, msg = TargetControl and TargetControl.DespawnCurrentTarget and TargetControl.DespawnCurrentTarget()
    st.status = tostring(msg or (ok and 'Despawned current target.' or 'Despawn failed.'))
  end
  st.targetForge = forge
end



local function sb_sliderValue(label, current, minv, maxv)
  local a, b = ImGui.SliderFloat(label, tonumber(current or 0) or 0, tonumber(minv or 0) or 0, tonumber(maxv or 0) or 0)
  if type(a) == 'number' then return a end
  if type(b) == 'number' then return b end
  return tonumber(current or 0) or 0
end

local function sb_drawTimelineTab()
  local st = ScenarioBuilder.state
  sb_refreshTimelineFromDraft()
  local tl = st.timeline or { playing = false, startedAt = 0, duration = 0, playhead = 0, events = {} }
  local duration = math.max(tonumber(tl.duration or 0) or 0, 0)
  ImGui.Text('Scenario Timeline')
  ImGui.TextWrapped('Each captured entry now carries explicit timing. Spawn, freeze, unfreeze, appearance, animation, status, and despawn happen on the timeline instead of depending on how the author happened to look at the scene while building it.')
  if ImGui.Button('Preview Draft Timeline##scenario_timeline_preview') then
    local ok, msg = ScenarioBuilder.ApplyScenarioAsset(sb_buildScenarioAsset(st.name or 'Scenario'))
    st.status = tostring(msg or (ok and 'Preview started.' or 'Preview failed.'))
  end
  ImGui.SameLine()
  if ImGui.Button('Stop Timeline##scenario_timeline_stop') then
    tl.playing = false
    st.runtimeJobs = {}
    st.status = 'Stopped scenario timeline preview.'
  end
  ImGui.Text('Duration: ' .. string.format('%.2fs', duration))
  tl.playhead = sb_sliderValue('Playhead##scenario_timeline_playhead', tl.playhead or 0, 0, math.max(duration, 0.10))
  ImGui.TextDisabled(tl.playing == true and 'Preview running live. Use this playhead as a timeline readout while events execute.' or 'Preview idle. Move the playhead to inspect event timing.')
  if ImGui.BeginChild('scenario_timeline_events', 0, 320, true) then
    for i = 1, #(tl.events or {}) do
      local ev = tl.events[i]
      local hit = (tonumber(ev.time or 0) or 0) <= (tonumber(tl.playhead or 0) or 0)
      if hit then
        ImGui.TextColored(0.30, 0.95, 0.45, 1.00, string.format('%.2fs | %s', tonumber(ev.time or 0) or 0, tostring(ev.label or 'event')))
      else
        ImGui.Text(string.format('%.2fs | %s', tonumber(ev.time or 0) or 0, tostring(ev.label or 'event')))
      end
      if ImGui.IsItemClicked() then
        tl.playhead = tonumber(ev.time or 0) or 0
        if tonumber(ev.entryIndex or 0) > 0 then st.selectedIndex = tonumber(ev.entryIndex or 0) or st.selectedIndex end
      end
    end
    ImGui.EndChild()
  end
  st.timeline = tl
end

function ScenarioBuilder.DrawTab(_)
  if ImGui.BeginTabBar('scenario_builder_tabs') then
    if ImGui.BeginTabItem('Home') then
      sb_drawHomeTab()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Scene') then
      sb_drawSceneTab()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Animations') then
      sb_drawAnimationTab()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Spawn') then
      sb_drawQuickSpawn()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Target') then
      if ImGui.BeginTabBar('scenario_target_tabs') then
        if ImGui.BeginTabItem('Transform') then
          sb_drawTargetTransformPane()
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem('Appearance') then
          sb_drawTargetAppearancePane()
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem('Status / Tools') then
          sb_drawTargetStatusPane()
          ImGui.EndTabItem()
        end
        ImGui.EndTabBar()
      end
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Player') then
      sb_drawPlayerState()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Timeline') then
      sb_drawTimelineTab()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Saved') then
      sb_drawSavedScenarios()
      ImGui.EndTabItem()
    end
    ImGui.EndTabBar()
  else
    sb_drawHomeTab()
  end
  ImGui.Separator()
  ImGui.TextWrapped(tostring(ScenarioBuilder.state.status or 'Ready.'))
end

return ScenarioBuilder
