local AssetRegistry = require("GTS/asset_registry")
local RuleRunner = require("GTS/rule_runner")

local CreatedTab = CreatedTab or {}

local function _runCreatedAssetSafe(assetId, desiredState)
  local ok, success, msg = pcall(RuleRunner.RunCreatedAssetById, assetId, desiredState)
  if not ok then return false, tostring(success or "Created asset runtime error") end
  return success == true, msg
end
CreatedTab.state = CreatedTab.state or { search = "", lastRunMessage = "" }

local function _displayAssetType(assetType)
  local key = tostring(assetType or "asset")
  if key == "observer_preset" then return "stat_condition" end
  if key == "stat_preset" then return "stat_profile" end
  return key
end

local function _checkboxValue(label, current)
  local a, b = ImGui.Checkbox(label, current == true)
  if type(a) == "boolean" and type(b) == "boolean" then
    if b == (a ~= current) then return a == true end
    if a == (b ~= current) then return b == true end
    return b == true
  end
  if type(a) == "boolean" then return a == true end
  if type(b) == "boolean" then return b == true end
  return current == true
end

local function _inputTextValue(label, value, size)
  local a, b = ImGui.InputText(label, value or "", size or 128)
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return value or ""
end

local function _matchesSearch(asset, needle)
  if needle == "" then return true end
  local hay = string.lower(string.format("%s %s %s", tostring(asset.type or ""), tostring(asset.name or ""), tostring(asset.id or "")))
  return string.find(hay, needle, 1, true) ~= nil
end

local function _assetHeader(asset)
  local t = _displayAssetType(asset.type or "asset")
  return string.format("[%s] %s", t, tostring(asset.name or asset.id or "asset"))
end

local function _runButton(asset)
  local t = tostring(asset.type or "")
  if t == "rule" then
    if ImGui.SmallButton("Run##created_run_" .. tostring(asset.id)) then local ok, msg = _runCreatedAssetSafe(asset.id, "run"); CreatedTab.state.lastRunMessage = tostring(msg or (ok and "Ran asset." or "Asset failed.")) end
    return
  end
  local mode = tostring((((asset or {}).data or {}).mode) or "button")
  if (t == "macro" or t == "custom_code" or t == "launcher") and mode == "toggle" then
    local enabled = RuleRunner.IsCreatedAssetEnabled(asset.id)
    if enabled then
      if ImGui.SmallButton("Turn OFF##created_off_" .. tostring(asset.id)) then
        local ok, msg = _runCreatedAssetSafe(asset.id, "off")
        CreatedTab.state.lastRunMessage = tostring(msg or (ok and "Turned asset off." or "Asset failed."))
      end
      ImGui.SameLine()
      ImGui.TextUnformatted("ON")
    else
      if ImGui.SmallButton("Turn ON##created_on_" .. tostring(asset.id)) then
        local ok, msg = _runCreatedAssetSafe(asset.id, "on")
        CreatedTab.state.lastRunMessage = tostring(msg or (ok and "Turned asset on." or "Asset failed."))
      end
      ImGui.SameLine()
      ImGui.TextUnformatted("OFF")
    end
  else
    if ImGui.SmallButton("Run##created_run_" .. tostring(asset.id)) then local ok, msg = _runCreatedAssetSafe(asset.id, "run"); CreatedTab.state.lastRunMessage = tostring(msg or (ok and "Ran asset." or "Asset failed.")) end
  end
end

local function _drawCategory(label, types)
  if not ImGui.CollapsingHeader(label .. "##created_cat") then return end
  local needle = string.lower(tostring(CreatedTab.state.search or ""))
  local items = AssetRegistry.ListCreatedAssets and AssetRegistry.ListCreatedAssets() or AssetRegistry.List() or {}
  local filtered = {}
  for i = 1, #items do
    local a = items[i]
    for j = 1, #types do
      if tostring(a.type or "") == tostring(types[j]) and _matchesSearch(a, needle) then filtered[#filtered + 1] = a break end
    end
  end
  if #filtered == 0 then ImGui.TextDisabled("None."); return end
  if ImGui.BeginTable("created_tbl_" .. label, 5, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("Name")
    ImGui.TableSetupColumn("Details")
    ImGui.TableSetupColumn("State / Run", ImGuiTableColumnFlags.WidthFixed, 120)
    ImGui.TableSetupColumn("Duplicate", ImGuiTableColumnFlags.WidthFixed, 80)
    ImGui.TableSetupColumn("Delete", ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableHeadersRow()
    for i = 1, #filtered do
      local asset = filtered[i]
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(_assetHeader(asset))
      ImGui.TableSetColumnIndex(1)
      if tostring(asset.type or "") == "rule" then
        local enabled = (((asset or {}).data or {}).enabled) ~= false
        local mutable = AssetRegistry.GetMutable(asset.id)
        local newEnabled = _checkboxValue("Enabled##rule_enabled_" .. tostring(asset.id), enabled)
        if mutable and mutable.data then mutable.data.enabled = newEnabled end
        ImGui.SameLine()
        ImGui.TextUnformatted(tostring((RuleRunner.GetStatus(asset.id) or {}).lastMessage or "Script"))
      elseif tostring(asset.type or "") == "teleport_preset" then
        local d = (asset.data or {})
        ImGui.TextUnformatted(string.format("%.2f, %.2f, %.2f", tonumber(d.x or 0) or 0, tonumber(d.y or 0) or 0, tonumber(d.z or 0) or 0))
      elseif tostring(asset.type or "") == "launcher" then
        ImGui.TextUnformatted(string.format("%d linked item(s)", #(((asset.data or {}).entries) or {})))
      elseif tostring(asset.type or "") == "animation_sequence" then
        ImGui.TextUnformatted(string.format("%d step(s)", #((((asset.data or {}).steps) or {}))) )
      elseif tostring(asset.type or "") == "scenario" then
        local d = (asset.data or {})
        ImGui.TextUnformatted(string.format("%s | %d entr%s", tostring(d.mode or 'relative'), #((d.entities) or {}), (#((d.entities) or {}) == 1 and 'y' or 'ies')))
      elseif tostring(asset.type or "") == "macro" then
        ImGui.TextUnformatted(string.format("%s | %s", tostring(((asset.data or {}).mode) or "toggle"), tostring(((asset.data or {}).offPolicy) or "none")))
      elseif tostring(asset.type or "") == "custom_code" then
        ImGui.TextUnformatted(string.format("%s code asset", tostring(((asset.data or {}).mode) or "button")))
      else
        ImGui.TextUnformatted(tostring((((asset or {}).data or {}).source) or asset.type or "asset"))
      end
      ImGui.TableSetColumnIndex(2)
      _runButton(asset)
      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton("Copy##created_dup_" .. tostring(asset.id)) then AssetRegistry.Duplicate(asset.id) end
      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton("Delete##created_del_" .. tostring(asset.id)) then AssetRegistry.Delete(asset.id) end
    end
    ImGui.EndTable()
  end
end

function CreatedTab.DrawTab(_)
  CreatedTab.state.search = _inputTextValue("Search Created Assets", CreatedTab.state.search or "", 128)
  if tostring(CreatedTab.state.lastRunMessage or "") ~= "" then ImGui.TextWrapped(tostring(CreatedTab.state.lastRunMessage or "")) end
  ImGui.Separator()
  _drawCategory("Scripts", { "rule" })
  _drawCategory("Macros / Code / Launchers", { "macro", "custom_code", "launcher" })
  _drawCategory("Animation Sequences", { "animation_sequence" })
  _drawCategory("Scenarios", { "scenario" })
  _drawCategory("Player / World Profiles", { "stat_preset", "inventory_bundle", "spawn_set", "spawn_grid", "shooter_profile", "teleport_preset" })
  _drawCategory("Stat Conditions", { "observer_preset" })
end

return CreatedTab
