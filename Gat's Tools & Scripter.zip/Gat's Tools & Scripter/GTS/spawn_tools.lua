local SpawnTools = SpawnTools or {}
local AssetRegistry = require("GTS/asset_registry")
local TargetService = require("GTS/target_service")
local ShooterFxLibrary = require("GTS/shooter_fx_library")
local EntTemplateLibrary = require("GTS/ent_template_library")

SpawnTools.state = SpawnTools.state or {
  mode = "Character", -- Character / Vehicle / Prop / FX / Attack / Entity
  spawnLocation = "In Front of Player",
  recordInput = "",
  search = "",
  dbBuilt = false,
  characters = {},
  vehicles = {},
  props = {},
  fxPresets = {},
  attacks = {},
  entities = {},
  filtered = {},
  lastFilterKey = "",
  selectedDbIndex = 1,
  selectedSpawnIndex = 1,
  spawned = {},
  nextId = 1,
  maxListRows = 350,
  _nextRefresh = 0,
  refreshEvery = 0.15,
  customXYZ = { x = "0", y = "0", z = "0" },
  despawnAfterSeconds = 0.0,
  presetName = "",
  gridPresetName = "",
  gridSelectedAssetId = nil,
  gridPresetStatus = "",
  gridSize = 11,
  gridSpacing = "2.0",
  gridZOffset = "0.05",
  gridMarks = {},
  showGridWindow = false,
  gridLiveSpawn = true,
  spawnStatus = "",
  lastSpawnError = "",
  target = {
    exists = false,
    className = "-",
    faction = "-",
    hostile = false,
    aggro = false,
    distance = 0,
    speed = 0,
    health = 0,
    xyz = { x = 0, y = 0, z = 0 },
    handle = nil,
  },
}

local function _pcall(f)
  local ok, r = pcall(f)
  if ok then return r end
  return nil
end

local function _pcallErr(f)
  local ok, r = pcall(f)
  if ok then return r, nil end
  return nil, tostring(r)
end

local function _InputTextValue(label, value, bufSize, flags)
  if flags ~= nil then
    local a, b = ImGui.InputText(label, value, bufSize, flags)
    if type(a) == "boolean" and type(b) == "string" then return b end
    if type(a) == "string" then return a end
    if type(b) == "string" then return b end
    return value
  end
  local a, b = ImGui.InputText(label, value, bufSize)
  if type(a) == "boolean" and type(b) == "string" then return b end
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return value
end

local function _checkboxValue(label, current)
  local value, changed = ImGui.Checkbox(label, current == true)
  if type(value) == "boolean" then return value == true end
  if type(changed) == "boolean" then return changed == true end
  return current == true
end


local function _tabBarOpen(id)
  if type(ImGui.BeginTabBar) ~= "function" then return false end
  local a, b = ImGui.BeginTabBar(id)
  if type(a) == "boolean" then return a end
  if type(b) == "boolean" then return b end
  return false
end

local function _tabItemOpen(label)
  if type(ImGui.BeginTabItem) ~= "function" then return false end
  local a, b = ImGui.BeginTabItem(label)
  if type(a) == "boolean" then return a end
  if type(b) == "boolean" then return b end
  return false
end

local function _getPlayer() return Game.GetPlayer() end
local function _getTargeting() return Game.GetTargetingSystem and Game.GetTargetingSystem() or nil end
local function _getDES() return Game.GetDynamicEntitySystem and Game.GetDynamicEntitySystem() or nil end
local function _getSPS() return Game.GetStatPoolsSystem and Game.GetStatPoolsSystem() or nil end

local function _len3(x, y, z)
  return math.sqrt((x*x) + (y*y) + (z*z))
end

local function _distVec(a, b)
  if not a or not b then return 0 end
  return _len3((a.x or 0) - (b.x or 0), (a.y or 0) - (b.y or 0), (a.z or 0) - (b.z or 0))
end

local function _fmtNum(v)
  if type(v) ~= "number" then return "-" end
  return string.format("%.2f", v)
end

local function _trim(s)
  s = tostring(s or "")
  s = s:gsub('^%s+', ''):gsub('%s+$', '')
  return s
end

local function _fxBasename(s)
  s = tostring(s or "")
  local name = s:match('([^/\\]+)$')
  return name or s
end

local function _normalizeEffectInput(s)
  s = _trim(s)
  s = s:gsub('^gameFxResource%.new%(%s*{%s*effect%s*=%s*"', '')
  s = s:gsub('"%s*}%s*%)$', '')
  s = s:gsub('^"', ''):gsub('"$', '')
  return s
end

local function _resolveFxPath(effectId)
  local s = _normalizeEffectInput(effectId)
  if s == "" then return nil end
  if s:find('\\', 1, true) or s:find('/', 1, true) then return s end
  local low = string.lower(s)
  local src = SpawnTools.state.fxPresets or {}
  for i = 1, #src do
    local full = src[i]
    if string.lower(full) == low then return full end
  end
  for i = 1, #src do
    local full = src[i]
    if string.lower(_fxBasename(full)) == low then return full end
  end
  if not low:match('%.effect$') then
    local withExt = low .. '.effect'
    for i = 1, #src do
      local full = src[i]
      if string.lower(_fxBasename(full)) == withExt then return full end
    end
  end
  return s
end

local function _recordPathFromRec(rec)
  if not rec then return nil end

  local id = _pcall(function() return rec:GetID() end)
  if id and type(id.value) == "string" and id.value ~= "" then
    return id.value
  end

  local rid = _pcall(function() return rec:GetRecordID() end)
  if rid and type(rid.value) == "string" and rid.value ~= "" then
    return rid.value
  end

  local candidates = {
    function() return tostring(rec:GetID()) end,
    function() return tostring(rec:GetRecordID()) end,
    function() return tostring(rec) end,
  }
  for _, fn in ipairs(candidates) do
    local s = _pcall(fn)
    if type(s) == "string" and s ~= "" then
      s = s:gsub("^TweakDBID%(", ""):gsub("%)$", "")
      s = s:gsub("^RecordID%(", ""):gsub("%)$", "")
      if s ~= "" then return s end
    end
  end

  return nil
end

local function _appendRecordList(dst, recordTypeName, prefix)
  if type(recordTypeName) ~= "string" or recordTypeName == "" then return end
  local records = _pcall(function() return TweakDB:GetRecords(recordTypeName) end)
  if type(records) ~= "table" then return end

  for i = 1, #records do
    local path = _recordPathFromRec(records[i])
    if path and ((not prefix) or path:match("^" .. prefix)) then
      dst[#dst + 1] = path
    end
  end
end

local function _buildDB(force)
  local st = SpawnTools.state
  if (not force) and st.dbBuilt and (#(st.characters or {}) > 0 or #(st.vehicles or {}) > 0 or #(st.props or {}) > 0 or #(st.fxPresets or {}) > 0 or #(st.attacks or {}) > 0 or #(st.entities or {}) > 0) then return end

  local chars, vehs, props, effects, attacks, entities = {}, {}, {}, {}, {}, {}
  _appendRecordList(chars, "gamedataCharacter_Record", "Character%.")
  _appendRecordList(vehs, "gamedataVehicle_Record", "Vehicle%.")
  _appendRecordList(props, "gamedataProp_Record", nil)
  if ShooterFxLibrary and type(ShooterFxLibrary.effects) == "table" then
    for i = 1, #ShooterFxLibrary.effects do effects[#effects + 1] = tostring(ShooterFxLibrary.effects[i]) end
  end
  _appendRecordList(attacks, "gamedataAttack_Record", "Attacks%.")
  _appendRecordList(attacks, "gamedataAttack_GameEffect_Record", "Attacks%.")
  if EntTemplateLibrary and type(EntTemplateLibrary.paths) == "table" then
    for i = 1, #EntTemplateLibrary.paths do entities[#entities + 1] = tostring(EntTemplateLibrary.paths[i]) end
  end

  local function dedupeSort(src)
    local out, seen = {}, {}
    for i = 1, #src do
      local v = src[i]
      if type(v) == "string" and v ~= "" and not seen[v] then
        seen[v] = true
        out[#out + 1] = v
      end
    end
    table.sort(out)
    return out
  end

  st.characters = dedupeSort(chars)
  st.vehicles = dedupeSort(vehs)
  st.props = dedupeSort(props)
  st.fxPresets = dedupeSort(effects)
  st.attacks = dedupeSort(attacks)
  st.entities = dedupeSort(entities)
  st.dbBuilt = (#st.characters > 0 or #st.vehicles > 0 or #st.props > 0 or #st.fxPresets > 0 or #st.attacks > 0 or #st.entities > 0)
end

local function _currentDB()
  local st = SpawnTools.state
  if st.mode == "Vehicle" then return st.vehicles end
  if st.mode == "Prop" then return st.props end
  if st.mode == "FX" then return st.fxPresets end
  if st.mode == "Attack" then return st.attacks end
  if st.mode == "Entity" then return st.entities end
  return st.characters
end

local function _entBasename(path)
  local s = tostring(path or "")
  local name = s:match("([^\\/]+)$")
  return name or s
end

local function _refilter()
  local st = SpawnTools.state
  _buildDB()
  local key = (st.mode or "") .. "|" .. (st.search or "")
  if key == st.lastFilterKey then return end
  st.lastFilterKey = key
  st.filtered = {}
  local src = _currentDB()
  local low = string.lower(st.search or "")
  if low == "" then
    for i = 1, #src do st.filtered[#st.filtered + 1] = src[i] end
  else
    for i = 1, #src do
      local v = src[i]
      if string.find(string.lower(v), low, 1, true) then
        st.filtered[#st.filtered + 1] = v
      end
    end
  end
  if st.selectedDbIndex < 1 then st.selectedDbIndex = 1 end
  if st.selectedDbIndex > #st.filtered then st.selectedDbIndex = math.max(1, #st.filtered) end
end

local function _playerSpawnPointInFront(p)
  local pos = _pcall(function() return p:GetWorldPosition() end)
  local fwd = _pcall(function() return p:GetWorldForward() end)
  if not pos or not fwd then return nil end
  return Vector4.new((pos.x or 0) + (fwd.x or 0) * 4, (pos.y or 0) + (fwd.y or 0) * 4, (pos.z or 0) + 0.20, 1)
end

local function _playerSpawnPointMyLocation(p)
  local pos = _pcall(function() return p:GetWorldPosition() end)
  if not pos then return nil end
  return Vector4.new(pos.x or 0, pos.y or 0, pos.z or 0, 1)
end

local function _playerSpawnPointCrosshairs()
  local t = TargetService and TargetService.GetSnapshot and TargetService.GetSnapshot(false) or SpawnTools.state.target
  if t and t.exists then
    return Vector4.new((t.xyz and t.xyz.x) or 0, (t.xyz and t.xyz.y) or 0, (t.xyz and t.xyz.z) or 0, 1)
  end
  return nil
end

local function _playerSpawnPointCustomXYZ()
  local st = SpawnTools.state
  local x = tonumber(st.customXYZ.x or "")
  local y = tonumber(st.customXYZ.y or "")
  local z = tonumber(st.customXYZ.z or "")
  if not x or not y or not z then return nil end
  return Vector4.new(x, y, z, 1)
end

local function _trim(s)
  return tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function _parseRawTDBID(textValue)
  local hex, extra = string.match(_trim(textValue), "^0[xX]([%da-fA-F]+)%s*,%s*(%d+)$")
  if not hex or not extra then return nil end
  local hash = tonumber(hex, 16)
  local len = tonumber(extra)
  if not hash or not len then return nil end
  return _pcall(function() return TweakDBID.new(hash, len) end)
end

local function _recordIDFromInput(textValue)
  local trimmed = _trim(textValue)
  if trimmed == "" then return nil end
  local raw = _parseRawTDBID(trimmed)
  if raw then return raw end
  return _pcall(function() return TweakDBID.new(trimmed) end)
end

local function _selectedRecordText()
  local st = SpawnTools.state
  local record = _trim(st.recordInput or "")
  if record ~= "" then return record end
  return _trim(st.filtered[st.selectedDbIndex] or "")
end

local function _gridCellKey(gx, gy)
  return tostring(gx) .. ":" .. tostring(gy)
end

local function _clearGridMarks()
  SpawnTools.state.gridMarks = {}
end

local function _playerBasisXZ(p)
  local pos = _pcall(function() return p:GetWorldPosition() end)
  local fwd = _pcall(function() return p:GetWorldForward() end)
  if not pos or not fwd then return nil end
  local fx, fy = tonumber(fwd.x or 0) or 0, tonumber(fwd.y or 0) or 0
  local flen = math.sqrt((fx * fx) + (fy * fy))
  if flen < 0.0001 then fx, fy, flen = 0, 1, 1 end
  fx, fy = fx / flen, fy / flen
  local rx, ry = -fy, fx
  return pos, fx, fy, rx, ry
end

local function _gridWorldPosition(p, gx, gy)
  local st = SpawnTools.state
  local pos, fx, fy, rx, ry = _playerBasisXZ(p)
  if not pos then return nil end
  local size = tonumber(st.gridSize or 11) or 11
  local half = math.floor(size / 2)
  local spacing = tonumber(st.gridSpacing or "2.0") or 2.0
  local zOffset = tonumber(st.gridZOffset or "0.05") or 0.05
  local dx = gx - half - 1
  local dy = half - gy + 1
  return Vector4.new(
    (pos.x or 0) + (rx * dx * spacing) + (fx * dy * spacing),
    (pos.y or 0) + (ry * dx * spacing) + (fy * dy * spacing),
    (pos.z or 0) + zOffset,
    1
  )
end

local function _resolveSpawnPoint(p)
  local mode = SpawnTools.state.spawnLocation
  if mode == "At Crosshairs" then
    return _playerSpawnPointCrosshairs() or _playerSpawnPointInFront(p)
  elseif mode == "At My Location" then
    return _playerSpawnPointMyLocation(p)
  elseif mode == "Custom XYZ" then
    return _playerSpawnPointCustomXYZ()
  end
  return _playerSpawnPointInFront(p)
end


local function _stringFromAnyFlat(v)
  if type(v) == "string" and v ~= "" then return v end
  if type(v) == "table" and type(v.value) == "string" and v.value ~= "" then return v.value end
  local s = tostring(v or "")
  local m = s:match("(Attacks%.[%w_]+)")
  if m and m ~= "" then return m end
  return nil
end

local function _resolveAttackRecordPath(attackId)
  local s = _trim(attackId)
  if s == '' then return nil, 'Missing attack record' end
  local low = string.lower(s)
  local src = SpawnTools.state.attacks or {}
  for i = 1, #src do
    local full = src[i]
    if string.lower(full) == low then return full, nil end
  end
  if not s:match('^Attacks%.') then
    for i = 1, #src do
      local full = src[i]
      local leaf = full:match('([^%.]+)$') or full
      if string.lower(leaf) == low then return full, nil end
    end
    local prefixed = 'Attacks.' .. s
    for i = 1, #src do
      local full = src[i]
      if string.lower(full) == string.lower(prefixed) then return full, nil end
    end
  end
  if s:match('^Attacks%.') then return s, nil end
  return nil, 'Attack record not found'
end

local function _spawnAttackAt(attackId, point)
  local pos = point or _resolveSpawnPoint(_getPlayer())
  if not pos then return nil, 'Missing spawn position' end
  local attackRecordPath, resolveErr = _resolveAttackRecordPath(attackId)
  if not attackRecordPath then return nil, resolveErr or 'Attack record not found' end
  local atkSys = (type(GetSingleton) == 'function') and GetSingleton('gameAttack_GameEffect') or nil
  if not atkSys then return nil, 'gameAttack_GameEffect unavailable' end
  local record = nil
  if TweakDB and TweakDB.GetRecord then
    record = _pcall(function() return TweakDB:GetRecord(attackRecordPath) end)
  end
  if record == nil then return nil, 'TweakDB attack record missing: ' .. tostring(attackRecordPath) end
  local player = _getPlayer()
  if not player then return nil, 'Player unavailable' end
  local weapon = nil
  pcall(function() weapon = player:GetActiveWeapon() end)
  local ok, err = pcall(function() atkSys:SpawnExplosionAttack(record, weapon, player, player, pos, 3.0) end)
  if not ok then return nil, tostring(err or 'SpawnExplosionAttack failed') end
  local item = {
    id = SpawnTools.state.nextId,
    mode = 'Attack',
    record = tostring(attackRecordPath),
    attackRecord = tostring(attackRecordPath),
    entityID = nil,
    handle = nil,
    createdAtText = os.date('%Y-%m-%d %H:%M:%S'),
    xyz = { x = pos.x or 0, y = pos.y or 0, z = pos.z or 0 },
    distance = 0, speed = 0, health = 0, exists = false, transient = true,
  }
  SpawnTools.state.nextId = SpawnTools.state.nextId + 1
  return item, nil
end


local function _queueDespawnEntry(entry, seconds)
  if type(entry) ~= 'table' then return end
  seconds = tonumber(seconds or 0) or 0
  if seconds <= 0 then return end
  entry.despawnAt = os.clock() + seconds
end

local function _spawnFXAt(effectId, point)
  local resolved = _resolveFxPath(effectId)
  if _trim(resolved) == '' then return nil, 'Missing FX path' end
  local fxSystem = (Game and Game.GetFxSystem and Game.GetFxSystem()) or nil
  if fxSystem == nil then return nil, 'FxSystem unavailable' end
  if gameFxResource == nil or gameFxResource.new == nil then return nil, 'gameFxResource unavailable' end
  local pos = point or _resolveSpawnPoint(_getPlayer())
  if not pos then return nil, 'Missing spawn position' end
  local transform = WorldTransform.new()
  pcall(function() transform:SetOrientation(EulerAngles.new(0, 0, 0)) end)
  pcall(function() transform:SetPosition(Vector4.new(pos.x or 0, pos.y or 0, pos.z or 0, 1)) end)
  local fxParticle = gameFxResource.new({ effect = resolved })
  local okHandle, fxHandle = pcall(function() return fxSystem:SpawnEffect(fxParticle, transform) end)
  local ok = okHandle and fxHandle ~= nil and (IsDefined == nil or IsDefined(fxHandle))
  if not ok then
    local okGround = pcall(function() fxSystem:SpawnEffectOnGround(fxParticle, transform, true) end)
    if not okGround then return nil, 'FX spawn failed' end
  end
  local item = {
    id = SpawnTools.state.nextId,
    mode = 'FX',
    record = resolved,
    entityID = nil,
    handle = fxHandle,
    createdAtText = os.date('%Y-%m-%d %H:%M:%S'),
    xyz = { x = pos.x, y = pos.y, z = pos.z },
    distance = 0, speed = 0, health = 0, exists = true,
  }
  SpawnTools.state.nextId = SpawnTools.state.nextId + 1
  SpawnTools.state.spawned[#SpawnTools.state.spawned + 1] = item
  return item, nil
end

local function _normalizeEntityTemplatePath(path)
  local s = _trim(path)
  s = s:gsub("/", "\\")
  s = s:gsub("\\+", "\\")
  if s ~= "" and not s:lower():match("%.ent$") then s = s .. ".ent" end
  return s
end

local function _spawnEntityTemplateAt(templatePath, point)
  local pos = point or _resolveSpawnPoint(_getPlayer())
  if not pos then return nil, "Missing spawn position" end
  local path = _normalizeEntityTemplatePath(templatePath)
  if path == "" then return nil, "Missing entity template path" end
  if exEntitySpawner == nil or exEntitySpawner.Spawn == nil then return nil, "exEntitySpawner.Spawn unavailable" end
  local player = _getPlayer()
  if not player then return nil, "Player unavailable" end
  local tr = _pcall(function() return player:GetWorldTransform() end)
  if tr == nil then return nil, "Could not get player transform" end
  local okPos, posErr = pcall(function() tr:SetPosition(Vector4.new(pos.x or 0, pos.y or 0, pos.z or 0, pos.w or 1.0)) end)
  if not okPos then return nil, "Could not set transform position: " .. tostring(posErr) end
  pcall(function() local ori = player:GetWorldOrientation() if ori ~= nil then tr:SetOrientation(ori) end end)
  local okS, spawned = pcall(function() return exEntitySpawner.Spawn(path, tr, "", "") end)
  if not okS then return nil, "Entity spawn threw an error: " .. tostring(spawned) end
  if spawned == nil then return nil, "Entity spawn returned nil" end
  local item = {
    id = SpawnTools.state.nextId,
    mode = 'Entity',
    record = path,
    entityID = nil,
    handle = spawned,
    createdAtText = os.date('%Y-%m-%d %H:%M:%S'),
    xyz = { x = pos.x or 0, y = pos.y or 0, z = pos.z or 0 },
    distance = 0, speed = 0, health = 0, exists = true,
  }
  SpawnTools.state.nextId = SpawnTools.state.nextId + 1
  SpawnTools.state.spawned[#SpawnTools.state.spawned + 1] = item
  return item, nil
end

local function _spawnRecord(recordPath, overridePoint, modeOverride)
  local p = _getPlayer()
  if not p then return nil, "Player unavailable" end
  local des = _getDES()
  if not des then return nil, "DynamicEntitySystem unavailable" end
  if not DynamicEntitySpec or not DynamicEntitySpec.new then return nil, "DynamicEntitySpec unavailable" end
  if type(recordPath) ~= "string" or recordPath == "" then return nil, "Missing record" end
  local sp = overridePoint or _resolveSpawnPoint(p)
  if not sp then return nil, "Missing spawn position" end

  local tid = _recordIDFromInput(recordPath)
  if tid == nil then return nil, "Invalid record ID" end

  local mode = tostring(modeOverride or SpawnTools.state.mode or "Character")
  local tag = "MG_SPAWNED_CHARACTER"
  if mode == "Vehicle" then tag = "MG_SPAWNED_VEHICLE" end
  if mode == "Prop" then tag = "MG_SPAWNED_PROP" end

  local spec = DynamicEntitySpec.new()
  pcall(function() spec.persistState = false end)
  pcall(function() spec.persistSpawn = false end)
  pcall(function() spec.alwaysSpawned = false end)
  pcall(function() spec.spawnInView = true end)
  spec.recordID = tid
  spec.position = Vector4.new(sp.x or 0, sp.y or 0, sp.z or 0, sp.w or 1.0)
  pcall(function() spec.tags = { "MG_SPAWNED_ENTITY", tag } end)

  local entID, createErr = _pcallErr(function() return des:CreateEntity(spec) end)
  if not entID then
    return nil, createErr and ("CreateEntity failed: " .. tostring(createErr)) or "CreateEntity failed"
  end
  local handle = _pcall(function() return Game.FindEntityByID(entID) end)

  local item = {
    id = SpawnTools.state.nextId,
    mode = mode,
    record = recordPath,
    entityID = entID,
    handle = handle,
    createdAtText = os.date("%Y-%m-%d %H:%M:%S"),
    xyz = { x = sp.x, y = sp.y, z = sp.z },
    distance = 0,
    speed = 0,
    health = 0,
    exists = true,
  }
  SpawnTools.state.nextId = SpawnTools.state.nextId + 1
  SpawnTools.state.spawned[#SpawnTools.state.spawned + 1] = item
  return item, nil
end

local _gridMarkData, _setGridMark, _gridMarkEntry, _clearGridMark

local function _spawnSelectedRecordAtPoint(point, markKey)
  local st = SpawnTools.state
  local record = _selectedRecordText()
  if record == "" then
    st.lastSpawnError = "Select or enter a record first."
    st.spawnStatus = st.lastSpawnError
    return nil, st.lastSpawnError
  end
  if point == nil then
    point = _resolveSpawnPoint(_getPlayer())
    if point == nil then
      st.lastSpawnError = "Missing spawn position"
      st.spawnStatus = "Spawn failed: " .. st.lastSpawnError
      return nil, st.lastSpawnError
    end
  end
  if markKey then
    local existing = _gridMarkData(markKey)
    if existing and existing.active then
      _clearGridMark(markKey)
    end
  end
  local ok, itemOrErr = SpawnTools.SpawnRecordAtPoint(record, st.mode, point, st.despawnAfterSeconds)
  local item, err = nil, nil
  if ok then
    item = itemOrErr
  else
    err = tostring(itemOrErr or "Spawn failed")
  end
  if markKey and (item or st.mode == "Attack") then
    _setGridMark(markKey, item, point, record, st.mode, st.despawnAfterSeconds)
  end
  if item then
    st.lastSpawnError = ""
    st.spawnStatus = "Spawned: " .. tostring(item.record or record)
  else
    st.lastSpawnError = tostring(err or "Spawn failed")
    st.spawnStatus = "Spawn failed: " .. st.lastSpawnError
  end
  return item, err
end

local function _despawnEntry(entry)
  if not entry then return false end
  local des = _getDES()
  local handle = entry.handle or _pcall(function() return Game.FindEntityByID(entry.entityID) end)
  if handle then _pcall(function() handle:Dispose() end) end
  if des and entry.entityID then _pcall(function() des:DeleteEntity(entry.entityID) end) end
  entry.exists = false
  return true
end

local function _despawnSelected()
  local st = SpawnTools.state
  local entry = st.spawned[st.selectedSpawnIndex or 1]
  if entry then _despawnEntry(entry) end
end

local function _despawnAll()
  local st = SpawnTools.state
  for i = 1, #st.spawned do _despawnEntry(st.spawned[i]) end
end

local function _refreshTarget()
  local st = SpawnTools.state
  local T = st.target
  local snap = TargetService and TargetService.GetSnapshot and TargetService.GetSnapshot(false) or nil
  T.exists = false
  T.className = "-"
  T.faction = "-"
  T.hostile = false
  T.aggro = false
  T.distance = 0
  T.speed = 0
  T.health = 0
  T.handle = nil
  T.xyz = { x = 0, y = 0, z = 0 }
  if type(snap) ~= "table" or snap.exists ~= true then return end
  T.exists = true
  T.handle = snap.handle
  T.className = tostring(snap.className or "-")
  T.faction = tostring(snap.faction or "-")
  T.hostile = snap.hostile == true
  T.aggro = snap.aggro == true
  T.distance = tonumber(snap.distance or 0) or 0
  T.speed = tonumber(snap.speed or 0) or 0
  T.health = tonumber(snap.health or 0) or 0
  if type(snap.xyz) == "table" then
    T.xyz = { x = tonumber(snap.xyz.x or 0) or 0, y = tonumber(snap.xyz.y or 0) or 0, z = tonumber(snap.xyz.z or 0) or 0 }
  end
end


local function _refreshSpawned()
  local st = SpawnTools.state
  local now = os.clock()
  if now < (st._nextRefresh or 0) then return end
  st._nextRefresh = now + (st.refreshEvery or 0.15)

  local p = _getPlayer()
  local sps = _getSPS()
  local pPos = p and _pcall(function() return p:GetWorldPosition() end) or nil

  _refreshTarget()

  for i = #st.spawned, 1, -1 do
    local e = st.spawned[i]
    if type(e) ~= 'table' then
      table.remove(st.spawned, i)
    elseif tonumber(e.despawnAt or 0) > 0 and now >= (tonumber(e.despawnAt or 0) or 0) then
      local des = _getDES()
      local handle = e.handle or _pcall(function() return Game.FindEntityByID(e.entityID) end)
      if handle then _pcall(function() handle:Dispose() end) end
      if des and e.entityID then _pcall(function() des:DeleteEntity(e.entityID) end) end
      table.remove(st.spawned, i)
    else
      local h = e.handle or _pcall(function() return Game.FindEntityByID(e.entityID) end)
      e.handle = h
      e.exists = (h ~= nil)
      if h then
        local pos = _pcall(function() return h:GetWorldPosition() end)
        local vel = _pcall(function() return h:GetVelocity() end)
        e.distance = (pPos and pos) and _distVec(pPos, pos) or 0
        e.speed = vel and _len3(vel.x or 0, vel.y or 0, vel.z or 0) or 0
        e.health = (sps and h.GetEntityID and _pcall(function() return sps:GetStatPoolValue(h:GetEntityID(), gamedataStatPoolType.Health) end)) or 0
        if pos then e.xyz = { x = pos.x or 0, y = pos.y or 0, z = pos.z or 0 } end
      else
        e.distance = 0
        e.speed = 0
        e.health = 0
      end
    end
  end
end

function SpawnTools.OnUpdate(delta)
  _refreshSpawned()
end

local function _drawTargetPanel(uiState)
  local T = SpawnTools.state.target
  ImGui.Separator()
  ImGui.Text("Target Snapshot")
  if uiState and uiState.colors then
    local c = T.exists and {0.20, 0.95, 0.20, 1.00} or {0.95, 0.20, 0.20, 1.00}
    ImGui.TextColored(c[1], c[2], c[3], c[4], "TargetExists: " .. tostring(T.exists):upper())
  else
    ImGui.Text("TargetExists: " .. tostring(T.exists):upper())
  end
  ImGui.Text("TargetClass: " .. tostring(T.className or "-"))
  ImGui.Text("TargetFaction: " .. tostring(T.faction or "-"))
  ImGui.Text("TargetIsHostile: " .. tostring(T.hostile):upper())
  ImGui.Text("TargetAggro: " .. tostring(T.aggro):upper())
  ImGui.Text("TargetDistance: " .. _fmtNum(T.distance))
  ImGui.Text("TargetSpeed: " .. _fmtNum(T.speed))
  ImGui.Text("TargetHealth: " .. _fmtNum(T.health))
  ImGui.Text(string.format("Target XYZ: %.2f, %.2f, %.2f", T.xyz.x or 0, T.xyz.y or 0, T.xyz.z or 0))
end


local function _GetVehicleSystem()
  local ok, vs = pcall(function() return Game.GetVehicleSystem() end)
  return (ok and vs) or nil
end

local function _vehResolveNameFromTDBID(tdbidStr)
  if not tdbidStr or tdbidStr == "" then return "<UNKNOWN VEHICLE>" end
  local name = nil
  pcall(function()
    if TweakDB and TweakDB.GetRecord and TweakDBID and TweakDBID.new then
      local rec = TweakDB:GetRecord(TweakDBID.new(tdbidStr))
      if rec and rec.DisplayName then
        local dn = rec:DisplayName()
        if dn ~= nil then
          local dnStr = tostring(dn)
          local loc = ""
          pcall(function() if Game and Game.GetLocalizedTextByKey then loc = Game.GetLocalizedTextByKey(dnStr) end end)
          if loc and loc ~= "" then name = loc elseif dnStr and dnStr ~= "" and not string.find(dnStr, "gamedata") then name = dnStr end
        end
      end
    end
  end)
  pcall(function()
    if (name == nil or name == "") and Game and Game.GetLocalizedTextByKey and TDB and TDB.GetLocKey then
      local loc2 = Game.GetLocalizedTextByKey(TDB.GetLocKey(tdbidStr .. ".displayName"))
      if loc2 and loc2 ~= "" then name = loc2 end
    end
  end)
  if not name or name == "" then name = tdbidStr end
  return name
end

local function _vehExtractId(obj)
  if obj == nil then return nil end
  if type(obj) == "string" then
    local s = obj:gsub("^%s+", ""):gsub("%s+$", "")
    return (s ~= "") and s or nil
  end
  if type(obj) == "userdata" then
    local probes = {
      function() if obj.GetID then return obj:GetID() end end,
      function() if obj.GetRecordID then return obj:GetRecordID() end end,
      function() if obj.GetVehicleRecordID then return obj:GetVehicleRecordID() end end,
      function() if obj.ToString then return obj:ToString() end end,
      function() return obj.recordID end,
      function() return obj.id end,
    }
    for _, fn in ipairs(probes) do
      local ok, res = pcall(fn)
      if ok and res ~= nil then
        if type(res) == "string" then
          local s = res:gsub("^%s+", ""):gsub("%s+$", "")
          if s ~= "" then return s end
        end
        local ts = tostring(res)
        if ts ~= nil and ts ~= "" and ts:find("userdata") == nil then
          local tok = ts:match("(Vehicle%.[%w_]+)")
          if tok ~= nil and tok ~= "" then return tok end
        end
      end
    end
    if GameDump ~= nil then
      local ok, dump = pcall(function() return GameDump(obj) end)
      if ok and type(dump) == "string" then
        local tok = dump:match("(Vehicle%.[%w_]+)")
        if tok ~= nil and tok ~= "" then return tok end
      end
    end
  end
  return nil
end

local function _scanOwnedVehicles()
  local vs = _GetVehicleSystem()
  if not vs then return false, "VehicleSystem unavailable", {} end
  local list = nil
  local ok = false
  if vs.GetPlayerUnlockedVehicles ~= nil then ok, list = pcall(function() return vs:GetPlayerUnlockedVehicles() end) end
  if (not ok or list == nil) and vs.GetPlayerVehicles ~= nil then ok, list = pcall(function() return vs:GetPlayerVehicles() end) end
  if (not ok or list == nil) and vs.GetVehicles ~= nil then ok, list = pcall(function() return vs:GetVehicles() end) end
  if not ok or list == nil then return false, "No supported owned-vehicle API on this build", {} end
  local out, seen = {}, {}
  for _, v in ipairs(list) do
    local id = _vehExtractId(v)
    if id ~= nil then
      id = tostring(id):gsub("^%s+", ""):gsub("%s+$", "")
      if id ~= "" and seen[id] ~= true then
        seen[id] = true
        out[#out + 1] = { id = id, label = _vehResolveNameFromTDBID(id) }
      end
    end
  end
  table.sort(out, function(a, b) return string.lower(tostring(a.label or a.id)) < string.lower(tostring(b.label or b.id)) end)
  return true, nil, out
end

local function _comboValue(label, current, values)
  local currentIndex = 0
  for i = 1, #values do
    if values[i] == current then currentIndex = i - 1 break end
  end
  local changed, newIndex = ImGui.Combo(label, currentIndex, values, #values)
  if type(changed) == "boolean" then
    if changed then return values[(newIndex or 0) + 1] or current end
    return current
  end
  if type(changed) == "number" then
    return values[(changed or 0) + 1] or current
  end
  return current
end

local function _glyphFromKeys(keys, fallback)
  if type(IconGlyphs) == "table" then
    for _, k in ipairs(keys or {}) do
      local g = IconGlyphs[k]
      if g ~= nil and g ~= "" and g ~= "?" and g ~= "S" then
        return g
      end
    end
  end
  return fallback
end

local function _gridEmptyGlyph()
  return _glyphFromKeys({
    "SquareMediumOutline", "SquareOutline", "CheckboxBlankOutline", "SquareRoundedOutline",
  }, "□")
end

local function _gridFilledGlyph()
  return _glyphFromKeys({
    "SquareMedium", "Square", "CheckboxMarked", "Stop", "SquareRounded",
  }, "■")
end

local function _gridCenterGlyph()
  return _glyphFromKeys({
    "Crosshairs", "CrosshairsGps", "Target", "CircleMedium", "RecordCircleOutline",
  }, "◎")
end

local function _findNamedSpawnPreset(name)
  if type(name) ~= "string" or name == "" then return nil end
  return AssetRegistry.FindByTypeAndName and AssetRegistry.FindByTypeAndName("spawn_set", name) or nil
end

local function _upsertSpawnPreset(name, entries, source)
  local trimmed = tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if trimmed == "" then return nil, "Enter a preset name first." end
  if type(entries) ~= "table" or #entries == 0 then return nil, "No spawn entries to save." end
  local asset = {
    type = "spawn_set",
    name = trimmed,
    data = { source = source or "spawn_tools", entries = entries }
  }
  return (AssetRegistry.UpsertNew and AssetRegistry.UpsertNew(asset, trimmed)) or AssetRegistry.Upsert(asset)
end

function SpawnTools.SaveCurrentSelectionAsPreset(name)
  local st = SpawnTools.state
  local record = _selectedRecordText()
  if record == "" then return nil, "Select or enter a record first." end
  return _upsertSpawnPreset(name, { { record = record, mode = st.mode } }, "spawn_tools_current")
end

function SpawnTools.SaveSpawnedAsPreset(name)
  local st = SpawnTools.state
  local seen, entries = {}, {}
  for i = 1, #(st.spawned or {}) do
    local e = st.spawned[i]
    local record = tostring((e or {}).record or "")
    if record ~= "" and not seen[record] then
      seen[record] = true
      entries[#entries + 1] = { record = record, mode = e.mode or st.mode }
    end
  end
  return _upsertSpawnPreset(name, entries, "spawn_tools_spawned")
end

function SpawnTools.ApplySpawnSet(entries)
  if type(entries) ~= "table" then return false end
  local ran = 0
  for i = 1, #entries do
    local e = entries[i]
    if e and e.record and e.record ~= "" then
      local item = _spawnRecordWithMode(tostring(e.record), nil, tostring(e.mode or "Character"), tonumber(e.despawnAfterSeconds or 0) or 0)
      if item then ran = ran + 1 end
    end
  end
  return ran > 0
end


local function _findNamedSpawnGrid(name)
  if type(name) ~= "string" or name == "" then return nil end
  return AssetRegistry.FindByTypeAndName and AssetRegistry.FindByTypeAndName("spawn_grid", name) or nil
end

local function _normalizeSpawnGridData(data)
  if type(data) ~= "table" then return nil end
  local out = {
    mode = tostring(data.mode or "Character"),
    record = tostring(data.record or ""),
    gridSize = math.floor(tonumber(data.gridSize or 11) or 11),
    gridSpacing = tostring(data.gridSpacing or "2.0"),
    gridZOffset = tostring(data.gridZOffset or "0.05"),
    gridMarks = {},
    despawnAfterSeconds = tonumber(data.despawnAfterSeconds or 0) or 0,
    gridLiveSpawn = data.gridLiveSpawn == true,
  }
  if out.gridSize < 5 then out.gridSize = 5 end
  if out.gridSize > 21 then out.gridSize = 21 end
  if (out.gridSize % 2) == 0 then out.gridSize = out.gridSize + 1 end
  if out.mode ~= "Vehicle" and out.mode ~= "Prop" and out.mode ~= "FX" and out.mode ~= "Attack" and out.mode ~= "Entity" then out.mode = "Character" end
  if type(data.gridMarks) == "table" then
    for k, v in pairs(data.gridMarks) do
      if v == true then
        out.gridMarks[tostring(k)] = { active = true, mode = out.mode, record = out.record, despawnAfterSeconds = out.despawnAfterSeconds }
      elseif type(v) == "table" and v.active == true then
        local mode = tostring(v.mode or out.mode or "Character")
        if mode ~= "Vehicle" and mode ~= "Prop" and mode ~= "FX" and mode ~= "Attack" and mode ~= "Entity" then mode = "Character" end
        out.gridMarks[tostring(k)] = {
          active = true,
          itemId = v.itemId,
          entityID = v.entityID,
          record = tostring(v.record or out.record or ""),
          mode = mode,
          despawnAfterSeconds = tonumber(v.despawnAfterSeconds or out.despawnAfterSeconds or 0) or 0,
          xyz = type(v.xyz) == "table" and { x = tonumber(v.xyz.x or 0) or 0, y = tonumber(v.xyz.y or 0) or 0, z = tonumber(v.xyz.z or 0) or 0 } or nil,
        }
      end
    end
  end
  return out
end

local function _gridWorldPositionFromData(p, data, gx, gy)
  local pos, fx, fy, rx, ry = _playerBasisXZ(p)
  if not pos then return nil end
  local size = tonumber(data.gridSize or 11) or 11
  local half = math.floor(size / 2)
  local spacing = tonumber(data.gridSpacing or "2.0") or 2.0
  local zOffset = tonumber(data.gridZOffset or "0.05") or 0.05
  local dx = gx - half - 1
  local dy = half - gy + 1
  return Vector4.new(
    (pos.x or 0) + (rx * dx * spacing) + (fx * dy * spacing),
    (pos.y or 0) + (ry * dx * spacing) + (fy * dy * spacing),
    (pos.z or 0) + zOffset,
    1
  )
end

local function _spawnRecordWithMode(recordPath, overridePoint, modeOverride, despawnAfterSeconds)
  local st = SpawnTools.state
  local prevMode = st.mode
  local mode = (type(modeOverride) == "string" and modeOverride ~= "") and modeOverride or st.mode
  st.mode = mode
  local item, err = nil, nil
  if mode == 'FX' then
    item, err = _spawnFXAt(recordPath, overridePoint)
  elseif mode == 'Attack' then
    item, err = _spawnAttackAt(recordPath, overridePoint)
  elseif mode == 'Entity' then
    item, err = _spawnEntityTemplateAt(recordPath, overridePoint)
  else
    item, err = _spawnRecord(recordPath, overridePoint, mode)
  end
  st.mode = prevMode
  if item then _queueDespawnEntry(item, despawnAfterSeconds) end
  return item, err
end

function SpawnTools.GetCurrentGridData()
  return _normalizeSpawnGridData({
    mode = SpawnTools.state.mode,
    record = _selectedRecordText(),
    gridSize = SpawnTools.state.gridSize,
    gridSpacing = SpawnTools.state.gridSpacing,
    gridZOffset = SpawnTools.state.gridZOffset,
    gridMarks = _clone and _clone(SpawnTools.state.gridMarks or {}) or (SpawnTools.state.gridMarks or {}),
    despawnAfterSeconds = tonumber(SpawnTools.state.despawnAfterSeconds or 0) or 0,
    gridLiveSpawn = SpawnTools.state.gridLiveSpawn == true,
  })
end

function SpawnTools.SaveCurrentGridAsPreset(name)
  local trimmed = tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if trimmed == "" then return nil, "Enter a grid name first." end
  local data = SpawnTools.GetCurrentGridData()
  local hasAny = false
  if type(data) == "table" then
    if tostring(data.record or "") ~= "" then hasAny = true end
    if type(data.gridMarks) == "table" then
      for _, v in pairs(data.gridMarks) do
        if v == true or (type(v) == "table" and v.active == true and tostring(v.record or data.record or "") ~= "") then
          hasAny = true
          break
        end
      end
    end
  end
  if not hasAny then return nil, "Place at least one grid item or select a record first." end
  local asset = {
    type = "spawn_grid",
    name = trimmed,
    data = { source = "spawn_tools_grid", grid = data }
  }
  return (AssetRegistry.UpsertNew and AssetRegistry.UpsertNew(asset, trimmed)) or AssetRegistry.Upsert(asset)
end

function SpawnTools.LoadGridAsset(asset)
  if type(asset) ~= "table" or tostring(asset.type or "") ~= "spawn_grid" then return false, "Missing saved grid" end
  local data = _normalizeSpawnGridData((((asset or {}).data or {}).grid) or {})
  if type(data) ~= "table" then return false, "Invalid grid data" end
  local st = SpawnTools.state
  st.mode = data.mode
  st.recordInput = tostring(data.record or "")
  st.gridSize = data.gridSize
  st.gridSpacing = tostring(data.gridSpacing or "2.0")
  st.gridZOffset = tostring(data.gridZOffset or "0.05")
  st.gridMarks = data.gridMarks or {}
  st.despawnAfterSeconds = tonumber(data.despawnAfterSeconds or 0) or 0
  st.gridLiveSpawn = data.gridLiveSpawn == true
  st.gridPresetStatus = "Loaded grid: " .. tostring(asset.name or asset.id)
  return true, st.gridPresetStatus
end

function SpawnTools.ApplyGridData(data)
  local cfg = _normalizeSpawnGridData(data)
  if type(cfg) ~= "table" then return false end
  local p = _getPlayer()
  if not p then return false end
  local ran, activeCount = 0, 0
  for key, mark in pairs(cfg.gridMarks or {}) do
    local isActive = (mark == true) or (type(mark) == "table" and mark.active == true)
    if isActive then
      local gx, gy = key:match("^(%-?%d+):(%-?%d+)$")
      gx, gy = tonumber(gx), tonumber(gy)
      if gx and gy then
        local point = _gridWorldPositionFromData(p, cfg, gx, gy)
        local mode = tostring((type(mark) == "table" and mark.mode) or cfg.mode or "Character")
        local record = tostring((type(mark) == "table" and mark.record) or cfg.record or "")
        local despawn = tonumber((type(mark) == "table" and mark.despawnAfterSeconds) or cfg.despawnAfterSeconds or 0) or 0
        if point and record ~= "" then
          local item = _spawnRecordWithMode(record, point, mode, despawn)
          if item then ran = ran + 1 end
          activeCount = activeCount + 1
        end
      end
    end
  end
  if activeCount == 0 and tostring(cfg.record or "") ~= "" then
    local pos = _pcall(function() return p:GetWorldPosition() end)
    if pos then
      local point = Vector4.new(pos.x or 0, pos.y or 0, (pos.z or 0) + (tonumber(cfg.gridZOffset or "0.05") or 0.05), 1)
      local item = _spawnRecordWithMode(tostring(cfg.record), point, cfg.mode, cfg.despawnAfterSeconds)
      if item then ran = ran + 1 end
    end
  end
  return ran > 0
end

function SpawnTools.ApplyGridAsset(asset)
  if type(asset) ~= "table" or tostring(asset.type or "") ~= "spawn_grid" then return false end
  return SpawnTools.ApplyGridData((((asset or {}).data or {}).grid) or {})
end

local function _basisFromCenterAndForward(center, forward)
  local ct = type(center)
  if ct ~= "table" and ct ~= "userdata" then return nil end
  local fx = tonumber((forward or {}).x or 0) or 0
  local fy = tonumber((forward or {}).y or 0) or 0
  local flen = math.sqrt((fx * fx) + (fy * fy))
  if flen < 0.0001 then fx, fy, flen = 0, 1, 1 end
  fx, fy = fx / flen, fy / flen
  local rx, ry = -fy, fx
  return center, fx, fy, rx, ry
end

local function _gridWorldPositionFromCenter(center, forward, data, gx, gy)
  local pos, fx, fy, rx, ry = _basisFromCenterAndForward(center, forward)
  if not pos then return nil end
  local size = tonumber(data.gridSize or 11) or 11
  local half = math.floor(size / 2)
  local spacing = tonumber(data.gridSpacing or "2.0") or 2.0
  local zOffset = tonumber(data.gridZOffset or "0.05") or 0.05
  local dx = gx - half - 1
  local dy = half - gy + 1
  return Vector4.new(
    (pos.x or 0) + (rx * dx * spacing) + (fx * dy * spacing),
    (pos.y or 0) + (ry * dx * spacing) + (fy * dy * spacing),
    (pos.z or 0) + zOffset,
    1
  )
end

function SpawnTools.GetRecordsForMode(mode, search)
  _buildDB(false)
  local src = SpawnTools.state.characters or {}
  mode = tostring(mode or "Character")
  if mode == "Vehicle" then
    src = SpawnTools.state.vehicles or {}
  elseif mode == "Prop" then
    src = SpawnTools.state.props or {}
  elseif mode == "FX" then
    src = SpawnTools.state.fxPresets or {}
  elseif mode == "Attack" then
    src = SpawnTools.state.attacks or {}
  elseif mode == "Entity" then
    src = SpawnTools.state.entities or {}
  end
  if #src == 0 then
    _buildDB(true)
    if mode == "Vehicle" then
      src = SpawnTools.state.vehicles or {}
    elseif mode == "Prop" then
      src = SpawnTools.state.props or {}
    elseif mode == "FX" then
      src = SpawnTools.state.fxPresets or {}
    elseif mode == "Attack" then
      src = SpawnTools.state.attacks or {}
    elseif mode == "Entity" then
      src = SpawnTools.state.entities or {}
    else
      src = SpawnTools.state.characters or {}
    end
  end
  local low = string.lower(tostring(search or ""))
  if low == "" then
    local out = {}
    for i = 1, #src do out[#out + 1] = src[i] end
    return out
  end
  local out = {}
  for i = 1, #src do
    local v = src[i]
    if string.find(string.lower(v), low, 1, true) then out[#out + 1] = v end
  end
  return out
end

function SpawnTools.RefreshDB()
  local st = SpawnTools.state or {}
  st.dbBuilt = false
  _buildDB(true)
  return {
    characters = #(st.characters or {}),
    vehicles = #(st.vehicles or {}),
    props = #(st.props or {}),
    fx = #(st.fxPresets or {}),
    attacks = #(st.attacks or {}),
    entities = #(st.entities or {}),
  }
end

function SpawnTools.SpawnRecordAtPoint(record, mode, point, despawnAfterSeconds)
  local item, err = _spawnRecordWithMode(tostring(record or ""), point, tostring(mode or "Character"), despawnAfterSeconds)
  if item then return true, item end
  return false, tostring(err or "Could not spawn record.")
end

function SpawnTools.ApplyGridDataAtPoint(data, point, forward)
  local cfg = _normalizeSpawnGridData(data)
  if type(cfg) ~= "table" then return false end
  local pt = type(point)
  if pt ~= "table" and pt ~= "userdata" then return false end
  local ran, activeCount = 0, 0
  for key, mark in pairs(cfg.gridMarks or {}) do
    local isActive = (mark == true) or (type(mark) == "table" and mark.active == true)
    if isActive then
      local gx, gy = key:match("^(%-?%d+):(%-?%d+)$")
      gx, gy = tonumber(gx), tonumber(gy)
      if gx and gy then
        local worldPoint = _gridWorldPositionFromCenter(point, forward, cfg, gx, gy)
        local mode = tostring((type(mark) == "table" and mark.mode) or cfg.mode or "Character")
        local record = tostring((type(mark) == "table" and mark.record) or cfg.record or "")
        local despawn = tonumber((type(mark) == "table" and mark.despawnAfterSeconds) or cfg.despawnAfterSeconds or 0) or 0
        if worldPoint and record ~= "" then
          local item = _spawnRecordWithMode(record, worldPoint, mode, despawn)
          if item then ran = ran + 1 end
          activeCount = activeCount + 1
        end
      end
    end
  end
  if activeCount == 0 and tostring(cfg.record or "") ~= "" then
    local centerPoint = Vector4.new(point.x or 0, point.y or 0, (point.z or 0) + (tonumber(cfg.gridZOffset or "0.05") or 0.05), 1)
    local item = _spawnRecordWithMode(tostring(cfg.record), centerPoint, cfg.mode, cfg.despawnAfterSeconds)
    if item then ran = ran + 1 end
  end
  return ran > 0
end

function SpawnTools.ApplyGridAssetAtPoint(asset, point, forward)
  if type(asset) ~= "table" or tostring(asset.type or "") ~= "spawn_grid" then return false end
  return SpawnTools.ApplyGridDataAtPoint((((asset or {}).data or {}).grid) or {}, point, forward)
end

local function _drawSavedGridManager()
  local st = SpawnTools.state
  ImGui.Separator()
  ImGui.Text("Saved Grid Profiles")
  st.gridPresetName = _InputTextValue("Grid Name##spawn_grid_preset_name", st.gridPresetName or "", 128)
  if ImGui.Button("Save Current Grid") then
    local _, err = SpawnTools.SaveCurrentGridAsPreset(st.gridPresetName)
    st.gridPresetStatus = err or "Saved current grid."
  end
  if st.gridPresetStatus and st.gridPresetStatus ~= "" then
    ImGui.TextWrapped(tostring(st.gridPresetStatus))
  end
  local assets = AssetRegistry.List("spawn_grid")
  if #assets == 0 then
    ImGui.TextDisabled("No saved grids yet.")
    return
  end
  if ImGui.BeginChild("spawn_grid_assets", -1, 150, true) then
    for i = 1, #assets do
      local asset = assets[i]
      local data = _normalizeSpawnGridData((((asset or {}).data or {}).grid) or {}) or {}
      local label = tostring(asset.name or asset.id) .. " | " .. tostring(data.mode or "-")
      local selected = (st.gridSelectedAssetId == asset.id)
      if ImGui.Selectable(label .. "##saved_grid_" .. tostring(i), selected) then
        st.gridSelectedAssetId = asset.id
      end
      if ImGui.IsItemHovered() then
        ImGui.BeginTooltip()
        ImGui.TextWrapped(tostring(data.record or ""))
        ImGui.EndTooltip()
      end
    end
    ImGui.EndChild()
  end
  local asset = st.gridSelectedAssetId and AssetRegistry.Get(st.gridSelectedAssetId) or nil
  if asset then
    if ImGui.SmallButton("Load Selected Grid") then
      SpawnTools.LoadGridAsset(asset)
    end
    ImGui.SameLine()
    if ImGui.SmallButton("Spawn Selected Grid") then
      local ok = SpawnTools.ApplyGridAsset(asset)
      st.gridPresetStatus = ok and "Spawned selected grid." or "Could not spawn selected grid."
    end
    ImGui.SameLine()
    if ImGui.SmallButton("Delete Selected Grid") then
      AssetRegistry.Delete(asset.id)
      st.gridSelectedAssetId = nil
      st.gridPresetStatus = "Deleted saved grid."
    end
  end
end

_gridMarkData = function(key)
  local marks = SpawnTools.state.gridMarks or {}
  local mark = marks[key]
  if type(mark) == "table" then return mark end
  if mark == true then return { active = true } end
  return nil
end

_setGridMark = function(key, item, point, record, mode, despawnAfterSeconds)
  SpawnTools.state.gridMarks = SpawnTools.state.gridMarks or {}
  local resolvedMode = tostring(mode or (item and item.mode) or SpawnTools.state.mode or "Character")
  if resolvedMode ~= "Vehicle" and resolvedMode ~= "Prop" and resolvedMode ~= "FX" and resolvedMode ~= "Attack" and resolvedMode ~= "Entity" then resolvedMode = "Character" end
  SpawnTools.state.gridMarks[key] = {
    active = true,
    itemId = item and item.id or nil,
    entityID = item and item.entityID or nil,
    record = tostring(record or (item and item.record) or ""),
    mode = resolvedMode,
    despawnAfterSeconds = tonumber(despawnAfterSeconds or SpawnTools.state.despawnAfterSeconds or 0) or 0,
    xyz = {
      x = point and point.x or 0,
      y = point and point.y or 0,
      z = point and point.z or 0,
    },
  }
end

_gridMarkEntry = function(mark)
  if type(mark) ~= "table" then return nil end
  local itemId = mark.itemId
  local spawned = SpawnTools.state.spawned or {}
  if type(itemId) == "number" then
    for i = 1, #spawned do
      local e = spawned[i]
      if e and e.id == itemId then return e end
    end
  end
  local entityID = mark.entityID
  if entityID ~= nil then
    for i = 1, #spawned do
      local e = spawned[i]
      if e and e.entityID == entityID then return e end
    end
  end
  return nil
end

_clearGridMark = function(key)
  local marks = SpawnTools.state.gridMarks or {}
  local mark = marks[key]
  if type(mark) == "table" then
    local entry = _gridMarkEntry(mark)
    if entry then _despawnEntry(entry) end
  end
  marks[key] = nil
end

local function _gridButtonLabel(isCenter, mark)
  if isCenter then return _gridCenterGlyph() end
  if mark and mark.active then return _gridFilledGlyph() end
  return _gridEmptyGlyph()
end

local function _drawGridGlyphButton(label, size)
  local transparent = {0.00, 0.00, 0.00, 0.00}
  ImGui.PushStyleColor(ImGuiCol.Button, transparent[1], transparent[2], transparent[3], transparent[4])
  ImGui.PushStyleColor(ImGuiCol.ButtonHovered, transparent[1], transparent[2], transparent[3], transparent[4])
  ImGui.PushStyleColor(ImGuiCol.ButtonActive, transparent[1], transparent[2], transparent[3], transparent[4])
  ImGui.PushStyleColor(ImGuiCol.Border, transparent[1], transparent[2], transparent[3], transparent[4])
  ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, 0, 0)
  local clicked = ImGui.Button(label, size, size)
  ImGui.PopStyleVar(1)
  ImGui.PopStyleColor(4)
  return clicked
end

local function _drawGridCellTooltip(point, mark)
  if not point then return end
  ImGui.BeginTooltip()
  ImGui.Text(string.format("XYZ: %.2f, %.2f, %.2f", point.x or 0, point.y or 0, point.z or 0))
  local entry = _gridMarkEntry(mark)
  local record = nil
  if entry and type(entry.record) == "string" and entry.record ~= "" then
    record = entry.record
  elseif type(mark) == "table" and type(mark.record) == "string" and mark.record ~= "" then
    record = mark.record
  end
  if record and record ~= "" then
    ImGui.Text("TweakID: " .. tostring(record))
  else
    ImGui.TextDisabled("TweakID: <empty>")
  end
  local mode = (type(mark) == "table" and tostring(mark.mode or "")) or ""
  if mode ~= "" then ImGui.Text("Type: " .. tostring(mode)) end
  ImGui.EndTooltip()
end

local function _drawGridPlanner()
  local st = SpawnTools.state
  local size = tonumber(st.gridSize or 11) or 11
  if size < 5 then size = 5 end
  if size > 21 then size = 21 end
  if (size % 2) == 0 then size = size + 1 end
  st.gridSize = size

  ImGui.Text("Grid Spawn Planner")
  st.gridLiveSpawn = _checkboxValue("Spawn Live While Editing##grid_live_spawn", st.gridLiveSpawn == true)
  ImGui.TextDisabled(st.gridLiveSpawn and "Center cell is the player. Click any square to place and spawn the selected record immediately." or "Center cell is the player. Click any square to build the grid without spawning live.")
  ImGui.SameLine()
  ImGui.Text("Grid Despawn (sec)")
  ImGui.SameLine()
  ImGui.PushItemWidth(80)
  st.despawnAfterSeconds = tonumber(_InputTextValue("##grid_despawn_seconds", tostring(st.despawnAfterSeconds or 0), 32) or st.despawnAfterSeconds or 0) or 0
  ImGui.PopItemWidth()

  ImGui.PushItemWidth(95)
  st.gridSpacing = _InputTextValue("##grid_spacing", st.gridSpacing or "2.0", 32)
  ImGui.PopItemWidth()
  ImGui.SameLine()
  ImGui.Text("Cell Spacing (m)")
  ImGui.SameLine()
  ImGui.PushItemWidth(80)
  st.gridZOffset = _InputTextValue("##grid_z", st.gridZOffset or "0.05", 32)
  ImGui.PopItemWidth()
  ImGui.SameLine()
  ImGui.Text("Z Offset")
  ImGui.SameLine()
  ImGui.PushItemWidth(80)
  local sizeOptions = { "7", "9", "11", "13", "15" }
  local sizeText = tostring(size)
  sizeText = _comboValue("##grid_size", sizeText, sizeOptions)
  st.gridSize = tonumber(sizeText) or size
  ImGui.PopItemWidth()
  ImGui.SameLine()
  ImGui.Text("Grid Size")
  ImGui.SameLine()
  if ImGui.Button("Clear Grid Marks") then _clearGridMarks() end

  local center = math.floor(size / 2) + 1
  local cellSize = 22
  if ImGui.BeginChild("spawn_grid_planner", 0, math.min(360, (size * 24) + 12), true) then
    local p = _getPlayer()
    for gy = 1, size do
      for gx = 1, size do
        local key = _gridCellKey(gx, gy)
        local isCenter = (gx == center and gy == center)
        local mark = _gridMarkData(key)
        local worldPoint = p and _gridWorldPosition(p, gx, gy) or nil
        if gx > 1 then ImGui.SameLine() end
        ImGui.PushID(key)
        local clicked = _drawGridGlyphButton(_gridButtonLabel(isCenter, mark), cellSize)
        if clicked and not isCenter and worldPoint then
          local currentRecord = _selectedRecordText()
          if st.gridLiveSpawn == true then
            _spawnSelectedRecordAtPoint(worldPoint, key)
          else
            if mark and mark.active then
              _clearGridMark(key)
            elseif currentRecord ~= "" then
              _setGridMark(key, nil, worldPoint, currentRecord, st.mode, st.despawnAfterSeconds)
            end
          end
        end
        if ImGui.IsItemHovered() then
          _drawGridCellTooltip(worldPoint, mark)
        end
        if (not isCenter) and ImGui.BeginPopupContextItem("grid_ctx") then
          local hasEntry = (mark and mark.active) or false
          if hasEntry then
            if ImGui.MenuItem("Delete") then
              _clearGridMark(key)
            end
          else
            ImGui.TextDisabled("Nothing spawned here")
          end
          ImGui.EndPopup()
        end
        ImGui.PopID()
      end
    end
    ImGui.EndChild()
  end
  _drawSavedGridManager()
end

local function _drawGridSelectionPanel()
  local st = SpawnTools.state
  _buildDB()
  _refilter()

  ImGui.Text("Grid Spawn Selection")
  ImGui.TextDisabled("Change what the grid spawns without returning to the main window.")

  ImGui.PushItemWidth(180)
  st.mode = _comboValue("Type##grid_type", st.mode, { "Character", "Vehicle", "Prop", "FX", "Attack", "Entity" })
  ImGui.PopItemWidth()

  ImGui.Text((st.mode == "Prop") and "Custom Prop TweakDBID" or ((st.mode == "FX") and "FX Path" or ((st.mode == "Attack") and "Attack ID" or ((st.mode == "Entity") and ".ent Path" or "Custom Record ID"))))
  ImGui.PushItemWidth(-1)
  st.recordInput = _InputTextValue("##grid_record_id", st.recordInput or "", 256)
  ImGui.PopItemWidth()

  ImGui.Text("Search DB")
  ImGui.PushItemWidth(-1)
  st.search = _InputTextValue("##grid_spawn_search", st.search or "", 128)
  ImGui.PopItemWidth()

  _refilter()

  if ImGui.Button("Use Selected DB Record##grid_use_selected") then
    local rec = st.filtered[st.selectedDbIndex]
    if rec then st.recordInput = rec end
  end
  ImGui.SameLine()
  if ImGui.Button("Clear Input##grid_clear_input") then
    st.recordInput = ""
  end

  local activeRecord = _selectedRecordText()
  if activeRecord ~= "" then
    ImGui.Text("Selected: " .. tostring(activeRecord))
  else
    ImGui.TextDisabled("Selected: <none>")
  end

  ImGui.Text(st.mode .. " DB Results")
  ImGui.SameLine()
  ImGui.TextDisabled("(" .. tostring(#st.filtered) .. " results)")

  if ImGui.BeginChild("grid_db_list", 0, 0, true) then
    for i = 1, #st.filtered do
      local rec = st.filtered[i]
      local selected = (st.selectedDbIndex == i)
      local label = (st.mode == "Entity") and ((_entBasename(rec) or rec) .. "##grid_ent_" .. tostring(i)) or rec
      if ImGui.Selectable(label, selected) then
        st.selectedDbIndex = i
      end
      if st.mode == "Entity" and ImGui.IsItemHovered() then ImGui.BeginTooltip(); ImGui.TextWrapped(tostring(rec)); ImGui.EndTooltip() end
    end
    ImGui.EndChild()
  end
end

local function _drawSpawnerContent(uiState)
  local st = SpawnTools.state
  _buildDB()
  _refilter()

  local comboWidth = 210
  local inputWidth = 250

  ImGui.PushItemWidth(comboWidth)
  st.mode = _comboValue("Type", st.mode, { "Character", "Vehicle", "Prop", "FX", "Attack", "Entity" })
  ImGui.PopItemWidth()

  ImGui.SameLine()
  ImGui.Text((st.mode == "Prop") and "Custom Prop TweakDBID" or ((st.mode == "FX") and "FX Path" or ((st.mode == "Attack") and "Attack ID" or ((st.mode == "Entity") and ".ent Path" or "Custom Record ID"))))
  ImGui.SameLine()
  ImGui.PushItemWidth(inputWidth)
  st.recordInput = _InputTextValue("##spawn_record_id", st.recordInput or "", 256)
  ImGui.PopItemWidth()

  ImGui.SameLine()
  ImGui.Text("Search DB")
  ImGui.SameLine()
  ImGui.PushItemWidth(180)
  st.search = _InputTextValue("##spawn_search", st.search or "", 128)
  ImGui.PopItemWidth()

  ImGui.PushItemWidth(comboWidth)
  st.spawnLocation = _comboValue("Spawn Location", st.spawnLocation, {
    "In Front of Player",
    "At Crosshairs",
    "At My Location",
    "Custom XYZ",
  })
  ImGui.PopItemWidth()

  ImGui.SameLine()
  ImGui.Text("Despawn (sec)")
  ImGui.SameLine()
  ImGui.PushItemWidth(85)
  st.despawnAfterSeconds = tonumber(_InputTextValue("##spawn_despawn_seconds", tostring(st.despawnAfterSeconds or 0), 32) or st.despawnAfterSeconds or 0) or 0
  ImGui.PopItemWidth()

  if st.spawnLocation == "Custom XYZ" then
    ImGui.SameLine(); ImGui.Text("X"); ImGui.SameLine(); ImGui.PushItemWidth(95)
    st.customXYZ.x = _InputTextValue("##spawn_x", st.customXYZ.x or "0", 64)
    ImGui.PopItemWidth()
    ImGui.SameLine(); ImGui.Text("Y"); ImGui.SameLine(); ImGui.PushItemWidth(95)
    st.customXYZ.y = _InputTextValue("##spawn_y", st.customXYZ.y or "0", 64)
    ImGui.PopItemWidth()
    ImGui.SameLine(); ImGui.Text("Z"); ImGui.SameLine(); ImGui.PushItemWidth(95)
    st.customXYZ.z = _InputTextValue("##spawn_z", st.customXYZ.z or "0", 64)
    ImGui.PopItemWidth()
  end

  _refilter()

  if ImGui.Button("Use Selected DB Record") then
    local rec = st.filtered[st.selectedDbIndex]
    if rec then st.recordInput = rec end
  end
  ImGui.SameLine()
  if ImGui.Button("Spawn") then
    local _, err = _spawnSelectedRecordAtPoint(nil, nil)
    if err then st._presetStatus = "Spawn failed: " .. tostring(err) else st._presetStatus = st.spawnStatus end
  end
  ImGui.SameLine()
  if ImGui.Button("Despawn Selected") then _despawnSelected() end
  ImGui.SameLine()
  if ImGui.Button("Despawn All Spawned") then _despawnAll() end

  if st.spawnStatus and st.spawnStatus ~= "" then
    ImGui.TextWrapped(tostring(st.spawnStatus))
  end

  ImGui.Separator()
  ImGui.Text(st.mode .. " DB Results")
  ImGui.SameLine()
  ImGui.TextDisabled("(" .. tostring(#st.filtered) .. " results)")

  if ImGui.BeginChild("spawn_db_list", 0, 320, true) then
    for i = 1, #st.filtered do
      local rec = st.filtered[i]
      local selected = (st.selectedDbIndex == i)
      local label = (st.mode == "Entity") and ((_entBasename(rec) or rec) .. "##spawn_ent_" .. tostring(i)) or rec
      if ImGui.Selectable(label, selected) then st.selectedDbIndex = i end
      if st.mode == "Entity" and ImGui.IsItemHovered() then ImGui.BeginTooltip(); ImGui.TextWrapped(tostring(rec)); ImGui.EndTooltip() end
    end
    ImGui.EndChild()
  end

  if st.mode == "Vehicle" then
    ImGui.Separator()
    if ImGui.CollapsingHeader("Owned Vehicles") then
      local ok, note, owned = _scanOwnedVehicles()
      if not ok then
        ImGui.TextDisabled(tostring(note or "Unable to scan owned vehicles."))
      else
        ImGui.TextDisabled("Detected: " .. tostring(#owned))
        if ImGui.BeginChild("owned_vehicle_list", 0, 140, true) then
          for i = 1, #owned do
            local v = owned[i]
            local label = tostring(v.label or v.id) .. "##ownedveh_" .. tostring(i)
            if ImGui.Selectable(label, false) then
              st.mode = "Vehicle"
              st.recordInput = tostring(v.id or "")
            end
            ImGui.SameLine()
            ImGui.TextDisabled(tostring(v.id or ""))
          end
          ImGui.EndChild()
        end
      end
    end
  end


  ImGui.Separator()
  ImGui.Text("Spawned Entities")
  if ImGui.BeginChild("spawned_list", 0, 160, true) then
    for i = 1, #st.spawned do
      local e = st.spawned[i]
      local label = string.format("[%s] %s##spawn_%d", e.exists and "ON" or "OFF", tostring(e.record or "-"), i)
      if ImGui.Selectable(label, st.selectedSpawnIndex == i) then st.selectedSpawnIndex = i end
    end

    local e = st.spawned[st.selectedSpawnIndex]
    if e then
      ImGui.Separator()
      ImGui.Text("Selected Spawn")
      ImGui.Text("Type: " .. tostring(e.mode or "-"))
      ImGui.Text("Record: " .. tostring(e.record or "-"))
      ImGui.Text("Spawned At: " .. tostring(e.createdAtText or "-"))
      ImGui.Text("Exists: " .. tostring(e.exists):upper())
      ImGui.Text("Distance: " .. _fmtNum(e.distance))
      ImGui.Text("Speed: " .. _fmtNum(e.speed))
      ImGui.Text("Health: " .. _fmtNum(e.health))
      ImGui.Text(string.format("XYZ: %.2f, %.2f, %.2f", e.xyz.x or 0, e.xyz.y or 0, e.xyz.z or 0))
      if ImGui.Button("Despawn Selected Entity") then _despawnEntry(e) end
    end
    ImGui.EndChild()
  end
end

local function _drawSpawnPresetManager()
  local st = SpawnTools.state
  ImGui.TextWrapped("Save named spawn presets here. Automation reads these directly, so there is no separate import step.")
  ImGui.Separator()
  st.presetName = _InputTextValue("Preset Name##spawn_preset_name", st.presetName or "", 128)
  if ImGui.Button("Save Current Record as Preset") then
    local _, err = SpawnTools.SaveCurrentSelectionAsPreset(st.presetName)
    if err then st._presetStatus = tostring(err) else st._presetStatus = "Saved current record as a spawn preset." end
  end
  ImGui.SameLine()
  if ImGui.Button("Save Spawned Records as Preset") then
    local _, err = SpawnTools.SaveSpawnedAsPreset(st.presetName)
    if err then st._presetStatus = tostring(err) else st._presetStatus = "Saved spawned records as a spawn preset." end
  end
  if st._presetStatus and st._presetStatus ~= "" then
    ImGui.TextWrapped(st._presetStatus)
  end

  local presets = AssetRegistry.List("spawn_set")
  ImGui.Spacing()
  ImGui.Text("Saved Spawn Presets")
  if #presets == 0 then
    ImGui.TextDisabled("No spawn presets saved yet.")
    return
  end
  if ImGui.BeginTable("spawn_presets_tbl", 5, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("Preset")
    ImGui.TableSetupColumn("Source", ImGuiTableColumnFlags.WidthFixed, 110)
    ImGui.TableSetupColumn("Entries", ImGuiTableColumnFlags.WidthFixed, 60)
    ImGui.TableSetupColumn("Spawn", ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableSetupColumn("Delete", ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableHeadersRow()
    local deleteId = nil
    for i = 1, #presets do
      local asset = presets[i]
      local entries = (((asset or {}).data or {}).entries) or {}
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(tostring(asset.name or asset.id))
      if ImGui.IsItemHovered() and type(entries) == "table" then
        ImGui.BeginTooltip()
        local maxRows = math.min(#entries, 12)
        for j = 1, maxRows do
          local e = entries[j]
          ImGui.TextUnformatted(tostring(e.record or ""))
        end
        if #entries > maxRows then ImGui.TextUnformatted("...") end
        ImGui.EndTooltip()
      end
      ImGui.TableSetColumnIndex(1)
      ImGui.TextUnformatted(tostring((((asset or {}).data or {}).source) or "spawn_tools"))
      ImGui.TableSetColumnIndex(2)
      ImGui.TextUnformatted(tostring(#entries))
      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton("Spawn##spawnpreset_" .. tostring(asset.id)) then
        SpawnTools.ApplySpawnSet(entries)
        st._presetStatus = "Applied spawn preset."
      end
      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton("Delete##spawnpreset_del_" .. tostring(asset.id)) then deleteId = asset.id end
    end
    ImGui.EndTable()
    if deleteId then
      AssetRegistry.Delete(deleteId)
      st._presetStatus = "Deleted spawn preset."
    end
  end
end

function SpawnTools.DrawTab(uiState)
  local st = SpawnTools.state
  if ImGui.Button(st.showGridWindow and "Hide Grid Spawner" or "Open Grid Spawner") then
    st.showGridWindow = not st.showGridWindow
  end
  ImGui.SameLine()
  ImGui.TextDisabled("Grid planner opens in its own window.")
  ImGui.Separator()

  if _tabBarOpen("spawn_tools_inner_tabs") then
    if _tabItemOpen("Spawn Workspace") then
      _drawSpawnerContent(uiState)
      ImGui.EndTabItem()
    end
    if _tabItemOpen("Saved Presets") then
      _drawSpawnPresetManager()
      ImGui.EndTabItem()
    end
    ImGui.EndTabBar()
  else
    _drawSpawnerContent(uiState)
    ImGui.Separator()
    _drawSpawnPresetManager()
  end
end

function SpawnTools.DrawWindows(_)
  local st = SpawnTools.state
  if not st.showGridWindow then return end
  if type(ImGui.SetNextWindowSize) == "function" then
    ImGui.SetNextWindowSize(920, 760, ImGuiCond.FirstUseEver)
  end
  local open = ImGui.Begin("Grid Spawner", true)
  if open then
    if ImGui.Button("Hide Grid Spawner##hide_grid_spawner") then
      st.showGridWindow = false
    end
    ImGui.SameLine()
    ImGui.TextDisabled("Click glyphs to spawn at player-relative positions in real time.")
    ImGui.Separator()

    local availX = (ImGui.GetContentRegionAvail and ImGui.GetContentRegionAvail()) or 0
    local leftWidth = 360
    if type(availX) == "number" and availX > 700 then leftWidth = 380 end

    if ImGui.BeginChild("grid_window_left", leftWidth, 0, false) then
      _drawGridPlanner()
      ImGui.EndChild()
    end
    ImGui.SameLine()
    if ImGui.BeginChild("grid_window_right", 0, 0, false) then
      _drawGridSelectionPanel()
      ImGui.EndChild()
    end
  end
  ImGui.End()
end

return SpawnTools
