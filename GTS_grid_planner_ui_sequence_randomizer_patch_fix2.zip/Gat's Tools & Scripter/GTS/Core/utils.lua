local Utils = Utils or {}

function Utils.clone(value, seen)
  if type(value) ~= "table" then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do
    out[Utils.clone(k, seen)] = Utils.clone(v, seen)
  end
  return out
end

function Utils.checkboxValue(label, current)
  local a, b = ImGui.Checkbox(label, current == true)
  if type(a) == "boolean" and type(b) == "boolean" then
    if b == (a ~= current) then return a == true end
    if a == (b ~= current) then return b == true end
    return b == true
  end
  if type(a) == "boolean" then return a == true end
  if type(b) == "boolean" then return b == true end
  return current == true
end

function Utils.inputTextValue(label, value, size)
  local a, b = ImGui.InputText(label, value or "", size or 128)
  if type(a) == "string" and type(b) == "boolean" then return a end
  if type(a) == "boolean" and type(b) == "string" then return b end
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return value or ""
end

function Utils.inputFloatValue(label, value, step, fast, fmt)
  local a, b = ImGui.InputFloat(label, tonumber(value or 0) or 0, step or 0.05, fast or 0.25, fmt or "%.2f")
  if type(a) == "number" then return a end
  if type(b) == "number" then return b end
  return tonumber(value or 0) or 0
end

function Utils.inputIntValue(label, value, step, fast)
  local current = math.floor(tonumber(value or 0) or 0)
  local a, b = ImGui.InputInt(label, current, step or 1, fast or 10)
  if type(a) == "number" then return math.floor(a) end
  if type(b) == "number" then return math.floor(b) end
  return current
end

function Utils.comboSelect(label, currentValue, labels)
  if type(labels) ~= "table" or #labels == 0 then return currentValue end
  local current = currentValue
  local found = false
  for i = 1, #labels do
    if labels[i] == current then
      found = true
      break
    end
  end
  if not found then current = labels[1] end
  if ImGui.BeginCombo and ImGui.BeginCombo(label, tostring(current or "")) then
    for i = 1, #labels do
      local item = labels[i]
      local selected = (item == current)
      if ImGui.Selectable(item, selected) then current = item end
      if selected and ImGui.SetItemDefaultFocus then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  return current
end

-- ── GTS Universal Bookmark System ───────────────────────────────────────────
-- Stored as a global so all modules can read/write without re-requiring.
-- Keys: "type:id"  e.g. "stat:Health", "status_effect:BaseStatusEffect.Burning"
-- Values: { type, id, label, savedAt }
GTS_Bookmarks = GTS_Bookmarks or {}

local function _bmKey(itemType, itemId)
  return tostring(itemType or "item") .. ":" .. tostring(itemId or "")
end

function Utils.BmSet(itemType, itemId, label, on)
  local key = _bmKey(itemType, itemId)
  if on then
    GTS_Bookmarks[key] = {
      type    = tostring(itemType or "item"),
      id      = tostring(itemId or ""),
      label   = tostring(label or itemId or ""),
      savedAt = (os and os.date and os.date("%Y-%m-%d %H:%M")) or "",
    }
  else
    GTS_Bookmarks[key] = nil
  end
  -- Persist after every change so bookmarks survive mod reload
  local Persistence = _pcallRequire and _pcallRequire("GTS/Core/persistence")
    or (pcall(require, "GTS/Core/persistence") and require("GTS/Core/persistence") or nil)
  if Persistence and Persistence.SaveBookmarks then
    pcall(Persistence.SaveBookmarks)
  end
end

function Utils.BmToggle(itemType, itemId, label)
  Utils.BmSet(itemType, itemId, label, not Utils.BmIs(itemType, itemId))
end

function Utils.BmIs(itemType, itemId)
  return GTS_Bookmarks[_bmKey(itemType, itemId)] ~= nil
end

function Utils.BmList(itemType)
  local out = {}
  for _, v in pairs(GTS_Bookmarks) do
    if itemType == nil or tostring(v.type or "") == tostring(itemType) then
      out[#out + 1] = v
    end
  end
  table.sort(out, function(a, b)
    if tostring(a.type or "") ~= tostring(b.type or "") then
      return tostring(a.type or "") < tostring(b.type or "")
    end
    return tostring(a.label or a.id or "") < tostring(b.label or b.id or "")
  end)
  return out
end

-- Renders a Bookmark / BookmarkOutline SmallButton using IconGlyphs.
-- Returns true if now bookmarked.
function Utils.BmButton(itemType, itemId, label, uid)
  local on = Utils.BmIs(itemType, itemId)
  local gOn  = (type(IconGlyphs) == "table" and (IconGlyphs["Bookmark"] or IconGlyphs["BookmarkCheck"])) or "*"
  local gOff = (type(IconGlyphs) == "table" and (IconGlyphs["BookmarkOutline"] or IconGlyphs["BookmarkPlusOutline"])) or "o"
  local btnLbl = (on and gOn or gOff) .. "##bm_" .. tostring(uid or (tostring(itemType) .. tostring(itemId)))
  if ImGui.SmallButton(btnLbl) then
    Utils.BmToggle(itemType, itemId, label)
    on = not on
  end
  if ImGui.IsItemHovered() then
    ImGui.BeginTooltip()
    ImGui.TextUnformatted(on and "Remove bookmark" or "Bookmark this item")
    ImGui.EndTooltip()
  end
  return on
end

-- Magnify glyph for search fields (falls back to "?")
function Utils.GlyphMagnify()
  if type(IconGlyphs) == "table" then
    for _, k in ipairs({"Magnify","MagnifyPlus","MagnifyScan","Search"}) do
      local g = IconGlyphs[k]
      if g and g ~= "" and g ~= "?" and g ~= "S" then return g end
    end
  end
  return "?"
end
-- ────────────────────────────────────────────────────────────────────────────

return Utils
