local Guide = {
  id = "actions_conditions",
  title = "Conditions / Actions Guide",
}

local function _data(ctx)
  return ((((ctx or {}).draft) or {}).data) or {}
end

local function _conditionGroups(ctx) return _data(ctx).conditionGroups or {} end
local function _actionGroups(ctx) return _data(ctx).actionGroups or {} end
local function _firstCondition(ctx, index) local g = (_conditionGroups(ctx)[index or 1]) or {}; return ((g.conditions or {})[1]) end
local function _groupHasNoCondition(ctx) local c = _firstCondition(ctx, 1); return type(c) == "table" and tostring(c.kind or "") == "no_condition" end
local function _group2IsTargetNpc(ctx) local c = _firstCondition(ctx, 2); return type(c) == "table" and tostring(c.key or "") == "target_npc" end
local function _actionGroup1Message(ctx) local g = (_actionGroups(ctx)[1]) or {}; local a = ((g.actions or {})[1]); return type(a) == "table" and tostring(a.type or "") == "show_ui_message" and tostring(a.messageText or "") ~= "" end
local function _actionGroup2Kill(ctx) local g = (_actionGroups(ctx)[2]) or {}; local a = ((g.actions or {})[1]); return type(a) == "table" and tostring(a.type or "") == "force_kill_lookat_npc" end
local function _group2Assigned(ctx) local groups = _conditionGroups(ctx); local ag = (_actionGroups(ctx)[2]) or {}; local target = tostring((groups[2] or {}).id or ""); return target ~= "" and tostring(ag.conditionGroupId or "") == target end

function Guide.onStart(ctx, fw)
  if ctx and ctx.resetDraftForGuide then ctx.resetDraftForGuide("Guide - Conditions & Actions") end
  if fw and fw.RequestLocation then fw.RequestLocation("Scripter", "Rules") end
end

Guide.steps = {
  {
    id = "intro",
    title = "What Conditions and Actions are",
    body = "A Condition answers when a script is allowed to fire. An Action answers what the script does after its Conditions allow it. This guide walks you through one always-on message, then a second action that only runs when the looked-at target is an NPC.",
    expected = "Read the overview, then continue.",
    manualContinue = true,
    continueLabel = "Start Building",
    jump = { main = "Scripter", sub = "Rules" },
  },
  {
    id = "open_rules",
    title = "Open the Rules page",
    body = "The guide works inside Scripter > Rules.",
    expected = "Be on Scripter > Rules.",
    jump = { main = "Scripter", sub = "Rules" },
    check = function(ctx)
      return tostring((ctx or {}).mainTab or "") == "Scripter" and tostring((ctx or {}).subTab or "") == "Rules"
    end,
  },
  {
    id = "add_no_condition",
    title = "Add a No Condition line",
    body = "Start with a Condition Group that always passes. This is useful when you want a script branch to run without any qualifier at all.",
    expected = "Add a Condition row in Condition Group 1 and set it to No Condition.",
    allowedSections = { conditions = true },
    highlightIds = function(ctx)
      if not _firstCondition(ctx, 1) then return { "conditions.add_condition" } end
      if not _groupHasNoCondition(ctx) then return { "conditions.group_1.row_1.type", "conditions.group_1.row_1.type::No Condition" } end
      return {}
    end,
    check = function(ctx) return _groupHasNoCondition(ctx) end,
  },
  {
    id = "add_ui_message",
    title = "Add a UI message Action",
    body = "Now add one action to Group 1. Any message variant is fine, and any non-empty text is fine, as long as the action is a UI message.",
    expected = "Add an Action in Group 1, set it to Show UI Message, and enter any message text.",
    allowedSections = { actions = true, conditions = true },
    highlightIds = function(ctx)
      local g = (_actionGroups(ctx)[1]) or {}
      local a = ((g.actions or {})[1])
      if not a then return { "actions.add_action" } end
      if tostring(a.type or "") ~= "show_ui_message" then return { "actions.group_1.row_1.type", "actions.group_1.row_1.type::Show UI Message" } end
      if tostring(a.messageText or "") == "" then return { "actions.setup.message_text" } end
      return {}
    end,
    check = function(ctx) return _actionGroup1Message(ctx) end,
  },
  {
    id = "run_message",
    title = "Run the script and watch the message",
    body = "With No Condition in the first group, the message branch is allowed immediately. Press Run Now and confirm the UI message appears.",
    expected = "Press Run Now and wait for the UI message action to fire.",
    allowedSections = { actions = true, conditions = true },
    highlightIds = { "rules.run_now" },
    check = function(_, fw) local ev = fw and fw.GetLastRuntimeEvent and fw.GetLastRuntimeEvent() or nil; return type(ev) == "table" and tostring(ev.name or "") == "show_ui_message" end,
  },
  {
    id = "add_group_two",
    title = "Add a second Condition Group",
    body = "Now create a second Condition Group so the next action can be tied to a different qualifier.",
    expected = "Create Condition Group 2.",
    allowedSections = { conditions = true },
    highlightIds = { "conditions.add_group" },
    check = function(ctx) return #_conditionGroups(ctx) >= 2 end,
  },
  {
    id = "set_target_npc",
    title = "Set Condition Group 2 to Target Is NPC = TRUE",
    body = "This group should only pass when the looked-at target is an NPC.",
    expected = "Select Condition Group 2, add a Condition if needed, and set it to Target Is NPC.",
    allowedSections = { conditions = true },
    highlightIds = function(ctx)
      local g2 = (_conditionGroups(ctx)[2]) or {}
      if #((g2.conditions or {})) == 0 then return { "conditions.add_condition" } end
      if not _group2IsTargetNpc(ctx) then return { "conditions.group_2.row_1.type", "conditions.group_2.row_1.type::Condition: Target Is NPC" } end
      return {}
    end,
    check = function(ctx) return _group2IsTargetNpc(ctx) end,
  },
  {
    id = "add_kill_group",
    title = "Add a second Action Group tied to Condition Group 2",
    body = "Create another action group, assign it to Condition Group 2, and add Kill Looked-At NPC.",
    expected = "Group 2 should contain Force Kill Looked-At NPC and be assigned to Condition Group 2.",
    allowedSections = { actions = true, conditions = true },
    highlightIds = function(ctx)
      if #_actionGroups(ctx) < 2 then return { "actions.add_group" } end
      if not _group2Assigned(ctx) then return { "actions.group_2.condition_group" } end
      if not ((_actionGroups(ctx)[2] or {}).actions or {})[1] then return { "actions.add_action" } end
      if not _actionGroup2Kill(ctx) then return { "actions.group_2.row_1.type", "actions.group_2.row_1.type::Force Kill Looked-At NPC" } end
      return {}
    end,
    check = function(ctx) return #_actionGroups(ctx) >= 2 and _group2Assigned(ctx) and _actionGroup2Kill(ctx) end,
  },
}

return Guide
