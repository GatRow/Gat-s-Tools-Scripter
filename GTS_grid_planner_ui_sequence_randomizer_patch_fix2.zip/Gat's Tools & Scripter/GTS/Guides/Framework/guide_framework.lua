local Framework = {}

local state = {
  guides = {},
  activeId = nil,
  stepIndex = 1,
  currentLocation = { main = nil, sub = nil, section = nil },
  requestedLocation = nil,
  elements = {},
  hoveredId = nil,
  hoveredLabel = nil,
  lastInteraction = nil,
  lastRuntimeEvent = nil,
  pendingBlock = nil,
}

local function _now()
  return (os and os.clock and os.clock()) or 0
end

local function _guide()
  return state.activeId and state.guides[state.activeId] or nil
end

local function _step(ctx)
  local g = _guide()
  if not g or type(g.steps) ~= "table" then return nil end
  return g.steps[state.stepIndex]
end

local function _safeHovered()
  if not ImGui or not ImGui.IsItemHovered then return false end
  local ok, v = pcall(ImGui.IsItemHovered)
  return ok and v == true
end

local function _safeActive()
  if not ImGui or not ImGui.IsItemActive then return false end
  local ok, v = pcall(ImGui.IsItemActive)
  return ok and v == true
end

local function _getHighlightIds(step, ctx)
  if not step then return {} end
  local ids = step.highlightIds
  if type(ids) == "function" then
    local ok, out = pcall(ids, ctx, Framework)
    if ok and type(out) == "table" then return out end
    return {}
  end
  return type(ids) == "table" and ids or {}
end

local function _contains(list, value)
  if type(list) ~= "table" then return false end
  for i = 1, #list do if tostring(list[i]) == tostring(value) then return true end end
  return false
end

local function _stepComplete(ctx)
  local step = _step(ctx)
  if not step then return false end
  if step.manualContinue == true then return false end
  if type(step.check) ~= "function" then return false end
  local ok, done = pcall(step.check, ctx, Framework)
  return ok and done == true
end

local function _advance(ctx)
  local g = _guide()
  if not g or type(g.steps) ~= "table" then return end
  while true do
    local step = _step(ctx)
    if not step then break end
    if not _stepComplete(ctx) then break end
    state.stepIndex = state.stepIndex + 1
    local nextStep = _step(ctx)
    if nextStep and type(nextStep.onEnter) == "function" then pcall(nextStep.onEnter, ctx, Framework) end
    if not nextStep then break end
  end
end

function Framework.RegisterGuide(id, guide)
  if tostring(id or "") == "" or type(guide) ~= "table" then return end
  state.guides[tostring(id)] = guide
end

function Framework.StartGuide(id, ctx)
  local g = state.guides[tostring(id or "")]
  if type(g) ~= "table" then return false end
  state.activeId = tostring(id)
  state.stepIndex = 1
  state.lastInteraction = nil
  state.lastRuntimeEvent = nil
  state.pendingBlock = nil
  state.requestedLocation = nil
  state.elements = {}
  if type(g.onStart) == "function" then pcall(g.onStart, ctx, Framework) end
  local step = _step(ctx)
  if step and type(step.onEnter) == "function" then pcall(step.onEnter, ctx, Framework) end
  return true
end

function Framework.EndGuide()
  state.activeId = nil
  state.stepIndex = 1
  state.pendingBlock = nil
  state.requestedLocation = nil
  state.elements = {}
end

function Framework.CancelGuide()
  Framework.EndGuide()
end

function Framework.IsActive() return state.activeId ~= nil end
function Framework.GetCurrentStep() return _step(nil) end
function Framework.GetCurrentMainTab() return state.currentLocation.main end
function Framework.GetCurrentSubTab() return state.currentLocation.sub end
function Framework.GetCurrentSection() return state.currentLocation.section end
function Framework.GetHoveredElement() return state.hoveredId, state.hoveredLabel end
function Framework.GetElement(id) return state.elements[tostring(id or "")] end
function Framework.GetElements() return state.elements end

function Framework.SetLocation(main, sub, section)
  state.currentLocation.main = main
  state.currentLocation.sub = sub
  state.currentLocation.section = section
end

function Framework.RequestLocation(main, sub, section)
  state.requestedLocation = { main = main, sub = sub, section = section }
end

function Framework.OpenTab(main, sub, section)
  Framework.RequestLocation(main, sub, section)
end

function Framework.ConsumeRequestedLocation()
  local req = state.requestedLocation
  state.requestedLocation = nil
  return req
end

function Framework.RegisterElement(id, meta)
  if tostring(id or "") == "" then return end
  meta = type(meta) == "table" and meta or {}
  meta.hovered = _safeHovered()
  meta.active = _safeActive()
  state.elements[tostring(id)] = meta
  if meta.hovered then
    state.hoveredId = tostring(id)
    state.hoveredLabel = tostring(meta.label or id)
  end
end

function Framework.NoteInteraction(id, payload)
  state.lastInteraction = { id = tostring(id or ""), payload = payload, t = _now() }
end

function Framework.GetLastInteraction() return state.lastInteraction end

function Framework.NotifyRuntimeEvent(name, payload)
  state.lastRuntimeEvent = { name = tostring(name or ""), payload = payload, t = _now() }
end

function Framework.GetLastRuntimeEvent() return state.lastRuntimeEvent end

function Framework.ShouldHighlight(id, ctx)
  local step = _step(ctx)
  if not step then return false end
  return _contains(_getHighlightIds(step, ctx), tostring(id or ""))
end

function Framework.ShouldHighlightPrefix(prefix, ctx)
  local step = _step(ctx)
  if not step then return false end
  prefix = tostring(prefix or "")
  for _, value in ipairs(_getHighlightIds(step, ctx)) do
    value = tostring(value)
    if value:sub(1, #prefix) == prefix then return true end
  end
  return false
end

function Framework.PushHighlight(id, kind, ctx)
  if not Framework.ShouldHighlight(id, ctx) and not Framework.ShouldHighlightPrefix(tostring(id or "") .. "::", ctx) then return 0 end
  local t = _now()
  local pulse = 0.5 + 0.5 * math.sin(t * 6.0)
  local hot = 0.25 + pulse * 0.55
  local count = 0
  local function push(idx, r, g, b, a)
    if ImGui and ImGui.PushStyleColor then ImGui.PushStyleColor(idx, r, g, b, a); count = count + 1 end
  end
  kind = tostring(kind or "button")
  if kind == "text" then
    push(ImGuiCol.Text, 1.0, 0.82, hot, 1.0)
  elseif kind == "combo" or kind == "input" or kind == "frame" then
    push(ImGuiCol.FrameBg, 0.35, 0.20 + hot * 0.2, 0.05, 0.95)
    push(ImGuiCol.FrameBgHovered, 0.55, 0.30 + hot * 0.2, 0.08, 1.0)
    push(ImGuiCol.FrameBgActive, 0.75, 0.35 + hot * 0.2, 0.08, 1.0)
    push(ImGuiCol.Border, 1.0, 0.82, hot, 1.0)
  elseif kind == "selectable" then
    push(ImGuiCol.Header, 0.45, 0.25 + hot * 0.2, 0.08, 0.95)
    push(ImGuiCol.HeaderHovered, 0.75, 0.35 + hot * 0.2, 0.08, 1.0)
    push(ImGuiCol.HeaderActive, 0.90, 0.42 + hot * 0.2, 0.08, 1.0)
  else
    push(ImGuiCol.Button, 0.45, 0.25 + hot * 0.2, 0.08, 0.95)
    push(ImGuiCol.ButtonHovered, 0.75, 0.35 + hot * 0.2, 0.08, 1.0)
    push(ImGuiCol.ButtonActive, 0.90, 0.42 + hot * 0.2, 0.08, 1.0)
    push(ImGuiCol.Border, 1.0, 0.82, hot, 1.0)
    push(ImGuiCol.Text, 1.0, 0.95, 0.80 + pulse * 0.2, 1.0)
  end
  return count
end

function Framework.PopHighlight(count)
  count = tonumber(count or 0) or 0
  if count > 0 and ImGui and ImGui.PopStyleColor then ImGui.PopStyleColor(count) end
end

function Framework.IsSectionBlocked(section)
  local step = _step(nil)
  if not step or type(step.allowedSections) ~= "table" then return false end
  return step.allowedSections[tostring(section or "")] ~= true
end

function Framework.RequestBlockedEdit(section, label)
  state.pendingBlock = { section = tostring(section or ""), label = tostring(label or section or "this area") }
  if ImGui and ImGui.OpenPopup then ImGui.OpenPopup("Guide Continue Popup") end
end

local function _drawPopup()
  local beginOk = false
  if ImGui and ImGui.BeginPopupModal then
    local a, b = ImGui.BeginPopupModal("Guide Continue Popup", true)
    beginOk = (type(a) == "boolean" and a) or (type(b) == "boolean" and b) or false
  end
  if not beginOk then return end
  local p = state.pendingBlock or {}
  ImGui.TextWrapped("If you wish to continue the guide, editing " .. tostring(p.label or "this area") .. " outside of the guide will cause the guide to end.")
  ImGui.Spacing()
  if ImGui.Button("Continue Guide##guide_continue_popup") then
    state.pendingBlock = nil
    if ImGui.CloseCurrentPopup then ImGui.CloseCurrentPopup() end
  end
  ImGui.SameLine()
  if ImGui.Button("End Guide And Continue##guide_end_popup") then
    Framework.EndGuide()
    if ImGui.CloseCurrentPopup then ImGui.CloseCurrentPopup() end
  end
  ImGui.EndPopup()
end

function Framework.DrawDockedPanel(ctx)
  _advance(ctx)
  local g = _guide()
  if not g then _drawPopup(); return end
  local steps = g.steps or {}
  local step = _step(ctx)
  if not step then
    ImGui.Separator()
    ImGui.TextUnformatted((g.title or "Guide") .. " complete")
    ImGui.TextDisabled("You can end the guide or restart it from the launch button.")
    if ImGui.Button("End Guide##guide_end_complete") then Framework.EndGuide() end
    _drawPopup()
    return
  end

  ImGui.Separator()
  ImGui.TextUnformatted(tostring(g.title or "Guide"))
  ImGui.TextDisabled(string.format("Step %d of %d", state.stepIndex, #steps))
  ImGui.TextWrapped(tostring(step.title or ""))
  if tostring(step.body or "") ~= "" then ImGui.TextWrapped(tostring(step.body or "")) end
  if tostring(step.expected or "") ~= "" then
    ImGui.Spacing()
    ImGui.TextDisabled("Waiting for: " .. tostring(step.expected))
  end
  ImGui.Spacing()
  ImGui.TextDisabled("Page: " .. tostring(state.currentLocation.main or "-") .. " > " .. tostring(state.currentLocation.sub or "-"))
  if state.hoveredLabel then ImGui.TextDisabled("Hovering: " .. tostring(state.hoveredLabel)) end
  if step.jump and (state.currentLocation.main ~= step.jump.main or (step.jump.sub and state.currentLocation.sub ~= step.jump.sub)) then
    if ImGui.Button("Open " .. tostring(step.jump.main or "Tab") .. (step.jump.sub and (" > " .. tostring(step.jump.sub)) or "") .. "##guide_jump") then
      Framework.RequestLocation(step.jump.main, step.jump.sub, step.jump.section)
    end
  end
  if step.manualContinue == true then
    if ImGui.Button(tostring(step.continueLabel or "Continue") .. "##guide_continue") then
      state.stepIndex = state.stepIndex + 1
      local nextStep = _step(ctx)
      if nextStep and type(nextStep.onEnter) == "function" then pcall(nextStep.onEnter, ctx, Framework) end
    end
    ImGui.SameLine()
  end
  if ImGui.SmallButton("Cancel Guide##guide_cancel") then Framework.EndGuide() end
  _drawPopup()
end

return Framework
