-- GTS/Guides/stats_editor_guide.lua
-- Guided tutorial helper for the Stats Editor Cheat Impact Analyzer.

local Guide = {}

local state = {
  enabled = false,
  step = "baseline",
  godMode = false,
  noRecoil = false,
  ackedStep = nil,
  popupStep = nil,
  notice = nil,
  preferredExample = "god",
  lastExample = nil,
}

local tracked = {
  Armor = true,
  Health = true,
  ChemicalResistance = true,
  ElectricResistance = true,
  ExplosionResistance = true,
  HasFireproofSkin = true,
  RecoilKickMax = true,
  RecoilKickMin = true,
}

local baseline = {
  Armor = 100,
  Health = 400,
  ChemicalResistance = 0,
  ElectricResistance = 0,
  ExplosionResistance = 0,
  HasFireproofSkin = 0,
  RecoilKickMax = 1,
  RecoilKickMin = 1,
}

local function _checkboxValue(label, current)
  local a, b = ImGui.Checkbox(label, current == true)
  if type(a) == "boolean" and type(b) == "boolean" then
    if b == (a ~= current) then return a == true end
    if a == (b ~= current) then return b == true end
    return b == true
  end
  if type(a) == "boolean" then return a == true end
  if type(b) == "boolean" then return b == true end
  return current == true
end

local function _currentValue(name)
  local value = baseline[name]
  if value == nil then return nil end

  if state.godMode then
    if name == "Armor" then value = 99999 end
    if name == "Health" then value = 99999 end
    if name == "ChemicalResistance" then value = 100 end
    if name == "ElectricResistance" then value = 100 end
    if name == "ExplosionResistance" then value = 100 end
    if name == "HasFireproofSkin" then value = 1 end
  end

  if state.noRecoil then
    if name == "RecoilKickMax" then value = 0 end
    if name == "RecoilKickMin" then value = 0 end
  end

  return value
end

local function _stepTitle()
  if state.step == "baseline" then return "Step 1: Capture Baseline" end
  if state.step == "activate_mod" then return "Step 2: Turn a Mock Cheat ON and Capture Activated" end
  if state.step == "capture_off" then return "Step 3: Turn the Mock Cheat OFF and Capture Deactivated" end
  if state.step == "bookmark" then return "Step 4: Bookmark Important Results" end
  if state.step == "save_preset" then return "Step 5: Save the Scan as a Preset" end
  return "Guide Complete"
end

local function _stepText()
  if state.step == "baseline" then
    return table.concat({
      "The Cheat Impact Analyzer compares three snapshots of stats: baseline with the cheat OFF, activated with the cheat ON, and deactivated after it is turned back OFF.",
      "That makes it easy to see exactly what a cheat changed, what returned to normal, and what stayed modified after the cheat was disabled.",
      "For this example, leave both mock cheats OFF and press Capture Baseline in the Stats Editor.",
    }, "\n\n")
  elseif state.step == "activate_mod" then
    return table.concat({
      "Use the mock mod menu to enable God Mode or No Recoil, then press Capture Activated.",
      "The guide uses exact set targets, not additive values, so the ON snapshot shows the forced values while the cheat is active.",
      "This teaches you how to scan a cheat menu, not just how to read raw numbers.",
    }, "\n\n")
  elseif state.step == "capture_off" then
    return table.concat({
      "Turn the mock cheat back OFF and press Capture Deactivated.",
      "The OFF snapshot reveals which values returned to baseline and which remained changed after the cheat was disabled.",
    }, "\n\n")
  elseif state.step == "bookmark" then
    return table.concat({
      "The results table now shows the stats that changed while the cheat was ON.",
      "Bookmark the important rows so you can keep those discoveries visible later.",
      "A bookmark is a reference. The preset you save next is the reusable action built from those results.",
    }, "\n\n")
  elseif state.step == "save_preset" then
    return table.concat({
      "Enter a preset name and press Save Changed Results as Preset.",
      "This stores the scan's ON values as absolute set targets like Armor = 99999 or RecoilKickMax = 0.",
      "After saving, look in Saved Scan Presets below the analyzer to see the reusable result you just created.",
    }, "\n\n")
  end
  return table.concat({
    "Guide complete.",
    "You now have a saved preset built from analyzer results, and you can re-run the example from the practice buttons whenever you want.",
  }, "\n\n")
end

local function _setStep(stepName)
  state.step = stepName
  state.popupStep = nil
end

local function _closePopup()
  if ImGui and ImGui.CloseCurrentPopup then
    ImGui.CloseCurrentPopup()
  end
end

local function _openGuidePopupForStep()
  if state.notice then return end
  if state.popupStep == state.step then return end
  if ImGui and ImGui.OpenPopup then
    ImGui.OpenPopup("Stats Editor Guide Popup")
  end
  state.popupStep = state.step
end


local function _withTextColor(r, g, b, a, drawFn)
  if ImGui and ImGui.PushStyleColor then
    ImGui.PushStyleColor(ImGuiCol.Text, r, g, b, a or 1.0)
    drawFn()
    ImGui.PopStyleColor()
  else
    drawFn()
  end
end

local function _drawColoredWrapped(text, r, g, b, a)
  _withTextColor(r, g, b, a or 1.0, function()
    ImGui.TextWrapped(text)
  end)
end

local function _drawSectionTitle(text, kind)
  local colors = {
    info = {0.90, 0.82, 0.28, 1.0},
    error = {1.00, 0.28, 0.28, 1.0},
    success = {0.35, 0.95, 0.45, 1.0},
  }
  local c = colors[kind or "info"] or colors.info
  _withTextColor(c[1], c[2], c[3], c[4], function()
    ImGui.TextUnformatted("[ " .. tostring(text or "") .. " ]")
  end)
  ImGui.Separator()
end

local function _analyzerSummaryText()
  return table.concat({
    "The Cheat Impact Analyzer compares three snapshots of the same stats while a cheat is OFF, ON, and then OFF again.",
    "This lets you see exactly which values changed, which values returned to normal, and which values stayed modified after the cheat was disabled."
  }, "\n\n")
end

local function _drawProgressStrip()
  local steps = {
    { id = "baseline", label = "Baseline" },
    { id = "activate_mod", label = "Activated" },
    { id = "capture_off", label = "Deactivated" },
    { id = "bookmark", label = "Bookmark" },
    { id = "save_preset", label = "Save Preset" },
  }

  ImGui.BeginChild("##guide_progress", 0, 56, true)
  ImGui.TextUnformatted("Analyzer Flow")
  ImGui.Separator()
  for i = 1, #steps do
    local s = steps[i]
    local prefix = "[ ] "
    if s.id == state.step then
      prefix = "[>] "
    elseif state.step == "complete" or state.ackedStep == s.id then
      prefix = "[x] "
    end
    ImGui.TextUnformatted(prefix .. s.label)
    if i < #steps then
      ImGui.SameLine()
      ImGui.TextUnformatted(" -> ")
      ImGui.SameLine()
    end
  end
  ImGui.EndChild()
end

local function _drawGlossary()
  ImGui.BeginChild("##guide_glossary", 0, 108, true)
  _drawSectionTitle("QUICK REFERENCE", "info")
  ImGui.TextWrapped("BASELINE: cheat OFF reference snapshot.")
  ImGui.TextWrapped("ACTIVATED: cheat ON snapshot with the forced values visible.")
  ImGui.TextWrapped("DEACTIVATED: cheat OFF snapshot after the test.")
  ImGui.TextWrapped("BOOKMARKS: keep useful stats visible later.")
  ImGui.TextWrapped("PRESETS: save the ON values so you can apply them later without rescanning.")
  ImGui.EndChild()
end

function Guide.ShowNotice(title, text, kind)
  state.notice = {
    title = tostring(title or "Guide Hint"),
    text = tostring(text or ""),
    kind = tostring(kind or "error"),
  }
  if ImGui and ImGui.OpenPopup then
    ImGui.OpenPopup("Stats Editor Guide Popup")
  end
end

local function _popupPayload()
  if state.notice then
    return state.notice.title, state.notice.text, true
  end
  return _stepTitle(), _stepText(), false
end

local function _drawGuidePopup()
  if state.notice then
    if ImGui and ImGui.OpenPopup then
      ImGui.OpenPopup("Stats Editor Guide Popup")
    end
  else
    _openGuidePopupForStep()
  end

  local beginOk = false
  if ImGui and ImGui.BeginPopupModal then
    local ok1, ok2 = ImGui.BeginPopupModal("Stats Editor Guide Popup", true)
    if type(ok1) == "boolean" and type(ok2) == "boolean" then
      beginOk = ok1 or ok2
    elseif type(ok1) == "boolean" then
      beginOk = ok1
    else
      beginOk = false
    end
  else
    beginOk = ImGui.BeginPopup("Stats Editor Guide Popup")
  end

  if not beginOk then return end

  local title, text, isNotice = _popupPayload()
  local noticeKind = state.notice and state.notice.kind or "error"
  if isNotice then
    _drawSectionTitle(title, noticeKind == "error" and "error" or "info")
    if noticeKind == "error" then
      _drawColoredWrapped(text, 1.00, 0.28, 0.28, 1.0)
    else
      ImGui.TextWrapped(text)
    end
    ImGui.Spacing()
  else
    _drawSectionTitle("IMPACT ANALYZER", "info")
    ImGui.TextWrapped(_analyzerSummaryText())
    ImGui.Spacing()
    _drawSectionTitle(title, "success")
    ImGui.TextWrapped(text)
    ImGui.Spacing()
  end

  if not isNotice then
    if state.step == "activate_mod" then
      ImGui.BeginChild("##guide_example_cheats", 0, 76, true)
      _drawSectionTitle("EXAMPLE CHEAT OUTPUT", "info")
      ImGui.TextWrapped("God Mode sets Armor and Health to 99999, Chemical/Electric/Explosion Resistance to 100, and HasFireproofSkin to 1.")
      ImGui.TextWrapped("No Recoil sets RecoilKickMax and RecoilKickMin to 0.")
      ImGui.EndChild()
      ImGui.Spacing()
    elseif state.step == "bookmark" or state.step == "save_preset" then
      ImGui.BeginChild("##guide_result_meaning", 0, 96, true)
      _drawSectionTitle("HOW TO READ THE RESULT BUCKETS", "info")
      ImGui.TextWrapped("Increased when ON / Decreased when ON show what the cheat changed while active.")
      ImGui.TextWrapped("Returned to baseline after OFF means the cheat was temporary. Stayed changed after OFF means the change persisted after disable.")
      ImGui.EndChild()
      ImGui.Spacing()
    end
    _drawGlossary()
    ImGui.Spacing()
  end

  if ImGui.Button(isNotice and "Close##guide_notice_close" or "Understood##guide_confirm") then
    if isNotice then
      state.notice = nil
    else
      state.ackedStep = state.step
    end
    _closePopup()
  end
  ImGui.SameLine()
  if ImGui.Button("Disable Guide##guide_disable") then
    Guide.SetEnabled(false)
    state.notice = nil
    _closePopup()
  end

  ImGui.EndPopup()
end

function Guide.IsEnabled()
  return state.enabled == true
end

function Guide.GetStep()
  return state.step
end

function Guide.GetExpectedAction()
  if state.step == "baseline" then return "capture_baseline" end
  if state.step == "activate_mod" then return "capture_activated" end
  if state.step == "capture_off" then return "capture_deactivated" end
  if state.step == "bookmark" then return "bookmark_results" end
  if state.step == "save_preset" then return "save_preset" end
  return nil
end

function Guide.IsFocus(action)
  if not state.enabled then return false end
  return Guide.GetExpectedAction() == action
end

function Guide.CanPerform(action, ctx)
  if not state.enabled then return true end
  ctx = ctx or {}

  if state.ackedStep ~= state.step then
    return false, "Read and confirm the current guide popup before using that control."
  end

  if state.step == "complete" then
    return true
  end

  if action == "capture_baseline" then
    if state.step ~= "baseline" then
      return false, "Capture Baseline is not the current guide step. Follow the highlighted action order."
    end
    if state.godMode or state.noRecoil then
      return false, "For the baseline snapshot, leave both mock cheats OFF so the analyzer gets a clean before-state."
    end
    return true
  elseif action == "capture_activated" then
    if state.step ~= "activate_mod" then
      return false, "Capture Activated comes after the baseline snapshot."
    end
    if not state.godMode and not state.noRecoil then
      return false, "Enable God Mode or No Recoil in the mock mod menu before capturing the activated snapshot."
    end
    return true
  elseif action == "capture_deactivated" then
    if state.step ~= "capture_off" then
      return false, "Capture Deactivated only happens after the activated snapshot."
    end
    if state.godMode or state.noRecoil then
      return false, "Turn the mock cheat back OFF first so the deactivated snapshot can show what returned to baseline."
    end
    return true
  elseif action == "bookmark_results" then
    if state.step ~= "bookmark" then
      return false, "Bookmarking is not the current guide step yet."
    end
    if ctx.hasChangedRows == false then
      return false, "There are no changed analyzer rows to bookmark yet. Complete the three captures first."
    end
    return true
  elseif action == "save_preset" then
    if state.step ~= "save_preset" then
      return false, "Save the preset after you bookmark the important results."
    end
    if ctx.hasBookmarks == false then
      return false, "Bookmark at least one result first so you understand which stats you want to keep visible later."
    end
    if tostring(ctx.presetName or ""):match("^%s*$") then
      return false, "Enter a preset name before saving the scan results."
    end
    if ctx.hasEntries == false then
      return false, "There are no changed analyzer results available to save yet."
    end
    return true
  end

  return true
end

function Guide.GetSuggestedPresetName()
  if state.godMode and state.noRecoil then return "Guide - Combined Scan" end
  if state.godMode then return "Guide - God Mode Scan" end
  if state.noRecoil then return "Guide - No Recoil Scan" end
  if state.lastExample == "god" or state.preferredExample == "god" then return "Guide - God Mode Scan" end
  if state.lastExample == "norecoil" or state.preferredExample == "norecoil" then return "Guide - No Recoil Scan" end
  return "Guide - Demo Scan"
end

function Guide.SetEnabled(enabled)
  state.enabled = enabled == true
  if state.enabled then
    Guide.Reset()
  else
    state.ackedStep = nil
    state.popupStep = nil
    state.notice = nil
  end
end

function Guide.Reset(example)
  state.godMode = false
  state.noRecoil = false
  state.ackedStep = nil
  state.notice = nil
  if example ~= nil then
    state.preferredExample = example
  end
  _setStep("baseline")
end

function Guide.Notify(eventName)
  if not state.enabled then return end
  if state.ackedStep ~= state.step then return end

  if eventName == "captured_baseline" and state.step == "baseline" then
    _setStep("activate_mod")
    state.ackedStep = nil
  elseif eventName == "captured_activated" and state.step == "activate_mod" then
    if state.godMode and state.noRecoil then state.lastExample = "combined"
    elseif state.godMode then state.lastExample = "god"
    elseif state.noRecoil then state.lastExample = "norecoil" end
    _setStep("capture_off")
    state.ackedStep = nil
  elseif eventName == "captured_deactivated" and state.step == "capture_off" then
    _setStep("bookmark")
    state.ackedStep = nil
  elseif eventName == "bookmarked_results" and state.step == "bookmark" then
    _setStep("save_preset")
    state.ackedStep = nil
  elseif eventName == "saved_preset" then
    _setStep("complete")
    state.ackedStep = nil
  end
end

function Guide.ShouldTrackStat(name)
  return tracked[name] == true
end

function Guide.GetMockStatValue(name, liveValue)
  if not state.enabled or not tracked[name] then
    return false, liveValue
  end
  return true, _currentValue(name)
end

function Guide.DrawWindows()
  if not state.enabled then return end

  _drawGuidePopup()

  ImGui.SetNextWindowSize(380, 250, ImGuiCond.FirstUseEver)
  ImGui.Begin("Guide: Mock Mod Menu")
  ImGui.TextUnformatted("Example Mod Menu")
  ImGui.Separator()
  ImGui.TextWrapped("Use this mock trainer to simulate a cheat menu while learning the Cheat Impact Analyzer.")
  ImGui.Spacing()
  ImGui.BeginChild("##mock_mod_menu_list", 0, 132, true)

  ImGui.TextUnformatted("Player Cheats")
  ImGui.Separator()

  local locked = (state.ackedStep ~= state.step)
  if locked then
    ImGui.TextWrapped("Confirm the guide popup before interacting with the mock menu.")
    ImGui.Separator()
  elseif state.step == "activate_mod" and state.preferredExample and state.preferredExample ~= "free" then
    local tip = (state.preferredExample == "god") and "Practice target: God Mode" or (state.preferredExample == "norecoil" and "Practice target: No Recoil" or nil)
    if tip then
      ImGui.TextWrapped(tip)
      ImGui.Separator()
    end
  end

  if locked then
    ImGui.TextDisabled("[ ] God Mode")
    ImGui.SameLine()
    ImGui.TextDisabled("Disabled")
    ImGui.TextWrapped("Sets survivability stats to fixed demo values when enabled.")
    ImGui.Separator()
    ImGui.TextDisabled("[ ] No Recoil")
    ImGui.SameLine()
    ImGui.TextDisabled("Disabled")
    ImGui.TextWrapped("Sets recoil stats to exact zero values when enabled.")
  else
    state.godMode = _checkboxValue("God Mode##mock_godmode", state.godMode)
    ImGui.SameLine()
    ImGui.TextUnformatted(state.godMode and "Enabled" or "Disabled")
    ImGui.TextWrapped("Sets survivability stats to fixed demo values when enabled.")
    ImGui.Separator()
    state.noRecoil = _checkboxValue("No Recoil##mock_norecoil", state.noRecoil)
    ImGui.SameLine()
    ImGui.TextUnformatted(state.noRecoil and "Enabled" or "Disabled")
    ImGui.TextWrapped("Sets recoil stats to exact zero values when enabled.")
  end

  ImGui.EndChild()
  ImGui.Spacing()
  ImGui.TextWrapped("This mock menu does not modify the player's real build. It only feeds tutorial values into the analyzer for the guide.")
  if state.step == "complete" then
    ImGui.Separator()
    ImGui.TextUnformatted("Practice Mode")
    if ImGui.SmallButton("Practice God Mode") then Guide.Reset("god") end
    ImGui.SameLine()
    if ImGui.SmallButton("Practice No Recoil") then Guide.Reset("norecoil") end
    ImGui.SameLine()
    if ImGui.SmallButton("Free Practice") then Guide.Reset("free") end
  end
  ImGui.End()
end

return Guide
