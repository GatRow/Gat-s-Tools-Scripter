local SettingsTab = {}

local function _loadSharedUIState()
  local defaults = {
    compact = false,
    colors = true,
    keepMenuOpenWhenOverlayClosed = false,
    keepMacroDebugOpenWhenOverlayClosed = false,
  }

  local ok, mod = pcall(require, "GTS/UI/main_ui_settings")
  if not ok or type(mod) ~= "table" then
    if not ok then
      print("[GTS] Failed to load module 'GTS/UI/main_ui_settings' from settings tab: " .. tostring(mod))
    end
    return defaults
  end

  if mod.compact == nil then mod.compact = defaults.compact end
  if mod.colors == nil then mod.colors = defaults.colors end
  if mod.keepMenuOpenWhenOverlayClosed == nil then
    mod.keepMenuOpenWhenOverlayClosed = defaults.keepMenuOpenWhenOverlayClosed
  end
  if mod.keepMacroDebugOpenWhenOverlayClosed == nil then
    mod.keepMacroDebugOpenWhenOverlayClosed = defaults.keepMacroDebugOpenWhenOverlayClosed
  end

  mod.compact = mod.compact == true
  mod.colors = mod.colors ~= false
  mod.keepMenuOpenWhenOverlayClosed = mod.keepMenuOpenWhenOverlayClosed == true
  mod.keepMacroDebugOpenWhenOverlayClosed = mod.keepMacroDebugOpenWhenOverlayClosed == true

  return mod
end

local Shared = _loadSharedUIState()

local function _checkboxValue(label, current)
  local a, b = ImGui.Checkbox(label, current == true)

  if type(a) == "boolean" and type(b) == "boolean" then
    if b == (a ~= current) then return a == true end
    if a == (b ~= current) then return b == true end
    return b == true
  end

  if type(a) == "boolean" then return a == true end
  if type(b) == "boolean" then return b == true end
  return current == true
end

function SettingsTab.ShouldKeepMenuOpen()
  return Shared.keepMenuOpenWhenOverlayClosed == true
end

function SettingsTab.OnOverlayStateChanged(_) end
function SettingsTab.OnUpdate(_) end

function SettingsTab.DrawTab(_)
  ImGui.Separator()
  ImGui.Text("Settings")

  Shared.keepMenuOpenWhenOverlayClosed = _checkboxValue(
    "Keep Menu Open While CET Overlay Is Closed",
    Shared.keepMenuOpenWhenOverlayClosed
  )

  Shared.compact = _checkboxValue("Compact Mode", Shared.compact)
  Shared.colors  = _checkboxValue("Colors On / Off", Shared.colors)
  Shared.keepMacroDebugOpenWhenOverlayClosed = _checkboxValue(
    "Keep Scripter Debug Open While CET Overlay Is Closed",
    Shared.keepMacroDebugOpenWhenOverlayClosed
  )

  ImGui.Spacing()
  ImGui.TextWrapped(
    "These settings are session-only. They stay in memory while the game is running and are not written to disk."
  )

  ImGui.Spacing()
  ImGui.Separator()
  ImGui.Text("Keep Menu Open: " .. tostring(Shared.keepMenuOpenWhenOverlayClosed):upper())
  ImGui.Text("Compact Mode: " .. tostring(Shared.compact):upper())
  ImGui.Text("Colors Enabled: " .. tostring(Shared.colors):upper())
  ImGui.Text("Keep Scripter Debug Open: " .. tostring(Shared.keepMacroDebugOpenWhenOverlayClosed):upper())
end

return SettingsTab
