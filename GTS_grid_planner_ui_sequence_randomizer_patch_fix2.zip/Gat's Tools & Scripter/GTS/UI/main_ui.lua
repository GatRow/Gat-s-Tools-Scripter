-- GTS/main_ui.lua
-- Unified UI: Create / Tools / Saved / Settings tabs
print("[GTS] GTS/main_ui.lua loaded")

local Utils = require("GTS/Core/utils")

local function _clearLoaded(name)
  if type(package) == "table" and type(package.loaded) == "table" then
    package.loaded[name] = nil
  end
end

local function _safeRequire(name)
  _clearLoaded(name)
  local ok, mod = pcall(require, name)
  if ok then return mod, nil end
  print("[GTS] Failed to load '" .. tostring(name) .. "': " .. tostring(mod))
  return nil, tostring(mod)
end

local function _loadSharedUIState()
  local defaults = {
    compact                              = false,
    colors                               = true,
    keepMenuOpenWhenOverlayClosed        = false,
    keepMacroDebugOpenWhenOverlayClosed  = false,
    menuBgAlpha                          = 0.96,
    slowTimeWhileOverlayOpen             = false,
    slowTimeFactor                       = 0.15,
    pauseWhileOverlayOpen                = false,
    poseSearchLimit                      = 500,
    lastPoseRig                          = "Player Man",
    playerSubtab                         = "Stats Editor",
    createSubtab                         = "Scripter",
    toolsSubtab                          = "Spawn Tools",
    themeR                               = 0.65,
    themeG                               = 0.08,
    themeB                               = 0.08,
    themeA                               = 1.00,
  }
  local ok, mod = pcall(require, "GTS/UI/main_ui_settings")
  if not ok or type(mod) ~= "table" then return defaults end
  for k, v in pairs(defaults) do
    if mod[k] == nil then mod[k] = v end
  end
  mod.compact    = mod.compact == true
  mod.colors     = mod.colors ~= false
  mod.keepMenuOpenWhenOverlayClosed       = mod.keepMenuOpenWhenOverlayClosed == true
  mod.keepMacroDebugOpenWhenOverlayClosed = mod.keepMacroDebugOpenWhenOverlayClosed == true
  mod.menuBgAlpha = tonumber(mod.menuBgAlpha)
  if mod.menuBgAlpha == nil then mod.menuBgAlpha = defaults.menuBgAlpha end
  if mod.menuBgAlpha < 0.05 then mod.menuBgAlpha = 0.05 end
  if mod.menuBgAlpha > 1.00 then mod.menuBgAlpha = 1.00 end
  mod.slowTimeWhileOverlayOpen = mod.slowTimeWhileOverlayOpen == true
  mod.slowTimeFactor = tonumber(mod.slowTimeFactor)
  if mod.slowTimeFactor == nil then mod.slowTimeFactor = defaults.slowTimeFactor end
  if mod.slowTimeFactor < 0.02 then mod.slowTimeFactor = 0.02 end
  if mod.slowTimeFactor > 1.00 then mod.slowTimeFactor = 1.00 end
  mod.pauseWhileOverlayOpen = mod.pauseWhileOverlayOpen == true
  mod.poseSearchLimit = 500
  mod.lastPoseRig  = tostring(mod.lastPoseRig  or defaults.lastPoseRig)
  mod.playerSubtab = tostring(mod.playerSubtab or defaults.playerSubtab)
  mod.createSubtab = tostring(mod.createSubtab or defaults.createSubtab)
  mod.toolsSubtab  = tostring(mod.toolsSubtab  or defaults.toolsSubtab)
  mod.themeR = tonumber(mod.themeR) or defaults.themeR
  mod.themeG = tonumber(mod.themeG) or defaults.themeG
  mod.themeB = tonumber(mod.themeB) or defaults.themeB
  mod.themeA = tonumber(mod.themeA) or defaults.themeA
  return mod
end

local UIState       = _loadSharedUIState()
local AssetRegistry = require("GTS/Core/asset_registry")
local Persistence   = require("GTS/Core/persistence")

local checkboxValue = Utils.checkboxValue
local inputIntValue = Utils.inputIntValue

local function _persistUIState()
  if type(UIState) == "table" and type(UIState.Save) == "function" then
    UIState.Save(UIState)
  end
end

local function _settingsChanged(before, after)
  for _, k in ipairs({ "compact", "colors", "keepMenuOpenWhenOverlayClosed",
      "menuBgAlpha", "slowTimeWhileOverlayOpen", "slowTimeFactor",
      "pauseWhileOverlayOpen", "poseSearchLimit", "lastPoseRig",
      "playerSubtab", "createSubtab", "toolsSubtab", "themeR", "themeG", "themeB", "themeA" }) do
    if tostring(before[k]) ~= tostring(after[k]) then return true end
  end
  return false
end

-- ── Module loads ──────────────────────────────────────────────────────────────
local TargetService,    TargetServiceErr    = _safeRequire("GTS/Services/target_service")
local MoveObserver,     MoveObserverErr     = _safeRequire("GTS/Services/move_observer")
local StatsUI,          StatsUIErr          = _safeRequire("GTS/Builders/stats_browser")
local SpawnTools,       SpawnToolsErr       = _safeRequire("GTS/Tools/spawn_tools")
local InventoryTab,     InventoryTabErr     = _safeRequire("GTS/Tools/inventory_tab")
local RuleBuilder,      RuleBuilderErr      = _safeRequire("GTS/Builders/rule_builder")
local MacroBuilder,     MacroBuilderErr     = _safeRequire("GTS/Builders/macro_builder")
local CreatedTab,       CreatedTabErr       = _safeRequire("GTS/UI/created_tab")
local ShooterTab,       ShooterTabErr       = _safeRequire("GTS/Tools/shooter_tab")
local CameraActions,    CameraActionsErr    = _safeRequire("GTS/Actions/macro_actions_camera")
local TargetActions,    TargetActionsErr    = _safeRequire("GTS/Actions/macro_actions_target")
local TargetControl,    TargetControlErr    = _safeRequire("GTS/Tools/target_control")
local MenuMaker,        MenuMakerErr        = _safeRequire("GTS/Tools/MenuMaker/menu_maker")
local PoseBuilder,      PoseBuilderErr      = _safeRequire("GTS/Builders/pose_builder")
local ScenarioBuilder,  ScenarioBuilderErr  = _safeRequire("GTS/Builders/scenario_builder")
local WorldActions,     WorldActionsErr     = _safeRequire("GTS/Actions/macro_actions_world")
local GridPlanner,      GridPlannerErr      = _safeRequire("GTS/Tools/Grid/grid_planner")

-- ── Settings tab (inline, no separate module) ─────────────────────────────────
pcall(function()
  if Persistence and Persistence.LoadBookmarks then
    Persistence.LoadBookmarks()
  end
end)

local SettingsTab = {}
function SettingsTab.ShouldKeepMenuOpen() return UIState.keepMenuOpenWhenOverlayClosed == true end
function SettingsTab.OnOverlayStateChanged(_) end
function SettingsTab.OnUpdate(_) end
function SettingsTab.DrawTab(_)
  local before = {
    compact                              = UIState.compact,
    colors                               = UIState.colors,
    keepMenuOpenWhenOverlayClosed        = UIState.keepMenuOpenWhenOverlayClosed,
    menuBgAlpha                          = UIState.menuBgAlpha,
    slowTimeWhileOverlayOpen             = UIState.slowTimeWhileOverlayOpen,
    slowTimeFactor                       = UIState.slowTimeFactor,
    pauseWhileOverlayOpen                = UIState.pauseWhileOverlayOpen,
    poseSearchLimit                      = UIState.poseSearchLimit,
    lastPoseRig                          = UIState.lastPoseRig,
    playerSubtab                         = UIState.playerSubtab,
    createSubtab                         = UIState.createSubtab,
    toolsSubtab                          = UIState.toolsSubtab,
    themeR                               = UIState.themeR,
    themeG                               = UIState.themeG,
    themeB                               = UIState.themeB,
    themeA                               = UIState.themeA,
  }

  UIState.poseSearchLimit = 500

  ImGui.Separator()
  ImGui.Text("Settings")
  ImGui.Spacing()

  local defaultOpenFlags = (ImGuiTreeNodeFlags and ImGuiTreeNodeFlags.DefaultOpen) or 32

  if ImGui.CollapsingHeader("Overlay Settings", defaultOpenFlags) then
    UIState.keepMenuOpenWhenOverlayClosed = checkboxValue(
      "Keep window open when CET overlay closes", UIState.keepMenuOpenWhenOverlayClosed)
    UIState.slowTimeWhileOverlayOpen = checkboxValue(
      "Slow time while CET overlay is open", UIState.slowTimeWhileOverlayOpen)
    if UIState.slowTimeWhileOverlayOpen then
      local slowFactor, slowChanged = ImGui.SliderFloat(
        "Slow Time Factor", tonumber(UIState.slowTimeFactor or 0.15) or 0.15, 0.02, 1.00, "%.2f")
      if slowChanged then UIState.slowTimeFactor = slowFactor end
      ImGui.TextDisabled("Lower values run the world slower while the overlay is open.")
    end

    UIState.pauseWhileOverlayOpen = checkboxValue(
      "Pause while CET overlay is open", UIState.pauseWhileOverlayOpen)
    if UIState.pauseWhileOverlayOpen then
      ImGui.TextDisabled("GTS only resumes the game on close if GTS was the thing that paused it.")
    end
    if UIState.pauseWhileOverlayOpen and UIState.slowTimeWhileOverlayOpen then
      ImGui.TextDisabled("Pause takes priority over slow time while both are enabled.")
    end
  end

  if ImGui.CollapsingHeader("UI", defaultOpenFlags) then
    UIState.compact = checkboxValue("Compact window size", UIState.compact)
    UIState.colors  = checkboxValue("Enable custom colours", UIState.colors)

    local bgAlpha, bgChanged = ImGui.SliderFloat(
      "Background Transparency", tonumber(UIState.menuBgAlpha or 0.96) or 0.96, 0.05, 1.00, "%.2f")
    if bgChanged then UIState.menuBgAlpha = bgAlpha end
    ImGui.TextDisabled("This affects the main window and its background panels only. Popups, drop-downs, and hover surfaces stay solid.")

    if UIState.colors then
      ImGui.Spacing()
      ImGui.Text("Theme Colour")
      local r0, g0, b0 = UIState.themeR, UIState.themeG, UIState.themeB
      ImGui.PushItemWidth(260)
      local cr, rChanged = ImGui.SliderFloat("Red##theme_r",   r0, 0.0, 1.0, "R: %.2f")
      local cg, gChanged = ImGui.SliderFloat("Green##theme_g", g0, 0.0, 1.0, "G: %.2f")
      local cb, bChanged = ImGui.SliderFloat("Blue##theme_b",  b0, 0.0, 1.0, "B: %.2f")
      ImGui.PopItemWidth()
      if rChanged then UIState.themeR = cr end
      if gChanged then UIState.themeG = cg end
      if bChanged then UIState.themeB = cb end
      ImGui.TextColored(UIState.themeR, UIState.themeG, UIState.themeB, 1.0, "  >>>  Current accent colour")
      if ImGui.SmallButton("Reset##theme_reset") then
        UIState.themeR = 0.65
        UIState.themeG = 0.08
        UIState.themeB = 0.08
        UIState.themeA = 1.00
      end
    end
  end

  if ImGui.CollapsingHeader("Asset Persistence") then
    ImGui.Spacing()
    if ImGui.Button("Save Assets To Disk") then
      local ok, msg = AssetRegistry.SaveToDisk()
      print("[GTS] " .. tostring(msg or (ok and "Assets saved" or "Asset save failed")))
    end
    ImGui.SameLine()
    if ImGui.Button("Reload Assets From Disk") then
      local ok, msg = AssetRegistry.ReloadFromDisk()
      print("[GTS] " .. tostring(msg or (ok and "Assets reloaded" or "Asset reload failed")))
    end
    local info = AssetRegistry.GetPersistenceInfo and AssetRegistry.GetPersistenceInfo() or {}
    if info.lastSaveAt then ImGui.TextDisabled("Last saved: " .. tostring(info.lastSaveAt)) end
    if info.lastLoadAt then ImGui.TextDisabled("Last loaded: " .. tostring(info.lastLoadAt)) end
    if info.lastError  then ImGui.TextWrapped("Error: " .. tostring(info.lastError)) end
    ImGui.Spacing()
    ImGui.TextDisabled("User folder: " .. tostring(
      (Persistence.GetUserDir and Persistence.GetUserDir()) or "-"))
  end

  if _settingsChanged(before, UIState) then
    _persistUIState()
  end
end

-- ── UI state ──────────────────────────────────────────────────────────────────
local UI = {
  open        = true,
  state       = UIState,
  _justOpened = false,
  _lastAppliedCompact = nil,
  _overlayActive = false,
  _slowTimeActive = false,
  _slowTimeScale = nil,
  _pauseAppliedByGTS = false,
}

local function _isInWorld()
  local ok, player = pcall(function()
    return Game and Game.GetPlayer and Game.GetPlayer() or nil
  end)
  return ok and player ~= nil
end

local function _getTimeSystem()
  if Game and Game.GetTimeSystem then return Game.GetTimeSystem() end
  return nil
end

local function _getPauseHandler()
  local ok, handler = pcall(function()
    if GetSingleton == nil then return nil end
    local scenario = GetSingleton('inkMenuScenario')
    if scenario == nil or scenario.GetSystemRequestsHandler == nil then return nil end
    return scenario:GetSystemRequestsHandler()
  end)
  if ok then return handler end
  return nil
end

local function _clearOverlaySlowTime()
  if UI._slowTimeActive ~= true and UI._slowTimeScale == nil then return end

  if type(WorldActions) == "table" and type(WorldActions.ResetTimeDilation) == "function" then
    pcall(function() WorldActions.ResetTimeDilation() end)
  else
    local ts = _getTimeSystem()
    if ts ~= nil then
      pcall(function() ts:SetIgnoreTimeDilationOnLocalPlayerZero(false) end)
      if ts.UnsetTimeDilation ~= nil then
        pcall(function() ts:UnsetTimeDilation('consoleCommand') end)
      end
    end
  end

  UI._slowTimeActive = false
  UI._slowTimeScale = nil
end

local function _applyOverlaySlowTime(scale)
  if not _isInWorld() then return end

  local value = tonumber(scale or 0.15) or 0.15
  if value < 0.02 then value = 0.02 end
  if value > 1.00 then value = 1.00 end

  if UI._slowTimeActive == true and UI._slowTimeScale ~= nil and math.abs(UI._slowTimeScale - value) < 0.0001 then
    return
  end

  local applied = false
  if type(WorldActions) == "table" and type(WorldActions.SetTimeDilation) == "function" then
    local ok = pcall(function()
      local success = WorldActions.SetTimeDilation('world_only', value)
      applied = (success == true)
    end)
    if not ok then applied = false end
  else
    local ts = _getTimeSystem()
    if ts ~= nil and ts.SetTimeDilation ~= nil then
      local ok = pcall(function()
        pcall(function() ts:SetIgnoreTimeDilationOnLocalPlayerZero(true) end)
        ts:SetTimeDilation('consoleCommand', value)
      end)
      applied = ok == true
    end
  end

  if applied then
    UI._slowTimeActive = true
    UI._slowTimeScale = value
  end
end

local function _clearOverlayPause(force)
  if UI._pauseAppliedByGTS ~= true and force ~= true then return end
  local handler = _getPauseHandler()
  if handler ~= nil and handler.UnpauseGame ~= nil then
    pcall(function() handler:UnpauseGame() end)
  end
  UI._pauseAppliedByGTS = false
end

local function _applyOverlayPause()
  if not _isInWorld() then return end
  local handler = _getPauseHandler()
  if handler == nil or handler.PauseGame == nil then return end

  local alreadyPaused = false
  if handler.IsGamePaused ~= nil then
    pcall(function() alreadyPaused = handler:IsGamePaused() == true end)
  end
  if alreadyPaused == true then
    return
  end
  if UI._pauseAppliedByGTS == true then return end

  local ok = pcall(function() handler:PauseGame() end)
  if ok then UI._pauseAppliedByGTS = true end
end

local function _syncOverlayRuntimeEffects()
  local overlayActive = UI._overlayActive == true
  if not overlayActive then
    _clearOverlaySlowTime()
    _clearOverlayPause(false)
    return
  end

  if UIState.pauseWhileOverlayOpen == true then
    _clearOverlaySlowTime()
    _applyOverlayPause()
    return
  end

  _clearOverlayPause(false)

  if UIState.slowTimeWhileOverlayOpen == true then
    _applyOverlaySlowTime(UIState.slowTimeFactor)
  else
    _clearOverlaySlowTime()
  end
end

-- ── Helpers ───────────────────────────────────────────────────────────────────
local function _callIfTableMethod(mod, methodName, ...)
  if type(mod) == "table" and type(mod[methodName]) == "function" then
    local ok, err = pcall(mod[methodName], ...)
    if not ok then
      print("[GTS] " .. tostring(methodName) .. " error: " .. tostring(err))
    end
  end
end

local function _drawModuleError(label, err)
  ImGui.TextDisabled(label .. " module could not load.")
  if err and err ~= "" then
    ImGui.Spacing()
    ImGui.TextWrapped(tostring(err))
  end
end

local function _drawTabModuleChild(id, mod, methodName, label, err, ...)
  if type(ImGui.BeginChild) == "function" then
    ImGui.BeginChild("gts_tab_body_" .. tostring(id), 0, 0, false)
  end
  if type(mod) == "table" and type(mod[methodName]) == "function" then
    _callIfTableMethod(mod, methodName, ...)
  else
    _drawModuleError(label, err)
  end
  if type(ImGui.EndChild) == "function" then ImGui.EndChild() end
end

-- ── Colour theme ──────────────────────────────────────────────────────────────
-- ── Dynamic theme system ─────────────────────────────────────────────────────
-- Builds all colours from a single RGBA accent colour stored in UIState.
-- Tones: dark bg tints from the accent, mid accent for interactive elements,
-- bright accent for active/hover. Text stays near-white (not tinted).

local _THEME_PUSH_COUNT = 0

-- Convert 0-1 floats to CET ImGui uint32 (0xAABBGGRR little-endian ABGR).
local function _c(r, g, b, a)
  a = a or 1.0
  return math.floor(a*255+0.5)*16777216
       + math.floor(b*255+0.5)*65536
       + math.floor(g*255+0.5)*256
       + math.floor(r*255+0.5)
end

local _TITLE_PUSH_COUNT = 0

local function _pushTitleTheme()
  -- Title bar colour must be set before ImGui.Begin() to affect the title bar.
  if not UIState.colors then return end
  local R = tonumber(UIState.themeR) or 0.65
  local G = tonumber(UIState.themeG) or 0.08
  local B = tonumber(UIState.themeB) or 0.08
  _TITLE_PUSH_COUNT = 0
  ImGui.PushStyleColor(ImGuiCol.TitleBg,       _c(R*0.45, G*0.45, B*0.45, 1.00))
  ImGui.PushStyleColor(ImGuiCol.TitleBgActive, _c(R*0.65, G*0.65, B*0.65, 1.00))
  _TITLE_PUSH_COUNT = 2
end

local function _popTitleTheme()
  if _TITLE_PUSH_COUNT > 0 then
    pcall(ImGui.PopStyleColor, _TITLE_PUSH_COUNT)
    _TITLE_PUSH_COUNT = 0
  end
end

local _WINDOW_BG_PUSHED = false

local function _pushMainWindowBgTheme()
  local bgAlpha = tonumber(UIState.menuBgAlpha or 0.96) or 0.96
  if bgAlpha < 0.05 then bgAlpha = 0.05 end
  if bgAlpha > 1.00 then bgAlpha = 1.00 end

  local r, g, b = 0.06, 0.06, 0.06
  if UIState.colors then
    local R = tonumber(UIState.themeR) or 0.65
    local G = tonumber(UIState.themeG) or 0.08
    local B = tonumber(UIState.themeB) or 0.08
    r, g, b = R * 0.10, G * 0.10, B * 0.10
  end

  ImGui.PushStyleColor(ImGuiCol.WindowBg, _c(r, g, b, bgAlpha))
  _WINDOW_BG_PUSHED = true
end

local function _popMainWindowBgTheme()
  if _WINDOW_BG_PUSHED then
    pcall(ImGui.PopStyleColor, 1)
    _WINDOW_BG_PUSHED = false
  end
end

local function _pushTheme()
  if not UIState.colors then return end
  _THEME_PUSH_COUNT = 0

  -- Pull accent from UIState (user-configurable)
  local R = tonumber(UIState.themeR) or 0.65
  local G = tonumber(UIState.themeG) or 0.08
  local B = tonumber(UIState.themeB) or 0.08
  local A = tonumber(UIState.themeA) or 1.00
  local bgAlpha = tonumber(UIState.menuBgAlpha or 0.96) or 0.96
  if bgAlpha < 0.05 then bgAlpha = 0.05 end
  if bgAlpha > 1.00 then bgAlpha = 1.00 end

  -- Derive tonal scale from accent: dark bg, mid interactive, bright active
  local function bg(s)   return R*s,   G*s,   B*s,   1.00 end  -- very dark tint
  local function mid(s)  return R*s,   G*s,   B*s,   1.00 end  -- mid accent
  local function hi(s)   return R*s,   G*s,   B*s,   1.00 end  -- bright accent
  local function bdr(s)  return R*s,   G*s,   B*s,   1.00 end  -- border

  local cols = {
    -- Backgrounds: transparency should affect the main window and child panels,
    -- but not popups / drop-downs / hover surfaces.
    { ImGuiCol.ChildBg,            _c(R*0.12, G*0.12, B*0.12, bgAlpha) },
    { ImGuiCol.PopupBg,            _c(R*0.14, G*0.14, B*0.14, 1.00) },
    -- Frames (inputs, combos): slightly visible red tint
    { ImGuiCol.FrameBg,            _c(mid(0.22)) },
    { ImGuiCol.FrameBgHovered,     _c(mid(0.35)) },
    { ImGuiCol.FrameBgActive,      _c(mid(0.50)) },
    -- Tabs: dark base, red accent on hover/active
    { ImGuiCol.Tab,                _c(mid(0.18)) },
    { ImGuiCol.TabHovered,         _c(hi(0.70)) },
    { ImGuiCol.TabActive,          _c(hi(0.55)) },
    { ImGuiCol.TabUnfocused,       _c(bg(0.14)) },
    { ImGuiCol.TabUnfocusedActive, _c(mid(0.32)) },
    -- Title bar: solid red accent so header is visibly coloured
    -- TitleBg pushed before Begin() via _pushTitleTheme()
    -- Buttons: clear red hierarchy
    { ImGuiCol.Button,             _c(mid(0.30)) },
    { ImGuiCol.ButtonHovered,      _c(hi(0.60)) },
    { ImGuiCol.ButtonActive,       _c(hi(0.80)) },
    -- Selectables / tree nodes
    { ImGuiCol.Header,             _c(R*0.38, G*0.38, B*0.38, 0.55) },
    { ImGuiCol.HeaderHovered,      _c(R*0.55, G*0.55, B*0.55, 0.80) },
    { ImGuiCol.HeaderActive,       _c(hi(0.70)) },
    -- Scrollbar
    { ImGuiCol.ScrollbarBg,        _c(bg(0.08)) },
    { ImGuiCol.ScrollbarGrab,      _c(mid(0.32)) },
    { ImGuiCol.ScrollbarGrabHovered, _c(mid(0.50)) },
    { ImGuiCol.ScrollbarGrabActive,  _c(hi(0.68)) },
    -- Widgets: checkmark, slider — bright red
    { ImGuiCol.CheckMark,          _c(hi(1.00)) },
    { ImGuiCol.SliderGrab,         _c(hi(0.75)) },
    { ImGuiCol.SliderGrabActive,   _c(hi(0.95)) },
    -- Borders & separators: subtle red tint
    { ImGuiCol.Border,             _c(bdr(0.28)) },
    { ImGuiCol.Separator,          _c(bdr(0.24)) },
    { ImGuiCol.SeparatorHovered,   _c(bdr(0.55)) },
    { ImGuiCol.SeparatorActive,    _c(bdr(0.75)) },
    -- Tables
    { ImGuiCol.TableHeaderBg,      _c(mid(0.28)) },
    { ImGuiCol.TableBorderStrong,  _c(bdr(0.30)) },
    { ImGuiCol.TableBorderLight,   _c(bdr(0.18)) },
    { ImGuiCol.TableRowBgAlt,      _c(R*0.80, G*0.10, B*0.10, 0.04) },
    -- NOTE: Text / TextDisabled intentionally NOT themed —
    -- text stays default near-white so all content remains readable.
  }

  for _, pair in ipairs(cols) do
    local col_id, colour = pair[1], pair[2]
    if col_id and colour then
      ImGui.PushStyleColor(col_id, colour)
      _THEME_PUSH_COUNT = _THEME_PUSH_COUNT + 1
    end
  end
end

local function _popTheme()
  if _THEME_PUSH_COUNT > 0 then
    pcall(ImGui.PopStyleColor, _THEME_PUSH_COUNT)
    _THEME_PUSH_COUNT = 0
  end
end


-- ── Icon glyph helper-- ── Icon glyph helper ─────────────────────────────────────────────────────────
-- Tries common IconGlyphs key names in order; falls back to a text symbol.
local function _icon(candidates, fallback)
  if type(IconGlyphs) == "table" then
    for _, k in ipairs(candidates) do
      local g = IconGlyphs[k]
      if g ~= nil and g ~= "" and g ~= "?" and g ~= "S" then
        return g .. " "
      end
    end
  end
  return fallback and (fallback .. " ") or ""
end

local ICO_NEW     = function() return _icon({"PlusBox","PlusBoxOutline","Plus","PlusCircle"}, "+") end
local ICO_TOOLS   = function() return _icon({"Toolbox","ToolboxOutline","Wrench","WrenchOutline","Tools"}, "#") end
local ICO_SAVED   = function() return _icon({"ContentSave","ContentSaveOutline","Floppy","Save","FloppyDisk"}, "*") end
local ICO_SETTINGS= function() return _icon({"Cog","CogOutline","Settings","Gear"}, "=") end

-- ── Window sizing ─────────────────────────────────────────────────────────────
local function _applyWindowSize()
  local w = UIState.compact and 900  or 1140
  local h = UIState.compact and 640  or 760
  if type(ImGui.SetNextWindowSizeConstraints) == "function" then
    ImGui.SetNextWindowSizeConstraints(
      UIState.compact and 820 or 980,
      UIState.compact and 560 or 680,
      2600, 1800)
  end
  if UI._lastAppliedCompact ~= UIState.compact then
    ImGui.SetNextWindowSize(w, h, ImGuiCond.Always)
    UI._lastAppliedCompact = UIState.compact
  else
    ImGui.SetNextWindowSize(w, h, ImGuiCond.FirstUseEver)
  end
end

-- ── Tab helpers ───────────────────────────────────────────────────────────────
local function _tabBarOpen(id)
  if type(ImGui.BeginTabBar) ~= "function" then return false end
  local a, b = ImGui.BeginTabBar(id)
  if type(a) == "boolean" then return a end
  if type(b) == "boolean" then return b end
  return false
end

local function _tabItemOpen(label, selected)
  if type(ImGui.BeginTabItem) ~= "function" then return false end

  local flags = 0
  if selected == true and type(ImGuiTabItemFlags) == "table" and ImGuiTabItemFlags.SetSelected ~= nil then
    flags = ImGuiTabItemFlags.SetSelected
  end

  local ok, a, b
  if flags ~= 0 then
    ok, a, b = pcall(ImGui.BeginTabItem, label, nil, flags)
  else
    ok, a, b = pcall(ImGui.BeginTabItem, label)
  end

  if not ok then
    local c, d = ImGui.BeginTabItem(label)
    if type(c) == "boolean" and type(d) == "boolean" then return c or d end
    if type(c) == "boolean" then return c end
    if type(d) == "boolean" then return d end
    return false
  end

  if type(a) == "boolean" and type(b) == "boolean" then return a or b end
  if type(a) == "boolean" then return a end
  if type(b) == "boolean" then return b end
  return false
end

local function _selectSubtab(stateKey, value)
  if UIState[stateKey] ~= value then
    UIState[stateKey] = value
    _persistUIState()
  else
    UIState[stateKey] = value
  end
  return value
end

-- ── Event registrations ───────────────────────────────────────────────────────
_callIfTableMethod(TargetControl, "OnInit")
_callIfTableMethod(MenuMaker,     "OnInit")

registerForEvent("onUpdate", function(delta)
  _callIfTableMethod(TargetService,   "OnUpdate", delta)
  _callIfTableMethod(MoveObserver,    "OnUpdate", delta)
  _callIfTableMethod(StatsUI,         "OnUpdate", delta)
  _callIfTableMethod(SpawnTools,      "OnUpdate", delta)
  _callIfTableMethod(InventoryTab,    "OnUpdate", delta)
  _callIfTableMethod(RuleBuilder,     "OnUpdate", delta)
  _callIfTableMethod(MacroBuilder,    "OnUpdate", delta)
  _callIfTableMethod(CreatedTab,      "OnUpdate", delta)
  _callIfTableMethod(ShooterTab,      "OnUpdate", delta)
  _callIfTableMethod(CameraActions,   "OnUpdate", delta)
  _callIfTableMethod(TargetActions,   "OnUpdate", delta)
  _callIfTableMethod(TargetControl,   "OnUpdate", delta)
  _callIfTableMethod(MenuMaker,       "OnUpdate", delta)
  _callIfTableMethod(PoseBuilder,     "OnUpdate", delta)
  _callIfTableMethod(ScenarioBuilder, "OnUpdate", delta)
  _callIfTableMethod(SettingsTab,     "OnUpdate", delta)
  _callIfTableMethod(GridPlanner,     "OnUpdate", delta)
  _syncOverlayRuntimeEffects()
end)

registerForEvent("onOverlayOpen", function()
  UI.open = true
  UI._justOpened = true
  UI._overlayActive = true
  _syncOverlayRuntimeEffects()
  _callIfTableMethod(SettingsTab,  "OnOverlayStateChanged", true)
  _callIfTableMethod(TargetControl,"OnOverlayStateChanged", true)
  _callIfTableMethod(GridPlanner, "OnOverlayStateChanged", true)
  print("[GTS] overlay opened")
end)

registerForEvent("onOverlayClose", function()
  UI._overlayActive = false
  _syncOverlayRuntimeEffects()
  _callIfTableMethod(SettingsTab,  "OnOverlayStateChanged", false)
  _callIfTableMethod(TargetControl,"OnOverlayStateChanged", false)
  _callIfTableMethod(GridPlanner, "OnOverlayStateChanged", false)
  if type(SettingsTab.ShouldKeepMenuOpen) == "function" then
    local ok, keep = pcall(SettingsTab.ShouldKeepMenuOpen)
    UI.open = ok and keep == true or false
  else
    UI.open = false
  end
  print("[GTS] overlay closed")
end)

registerForEvent("onShutdown", function()
  UI._overlayActive = false
  _syncOverlayRuntimeEffects()
  _persistUIState()
  _callIfTableMethod(TargetControl,   "OnShutdown")
  _callIfTableMethod(PoseBuilder,     "OnShutdown")
  _callIfTableMethod(ScenarioBuilder, "OnShutdown")
end)

-- ── Main draw ─────────────────────────────────────────────────────────────────
registerForEvent("onDraw", function()
  if not UI.open then
    if UIState.keepMacroDebugOpenWhenOverlayClosed == true then
      _callIfTableMethod(RuleBuilder, "DrawWindows", UIState)
    end
    return
  end

  if UI._justOpened then
    ImGui.SetNextWindowCollapsed(false, ImGuiCond.Always)
    if ImGui.SetNextWindowFocus then ImGui.SetNextWindowFocus() end
    UI._justOpened = false
  end

  _applyWindowSize()

  -- Title bar and background must be pushed BEFORE Begin() to affect this window.
  _pushTitleTheme()
  _pushMainWindowBgTheme()
  ImGui.Begin("Gat's Tools & Scripter")
  _pushTheme()

  -- Gear popup in top-right
  local winW = ImGui.GetWindowWidth()
  ImGui.SameLine(winW - 42)
  if ImGui.SmallButton("[=]##settings_gear") then
    ImGui.OpenPopup("gts_settings_popup")
  end
  if ImGui.BeginPopup("gts_settings_popup") then
    local before = {
      compact = UIState.compact,
      colors = UIState.colors,
      keepMenuOpenWhenOverlayClosed = UIState.keepMenuOpenWhenOverlayClosed,
      menuBgAlpha = UIState.menuBgAlpha,
      slowTimeWhileOverlayOpen = UIState.slowTimeWhileOverlayOpen,
      slowTimeFactor = UIState.slowTimeFactor,
      pauseWhileOverlayOpen = UIState.pauseWhileOverlayOpen,
      poseSearchLimit = UIState.poseSearchLimit,
      themeR = UIState.themeR, themeG = UIState.themeG, themeB = UIState.themeB, themeA = UIState.themeA,
      lastPoseRig = UIState.lastPoseRig, playerSubtab = UIState.playerSubtab,
      createSubtab = UIState.createSubtab, toolsSubtab = UIState.toolsSubtab,
    }
    UIState.poseSearchLimit = 500
    ImGui.TextDisabled("Quick settings")
    UIState.keepMenuOpenWhenOverlayClosed = checkboxValue(
      "Keep window open when overlay closes##popup", UIState.keepMenuOpenWhenOverlayClosed)
    UIState.slowTimeWhileOverlayOpen = checkboxValue(
      "Slow time while overlay is open##popup", UIState.slowTimeWhileOverlayOpen)
    if UIState.slowTimeWhileOverlayOpen then
      local popupSlowFactor, popupSlowChanged = ImGui.SliderFloat(
        "Slow time factor##popup", tonumber(UIState.slowTimeFactor or 0.15) or 0.15, 0.02, 1.00, "%.2f")
      if popupSlowChanged then UIState.slowTimeFactor = popupSlowFactor end
    end
    UIState.pauseWhileOverlayOpen = checkboxValue(
      "Pause while overlay is open##popup", UIState.pauseWhileOverlayOpen)
    local popupBgAlpha, popupBgChanged = ImGui.SliderFloat(
      "Background transparency##popup", tonumber(UIState.menuBgAlpha or 0.96) or 0.96, 0.05, 1.00, "%.2f")
    if popupBgChanged then UIState.menuBgAlpha = popupBgAlpha end
    UIState.compact = checkboxValue("Compact window##popup", UIState.compact)
    UIState.colors  = checkboxValue("Custom colours##popup", UIState.colors)
    if _settingsChanged(before, UIState) then
      _persistUIState()
      if UI._overlayActive == true then
        _syncOverlayRuntimeEffects()
      end
    end
    ImGui.EndPopup()
  end

  ImGui.Separator()

  -- ── Top-level tab bar ───────────────────────────────────────────────────────
  if ImGui.BeginTabBar("gts_main_tabs") then

    -- ── NEW ──────────────────────────────────────────────────────────────
    if ImGui.BeginTabItem(ICO_NEW() .. "New") then
      local drewCreateSubtab = false
      if ImGui.BeginTabBar("gts_create_subtabs") then
        if ImGui.BeginTabItem("Scripter") then
          _selectSubtab("createSubtab", "Scripter")
          _drawTabModuleChild("scripter", RuleBuilder, "DrawTab", "Scripter", RuleBuilderErr, UIState)
          drewCreateSubtab = true
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem("Macros") then
          _selectSubtab("createSubtab", "Macros")
          _drawTabModuleChild("macros", MacroBuilder, "DrawTab", "Macros", MacroBuilderErr, UIState)
          drewCreateSubtab = true
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem("Scenario Builder") then
          _selectSubtab("createSubtab", "Scenario Builder")
          _drawTabModuleChild("scenario_builder", ScenarioBuilder, "DrawTab", "Scenario Builder", ScenarioBuilderErr, UIState)
          drewCreateSubtab = true
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem("Pose Builder") then
          _selectSubtab("createSubtab", "Pose Builder")
          _drawTabModuleChild("pose_builder", PoseBuilder, "DrawTab", "Pose Builder", PoseBuilderErr, UIState)
          drewCreateSubtab = true
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem("Stat Builders") then
          _selectSubtab("createSubtab", "Stat Builders")
          _drawTabModuleChild("player_stats", StatsUI, "DrawTab", "Stats", StatsUIErr, UIState)
          drewCreateSubtab = true
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem("Menu Builder") then
          _selectSubtab("createSubtab", "Menu Builder")
          _drawTabModuleChild("menu_maker", MenuMaker, "DrawTab", "Menu Builder", MenuMakerErr, UIState)
          drewCreateSubtab = true
          ImGui.EndTabItem()
        end
        ImGui.EndTabBar()
      end
      if not drewCreateSubtab then
        local createTab = tostring(UIState.createSubtab or "Scripter")
        if createTab == "Macros" then
          _drawTabModuleChild("macros", MacroBuilder, "DrawTab", "Macros", MacroBuilderErr, UIState)
        elseif createTab == "Scenario Builder" then
          _drawTabModuleChild("scenario_builder", ScenarioBuilder, "DrawTab", "Scenario Builder", ScenarioBuilderErr, UIState)
        elseif createTab == "Pose Builder" then
          _drawTabModuleChild("pose_builder", PoseBuilder, "DrawTab", "Pose Builder", PoseBuilderErr, UIState)
        elseif createTab == "Stat Builders" then
          _drawTabModuleChild("player_stats", StatsUI, "DrawTab", "Stats", StatsUIErr, UIState)
        elseif createTab == "Menu Builder" then
          _drawTabModuleChild("menu_maker", MenuMaker, "DrawTab", "Menu Builder", MenuMakerErr, UIState)
        else
          _drawTabModuleChild("scripter", RuleBuilder, "DrawTab", "Scripter", RuleBuilderErr, UIState)
        end
      end
      ImGui.EndTabItem()
    end

    -- ── TOOLS ───────────────────────────────────────────────────────────────
    if ImGui.BeginTabItem(ICO_TOOLS() .. "Tools") then
      local drewToolsSubtab = false
      if ImGui.BeginTabBar("gts_tools_subtabs") then
        if ImGui.BeginTabItem("Spawn Tools") then
          _selectSubtab("toolsSubtab", "Spawn Tools")
          _drawTabModuleChild("spawn_spawner", SpawnTools, "DrawTab", "Spawn Tools", SpawnToolsErr, UIState)
          drewToolsSubtab = true
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem("Grid Planner") then
          _selectSubtab("toolsSubtab", "Grid Planner")
          _drawTabModuleChild("grid_planner", GridPlanner, "DrawTab", "Grid Planner", GridPlannerErr, UIState)
          drewToolsSubtab = true
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem("Shooter") then
          _selectSubtab("toolsSubtab", "Shooter")
          _drawTabModuleChild("spawn_shooter", ShooterTab, "DrawTab", "Shooter", ShooterTabErr, UIState)
          drewToolsSubtab = true
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem("Target Control") then
          _selectSubtab("toolsSubtab", "Target Control")
          _drawTabModuleChild("target_control", TargetControl, "DrawTab", "Target Control", TargetControlErr, UIState)
          drewToolsSubtab = true
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem("Conditions") then
          _selectSubtab("toolsSubtab", "Conditions")
          _drawTabModuleChild("conditions", MoveObserver, "DrawTab", "Conditions", MoveObserverErr, UIState)
          drewToolsSubtab = true
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem("Inventory") then
          _selectSubtab("toolsSubtab", "Inventory")
          _drawTabModuleChild("tools_inventory", InventoryTab, "DrawTab", "Inventory", InventoryTabErr, UIState)
          drewToolsSubtab = true
          ImGui.EndTabItem()
        end
        ImGui.EndTabBar()
      end
      if not drewToolsSubtab then
        local toolsTab = tostring(UIState.toolsSubtab or "Spawn Tools")
        if toolsTab == "Grid Planner" then
          _drawTabModuleChild("grid_planner", GridPlanner, "DrawTab", "Grid Planner", GridPlannerErr, UIState)
        elseif toolsTab == "Shooter" then
          _drawTabModuleChild("spawn_shooter", ShooterTab, "DrawTab", "Shooter", ShooterTabErr, UIState)
        elseif toolsTab == "Target Control" then
          _drawTabModuleChild("target_control", TargetControl, "DrawTab", "Target Control", TargetControlErr, UIState)
        elseif toolsTab == "Conditions" then
          _drawTabModuleChild("conditions", MoveObserver, "DrawTab", "Conditions", MoveObserverErr, UIState)
        elseif toolsTab == "Inventory" then
          _drawTabModuleChild("tools_inventory", InventoryTab, "DrawTab", "Inventory", InventoryTabErr, UIState)
        else
          _drawTabModuleChild("spawn_spawner", SpawnTools, "DrawTab", "Spawn Tools", SpawnToolsErr, UIState)
        end
      end
      ImGui.EndTabItem()
    end

    -- ── SAVED ───────────────────────────────────────────────────────────────
    if ImGui.BeginTabItem(ICO_SAVED() .. "Saved") then
      _drawTabModuleChild("created", CreatedTab, "DrawTab",
        "Saved Assets", CreatedTabErr, UIState)
      ImGui.EndTabItem()
    end

    -- ── SETTINGS ────────────────────────────────────────────────────────────
    if ImGui.BeginTabItem(ICO_SETTINGS() .. "Settings") then
      _drawTabModuleChild("settings", SettingsTab, "DrawTab", "Settings", nil, UIState)
      ImGui.EndTabItem()
    end

    ImGui.EndTabBar()
  end

  _popTheme()
  ImGui.End()
  _popMainWindowBgTheme()
  _popTitleTheme()

  _callIfTableMethod(RuleBuilder, "DrawWindows", UIState)
  _callIfTableMethod(SpawnTools,  "DrawWindows", UIState)
  _callIfTableMethod(MenuMaker,   "DrawWindows", UIState)
end)

return UI
