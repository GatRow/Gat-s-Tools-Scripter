local AssetRegistry = require("GTS/Core/asset_registry")
local RuleRunner = require("GTS/Builders/rule_runner")
local Persistence = require("GTS/Core/persistence")

local CreatedTab = CreatedTab or {}

local function _runCreatedAssetSafe(assetId, desiredState)
  local ok, success, msg = pcall(RuleRunner.RunCreatedAssetById, assetId, desiredState)
  if not ok then return false, tostring(success or "Created asset runtime error") end
  return success == true, msg
end
CreatedTab.state = CreatedTab.state or { search = "", lastRunMessage = "" }

local function _displayAssetType(assetType)
  local key = tostring(assetType or "asset")
  if key == "observer_preset" then return "stat_condition" end
  if key == "stat_preset" then return "stat_profile" end
  return key
end

local function _checkboxValue(label, current)
  local a, b = ImGui.Checkbox(label, current == true)
  if type(a) == "boolean" and type(b) == "boolean" then
    if b == (a ~= current) then return a == true end
    if a == (b ~= current) then return b == true end
    return b == true
  end
  if type(a) == "boolean" then return a == true end
  if type(b) == "boolean" then return b == true end
  return current == true
end

local function _inputTextValue(label, value, size)
  local a, b = ImGui.InputText(label, value or "", size or 128)
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return value or ""
end

local function _tabBarOpen(id)
  if type(ImGui.BeginTabBar) ~= "function" then return false end
  local a, b = ImGui.BeginTabBar(id)
  if type(a) == "boolean" then return a end
  if type(b) == "boolean" then return b end
  return false
end

local function _tabItemOpen(label, selected)
  if type(ImGui.BeginTabItem) ~= "function" then return false end

  local flags = 0
  if selected == true and type(ImGuiTabItemFlags) == "table" and ImGuiTabItemFlags.SetSelected ~= nil then
    flags = ImGuiTabItemFlags.SetSelected
  end

  local ok, a, b
  if flags ~= 0 then
    ok, a, b = pcall(ImGui.BeginTabItem, label, nil, flags)
  else
    ok, a, b = pcall(ImGui.BeginTabItem, label)
  end

  if not ok then
    local c, d = ImGui.BeginTabItem(label)
    if type(c) == "boolean" and type(d) == "boolean" then return c or d end
    if type(c) == "boolean" then return c end
    if type(d) == "boolean" then return d end
    return false
  end

  if type(a) == "boolean" and type(b) == "boolean" then return a or b end
  if type(a) == "boolean" then return a end
  if type(b) == "boolean" then return b end
  return false
end

local function _matchesSearch(asset, needle)
  if needle == "" then return true end
  local hay = string.lower(string.format("%s %s %s", tostring(asset.type or ""), tostring(asset.name or ""), tostring(asset.id or "")))
  return string.find(hay, needle, 1, true) ~= nil
end

local function _assetHeader(asset)
  local t = _displayAssetType(asset.type or "asset")
  return string.format("[%s] %s", t, tostring(asset.name or asset.id or "asset"))
end

local function _runButton(asset)
  local t = tostring(asset.type or "")
  if t == "rule" then
    if ImGui.SmallButton("Run##created_run_" .. tostring(asset.id)) then local ok, msg = _runCreatedAssetSafe(asset.id, "run"); CreatedTab.state.lastRunMessage = tostring(msg or (ok and "Ran asset." or "Asset failed.")) end
    return
  end
  local mode = tostring((((asset or {}).data or {}).mode) or "button")
  if (t == "macro" or t == "custom_code" or t == "launcher") and mode == "toggle" then
    local enabled = RuleRunner.IsCreatedAssetEnabled(asset.id)
    if enabled then
      if ImGui.SmallButton("Turn OFF##created_off_" .. tostring(asset.id)) then
        local ok, msg = _runCreatedAssetSafe(asset.id, "off")
        CreatedTab.state.lastRunMessage = tostring(msg or (ok and "Turned asset off." or "Asset failed."))
      end
      ImGui.SameLine()
      ImGui.TextUnformatted("ON")
    else
      if ImGui.SmallButton("Turn ON##created_on_" .. tostring(asset.id)) then
        local ok, msg = _runCreatedAssetSafe(asset.id, "on")
        CreatedTab.state.lastRunMessage = tostring(msg or (ok and "Turned asset on." or "Asset failed."))
      end
      ImGui.SameLine()
      ImGui.TextUnformatted("OFF")
    end
  else
    if ImGui.SmallButton("Run##created_run_" .. tostring(asset.id)) then local ok, msg = _runCreatedAssetSafe(asset.id, "run"); CreatedTab.state.lastRunMessage = tostring(msg or (ok and "Ran asset." or "Asset failed.")) end
  end
end

local function _drawCategory(label, types)
  if not ImGui.CollapsingHeader(label .. "##created_cat") then return end
  local needle = string.lower(tostring(CreatedTab.state.search or ""))
  local items = AssetRegistry.ListCreatedAssets and AssetRegistry.ListCreatedAssets() or AssetRegistry.List() or {}
  local filtered = {}
  for i = 1, #items do
    local a = items[i]
    for j = 1, #types do
      if tostring(a.type or "") == tostring(types[j]) and _matchesSearch(a, needle) then filtered[#filtered + 1] = a break end
    end
  end
  if #filtered == 0 then ImGui.TextDisabled("None."); return end
  if ImGui.BeginTable("created_tbl_" .. label, 5, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("Name")
    ImGui.TableSetupColumn("Details")
    ImGui.TableSetupColumn("State / Run", ImGuiTableColumnFlags.WidthFixed, 120)
    ImGui.TableSetupColumn("Duplicate", ImGuiTableColumnFlags.WidthFixed, 80)
    ImGui.TableSetupColumn("Delete", ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableHeadersRow()
    for i = 1, #filtered do
      local asset = filtered[i]
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(_assetHeader(asset))
      ImGui.TableSetColumnIndex(1)
      if tostring(asset.type or "") == "rule" then
        local enabled = (((asset or {}).data or {}).enabled) ~= false
        local mutable = AssetRegistry.GetMutable(asset.id)
        local newEnabled = _checkboxValue("Enabled##rule_enabled_" .. tostring(asset.id), enabled)
        if mutable and mutable.data then mutable.data.enabled = newEnabled end
        ImGui.SameLine()
        ImGui.TextUnformatted(tostring((RuleRunner.GetStatus(asset.id) or {}).lastMessage or "Script"))
      elseif tostring(asset.type or "") == "teleport_preset" then
        local d = (asset.data or {})
        ImGui.TextUnformatted(string.format("%.2f, %.2f, %.2f", tonumber(d.x or 0) or 0, tonumber(d.y or 0) or 0, tonumber(d.z or 0) or 0))
      elseif tostring(asset.type or "") == "launcher" then
        ImGui.TextUnformatted(string.format("%d linked item(s)", #(((asset.data or {}).entries) or {})))
      elseif tostring(asset.type or "") == "animation_sequence" then
        ImGui.TextUnformatted(string.format("%d step(s)", #((((asset.data or {}).steps) or {}))) )
      elseif tostring(asset.type or "") == "scenario" then
        local d = (asset.data or {})
        ImGui.TextUnformatted(string.format("%s | %d entr%s", tostring(d.mode or 'relative'), #((d.entities) or {}), (#((d.entities) or {}) == 1 and 'y' or 'ies')))
      elseif tostring(asset.type or "") == "macro" then
        ImGui.TextUnformatted(string.format("%s | %s", tostring(((asset.data or {}).mode) or "toggle"), tostring(((asset.data or {}).offPolicy) or "none")))
      elseif tostring(asset.type or "") == "custom_code" then
        ImGui.TextUnformatted(string.format("%s code asset", tostring(((asset.data or {}).mode) or "button")))
      else
        ImGui.TextUnformatted(tostring((((asset or {}).data or {}).source) or asset.type or "asset"))
      end
      ImGui.TableSetColumnIndex(2)
      _runButton(asset)
      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton("Copy##created_dup_" .. tostring(asset.id)) then AssetRegistry.Duplicate(asset.id) end
      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton("Delete##created_del_" .. tostring(asset.id)) then AssetRegistry.Delete(asset.id) end
    end
    ImGui.EndTable()
  end
end

-- Bookmark helpers using global store
local function _ctBookmarkKey(entry, fallbackKey)
  local item = type(entry) == "table" and entry or {}
  local savedKey = tostring(item.key or "")
  if savedKey ~= "" then return savedKey end

  local itemType = tostring(item.type or "item")
  local itemId   = tostring(item.id or "")
  local meta     = tostring(item.meta or "")
  if itemType == "spawn_record" and meta ~= "" then
    return "spawn:" .. meta .. ":" .. itemId
  end

  local fallback = tostring(fallbackKey or "")
  if fallback ~= "" then return fallback end
  return itemType .. ":" .. itemId
end

local function _ctBmBtn(entry, uid)
  if type(GTS_Bookmarks) ~= "table" then GTS_Bookmarks = {} end
  local item = type(entry) == "table" and entry or {}
  local key = _ctBookmarkKey(item)
  local on = GTS_Bookmarks[key] ~= nil
  local gOn  = type(IconGlyphs)=="table" and (IconGlyphs["Bookmark"] or "*") or "*"
  local gOff = type(IconGlyphs)=="table" and (IconGlyphs["BookmarkOutline"] or "o") or "o"
  if ImGui.SmallButton((on and gOn or gOff) .. "##ctbm_" .. tostring(uid or item.id or key)) then
    if on then
      GTS_Bookmarks[key] = nil
    else
      GTS_Bookmarks[key] = {
        key = key,
        type = tostring(item.type or "item"),
        id = tostring(item.id or ""),
        label = tostring(item.label or item.id or ""),
        meta = item.meta ~= nil and tostring(item.meta) or nil,
        savedAt = (os and os.date and os.date("%Y-%m-%d %H:%M")) or "",
      }
    end
    on = not on
    if Persistence and Persistence.SaveBookmarks then pcall(Persistence.SaveBookmarks) end
  end
  if ImGui.IsItemHovered() then
    ImGui.BeginTooltip(); ImGui.TextUnformatted(on and "Remove bookmark" or "Bookmark"); ImGui.EndTooltip()
  end
  return on
end

local function _drawBookmarksTab()
  local bms = {}
  for k, v in pairs(GTS_Bookmarks or {}) do
    local entry = type(v) == "table" and v or {}
    entry._key = tostring(k)
    bms[#bms + 1] = entry
  end
  table.sort(bms, function(a, b)
    if tostring(a.type or "") ~= tostring(b.type or "") then
      return tostring(a.type or "") < tostring(b.type or "")
    end
    return tostring(a.label or a.id or "") < tostring(b.label or b.id or "")
  end)

  if #bms == 0 then
    ImGui.TextDisabled("No bookmarks yet.")
    ImGui.TextWrapped("Bookmark items from any DB in the mod — stats, spawn records, status effects, appearances, inventory items, poses — using the bookmark icon next to each row.")
    return
  end

  if ImGui.BeginTable("bm_all_tbl", 4, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("*", ImGuiTableColumnFlags.WidthFixed, 26)
    ImGui.TableSetupColumn("Type", ImGuiTableColumnFlags.WidthFixed, 120)
    ImGui.TableSetupColumn("Item")
    ImGui.TableSetupColumn("Saved", ImGuiTableColumnFlags.WidthFixed, 130)
    ImGui.TableHeadersRow()

    for i, bm in ipairs(bms) do
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      _ctBmBtn(bm, "bm_all_" .. tostring(i))
      ImGui.TableSetColumnIndex(1)
      ImGui.TextUnformatted(tostring(bm.type or ""))
      ImGui.TableSetColumnIndex(2)
      -- Always show the full ID so the user sees e.g. "Character.Judy_Alvarez" not just "Character"
      local displayId = tostring(bm.id or bm.label or "")
      ImGui.TextUnformatted(displayId)
      if ImGui.IsItemHovered() and tostring(bm.meta or "") ~= "" then
        ImGui.BeginTooltip()
        ImGui.TextUnformatted("Category: " .. tostring(bm.meta or ""))
        ImGui.EndTooltip()
      end
      ImGui.TableSetColumnIndex(3)
      ImGui.TextDisabled(tostring(bm.savedAt or ""))
    end
    ImGui.EndTable()
  end

  if ImGui.Button("Clear All Bookmarks##bm_clear_all") then
    GTS_Bookmarks = {}
    if Persistence and Persistence.SaveBookmarks then pcall(Persistence.SaveBookmarks) end
  end
end

function CreatedTab.DrawTab(_)
  CreatedTab.state.savedSubtab = CreatedTab.state.savedSubtab or "Assets"
  local drewSavedSubtab = false
  if ImGui.BeginTabBar("created_saved_subtabs") then
    if ImGui.BeginTabItem("Assets") then
      CreatedTab.state.savedSubtab = "Assets"
      drewSavedSubtab = true
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem("Bookmarks") then
      CreatedTab.state.savedSubtab = "Bookmarks"
      drewSavedSubtab = true
      ImGui.EndTabItem()
    end
    ImGui.EndTabBar()
  end
  ImGui.Separator()

  local savedSubtab = tostring(CreatedTab.state.savedSubtab or "Assets")
  if (not drewSavedSubtab and savedSubtab == "Bookmarks") or savedSubtab == "Bookmarks" then
    _drawBookmarksTab()
    return
  end

  -- Assets tab content
  local _magnify = (type(IconGlyphs)=="table" and IconGlyphs["Magnify"]) or "?"
  ImGui.TextUnformatted(_magnify)
  ImGui.SameLine()
  CreatedTab.state.search = _inputTextValue("##created_search", CreatedTab.state.search or "", 128)
  if tostring(CreatedTab.state.lastRunMessage or "") ~= "" then ImGui.TextWrapped(tostring(CreatedTab.state.lastRunMessage or "")) end
  ImGui.Separator()
  _drawCategory("Scripts", { "rule" })
  _drawCategory("Macros / Code / Launchers", { "macro", "custom_code", "launcher" })
  _drawCategory("Animation Sequences", { "animation_sequence" })
  _drawCategory("Scenarios", { "scenario" })
  _drawCategory("Player / World Profiles", { "stat_preset", "inventory_bundle", "spawn_set", "spawn_grid", "shooter_profile", "teleport_preset" })
  _drawCategory("Stat Conditions", { "observer_preset" })
end

return CreatedTab
