local Persistence = require("GTS/Core/persistence")

local Settings = {
  compact = false,
  colors = true,
  keepMenuOpenWhenOverlayClosed = false,
  keepMacroDebugOpenWhenOverlayClosed = false,
  menuBgAlpha = 0.96,
  slowTimeWhileOverlayOpen = false,
  slowTimeFactor = 0.15,
  pauseWhileOverlayOpen = false,
  poseSearchLimit = 500,
  lastPoseRig = "Player Man",
  playerSubtab = "Stats Editor",
  createSubtab = "Scripter",
  toolsSubtab = "Spawn Tools",
  themeR = 0.65,
  themeG = 0.08,
  themeB = 0.08,
  themeA = 1.00,
}

local function _settingsPath()
  local base = (Persistence.GetUserDir and Persistence.GetUserDir()) or "User"
  base = tostring(base or "User")
  if base:sub(-1) == "/" or base:sub(-1) == "\\" then
    return base .. "gts_ui_settings.lua"
  end
  return base .. "/gts_ui_settings.lua"
end

local function _serialize(value, depth)
  depth = depth or 0
  local indent = string.rep("  ", depth)
  local nextIndent = string.rep("  ", depth + 1)

  if type(value) == "table" then
    local parts = {"{"}
    local keys = {}
    for k in pairs(value) do keys[#keys + 1] = k end
    table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
    for i = 1, #keys do
      local k = keys[i]
      local v = value[k]
      local keyText
      if type(k) == "string" and k:match("^[%a_][%w_]*$") then
        keyText = k
      else
        keyText = "[" .. _serialize(k, depth + 1) .. "]"
      end
      parts[#parts + 1] = string.format("\n%s%s = %s,", nextIndent, keyText, _serialize(v, depth + 1))
    end
    if #keys > 0 then
      parts[#parts + 1] = "\n" .. indent
    end
    parts[#parts + 1] = "}"
    return table.concat(parts)
  end

  if type(value) == "string" then
    return string.format("%q", value)
  end

  if type(value) == "number" or type(value) == "boolean" then
    return tostring(value)
  end

  return "nil"
end

local function _loadFromDisk()
  local path = _settingsPath()
  if not loadfile then
    return nil
  end

  local okChunk, chunkOrErr = pcall(loadfile, path)
  if not okChunk or type(chunkOrErr) ~= "function" then
    return nil
  end

  local okData, data = pcall(chunkOrErr)
  if not okData or type(data) ~= "table" then
    return nil
  end
  return data
end

function Settings.Load()
  local data = _loadFromDisk()
  if type(data) ~= "table" then
    return Settings
  end

  for k, v in pairs(data) do
    Settings[k] = v
  end

  Settings.compact = Settings.compact == true
  Settings.colors = Settings.colors ~= false
  Settings.keepMenuOpenWhenOverlayClosed = Settings.keepMenuOpenWhenOverlayClosed == true
  Settings.keepMacroDebugOpenWhenOverlayClosed = Settings.keepMacroDebugOpenWhenOverlayClosed == true
  Settings.menuBgAlpha = tonumber(Settings.menuBgAlpha)
  if Settings.menuBgAlpha == nil then Settings.menuBgAlpha = 0.96 end
  if Settings.menuBgAlpha < 0.05 then Settings.menuBgAlpha = 0.05 end
  if Settings.menuBgAlpha > 1.00 then Settings.menuBgAlpha = 1.00 end
  Settings.slowTimeWhileOverlayOpen = Settings.slowTimeWhileOverlayOpen == true
  Settings.slowTimeFactor = tonumber(Settings.slowTimeFactor)
  if Settings.slowTimeFactor == nil then Settings.slowTimeFactor = 0.15 end
  if Settings.slowTimeFactor < 0.02 then Settings.slowTimeFactor = 0.02 end
  if Settings.slowTimeFactor > 1.00 then Settings.slowTimeFactor = 1.00 end
  Settings.pauseWhileOverlayOpen = Settings.pauseWhileOverlayOpen == true
  Settings.poseSearchLimit = 500
  Settings.lastPoseRig = tostring(Settings.lastPoseRig or "Player Man")
  Settings.playerSubtab = tostring(Settings.playerSubtab or "Stats Editor")
  Settings.createSubtab = tostring(Settings.createSubtab or "Scripter")
  Settings.toolsSubtab = tostring(Settings.toolsSubtab or "Spawn Tools")
  Settings.themeR = tonumber(Settings.themeR) or 0.65
  Settings.themeG = tonumber(Settings.themeG) or 0.08
  Settings.themeB = tonumber(Settings.themeB) or 0.08
  Settings.themeA = tonumber(Settings.themeA) or 1.00

  return Settings
end

function Settings.Save(state)
  local source = type(state) == "table" and state or Settings
  local data = {
    compact = source.compact == true,
    colors = source.colors ~= false,
    keepMenuOpenWhenOverlayClosed = source.keepMenuOpenWhenOverlayClosed == true,
    keepMacroDebugOpenWhenOverlayClosed = source.keepMacroDebugOpenWhenOverlayClosed == true,
    menuBgAlpha = math.max(0.05, math.min(1.00, tonumber(source.menuBgAlpha or 0.96) or 0.96)),
    slowTimeWhileOverlayOpen = source.slowTimeWhileOverlayOpen == true,
    slowTimeFactor = math.max(0.02, math.min(1.00, tonumber(source.slowTimeFactor or 0.15) or 0.15)),
    pauseWhileOverlayOpen = source.pauseWhileOverlayOpen == true,
    poseSearchLimit = 500,
    lastPoseRig = tostring(source.lastPoseRig or "Player Man"),
    playerSubtab = tostring(source.playerSubtab or "Stats Editor"),
    createSubtab = tostring(source.createSubtab or "Scripter"),
    toolsSubtab = tostring(source.toolsSubtab or "Spawn Tools"),
    themeR = tonumber(source.themeR or 0.65) or 0.65,
    themeG = tonumber(source.themeG or 0.08) or 0.08,
    themeB = tonumber(source.themeB or 0.08) or 0.08,
    themeA = tonumber(source.themeA or 1.00) or 1.00,
  }

  local path = _settingsPath()
  local file, err = io.open(path, "w")
  if not file then
    return false, err or "Could not open UI settings file"
  end

  local okWrite, writeErr = pcall(function()
    file:write("return ")
    file:write(_serialize(data))
    file:write("\n")
  end)
  file:close()
  if not okWrite then
    return false, writeErr or "Could not write UI settings"
  end

  for k, v in pairs(data) do
    Settings[k] = v
  end
  return true, path
end

return Settings.Load()
