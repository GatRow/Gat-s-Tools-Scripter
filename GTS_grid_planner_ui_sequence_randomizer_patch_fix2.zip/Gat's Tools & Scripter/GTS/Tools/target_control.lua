print('[GTS][TargetControl] embedded target control module loaded')

local TargetControl = {}

local TCL = {
  overlayOpen = false,
  keepOpenWhenOverlayClosed = true,
  status = 'Idle',
  lastError = nil,
  now = 0,
  window = {
    open = true,
    title = 'Target Control',
  },
  configPath = "./bin/x64/plugins/cyber_engine_tweaks/mods/Gat's Tools & Scripter/gts_target_control_settings.lua",
  target = {
    exists = false,
    handle = nil,
    entityID = nil,
    entityHash = nil,
    className = nil,
    isNPC = false,
    recordId = nil,
    recordType = nil,
    displayName = nil,
    affiliation = nil,
    relation = nil,
    attitude = nil,
    category = nil,
    archetype = nil,
    appearance = nil,
    hostile = false,
    health = 0,
    healthMax = 0,
    healthPct = 0,
    distance = 0,
    speed = 0,
    velocity = { x = 0, y = 0, z = 0 },
    velocityMag = 0,
    velocitySource = 'None',
    combat = 'Unknown',
    state = 'Unknown',
    moveState = 'Idle',
    xyz = { x = 0, y = 0, z = 0 },
    boss = false,
    elite = false,
    reason = '',
    isPuppet = false,
  },
  refresh = {
    targetEvery = 0.10,
    nextTargetAt = 0,
    scanEvery = 0.60,
    nextScanAt = 0,
    cacheRetryEvery = 1.50,
    nextCacheRetryAt = 0,
  },
  statusFx = {
    built = false,
    ids = {},
    seen = {},
    search = '',
    selectedIndex = 1,
    manualEffectId = '',
    selectedEffectId = '',
    liveRefresh = true,
    active = {},
    activeCount = 0,
    scannedAt = 0,
    scannedKey = nil,
    status = 'Preparing status-effect cache...',
  },
  scan = {
    list = {},
    map = {},
    selectedIndex = 1,
    exportPath = "./bin/x64/plugins/cyber_engine_tweaks/mods/Gat's Tools & Scripter/gts_target_control_scanned_targets.log",
  },
  ui = {
    activeTab = 'Summary',
    appearanceSearch = '',
    logSearch = '',
    logNPCOnly = false,
    logHostileOnly = false,
    logVehicleOnly = false,
    sectionSummaryOpen = true,
    sectionActionsOpen = true,
    sectionLogbookOpen = false,
    sectionStatusOpen = false,
    sectionTweakDBOpen = false,
    lastCopiedValue = '',
    copyAssistOpen = false,
    copyAssistLabel = '',
    copyAssistValue = '',
  },
  targetLock = {
    active = false,
    handle = nil,
    entityID = nil,
    entityHash = nil,
    recordId = nil,
    className = nil,
    displayName = nil,
    snapshot = nil,
    lastGoodAt = nil,
    status = 'Live targeting',
  },
  appearance = {
    optionsByKey = {},
    originalByKey = {},
    pendingByKey = {},
    loadStateByKey = {},
    selectedIndex = 1,
  },
  move = {
    offsetX = 0.0,
    offsetY = 0.0,
    offsetZ = 0.0,
    exactX = 0.0,
    exactY = 0.0,
    exactZ = 0.0,
    tetherOffsetX = 0.0,
    tetherOffsetY = 0.0,
    tetherOffsetZ = 0.0,
    tetherEvery = 0.03,
    preserveCurrentZ = false,
    freezeNPC = true,
    disableCollider = false,
    tetherActive = false,
    tetherEntityID = nil,
    tetherEntityHash = nil,
    tetherHandle = nil,
  },
  slowmo = {
    enabled = false,
    scale = 0.15,
    lastAppliedEnabled = nil,
    lastAppliedScale = nil,
  },
  runtime = {
    armed = false,
    waitingStatus = 'Waiting to enter game world...',
  },
  metrics = {
    byKey = {},
  },
  db = {
    autoLoadCurrent = true,
    rootInput = '',
    rootRecordId = nil,
    rootType = nil,
    rootNode = nil,
    status = 'No TweakDB record loaded yet',
    search = '',
    rawDumpPreview = '',
    typeCache = {},
    recordCache = {},
    lastAutoRecordId = '',
    maxArrayPreview = 128,
  }
}

local function _now()
  return (os and os.clock and os.clock()) or 0
end

local function _pcall(fn)
  local ok, a, b, c, d = pcall(fn)
  if not ok then return nil end
  return a, b, c, d
end

local function _log(msg)
  TCL.status = tostring(msg or '')
  print('[GTS][TargetControl] ' .. TCL.status)
end

local function _setError(msg)
  TCL.lastError = tostring(msg or '')
  print('[GTS][TargetControl] ERROR: ' .. TCL.lastError)
end

local function _clearError()
  TCL.lastError = nil
end

local function _trim(s)
  return tostring(s or ''):gsub('^%s+', ''):gsub('%s+$', '')
end

local function _cloneArray(arr)
  local out = {}
  for i = 1, #(arr or {}) do out[i] = arr[i] end
  return out
end

local function _cloneXYZ(pos)
  return {
    x = tonumber(pos and pos.x or 0) or 0,
    y = tonumber(pos and pos.y or 0) or 0,
    z = tonumber(pos and pos.z or 0) or 0,
  }
end

local function _fmtXYZ(pos)
  local p = _cloneXYZ(pos)
  return string.format('%.3f, %.3f, %.3f', p.x, p.y, p.z)
end

local function _fmtAgo(t)
  local n = TCL.now or _now()
  local v = tonumber(t or 0) or 0
  if v <= 0 then return 'never' end
  local dt = math.max(0, n - v)
  if dt < 0.10 then return 'just now' end
  if dt < 10.0 then return string.format('%.2fs ago', dt) end
  if dt < 60.0 then return string.format('%.1fs ago', dt) end
  local m = math.floor(dt / 60.0)
  local s = math.floor(dt % 60.0)
  return string.format('%dm %02ds ago', m, s)
end

local function _wallNow()
  return (os and os.time and os.time()) or 0
end

local function _fmtWallTime(ts)
  local v = tonumber(ts or 0) or 0
  if v <= 0 or not os or not os.date then return 'unknown' end
  local ok, out = pcall(os.date, '%Y-%m-%d %H:%M:%S', v)
  if ok and out and out ~= '' then return tostring(out) end
  return tostring(v)
end

local function _prettyAppearanceName(raw)
  if raw == nil then return nil end
  if Game and Game.NameToString and type(raw) ~= 'string' then
    local converted = _pcall(function() return Game.NameToString(raw) end)
    if converted and tostring(converted) ~= '' then raw = converted end
  end
  local s = _trim(tostring(raw or ''))
  if s == '' then return nil end
  local inner = s:match('%-%[%[%s*(.-)%s*%-%]%]')
  if inner and inner ~= '' then return _trim(inner) end
  inner = s:match('%[%[%s*(.-)%s*%]%]')
  if inner and inner ~= '' then return _trim(inner) end
  return s
end

local function _saveSettings()
  local path = tostring(TCL.configPath or '')
  if path == '' then return false end
  local fh = io.open(path, 'w')
  if not fh then return false end
  fh:write('return {\n')
  fh:write('  keepOpenWhenOverlayClosed = ' .. tostring(TCL.keepOpenWhenOverlayClosed == true) .. ',\n')
  fh:write('  slowmoEnabled = ' .. tostring(TCL.slowmo.enabled == true) .. ',\n')
  fh:write(string.format('  slowmoScale = %.4f,\n', tonumber(TCL.slowmo.scale or 0.15) or 0.15))
  fh:write('  liveRefresh = ' .. tostring(TCL.statusFx.liveRefresh == true) .. ',\n')
  fh:write("  activeTab = " .. string.format('%q', tostring(TCL.ui.activeTab or 'Summary')) .. ',\n')
  fh:write("  appearanceSearch = " .. string.format('%q', tostring(TCL.ui.appearanceSearch or '')) .. ',\n')
  fh:write("  logSearch = " .. string.format('%q', tostring(TCL.ui.logSearch or '')) .. ',\n')
  fh:write('  logNPCOnly = ' .. tostring(TCL.ui.logNPCOnly == true) .. ',\n')
  fh:write('  logHostileOnly = ' .. tostring(TCL.ui.logHostileOnly == true) .. ',\n')
  fh:write('  logVehicleOnly = ' .. tostring(TCL.ui.logVehicleOnly == true) .. ',\n')
  fh:write('}\n')
  fh:close()
  return true
end

local function _loadSettings()
  local path = tostring(TCL.configPath or '')
  if path == '' then return false end
  local loader = loadfile and loadfile(path) or nil
  if not loader then return false end
  local ok, data = pcall(loader)
  if not ok or type(data) ~= 'table' then return false end
  if type(data.keepOpenWhenOverlayClosed) == 'boolean' then TCL.keepOpenWhenOverlayClosed = data.keepOpenWhenOverlayClosed end
  if type(data.slowmoEnabled) == 'boolean' then TCL.slowmo.enabled = data.slowmoEnabled end
  local scale = tonumber(data.slowmoScale or TCL.slowmo.scale or 0.15) or 0.15
  if scale < 0.01 then scale = 0.01 end
  if scale > 1.00 then scale = 1.00 end
  TCL.slowmo.scale = scale
  if type(data.liveRefresh) == 'boolean' then TCL.statusFx.liveRefresh = data.liveRefresh end
  if type(data.activeTab) == 'string' and data.activeTab ~= '' then TCL.ui.activeTab = data.activeTab end
  if type(data.appearanceSearch) == 'string' then TCL.ui.appearanceSearch = data.appearanceSearch end
  if type(data.logSearch) == 'string' then TCL.ui.logSearch = data.logSearch end
  if type(data.logNPCOnly) == 'boolean' then TCL.ui.logNPCOnly = data.logNPCOnly end
  if type(data.logHostileOnly) == 'boolean' then TCL.ui.logHostileOnly = data.logHostileOnly end
  if type(data.logVehicleOnly) == 'boolean' then TCL.ui.logVehicleOnly = data.logVehicleOnly end
  if type(data.sectionSummaryOpen) == 'boolean' then TCL.ui.sectionSummaryOpen = data.sectionSummaryOpen end
  if type(data.sectionActionsOpen) == 'boolean' then TCL.ui.sectionActionsOpen = data.sectionActionsOpen end
  if type(data.sectionLogbookOpen) == 'boolean' then TCL.ui.sectionLogbookOpen = data.sectionLogbookOpen end
  if type(data.sectionStatusOpen) == 'boolean' then TCL.ui.sectionStatusOpen = data.sectionStatusOpen end
  if type(data.sectionTweakDBOpen) == 'boolean' then TCL.ui.sectionTweakDBOpen = data.sectionTweakDBOpen end
  return true
end

local function _checkbox(label, current)
  local value, changed = ImGui.Checkbox(label, current == true)
  if type(value) == 'boolean' then
    return value, (changed == true)
  end
  return (current == true), false
end

local function _inputText(label, value, maxLen)
  local a, b = ImGui.InputText(label, tostring(value or ''), maxLen or 256)
  if type(b) == 'string' then return b end
  if type(a) == 'string' then return a end
  return tostring(value or '')
end

local function _inputFloat(label, value, step, stepFast, fmt)
  local a, b = ImGui.InputFloat(label, tonumber(value or 0) or 0, step or 0.05, stepFast or 0.25, fmt or '%.2f')
  if type(b) == 'number' then return b end
  if type(a) == 'number' then return a end
  return tonumber(value or 0) or 0
end

local function _drawKV(label, value)
  ImGui.Text(label)
  ImGui.SameLine()
  ImGui.TextColored(0.85, 0.95, 1.00, 1.00, tostring(value or '-'))
end

local function _clipboardString(value)
  if value == nil then return '' end
  if type(value) == 'table' then
    if value.x ~= nil or value.y ~= nil or value.z ~= nil then
      return _safeTargetXYZ(value)
    end
    if value.hash ~= nil then
      return tostring(value.hash or '')
    end
  end
  return tostring(value or '')
end

local function _copyToClipboard(value)
  local s = _clipboardString(value)
  if s == '' then return false, 'Empty value' end
  TCL.ui.lastCopiedValue = s
  local ok = false
  pcall(function()
    if ImGui and ImGui.SetClipboardText then
      ImGui.SetClipboardText(tostring(s or ''))
      ok = true
    end
  end)
  if ok then return true, 'ImGui.SetClipboardText' end
  return false, 'ImGui.SetClipboardText unavailable'
end

local function _drawCopyAssist()
  return
end

local function _drawCopyButton(id, value)
  local key = tostring(id or 'copy')
  if ImGui.SmallButton('Copy##' .. key) then
    local ok, why = _copyToClipboard(value)
    if ok then
      _log('Copied ' .. tostring(_clipboardString(value)))
    else
      _setError('Clipboard copy failed: ' .. tostring(why or 'unknown error'))
    end
  end
end

local function _drawKVCopy(label, value, id)
  _drawKV(label, value)
  ImGui.SameLine()
  _drawCopyButton(id or label, value)
end

local function _cloneShallowTable(src)
  local out = {}
  for k, v in pairs(src or {}) do
    if type(v) == 'table' then
      local child = {}
      for kk, vv in pairs(v) do child[kk] = vv end
      out[k] = child
    else
      out[k] = v
    end
  end
  return out
end

local function _targetLockLabel()
  local lock = TCL.targetLock or {}
  if lock.active ~= true then return 'Live Target' end
  local bits = {
    tostring(lock.displayName or ''),
    tostring(lock.className or ''),
    tostring(lock.recordId or ''),
  }
  local joined = _trim(table.concat(bits, ' | '))
  if joined == '' then joined = tostring(lock.entityHash or 'Locked Target') end
  if lock.snapshot and lock.snapshot.lockedSnapshot == true then
    joined = joined .. ' [snapshot]'
  end
  return joined
end

local function _handleSeemsValid(handle)
  if not handle then return false end
  if handle.GetWorldPosition and _pcall(function() return handle:GetWorldPosition() end) then return true end
  if handle.GetEntityID and _pcall(function() return handle:GetEntityID() end) then return true end
  if handle.ToString and _pcall(function() return handle:ToString() end) then return true end
  return false
end

local function _targetLockSnapshotFromTarget(t)
  local snap = _cloneShallowTable(t or {})
  snap.exists = (t and t.exists == true)
  snap.lockedSnapshot = false
  return snap
end

local function _applyLockFromTarget(t, status)
  if not t or t.exists ~= true then return false end
  local lock = TCL.targetLock
  lock.active = true
  lock.handle = t.handle
  lock.entityID = t.entityID
  lock.entityHash = t.entityHash
  lock.recordId = t.recordId
  lock.className = t.className
  lock.displayName = t.displayName
  lock.snapshot = _targetLockSnapshotFromTarget(t)
  lock.snapshot.lockedSnapshot = false
  lock.status = tostring(status or 'Locked to current target')
  lock.lastGoodAt = TCL.now
  return true
end

local function _lockCurrentTarget()
  local t = TCL.target
  if not t or t.exists ~= true or not _handleSeemsValid(t.handle) then
    t = _refreshTarget(true)
  end
  if not t or t.exists ~= true then return false, 'No current target to lock' end

  local handle = t.handle
  if not _handleSeemsValid(handle) and t.entityID then
    handle = _resolveTargetHandleByID(t.entityID)
    if _handleSeemsValid(handle) then
      t = _cloneShallowTable(t)
      t.handle = handle
    end
  end

  if not _handleSeemsValid(handle) then
    local snapshot = _targetLockSnapshotFromTarget(t)
    snapshot.handle = nil
    snapshot.lockedSnapshot = true
    local lock = TCL.targetLock
    lock.active = true
    lock.handle = nil
    lock.entityID = t.entityID
    lock.entityHash = t.entityHash
    lock.recordId = t.recordId
    lock.className = t.className
    lock.displayName = t.displayName
    lock.snapshot = snapshot
    lock.status = 'Locked snapshot (live handle unavailable at click time)'
    lock.lastGoodAt = TCL.now
    TCL.target = _cloneShallowTable(snapshot)
    TCL.target.exists = true
    TCL.target.lockedSnapshot = true
    return true, 'Locked target snapshot: ' .. tostring(t.displayName or t.className or t.recordId or t.entityHash or 'Unknown')
  end

  t = _cloneShallowTable(t)
  t.handle = handle
  _applyLockFromTarget(t, 'Locked to current target')
  return true, 'Locked target: ' .. tostring(t.displayName or t.className or t.recordId or t.entityHash or 'Unknown')
end

local function _unlockCurrentTarget()
  local lock = TCL.targetLock
  lock.active = false
  lock.handle = nil
  lock.entityID = nil
  lock.entityHash = nil
  lock.recordId = nil
  lock.className = nil
  lock.displayName = nil
  lock.snapshot = nil
  lock.lastGoodAt = nil
  lock.status = 'Live targeting'
  return true, 'Unlocked back to live target'
end

local function _lockScanEntry(entry)
  if not entry or not entry.entityID then return false, 'Selected log entry has no live entity ID to lock' end
  local handle = _pcall(function() return Game.FindEntityByID(entry.entityID) end)
  if not handle then return false, 'Selected log entry is not currently resolved in the world' end
  local locked = _cloneShallowTable(entry)
  locked.exists = true
  locked.handle = handle
  locked.entityID = entry.entityID
  locked.xyz = _cloneXYZ(entry.xyz)
  _applyLockFromTarget(locked, 'Locked from logbook selection')
  return true, 'Locked log entry target: ' .. tostring(entry.displayName or entry.className or entry.recordId or entry.entityHash or 'Unknown')
end

local function _resolveLockedTargetHandle()
  local lock = TCL.targetLock or {}
  if lock.active ~= true then return nil end
  if _handleSeemsValid(lock.handle) then return lock.handle end
  if lock.entityID and Game and Game.FindEntityByID then
    local handle = _pcall(function() return Game.FindEntityByID(lock.entityID) end)
    if _handleSeemsValid(handle) then
      lock.handle = handle
      return handle
    end
  end
  return nil
end

local function _isVehicleLikeEntry(entry)
  local category = string.lower(tostring(entry and entry.category or ''))
  local className = string.lower(tostring(entry and entry.className or ''))
  local recordType = string.lower(tostring(entry and entry.recordType or ''))
  local recordId = string.lower(tostring(entry and entry.recordId or ''))
  return string.find(category, 'vehicle', 1, true) ~= nil
    or string.find(className, 'vehicle', 1, true) ~= nil
    or string.find(recordType, 'vehicle', 1, true) ~= nil
    or string.find(recordId, 'vehicle', 1, true) ~= nil
end

local function _scanEntryMatchesFilters(entry)
  if not entry then return false end
  if TCL.ui.logNPCOnly == true and entry.isNPC ~= true then return false end
  if TCL.ui.logHostileOnly == true and entry.hostile ~= true then return false end
  if TCL.ui.logVehicleOnly == true and not _isVehicleLikeEntry(entry) then return false end
  local q = string.lower(_trim(TCL.ui.logSearch or ''))
  if q == '' then return true end
  local bits = {
    tostring(entry.displayName or ''),
    tostring(entry.className or ''),
    tostring(entry.recordId or ''),
    tostring(entry.recordType or ''),
    tostring(entry.entityHash or ''),
    tostring(entry.archetype or ''),
    tostring(entry.appearance or ''),
  }
  local hay = string.lower(table.concat(bits, ' | '))
  return string.find(hay, q, 1, true) ~= nil
end

local function _filteredScanIndices()
  local out = {}
  for i = 1, #(TCL.scan.list or {}) do
    local entry = TCL.scan.list[i]
    if _scanEntryMatchesFilters(entry) then out[#out + 1] = i end
  end
  return out
end

local function _filteredAppearanceIndices(options)
  local out = {}
  local q = string.lower(_trim(TCL.ui.appearanceSearch or ''))
  for i = 1, #(options or {}) do
    local name = tostring(options[i] or '')
    if q == '' or string.find(string.lower(name), q, 1, true) ~= nil then
      out[#out + 1] = i
    end
  end
  return out
end



local function _isPreGameState()
  if not GetSingleton then return false end
  local scenario = _pcall(function() return GetSingleton('inkMenuScenario') end)
  if not scenario or type(scenario.GetSystemRequestsHandler) ~= 'function' then return false end
  local handler = _pcall(function() return scenario:GetSystemRequestsHandler() end)
  if not handler or type(handler.IsPreGame) ~= 'function' then return false end
  return _pcall(function() return handler:IsPreGame() end) == true
end

local function _isGameplayReady()
  local player = (Game and Game.GetPlayer and Game.GetPlayer()) or nil
  if not player or type(player.IsAttached) ~= 'function' then return false end
  if _pcall(function() return player:IsAttached() end) ~= true then return false end
  return not _isPreGameState()
end

local function _beginDisabled(disabled)
  if disabled and ImGui.BeginDisabled then ImGui.BeginDisabled(true) end
end

local function _endDisabled(disabled)
  if disabled and ImGui.EndDisabled then ImGui.EndDisabled() end
end

local function _noTargetValue(value)
  if TCL.target and TCL.target.exists then
    local s = tostring(value or '-')
    if s == '' then return '-' end
    return s
  end
  return 'No Target'
end

local function _safeTargetXYZ(value)
  return (TCL.target and TCL.target.exists) and _fmtXYZ(value) or 'No Target'
end

local function _normalizeEffectId(raw)
  local s = _trim(raw)
  if s == '' then return '' end
  local inner = s:match('^TweakDBID%.new%([%s]*"([^"]+)"[%s]*%)$')
  if inner and inner ~= '' then return inner end
  inner = s:match("^TweakDBID%.new%([%s]*'([^']+)'[%s]*%)$")
  if inner and inner ~= '' then return inner end
  s = s:gsub('^TweakDBID%(', ''):gsub('%)$', '')
  s = s:gsub('^RecordID%(', ''):gsub('%)$', '')
  return _trim(s)
end

local function _toClassName(o)
  if not o then return nil end
  local cn = _pcall(function() return o:ToString() end)
  if (not cn or cn == '') and o.GetClassName then
    local cls = _pcall(function() return o:GetClassName() end)
    cn = cls and (cls.value or tostring(cls)) or nil
  end
  return cn or 'Unknown'
end

local function _toEntityID(o)
  if not o or not o.GetEntityID then return nil end
  return _pcall(function() return o:GetEntityID() end)
end

local function _entityHash(entityID)
  if not entityID then return nil end
  return tostring(entityID.hash or entityID)
end

local function _recordIdString(o)
  if not o or not o.GetRecordID then return nil end
  return _pcall(function()
    local r = o:GetRecordID()
    if not r then return nil end
    if TDBID and TDBID.ToStringDEBUG then return TDBID.ToStringDEBUG(r) end
    return tostring(r)
  end)
end

local function _distanceXYZ(a, b)
  local ax, ay, az = tonumber(a and a.x or 0) or 0, tonumber(a and a.y or 0) or 0, tonumber(a and a.z or 0) or 0
  local bx, by, bz = tonumber(b and b.x or 0) or 0, tonumber(b and b.y or 0) or 0, tonumber(b and b.z or 0) or 0
  local dx, dy, dz = ax - bx, ay - by, az - bz
  return math.sqrt(dx * dx + dy * dy + dz * dz)
end

local function _playerWorldPosition()
  local player = Game and Game.GetPlayer and Game.GetPlayer() or nil
  if not player or not player.GetWorldPosition then return nil end
  local pos = _pcall(function() return player:GetWorldPosition() end)
  if not pos then return nil end
  return { x = tonumber(pos.x or 0) or 0, y = tonumber(pos.y or 0) or 0, z = tonumber(pos.z or 0) or 0 }
end

local function _probeBoolMethod(o, name)
  if not o or type(name) ~= 'string' or name == '' then return nil end
  local fn = o[name]
  if type(fn) ~= 'function' then return nil end
  local ok, value = pcall(fn, o)
  if not ok or type(value) ~= 'boolean' then return nil end
  return value
end

local function _summaryNameToString(value)
  if value == nil then return nil end
  if type(value) == 'string' then
    local s = _trim(value)
    if s ~= '' and s ~= 'None' and s ~= 'nil' then return s end
    return nil
  end
  if Game and Game.NameToString then
    local out = _pcall(function() return Game.NameToString(value) end)
    out = _trim(out)
    if out ~= '' and out ~= 'userdata' and out ~= 'None' and out ~= 'nil' then return out end
  end
  return nil
end

local function _summaryTDBIDToString(value)
  if value == nil then return nil end
  if type(value) == 'string' then
    local s = _trim(value)
    if s ~= '' and s ~= 'None' and s ~= 'nil' then return s end
    return nil
  end
  if TDBID and TDBID.ToStringDEBUG then
    local out = _pcall(function() return TDBID.ToStringDEBUG(value) end)
    out = _trim(out)
    if out ~= '' and out ~= 'userdata' and out ~= 'None' and out ~= 'nil' and not string.find(out, '0000000000000000', 1, true) then return out end
  end
  local out = _trim(tostring(value or ''))
  if out ~= '' and out ~= 'userdata' and out ~= 'None' and out ~= 'nil' then return out end
  return nil
end

local function _summaryLocalizedText(value)
  if value == nil or not Game or not Game.GetLocalizedTextByKey then return nil end
  local tries = {}
  if type(value) == 'number' then tries[#tries + 1] = value end
  if type(value) == 'string' and value:match('^%-?%d+$') then tries[#tries + 1] = tonumber(value) end
  local fromValue = tonumber(value and value.value or nil)
  if fromValue then tries[#tries + 1] = fromValue end
  tries[#tries + 1] = value
  for i = 1, #tries do
    local out = _pcall(function() return Game.GetLocalizedTextByKey(tries[i]) end)
    out = _trim(out)
    if out ~= '' and out ~= 'nil' and out ~= 'None' then return out end
  end
  return nil
end

local function _summaryFlat(recordId, field)
  local rid = _trim(recordId)
  local fld = _trim(field)
  if rid == '' or fld == '' or not TweakDB or not TweakDB.GetFlat then return nil end
  return _pcall(function() return TweakDB:GetFlat(rid .. '.' .. fld) end)
end

local function _summaryTryResolveRecordId(value)
  if value == nil or not TweakDB or not TweakDB.GetRecord then return nil end
  local candidates, seen = {}, {}
  local function push(v)
    v = _trim(v)
    if v ~= '' and v ~= 'None' and v ~= 'nil' and not seen[v] and not string.find(v, '0000000000000000', 1, true) then
      seen[v] = true
      candidates[#candidates + 1] = v
    end
  end
  if type(value) == 'string' then push(value) end
  push(_summaryTDBIDToString(value) or '')
  push(_summaryNameToString(value) or '')
  for i = 1, #candidates do
    local rid = candidates[i]
    if _pcall(function() return TweakDB:GetRecord(rid) end) then return rid end
  end
  return nil
end

local function _summaryStringify(value)
  if value == nil then return nil end
  local loc = _summaryLocalizedText(value)
  local s = _summaryNameToString(value) or _summaryTDBIDToString(value)
  if (not s or s == '') and type(value) ~= 'table' then
    s = _trim(tostring(value or ''))
    if s == '' or s == 'userdata' or s == 'nil' or s == 'None' then s = nil end
  end
  if loc and loc ~= '' and loc ~= s then return loc end
  return s
end

local function _summaryRecordTypeName(recordId)
  local rid = _trim(recordId)
  if rid == '' or not TweakDB or not TweakDB.GetRecord then return nil end
  local rec = _pcall(function() return TweakDB:GetRecord(rid) end)
  if not rec then return nil end
  local t = _toClassName(rec)
  if t and t ~= '' and t ~= 'Unknown' then return t end
  return nil
end

local function _targetDisplayName(o, recordId)
  local name = nil
  if o and o.GetDisplayName then
    name = _summaryStringify(_pcall(function() return o:GetDisplayName() end))
  end
  if name and name ~= '' then return name end
  local fields = { 'displayName', 'fullDisplayName', 'alternativeDisplayName', 'alternativeFullDisplayName' }
  for i = 1, #fields do
    name = _summaryStringify(_summaryFlat(recordId, fields[i]))
    if name and name ~= '' then return name end
  end
  return nil
end

local function _targetAffiliation(recordId)
  local raw = _summaryFlat(recordId, 'affiliation')
  local rid = _summaryTryResolveRecordId(raw)
  if rid and rid ~= '' then
    local label = _summaryStringify(_summaryFlat(rid, 'localizedName'))
    if label and label ~= '' then return label end
    label = _summaryStringify(_summaryFlat(rid, 'displayName'))
    if label and label ~= '' then return label end
    label = _summaryStringify(_summaryFlat(rid, 'enumName'))
    if label and label ~= '' then return label end
    return rid
  end
  return _summaryStringify(raw)
end

local function _targetAttitudeLabel(o, recordId)
  local player = Game and Game.GetPlayer and Game.GetPlayer() or nil
  if player and GameObject and GameObject.GetAttitudeTowards then
    local raw = _pcall(function() return GameObject.GetAttitudeTowards(o, player) end)
    local attitude = _trim(tostring(raw or ''))
    if attitude ~= '' and attitude ~= 'userdata' and attitude ~= 'None' and attitude ~= 'nil' then return attitude end
  end
  return _summaryStringify(_summaryFlat(recordId, 'baseAttitudeGroup'))
end

local function _targetRelationLabel(hostile, attitude)
  if hostile == true then return 'Hostile' end
  local s = string.lower(tostring(attitude or ''))
  if s == '' then return 'Unknown' end
  if string.find(s, 'friendly', 1, true) then return 'Friendly' end
  if string.find(s, 'neutral', 1, true) then return 'Neutral' end
  if string.find(s, 'hostile', 1, true) or string.find(s, 'aggressive', 1, true) then return 'Hostile' end
  return tostring(attitude)
end

local function _targetCategory(o, className)
  local cn = string.lower(tostring(className or ''))
  if (o and o.IsNPC and _pcall(function() return o:IsNPC() end) == true) or cn:find('npc', 1, true) or cn:find('puppet', 1, true) then return 'NPC' end
  if (o and o.IsVehicle and _pcall(function() return o:IsVehicle() end) == true) or cn:find('vehicle', 1, true) or cn:find('car', 1, true) or cn:find('bike', 1, true) then return 'Vehicle' end
  if cn:find('device', 1, true) then return 'Device' end
  if cn:find('item', 1, true) or cn:find('pickup', 1, true) then return 'Item' end
  if cn:find('object', 1, true) then return 'Object' end
  return 'Object'
end

local function _healthForHandleMax(o)
  local sps = Game and Game.GetStatPoolsSystem and Game.GetStatPoolsSystem() or nil
  if not sps or not o or not o.GetEntityID or not gamedataStatPoolType then return 0 end
  local eid = _pcall(function() return o:GetEntityID() end)
  if not eid then return 0 end
  local v = _pcall(function() return sps:GetStatPoolMaxPointValue(eid, gamedataStatPoolType.Health) end)
  if not v or (tonumber(v or 0) or 0) <= 0 then
    v = _pcall(function() return sps:GetStatPoolMaxValue(eid, gamedataStatPoolType.Health) end)
  end
  return tonumber(v or 0) or 0
end

local function _targetStateLabel(o)
  local isDead = _probeBoolMethod(o, 'IsDead')
  if isDead == true then return 'Dead' end
  local isUnconscious = _probeBoolMethod(o, 'IsUnconscious')
  if isUnconscious == true then return 'Unconscious' end
  local isDefeated = _probeBoolMethod(o, 'IsDefeated')
  if isDefeated == true then return 'Downed' end
  if isDead == false then return 'Alive' end
  return 'Unknown'
end

local function _targetCombatLabel(o)
  local inCombat = _probeBoolMethod(o, 'IsInCombat')
  if inCombat == true then return 'In Combat' end
  if inCombat == false then return 'Out of Combat' end
  return 'Unknown'
end

local function _vectorXYZ(value)
  if value == nil then return nil end
  local function num(field)
    local v = _pcall(function() return value[field] end)
    if v == nil then return nil end
    return tonumber(v)
  end
  local x = num('x')
  if x == nil then x = num('X') end
  local y = num('y')
  if y == nil then y = num('Y') end
  local z = num('z')
  if z == nil then z = num('Z') end
  if x == nil and y == nil and z == nil then return nil end
  return { x = x or 0, y = y or 0, z = z or 0 }
end

local function _vectorMagnitude(v)
  if not v then return 0 end
  local x = tonumber(v.x or 0) or 0
  local y = tonumber(v.y or 0) or 0
  local z = tonumber(v.z or 0) or 0
  return math.sqrt(x * x + y * y + z * z)
end

local function _readHandleVelocity(o)
  if not o or type(o.GetVelocity) ~= 'function' then return nil, nil end
  local raw = _pcall(function() return o:GetVelocity() end)
  local vec = _vectorXYZ(raw)
  if vec then return vec, 'GetVelocity' end
  return nil, nil
end

local function _fmtVelocity(v, mag)
  if not v then return 'No Target' end
  local x = tonumber(v.x or 0) or 0
  local y = tonumber(v.y or 0) or 0
  local z = tonumber(v.z or 0) or 0
  local m = tonumber(mag or _vectorMagnitude(v) or 0) or 0
  return string.format('(%.2f, %.2f, %.2f) | |v| %.2f m/s', x, y, z, m)
end

local function _updateDerivedTargetMetrics(t)
  if not t or not t.exists then return t end
  local ppos = _playerWorldPosition()
  t.distance = ppos and _distanceXYZ(ppos, t.xyz) or 0

  local maxHp = tonumber(t.healthMax or 0) or 0
  local curHp = tonumber(t.health or 0) or 0
  if maxHp > 0.001 then
    t.healthPct = math.max(0, math.min(100, (curHp / maxHp) * 100.0))
  else
    t.healthPct = 0
  end

  local key = tostring(t.entityHash or '') .. '|' .. tostring(t.recordId or '') .. '|' .. tostring(t.className or '')
  local bucket = TCL.metrics.byKey or {}
  local sample = bucket[key]
  local now = tonumber(TCL.now or _now()) or 0
  local derivedVel = { x = 0, y = 0, z = 0 }
  if sample and sample.xyz and sample.at then
    local dt = now - (tonumber(sample.at or 0) or 0)
    if dt > 0.0001 and dt <= 1.0 then
      derivedVel = {
        x = ((tonumber(t.xyz.x or 0) or 0) - (tonumber(sample.xyz.x or 0) or 0)) / dt,
        y = ((tonumber(t.xyz.y or 0) or 0) - (tonumber(sample.xyz.y or 0) or 0)) / dt,
        z = ((tonumber(t.xyz.z or 0) or 0) - (tonumber(sample.xyz.z or 0) or 0)) / dt,
      }
    end
  end
  local velocity, source = _readHandleVelocity(t.handle)
  if not velocity then
    velocity, source = derivedVel, 'DerivedXYZDelta'
  end
  local mag = _vectorMagnitude(velocity)
  bucket[key] = { xyz = _cloneXYZ(t.xyz), at = now, speed = mag, velocity = _cloneXYZ(velocity) }
  TCL.metrics.byKey = bucket
  t.velocity = velocity or { x = 0, y = 0, z = 0 }
  t.velocityMag = mag
  t.velocitySource = tostring(source or 'None')
  t.speed = mag
  t.moveState = (mag > 0.05) and 'Moving' or 'Idle'
  return t
end

local function _archetypeForRecord(recordId)
  if not recordId or not TweakDB or not TweakDB.GetFlat then return nil end
  local raw = _pcall(function() return TweakDB:GetFlat(recordId .. '.archetypeName') end)
  if raw == nil then return nil end
  if Game and Game.NameToString then
    local s = _pcall(function() return Game.NameToString(raw) end)
    if s and s ~= '' then return s end
  end
  return tostring(raw)
end

local function _classifyTarget(recordId, archetype, className)
  local text = string.lower(table.concat({ tostring(recordId or ''), tostring(archetype or ''), tostring(className or '') }, ' | '))
  local reasons = {}
  local boss, elite = false, false
  local function has(p) return string.find(text, p, 1, true) ~= nil end
  if has('boss') then boss = true; reasons[#reasons + 1] = 'contains "boss"' end
  if has('miniboss') then boss = true; reasons[#reasons + 1] = 'contains "miniboss"' end
  if has('elite') then elite = true; reasons[#reasons + 1] = 'contains "elite"' end
  local reason = (#reasons > 0) and table.concat(reasons, '; ') or 'heuristic found no boss/elite keywords in record/archetype/class'
  return boss, elite, reason
end

local function _healthForHandle(o)
  local sps = Game and Game.GetStatPoolsSystem and Game.GetStatPoolsSystem() or nil
  if not sps or not o or not o.GetEntityID or not gamedataStatPoolType then return 0 end
  local eid = _pcall(function() return o:GetEntityID() end)
  if not eid then return 0 end
  return _pcall(function() return sps:GetStatPoolValue(eid, gamedataStatPoolType.Health) end) or 0
end

local function _getCurrentTargetHandle()
  local player = Game and Game.GetPlayer and Game.GetPlayer() or nil
  local ts = Game and Game.GetTargetingSystem and Game.GetTargetingSystem() or nil
  if not player or not ts or type(ts.GetLookAtObject) ~= 'function' then return nil end
  local o = _pcall(function() return ts:GetLookAtObject(player, false, false) end)
  if not o then o = _pcall(function() return ts:GetLookAtObject(player, true, false) end) end
  return o
end

local function _captureTarget(o)
  local out = {
    exists = false,
    handle = nil,
    entityID = nil,
    entityHash = nil,
    className = nil,
    isNPC = false,
    recordId = nil,
    recordType = nil,
    displayName = nil,
    affiliation = nil,
    relation = nil,
    attitude = nil,
    category = nil,
    archetype = nil,
    appearance = nil,
    hostile = false,
    health = 0,
    healthMax = 0,
    healthPct = 0,
    distance = 0,
    speed = 0,
    velocity = { x = 0, y = 0, z = 0 },
    velocityMag = 0,
    velocitySource = 'None',
    combat = 'Unknown',
    state = 'Unknown',
    moveState = 'Idle',
    xyz = { x = 0, y = 0, z = 0 },
    boss = false,
    elite = false,
    reason = '',
  }
  if not o then return out end
  out.exists = true
  out.handle = o
  out.className = _toClassName(o)
  out.isNPC = (o.IsNPC and _pcall(function() return o:IsNPC() end) == true) or out.className == 'NPCPuppet'
  out.entityID = _toEntityID(o)
  out.entityHash = _entityHash(out.entityID)
  out.recordId = _recordIdString(o)
  out.recordType = _summaryRecordTypeName(out.recordId)
  out.archetype = _archetypeForRecord(out.recordId)
  out.appearance = _prettyAppearanceName(_pcall(function() return o:GetCurrentAppearanceName() end)) or _summaryStringify(_summaryFlat(out.recordId, 'appearanceName'))
  out.hostile = (_pcall(function() return o:IsHostile() end) == true)
  out.health = _healthForHandle(o)
  out.healthMax = _healthForHandleMax(o)
  local pos = _pcall(function() return o:GetWorldPosition() end)
  if pos then out.xyz = { x = pos.x or 0, y = pos.y or 0, z = pos.z or 0 } end
  out.displayName = _targetDisplayName(o, out.recordId)
  out.affiliation = _targetAffiliation(out.recordId)
  out.attitude = _targetAttitudeLabel(o, out.recordId)
  out.relation = _targetRelationLabel(out.hostile, out.attitude)
  out.category = _targetCategory(o, out.className)
  out.combat = _targetCombatLabel(o)
  out.state = _targetStateLabel(o)
  out.boss, out.elite, out.reason = _classifyTarget(out.recordId, out.archetype, out.className)
  out.isPuppet = (tostring(out.className or ''):find('Puppet', 1, true) ~= nil) and tostring(out.className or '') ~= 'NPCPuppet'
  _updateDerivedTargetMetrics(out)
  return out
end

local function _scanKey(t)
  if not t or not t.exists then return nil end
  return tostring(t.entityHash or '') .. '|' .. tostring(t.recordId or '') .. '|' .. tostring(t.className or '')
end

local function _refreshTarget(force)
  local now = TCL.now
  if not force and now < (TCL.refresh.nextTargetAt or 0) then return TCL.target end
  TCL.refresh.nextTargetAt = now + math.max(0.02, tonumber(TCL.refresh.targetEvery or 0.10) or 0.10)

  local handle = nil
  if TCL.targetLock and TCL.targetLock.active == true then
    handle = _resolveLockedTargetHandle()
    if handle then
      local lockedTarget = _captureTarget(handle)
      if lockedTarget and lockedTarget.exists == true then
        _applyLockFromTarget(lockedTarget, 'Locked to current target')
        TCL.target = lockedTarget
        return TCL.target
      end
    end
    local snapshot = TCL.targetLock.snapshot
    if snapshot and snapshot.exists == true then
      TCL.target = _cloneShallowTable(snapshot)
      TCL.target.exists = true
      TCL.target.handle = handle
      TCL.target.lockedSnapshot = (handle == nil)
      if handle == nil then
        TCL.targetLock.status = 'Locked snapshot (live handle unavailable)'
        TCL.target.handle = nil
      else
        TCL.targetLock.status = 'Locked to current target'
      end
      TCL.targetLock.snapshot = _cloneShallowTable(TCL.target)
      return TCL.target
    end
  end
  if not handle then handle = _getCurrentTargetHandle() end

  TCL.target = _captureTarget(handle)
  return TCL.target
end


local function _scanIDForHandle(o)
  if not o then return nil end
  local rid = _recordIdString(o)
  if rid and rid ~= '' then return rid end
  return nil
end

local function _uniqStrings(list)
  local out, seen = {}, {}
  for i = 1, #(list or {}) do
    local v = tostring(list[i] or '')
    if v ~= '' and not seen[v] then
      seen[v] = true
      out[#out + 1] = v
    end
  end
  table.sort(out, function(a, b) return tostring(a) < tostring(b) end)
  return out
end


local _dbGetSchemaProps, _dbParseTypeProperties, _dbMergePropDefs

local function _appendAppearanceOptions(out, values)
  if type(values) ~= 'table' then return end
  for i = 1, #values do
    local v = _prettyAppearanceName(values[i]) or tostring(values[i] or '')
    if v ~= '' then out[#out + 1] = v end
  end
end

local function _appendAppearanceValue(out, value)
  if value == nil then return end
  if type(value) == 'table' then
    _appendAppearanceOptions(out, value)
    return
  end
  local v = _prettyAppearanceName(value) or _summaryNameToString(value) or tostring(value or '')
  v = _trim(v)
  if v ~= '' and v ~= 'None' and v ~= 'nil' then out[#out + 1] = v end
end


local function _discoverAppearanceOptionsForRecord(recordId, recordType)
  if not recordId or recordId == '' then return {} end
  local out = {}
  local props = {}
  local schemaProps = _dbGetSchemaProps(recordType, recordId)
  props = _dbMergePropDefs(schemaProps, _dbParseTypeProperties(recordType or ''))
  local seenField = {}
  local extras = {
    'appearanceName',
    'appearanceNames',
    'appearances',
    'crowdAppearanceNames',
    'displayAppearance',
    'displayAppearances',
    'variant',
    'variants',
    'skin',
    'skins',
  }
  local function tryField(field, typeName)
    field = _trim(field)
    if field == '' or seenField[field] then return end
    seenField[field] = true
    local lower = string.lower(field)
    local allow = (string.find(lower, 'appearance', 1, true) ~= nil) or (string.find(lower, 'variant', 1, true) ~= nil) or (string.find(lower, 'skin', 1, true) ~= nil)
    if not allow then return end
    local tn = string.lower(_trim(typeName or ''))
    if tn ~= '' and string.find(tn, 'foreignkey', 1, true) ~= nil then return end
    if tn ~= '' and string.find(tn, 'lockey', 1, true) ~= nil then return end
    local value = _summaryFlat(recordId, field)
    _appendAppearanceValue(out, value)
  end
  for i = 1, #(props or {}) do
    local def = props[i]
    tryField(def and def.name or '', def and def.typeName or '')
  end
  for i = 1, #extras do tryField(extras[i], '') end
  return _uniqStrings(out)
end

local function _appearanceOptionsCacheKeyForHandle(o)
  if not o then return '' end
  return tostring(_scanIDForHandle(o) or _entityHash(_toEntityID(o)) or '')
end

local function _appearanceTemplatePathForRecord(recordId)
  if not recordId or recordId == '' or not TweakDB or not TweakDB.GetFlat then return nil end
  return _pcall(function() return TweakDB:GetFlat(recordId .. '.entityTemplatePath') end)
end

local function _extractAppearanceNamesFromTemplate(template)
  local out = {}
  if not template then return out end
  local appearances = template.appearances
  if type(appearances) ~= 'table' then return out end
  for i = 1, #appearances do
    local entry = appearances[i]
    local raw = entry and entry.name or nil
    local name = _prettyAppearanceName(raw) or _summaryNameToString(raw) or _trim(tostring(raw or ''))
    if name ~= '' and name ~= 'None' and name ~= 'nil' then
      out[#out + 1] = name
    end
  end
  return _uniqStrings(out)
end

local function _beginAppearanceTemplateLoad(o, key)
  if not o then return false end
  key = tostring(key or '')
  if key == '' then return false end
  local app = TCL.appearance
  if app.pendingByKey[key] ~= nil then return true end
  local recordId = _recordIdString(o)
  if not recordId or recordId == '' then
    app.loadStateByKey[key] = 'No record ID for target'
    return false
  end
  local path = _appearanceTemplatePathForRecord(recordId)
  if not path then
    app.loadStateByKey[key] = 'No entity template path on record'
    return false
  end
  local depot = (Game and Game.GetResourceDepot and Game.GetResourceDepot()) or nil
  if not depot or type(depot.LoadResource) ~= 'function' then
    app.loadStateByKey[key] = 'Resource depot unavailable'
    return false
  end
  local token = _pcall(function() return depot:LoadResource(path) end)
  if not token then
    app.loadStateByKey[key] = 'LoadResource failed'
    return false
  end
  app.pendingByKey[key] = {
    token = token,
    recordId = recordId,
    startedAt = tonumber(TCL.now or 0) or 0,
  }
  app.loadStateByKey[key] = 'Loading entity template appearances...'
  return true
end

local function _pollAppearanceTemplateLoads()
  local app = TCL.appearance
  for key, job in pairs(app.pendingByKey or {}) do
    local token = job and job.token or nil
    local template = token and _pcall(function() return token:GetResource() end) or nil
    if template ~= nil then
      local options = _extractAppearanceNamesFromTemplate(template)
      app.pendingByKey[key] = nil
      app.optionsByKey[key] = options
      if #options > 0 then
        app.loadStateByKey[key] = 'Loaded ' .. tostring(#options) .. ' template appearances'
      else
        app.loadStateByKey[key] = 'Template has no appearance entries'
      end
    else
      local startedAt = tonumber(job and job.startedAt or 0) or 0
      if ((tonumber(TCL.now or 0) or 0) - startedAt) >= 1.50 then
        app.pendingByKey[key] = nil
        app.loadStateByKey[key] = 'Template appearance load timed out'
      end
    end
  end
end

local function _getAppearanceOptionsForHandle(o, force)
  if not o then return {} end
  local key = _appearanceOptionsCacheKeyForHandle(o)
  local app = TCL.appearance
  if force == true and key ~= '' then
    app.optionsByKey[key] = nil
    app.pendingByKey[key] = nil
    app.loadStateByKey[key] = nil
  end

  local options = {}
  local current = _pcall(function() return o:GetCurrentAppearanceName() end)
  current = _prettyAppearanceName(current)
  if current and tostring(current) ~= '' then
    options[#options + 1] = tostring(current)
  end

  local cached = (key ~= '' and type(app.optionsByKey[key]) == 'table') and app.optionsByKey[key] or nil
  if cached and #cached > 0 then
    _appendAppearanceOptions(options, cached)
    return _uniqStrings(options)
  end

  if key ~= '' then
    _beginAppearanceTemplateLoad(o, key)
  end

  return _uniqStrings(options)
end

local function _applyAppearanceToHandle(o, appearance)
  if not o then return false, 'No target handle' end
  local appName = _trim(tostring(appearance or ''))
  if appName == '' then return false, 'No appearance selected' end
  if type(o.ScheduleAppearanceChange) ~= 'function' then
    return false, 'Target does not expose ScheduleAppearanceChange'
  end
  if type(o.PrefetchAppearanceChange) == 'function' then
    pcall(function() o:PrefetchAppearanceChange(appName) end)
  end
  local ok = pcall(function() o:ScheduleAppearanceChange(appName) end)
  if not ok then
    return false, 'ScheduleAppearanceChange failed'
  end
  return true, 'Scheduled appearance ' .. appName
end

local function _appearanceKeyForTarget(t)
  if not t or not t.exists then return nil end
  return tostring(t.recordId or '') .. '|' .. tostring(t.entityHash or '')
end

local function _refreshAppearanceStateForCurrentTarget(force)
  local t = force and _refreshTarget(true) or TCL.target
  if not t or not t.exists or not t.handle then return {}, 0 end
  local key = _appearanceKeyForTarget(t)
  local app = TCL.appearance
  local options = _getAppearanceOptionsForHandle(t.handle, force == true) or {}
  if key and key ~= '' and app.originalByKey[key] == nil then app.originalByKey[key] = t.appearance end
  local idx = 1
  for i = 1, #options do
    if tostring(options[i]) == tostring(t.appearance or '') then idx = i break end
  end
  if #options == 0 then idx = 0 end
  app.selectedIndex = idx
  return options, idx
end

local function _cycleAppearance(step)
  local t = _refreshTarget(true)
  if not t or not t.exists or not t.handle then return false, 'No current target' end
  local options, idx = _refreshAppearanceStateForCurrentTarget(false)
  if type(options) ~= 'table' or #options == 0 then
    return false, 'No appearance options found for this target.'
  end
  local n = #options
  local nextIdx = (((tonumber(idx or 1) or 1) - 1 + (tonumber(step or 1) or 1)) % n) + 1
  local ok, msg = _applyAppearanceToHandle(t.handle, options[nextIdx])
  if ok then
    TCL.appearance.selectedIndex = nextIdx
    _refreshTarget(true)
  end
  return ok, msg
end

local function _restoreOriginalAppearance()
  local t = _refreshTarget(true)
  if not t or not t.exists or not t.handle then return false, 'No current target' end
  local key = _appearanceKeyForTarget(t)
  local original = key and TCL.appearance.originalByKey[key] or nil
  if not original or tostring(original) == '' then return false, 'No original appearance snapshot stored yet' end
  local ok, msg = _applyAppearanceToHandle(t.handle, original)
  if ok then _refreshTarget(true) end
  return ok, msg
end

local function _getTF()
  return (Game and Game.GetTeleportationFacility and Game.GetTeleportationFacility()) or nil
end

local function _getDES()
  return (Game and Game.GetDynamicEntitySystem and Game.GetDynamicEntitySystem()) or nil
end

local function _sameEntity(a, b)
  if not a or not b then return false end
  local aid = _pcall(function() return a:GetEntityID() end)
  local bid = _pcall(function() return b:GetEntityID() end)
  if aid == nil or bid == nil then return false end
  return tostring(aid) == tostring(bid)
end

local function _currentEulerForHandle(o)
  if not o then return EulerAngles.new(0, 0, 0) end
  local got = _pcall(function() return o:GetWorldOrientation() end)
  if got and GetSingleton then
    local q = _pcall(function() return GetSingleton('Quaternion') end)
    if q and q.ToEulerAngles then
      local ea = _pcall(function() return q:ToEulerAngles(got) end)
      if ea then return ea end
    end
  end
  return EulerAngles.new(0, 0, 0)
end

local function _yawForHandle(o)
  local ea = _currentEulerForHandle(o)
  return tonumber(ea and ea.yaw or 0) or 0
end

local function _asVector4(pos)
  if type(pos) ~= 'table' and type(pos) ~= 'userdata' then return nil end
  return Vector4.new(tonumber(pos.x or 0) or 0, tonumber(pos.y or 0) or 0, tonumber(pos.z or 0) or 0, tonumber(pos.w or 1) or 1)
end


local function _readWorldPosition(handle)
  if not handle or not handle.GetWorldPosition then return nil end
  local pos = _pcall(function() return handle:GetWorldPosition() end)
  if not pos then return nil end
  return {
    x = tonumber(pos.x or 0) or 0,
    y = tonumber(pos.y or 0) or 0,
    z = tonumber(pos.z or 0) or 0,
    w = tonumber(pos.w or 1) or 1,
  }
end

local _moveNPCHandleToDest

local function _distanceSq(a, b)
  if not a or not b then return nil end
  local dx = (tonumber(a.x or 0) or 0) - (tonumber(b.x or 0) or 0)
  local dy = (tonumber(a.y or 0) or 0) - (tonumber(b.y or 0) or 0)
  local dz = (tonumber(a.z or 0) or 0) - (tonumber(b.z or 0) or 0)
  return (dx * dx) + (dy * dy) + (dz * dz)
end

local function _positionsNear(a, b, eps)
  local dsq = _distanceSq(a, b)
  if dsq == nil then return false end
  local e = tonumber(eps or 0.05) or 0.05
  return dsq <= (e * e)
end

local function _madeMoveProgress(before, after, dest, minDelta)
  local beforeSq = _distanceSq(before, dest)
  local afterSq = _distanceSq(after, dest)
  if beforeSq == nil or afterSq == nil then return false end
  local d = tonumber(minDelta or 0.02) or 0.02
  return afterSq < (beforeSq - (d * d))
end

local function _moveTargetSnapshotBy(dx, dy, dz)
  local t = _refreshTarget(true)
  if not t or not t.exists or not t.handle then return nil, 'No current target' end
  local cur = _readWorldPosition(t.handle) or _cloneXYZ(t.xyz)
  local dest = {
    x = (tonumber(cur.x or 0) or 0) + (tonumber(dx or 0) or 0),
    y = (tonumber(cur.y or 0) or 0) + (tonumber(dy or 0) or 0),
    z = (tonumber(cur.z or 0) or 0) + (tonumber(dz or 0) or 0),
    w = tonumber(cur.w or 1) or 1,
  }
  return t, cur, dest
end

local function _resolveTargetHandleByID(entityID)
  if not entityID or not Game or not Game.FindEntityByID then return nil end
  return _pcall(function() return Game.FindEntityByID(entityID) end)
end

local function _isNPCHandle(handle)
  if not handle then return false end
  if handle.IsNPC and _pcall(function() return handle:IsNPC() end) == true then return true end
  local className = tostring(_toClassName(handle) or '')
  if className == 'NPCPuppet' then return true end
  if string.find(className, 'Puppet', 1, true) ~= nil then return true end
  return string.find(string.lower(className), 'npc', 1, true) ~= nil
end

local function _teleportNPCTo(handle, targetPosition, targetRotation)
  if not _isNPCHandle(handle) or not handle.GetAIControllerComponent then return false, 'NPC handle has no AI controller' end
  local ai = _pcall(function() return handle:GetAIControllerComponent() end)
  if not ai or not ai.SendCommand then return false, 'AI controller unavailable' end
  local teleportCmd = NewObject('handle:AITeleportCommand')
  teleportCmd.position = targetPosition
  teleportCmd.rotation = targetRotation or 0.0
  teleportCmd.doNavTest = false
  local ok, err = pcall(function() ai:SendCommand(teleportCmd) end)
  if not ok then return false, tostring(err or 'AITeleportCommand failed') end
  return true, 'Sent NPC teleport command'
end

local function _getNPCAIController(handle)
  if not _isNPCHandle(handle) or not handle or not handle.GetAIControllerComponent then return nil end
  local ai = _pcall(function() return handle:GetAIControllerComponent() end)
  if not ai or not ai.SendCommand then return nil end
  return ai
end

local function _commandNPCFollowTarget(handle, target, distance)
  local ai = _getNPCAIController(handle)
  if not ai or not target then return false, 'AI follow unavailable' end
  local cmd = NewObject('handle:AIFollowTargetCommand')
  cmd.desiredDistance = math.max(0.10, tonumber(distance or 0.35) or 0.35)
  cmd.matchSpeed = true
  cmd.stopWhenDestinationReached = false
  cmd.target = target
  cmd.movementType = 'Walk'
  cmd.teleport = false
  cmd.tolerance = math.max(0.25, tonumber(distance or 0.35) or 0.35)
  cmd.lookAtTarget = target
  local ok, err = pcall(function() ai:SendCommand(cmd) end)
  if not ok then return false, tostring(err or 'AIFollowTargetCommand failed') end
  return true, 'Sent NPC follow command'
end

local function _commandNPCMoveTo(handle, dest)
  local ai = _getNPCAIController(handle)
  if not ai then return false, 'AI move unavailable' end
  local worldPos = NewObject('WorldPosition')
  worldPos:SetVector4(worldPos, _asVector4(dest))
  local positionSpec = NewObject('AIPositionSpec')
  positionSpec:SetWorldPosition(positionSpec, worldPos)
  local cmd = NewObject('handle:AIMoveToCommand')
  cmd.movementTarget = positionSpec
  cmd.rotateEntityTowardsFacingTarget = false
  cmd.ignoreNavigation = true
  cmd.desiredDistanceFromTarget = 0
  cmd.movementType = 'Walk'
  cmd.finishWhenDestinationReached = false
  cmd.alwaysUseStealth = false
  local ok, err = pcall(function() ai:SendCommand(cmd) end)
  if not ok then return false, tostring(err or 'AIMoveToCommand failed') end
  return true, 'Sent NPC move command'
end

local function _holdNPCPosition(handle, seconds)
  local ai = _getNPCAIController(handle)
  if not ai then return false, 'AI hold unavailable' end
  local holdCmd = NewObject('handle:AIHoldPositionCommand')
  holdCmd.duration = math.max(0.10, tonumber(seconds or 0.25) or 0.25)
  holdCmd.ignoreInCombat = false
  holdCmd.removeAfterCombat = false
  holdCmd.alwaysUseStealth = true
  local ok, err = pcall(function() ai:SendCommand(holdCmd) end)
  if not ok then return false, tostring(err or 'AIHoldPositionCommand failed') end
  return true, 'Sent NPC hold command'
end

local function _moveNPCHandleDirect(handle, dest)
  if not handle or not dest then return false, 'Missing handle or destination' end
  local before = _readWorldPosition(handle)
  local ok, msg = _teleportNPCTo(handle, _asVector4(dest), _yawForHandle(handle))
  if not ok then return false, msg end
  local after = _readWorldPosition(handle)
  if after and (_positionsNear(after, dest, 0.10) or (before and not _positionsNear(after, before, 0.02))) then
    return true, 'NPC moved'
  end
  return true, 'NPC move queued'
end

local function _moveHandleToDest(handle, dest, opts)
  if not handle or not dest then return false, 'Missing handle or destination' end
  opts = opts or {}
  local before = _readWorldPosition(handle)
  local isNPC = _isNPCHandle(handle)
  local preferNpcAI = (opts.preferNpcAI ~= false)
  local preferHardPosition = (opts.preferHardPosition == true)
  local allowAsyncSuccess = (opts.allowAsyncSuccess ~= false)
  local progressEps = tonumber(opts.progressEps or 0.02) or 0.02
  local attempts = {}

  if isNPC and preferNpcAI and (not preferHardPosition) and handle.GetAIControllerComponent then
    attempts[#attempts + 1] = {
      tag = 'AITeleportCommand',
      async = true,
      fn = function()
        return _teleportNPCTo(handle, _asVector4(dest), _yawForHandle(handle))
      end
    }
  end

  local tf = _getTF()
  if tf and tf.Teleport then
    attempts[#attempts + 1] = {
      tag = 'TeleportationFacility',
      fn = function()
        tf:Teleport(handle, _asVector4(dest), _currentEulerForHandle(handle))
        return true, 'Teleported target'
      end
    }
  end

  if handle.SetWorldPosition then
    attempts[#attempts + 1] = {
      tag = 'SetWorldPosition',
      fn = function()
        handle:SetWorldPosition(_asVector4(dest))
        return true, 'SetWorldPosition target'
      end
    }
  end

  if isNPC and (((not preferNpcAI) or preferHardPosition) and handle.GetAIControllerComponent) then
    attempts[#attempts + 1] = {
      tag = 'AITeleportCommandFallback',
      async = true,
      fn = function()
        return _teleportNPCTo(handle, _asVector4(dest), _yawForHandle(handle))
      end
    }
  end

  if isNPC and preferNpcAI and preferHardPosition and handle.GetAIControllerComponent then
    attempts[#attempts + 1] = {
      tag = 'AITeleportCommandLast',
      async = true,
      fn = function()
        return _teleportNPCTo(handle, _asVector4(dest), _yawForHandle(handle))
      end
    }
  end

  local lastErr = 'No supported move path for target'
  for i = 1, #attempts do
    local step = attempts[i]
    local ok, a, b = pcall(step.fn)
    if ok and a == true then
      local after = _readWorldPosition(handle)
      if after and (_positionsNear(after, dest, 0.10) or _madeMoveProgress(before, after, dest, progressEps) or (before and not _positionsNear(after, before, 0.02))) then
        return true, tostring(step.tag) .. ': moved target'
      end
      if step.async == true and allowAsyncSuccess == true then
        return true, tostring(step.tag) .. ': queued target move'
      end
      lastErr = tostring(step.tag) .. ': no visible position change'
    else
      lastErr = tostring((ok and b) or a or 'move failed')
    end
  end
  return false, lastErr
end

local function _despawnCurrentTarget()
  local t = _refreshTarget(true)
  if not t or not t.exists or not t.handle then return false, 'No current target' end
  local p = (Game and Game.GetPlayer and Game.GetPlayer()) or nil
  if p and _sameEntity(t.handle, p) then return false, 'Refused to despawn player' end
  local didAnything = false
  local okDispose = pcall(function() t.handle:Dispose() end)
  if okDispose then didAnything = true end
  local des = _getDES()
  if des and t.entityID then
    local okDelete = pcall(function() des:DeleteEntity(t.entityID) end)
    if okDelete then didAnything = true end
  end
  if didAnything then
    TCL.target = _captureTarget(nil)
    return true, 'Despawned current target'
  end
  return false, 'Could not despawn target'
end

local function _moveCurrentTargetByOffset(dx, dy, dz)
  local t, cur, dest = _moveTargetSnapshotBy(dx, dy, dz)
  if not t then return false, cur end
  local ok, msg
  if t.isNPC == true then
    ok, msg = _moveNPCHandleDirect(t.handle, dest)
  else
    ok, msg = _moveHandleToDest(t.handle, dest, { preferNpcAI = not (t.isPuppet == true) })
  end
  if ok then _refreshTarget(true) end
  return ok, msg, cur, dest
end

local function _moveCurrentTargetToExact(x, y, z)
  local t = _refreshTarget(true)
  if not t or not t.exists or not t.handle then return false, 'No current target' end
  local dest = { x = tonumber(x or 0) or 0, y = tonumber(y or 0) or 0, z = tonumber(z or 0) or 0, w = 1 }
  local ok, msg
  if t.isNPC == true then
    ok, msg = _moveNPCHandleToDest(t.handle, dest, not (t.isPuppet == true))
  else
    ok, msg = _moveHandleToDest(t.handle, dest, { preferNpcAI = not (t.isPuppet == true) })
  end
  if ok then _refreshTarget(true) end
  return ok, msg, _cloneXYZ(t.xyz), dest
end

local function _freezeNPC(handle, freeze)
  if not _isNPCHandle(handle) then return end
  if not TimeDilationHelper then return end
  if freeze then
    pcall(function() TimeDilationHelper.SetIndividualTimeDilation(handle, CName.new('radialMenu'), 0.0) end)
  else
    pcall(function() TimeDilationHelper.UnsetIndividualTimeDilation(handle) end)
  end
end

local function _setColliderDisabled(handle, disabled)
  if not handle or not handle.GetAIControllerComponent then return end
  local ai = _pcall(function() return handle:GetAIControllerComponent() end)
  if not ai then return end
  if disabled and ai.DisableCollider then pcall(function() ai:DisableCollider() end) end
  if (not disabled) and ai.EnableCollider then pcall(function() ai:EnableCollider() end) end
end
local function _scheduleNPCRefreeze(handle, delay)
  local mv = TCL.move or nil
  if not mv or not handle then return end
  mv.pendingRefreezeHandle = handle
  mv.pendingRefreezeEntityID = _toEntityID(handle)
  mv.pendingRefreezeAt = TCL.now + math.max(0.00, tonumber(delay or 0.12) or 0.12)
end

local function _flushPendingNPCRefreeze()
  local mv = TCL.move or nil
  if not mv then return end
  local dueAt = tonumber(mv.pendingRefreezeAt or 0) or 0
  if dueAt <= 0 or TCL.now < dueAt then return end
  local handle = mv.pendingRefreezeHandle
  if not handle and mv.pendingRefreezeEntityID then
    handle = _resolveTargetHandleByID(mv.pendingRefreezeEntityID)
  end
  if handle then _freezeNPC(handle, true) end
end


local function _withTemporaryNPCUnfreeze(handle, fn, opts)
  if type(fn) ~= 'function' then return false end
  opts = opts or {}
  local isNPC = _isNPCHandle(handle)
  local shouldRefreeze = isNPC and TCL.move and TCL.move.freezeNPC == true and TimeDilationHelper ~= nil
  if shouldRefreeze then
    TCL.move.pendingRefreezeAt = 0
    TCL.move.pendingRefreezeEntityID = nil
    TCL.move.pendingRefreezeHandle = nil
    _freezeNPC(handle, false)
  end
  local ok, a, b, c = pcall(fn)
  if shouldRefreeze then
    local holdSeconds = tonumber(opts.holdSeconds or 0) or 0
    local queued = false
    if a == true then
      local s1 = string.lower(tostring(b or ''))
      local s2 = string.lower(tostring(c or ''))
      queued = (string.find(s1, 'queued', 1, true) ~= nil) or (string.find(s2, 'queued', 1, true) ~= nil)
    end
    if holdSeconds > 0 then
      _scheduleNPCRefreeze(handle, holdSeconds)
    elseif queued then
      _scheduleNPCRefreeze(handle, 0.12)
    else
      _freezeNPC(handle, true)
    end
  end
  if not ok then return false, tostring(a or 'NPC move failed') end
  return a, b, c
end

_moveNPCHandleToDest = function(handle, dest, preferNpcAI)
  return _withTemporaryNPCUnfreeze(handle, function()
    return _moveHandleToDest(handle, dest, { preferNpcAI = preferNpcAI })
  end, { holdSeconds = 0.12 })
end


local function _getTetherHandle()
  local mv = TCL.move
  local h = mv.tetherHandle
  if h then
    local okPos = _readWorldPosition(h)
    if okPos then return h end
  end
  h = _resolveTargetHandleByID(mv.tetherEntityID)
  if h then mv.tetherHandle = h end
  return h
end

local function _stopTether()
  local mv = TCL.move
  if mv.tetherActive ~= true then return end
  mv.tetherActive = false
  mv.tetherEntityID = nil
  mv.tetherEntityHash = nil
  mv.tetherHandle = nil
end

local function _startTetherToPlayer()
  local t = _refreshTarget(true)
  if not t or not t.exists or not t.entityID then return false, 'No current target' end
  local handle = _resolveTargetHandleByID(t.entityID) or t.handle
  if not handle then return false, 'Could not resolve target handle' end
  _stopTether()
  local mv = TCL.move
  mv.tetherActive = true
  mv.tetherEntityID = t.entityID
  mv.tetherEntityHash = t.entityHash
  mv.tetherHandle = handle
  return true, 'Started tether to player location'
end

local function _updateTether()
  local mv = TCL.move
  if mv.tetherActive ~= true then return end
  local handle = _getTetherHandle()
  local player = (Game and Game.GetPlayer and Game.GetPlayer()) or nil
  if not handle or not player then _stopTether(); return end
  local ppos = _pcall(function() return player:GetWorldPosition() end)
  if not ppos then return end
  local targetPos = _readWorldPosition(handle)
  local z = (tonumber(ppos.z or 0) or 0) + (tonumber(mv.tetherOffsetZ or 0) or 0)
  if targetPos and mv.preserveCurrentZ == true then
    z = tonumber(targetPos.z or z) or z
  end
  local dest = {
    x = (tonumber(ppos.x or 0) or 0) + (tonumber(mv.tetherOffsetX or 0) or 0),
    y = (tonumber(ppos.y or 0) or 0) + (tonumber(mv.tetherOffsetY or 0) or 0),
    z = z,
    w = tonumber(ppos.w or 1) or 1,
  }
  if targetPos and _positionsNear(targetPos, dest, 0.03) then return end
  local ok = (_moveHandleToDest(handle, dest, { preferNpcAI = true }) == true)
  if not ok then
    -- keep session alive; next update may succeed after streaming settles
  end
end

local function _applyGlobalSlowMo(enabled, scale)
  local ts = (Game and Game.GetTimeSystem and Game.GetTimeSystem()) or nil
  if not ts then return false end
  local s = tonumber(scale or 1.0) or 1.0
  if s < 0.01 then s = 0.01 end
  if s > 1.0 then s = 1.0 end
  if enabled then
    pcall(function() ts:SetIgnoreTimeDilationOnLocalPlayerZero(true) end)
    pcall(function() ts:SetTimeDilation('consoleCommand', s) end)
  else
    pcall(function() ts:SetIgnoreTimeDilationOnLocalPlayerZero(false) end)
    pcall(function() ts:UnsetTimeDilation('consoleCommand') end)
  end
  return true
end

local function _syncSlowMo(force)
  local sm = TCL.slowmo
  if force ~= true and sm.lastAppliedEnabled == sm.enabled and math.abs((tonumber(sm.lastAppliedScale or 0) or 0) - (tonumber(sm.scale or 0) or 0)) < 0.0001 then
    return
  end
  _applyGlobalSlowMo(sm.enabled == true, sm.scale)
  sm.lastAppliedEnabled = sm.enabled == true
  sm.lastAppliedScale = tonumber(sm.scale or 1.0) or 1.0
end

local function _ensureCurrentTargetLogged(force)
  local t = force and _refreshTarget(true) or TCL.target
  if not t or not t.exists then return end
  local key = _scanKey(t)
  if not key or key == '||' then return end
  local now = TCL.now
  local entry = TCL.scan.map[key]
  if not entry then
    entry = {
      key = key,
      firstSeen = now,
      firstSeenAt = _wallNow(),
      lastSeen = now,
      lastSeenAt = _wallNow(),
      scanCount = 0,
      entityID = t.entityID,
      entityHash = t.entityHash,
      className = t.className,
      displayName = t.displayName,
      recordId = t.recordId,
      recordType = t.recordType,
      category = t.category,
      archetype = t.archetype,
      appearance = t.appearance,
      isNPC = t.isNPC,
      hostile = t.hostile,
      health = t.health,
      boss = t.boss,
      elite = t.elite,
      reason = t.reason,
      firstSeenXYZ = _cloneXYZ(t.xyz),
      latestSeenXYZ = _cloneXYZ(t.xyz),
      activeEffectCount = 0,
      activeEffects = {},
      activeEffectsScannedAt = 0,
    }
    TCL.scan.map[key] = entry
    TCL.scan.list[#TCL.scan.list + 1] = entry
    if #TCL.scan.list == 1 then TCL.scan.selectedIndex = 1 end
  end
  entry.lastSeen = now
  entry.lastSeenAt = _wallNow()
  entry.scanCount = (tonumber(entry.scanCount or 0) or 0) + 1
  entry.entityID = t.entityID
  entry.entityHash = t.entityHash
  entry.className = t.className
  entry.displayName = t.displayName
  entry.recordId = t.recordId
  entry.recordType = t.recordType
  entry.category = t.category
  entry.archetype = t.archetype
  entry.appearance = t.appearance
  entry.isNPC = t.isNPC
  entry.hostile = t.hostile
  entry.isPuppet = t.isPuppet
  entry.health = t.health
  entry.boss = t.boss
  entry.elite = t.elite
  entry.reason = t.reason
  entry.latestSeenXYZ = _cloneXYZ(t.xyz)
end

local function _recordPathFromRec(rec)
  if not rec then return nil end
  local id = _pcall(function() return rec:GetID() end)
  if id and type(id.value) == 'string' and id.value ~= '' then return _normalizeEffectId(id.value) end
  local rid = _pcall(function() return rec:GetRecordID() end)
  if rid and type(rid.value) == 'string' and rid.value ~= '' then return _normalizeEffectId(rid.value) end
  local tries = {
    function() return tostring(rec:GetID()) end,
    function() return tostring(rec:GetRecordID()) end,
    function() return tostring(rec) end,
  }
  for _, fn in ipairs(tries) do
    local sval = _pcall(fn)
    if type(sval) == 'string' and sval ~= '' then
      sval = _normalizeEffectId(sval)
      if sval ~= '' and not sval:find('userdata', 1, true) then return sval end
    end
  end
  return nil
end

local function _addStatusRecordType(recordType)
  if not TweakDB or not TweakDB.GetRecords then return end
  local records = _pcall(function() return TweakDB:GetRecords(recordType) end)
  if type(records) ~= 'table' then return end
  for i = 1, #records do
    local id = _recordPathFromRec(records[i])
    if id and id ~= '' and not TCL.statusFx.seen[id] then
      TCL.statusFx.seen[id] = true
      TCL.statusFx.ids[#TCL.statusFx.ids + 1] = id
    end
  end
end

local function _buildStatusEffectCache(silent)
  TCL.statusFx.built = false
  TCL.statusFx.ids = {}
  TCL.statusFx.seen = {}
  _addStatusRecordType('gamedataStatusEffect_Record')
  _addStatusRecordType('gamedataGameplayRestrictionStatusEffect_Record')
  table.sort(TCL.statusFx.ids, function(a, b) return tostring(a) < tostring(b) end)
  TCL.statusFx.built = (#TCL.statusFx.ids > 0)
  TCL.statusFx.status = 'Known effect IDs: ' .. tostring(#TCL.statusFx.ids)
  if not silent then _log('Status cache ready: ' .. tostring(#TCL.statusFx.ids) .. ' ids') end
  return TCL.statusFx.ids
end

local function _ensureStatusEffectCache(force)
  if not (TCL.runtime and TCL.runtime.armed == true) then
    TCL.statusFx.status = 'Waiting for runtime arm'
    return false
  end
  if TCL.statusFx.built == true and #TCL.statusFx.ids > 0 and not force then return true end
  if not TweakDB or not TweakDB.GetRecords then
    TCL.statusFx.status = 'TweakDB not ready yet'
    return false
  end
  _buildStatusEffectCache(true)
  return TCL.statusFx.built == true
end

local function _getStatusToken(effectId)
  if TweakDBID and TweakDBID.new then
    return _pcall(function() return TweakDBID.new(effectId) end)
  end
  return nil
end

local function _targetHasStatusEffect(eid, effectId)
  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  if not ses or not eid then return false end
  local tok = _getStatusToken(effectId)
  if tok ~= nil and ses.HasStatusEffect ~= nil then
    local active = _pcall(function() return ses:HasStatusEffect(eid, tok) end)
    if type(active) == 'boolean' then return active end
  end
  if ses.HasStatusEffect ~= nil then
    local active = _pcall(function() return ses:HasStatusEffect(eid, effectId) end)
    if type(active) == 'boolean' then return active end
  end
  return false
end

local function _filteredStatusIds()
  if not (TCL.runtime and TCL.runtime.armed == true) then
    return {}
  end
  _ensureStatusEffectCache(false)
  local q = _trim(TCL.statusFx.search):lower()
  if q == '' then return TCL.statusFx.ids end
  local out = {}
  for i = 1, #TCL.statusFx.ids do
    local id = TCL.statusFx.ids[i]
    if tostring(id):lower():find(q, 1, true) then out[#out + 1] = id end
  end
  return out
end

local function _selectedStatusEffectId()
  local filtered = _filteredStatusIds()
  if #filtered == 0 then return '' end
  local idx = tonumber(TCL.statusFx.selectedIndex or 1) or 1
  if idx < 1 then idx = 1 end
  if idx > #filtered then idx = #filtered end
  TCL.statusFx.selectedIndex = idx
  return tostring(filtered[idx] or '')
end

local function _effectIdFromUI()
  local manual = _trim(TCL.statusFx.manualEffectId)
  if manual ~= '' then return manual end
  local selected = _trim(TCL.statusFx.selectedEffectId)
  if selected ~= '' then return selected end
  return _trim(_selectedStatusEffectId())
end

local function _setSelectedEffectId(effectId)
  local id = _trim(effectId)
  TCL.statusFx.selectedEffectId = id
  local filtered = _filteredStatusIds()
  for i = 1, #filtered do
    if tostring(filtered[i]) == id then
      TCL.statusFx.selectedIndex = i
      break
    end
  end
end

local function _clearActiveEffectsForNoTarget()
  TCL.statusFx.active = {}
  TCL.statusFx.activeCount = 0
  TCL.statusFx.scannedAt = 0
  TCL.statusFx.scannedKey = nil
end

local function _scanCurrentTargetStatusEffects(silent)
  if not _ensureStatusEffectCache(false) then return false, 'Status cache is not ready yet' end
  local t = _refreshTarget(true)
  if not t or not t.exists or not t.entityID then
    _clearActiveEffectsForNoTarget()
    return false, 'No current target entity ID'
  end
  local ids = _filteredStatusIds() or {}
  local out = {}
  for i = 1, #ids do
    local id = ids[i]
    if _targetHasStatusEffect(t.entityID, id) then out[#out + 1] = id end
  end
  TCL.statusFx.active = out
  TCL.statusFx.activeCount = #out
  TCL.statusFx.scannedAt = TCL.now
  TCL.statusFx.scannedKey = _scanKey(t)
  TCL.statusFx.status = ((silent and 'Live') or 'Scanned') .. ' ' .. tostring(#ids) .. ' ids, active=' .. tostring(#out)
  local entry = TCL.statusFx.scannedKey and TCL.scan.map[TCL.statusFx.scannedKey] or nil
  if entry then
    entry.activeEffects = _cloneArray(out)
    entry.activeEffectCount = #out
    entry.activeEffectsScannedAt = TCL.now
  end
  if not silent then _log(TCL.statusFx.status) end
  return true, TCL.statusFx.status
end

local function _applyStatusEffectToCurrentTarget(rawEffectId)
  local effectId = _trim(rawEffectId)
  if effectId == '' then return false, 'Enter status effect ID' end
  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  local t = _refreshTarget(true)
  if not ses then return false, 'StatusEffectSystem unavailable' end
  if not t or not t.exists then return false, 'No current target' end

  local handle = _resolveTargetHandleByID(t.entityID) or t.handle
  local eid = (handle and handle.GetEntityID and _pcall(function() return handle:GetEntityID() end)) or t.entityID
  local rid = (handle and handle.GetRecordID) and _pcall(function() return handle:GetRecordID() end) or nil
  if not eid or not handle then return false, 'No current target handle/entity ID' end

  local tok = _getStatusToken(effectId)
  local attempts = {}
  if tok ~= nil and rid ~= nil then
    attempts[#attempts + 1] = { tag = 'native_exact', fn = function() ses:ApplyStatusEffect(eid, tok, rid, eid) end }
  end
  if tok ~= nil then
    attempts[#attempts + 1] = { tag = 'token2', fn = function() ses:ApplyStatusEffect(eid, tok) end }
  end
  if rid ~= nil then
    attempts[#attempts + 1] = { tag = 'string4', fn = function() ses:ApplyStatusEffect(eid, effectId, rid, eid) end }
  end
  attempts[#attempts + 1] = { tag = 'string2', fn = function() ses:ApplyStatusEffect(eid, effectId) end }

  local lastErr = 'ApplyStatusEffect failed'
  for i = 1, #attempts do
    local step = attempts[i]
    local ok, err = pcall(step.fn)
    if ok then
      TCL.statusFx.manualEffectId = ''
      _setSelectedEffectId(effectId)
      _scanCurrentTargetStatusEffects(true)
      if _targetHasStatusEffect(eid, effectId) then
        return true, 'Applied ' .. tostring(effectId) .. ' via ' .. tostring(step.tag)
      end
      -- some effects apply asynchronously; treat the call as success but keep the note honest
      return true, 'Applied call sent for ' .. tostring(effectId) .. ' via ' .. tostring(step.tag)
    end
    lastErr = tostring(err)
  end
  return false, lastErr
end

local function _exportPathCandidates(raw)
  local out = {}
  local seen = {}
  local function add(path)
    path = tostring(path or '')
    if path == '' or seen[path] then return end
    seen[path] = true
    out[#out + 1] = path
  end
  local path = tostring(raw or '')
  add(path)
  add(path:gsub('^%./bin/x64/', './'))
  if _startsWith(path, './plugins/') then add('./bin/x64/' .. path:gsub('^%./', '')) end
  if _startsWith(path, './mods/') then add('./bin/x64/plugins/cyber_engine_tweaks/' .. path:gsub('^%./', '')) end
  add("./plugins/cyber_engine_tweaks/mods/Gat's Tools & Scripter/gts_target_control_scanned_targets.log")
  add("./bin/x64/plugins/cyber_engine_tweaks/mods/Gat's Tools & Scripter/gts_target_control_scanned_targets.log")
  add('./gts_target_control_scanned_targets.log')
  return out
end

local function _openExportFileForWrite(raw)
  if not io or not io.open then return nil, nil, 'Lua io.open unavailable for export' end
  local attempts = _exportPathCandidates(raw)
  local lastErr = nil
  for i = 1, #attempts do
    local path = attempts[i]
    local fh, err = io.open(path, 'w')
    if fh then return fh, path, nil end
    lastErr = err or ('Could not open export path: ' .. tostring(path))
  end
  return nil, nil, tostring(lastErr or ('Could not open export path: ' .. tostring(raw)))
end

local function _exportScans()
  local fh, usedPath, openErr = _openExportFileForWrite(TCL.scan.exportPath)
  if not fh then _setError(openErr); return false end
  TCL.scan.exportPath = usedPath or TCL.scan.exportPath
  fh:write('Target Control - scanned targets\n')
  fh:write('==================================\n\n')
  for i, e in ipairs(TCL.scan.list) do
    fh:write(string.format('[%d]\n', i))
    fh:write('EntityHash: ' .. tostring(e.entityHash or '-') .. '\n')
    fh:write('Class: ' .. tostring(e.className or '-') .. '\n')
    fh:write('Record: ' .. tostring(e.recordId or '-') .. '\n')
    fh:write('Archetype: ' .. tostring(e.archetype or '-') .. '\n')
    fh:write('Appearance: ' .. tostring(_prettyAppearanceName(e.appearance) or '-') .. '\n')
    fh:write('NPC: ' .. tostring(e.isNPC and 'TRUE' or 'FALSE') .. '\n')
    fh:write('Hostile: ' .. tostring(e.hostile and 'TRUE' or 'FALSE') .. '\n')
    fh:write('Health: ' .. tostring(e.health or 0) .. '\n')
    fh:write('CurrentXYZ: ' .. _fmtXYZ(e.latestSeenXYZ) .. '\n')
    fh:write('FirstSeenXYZ: ' .. _fmtXYZ(e.firstSeenXYZ) .. '\n')
    fh:write('Boss: ' .. tostring(e.boss and 'TRUE' or 'FALSE') .. '\n')
    fh:write('Elite: ' .. tostring(e.elite and 'TRUE' or 'FALSE') .. '\n')
    fh:write('Reason: ' .. tostring(e.reason or '-') .. '\n')
    fh:write('FirstSeenAt: ' .. _fmtWallTime(e.firstSeenAt) .. '\n')
    fh:write('FirstSeen: ' .. tostring(e.firstSeen or 0) .. '\n')
    fh:write('LastSeenAt: ' .. _fmtWallTime(e.lastSeenAt) .. '\n')
    fh:write('LastSeen: ' .. tostring(e.lastSeen or 0) .. '\n')
    fh:write('ScanCount: ' .. tostring(e.scanCount or 0) .. '\n')
    fh:write('ActiveEffectCount: ' .. tostring(e.activeEffectCount or 0) .. '\n')
    if type(e.activeEffects) == 'table' and #e.activeEffects > 0 then
      for j = 1, #e.activeEffects do fh:write('  - ' .. tostring(e.activeEffects[j]) .. '\n') end
    end
    fh:write('\n')
  end
  fh:close()
  _log('Exported scan log: ' .. tostring(usedPath or TCL.scan.exportPath))
  return true
end

local function _clearScans()
  TCL.scan.list = {}
  TCL.scan.map = {}
  TCL.scan.selectedIndex = 1
  _log('Cleared scanned target log')
end

local function _selectedScanEntry()
  local list = TCL.scan.list
  if #list == 0 then return nil end
  local idx = tonumber(TCL.scan.selectedIndex or 1) or 1
  if idx < 1 then idx = 1 end
  if idx > #list then idx = #list end
  TCL.scan.selectedIndex = idx
  return list[idx]
end

local function _currentTargetLogEntry()
  local key = _scanKey(TCL.target)
  if not key then return nil end
  return TCL.scan.map[key]
end


local function _drawLogSection()
  local filtered = _filteredScanIndices()
  _drawKV('Filtered Targets:', string.format('%d / %d', #filtered, #(TCL.scan.list or {})))
  _drawKV('Selected Entry:', tostring(TCL.scan.selectedIndex or 1))

  local prevSearch = tostring(TCL.ui.logSearch or '')
  local prevNPCOnly = TCL.ui.logNPCOnly == true
  local prevHostileOnly = TCL.ui.logHostileOnly == true
  local prevVehicleOnly = TCL.ui.logVehicleOnly == true

  TCL.ui.logSearch = _inputText('Log Search', TCL.ui.logSearch, 256)
  TCL.ui.logNPCOnly = _checkbox('NPC Only', TCL.ui.logNPCOnly == true)
  ImGui.SameLine()
  TCL.ui.logHostileOnly = _checkbox('Hostile Only', TCL.ui.logHostileOnly == true)
  ImGui.SameLine()
  TCL.ui.logVehicleOnly = _checkbox('Vehicles Only', TCL.ui.logVehicleOnly == true)

  if prevSearch ~= tostring(TCL.ui.logSearch or '')
    or prevNPCOnly ~= (TCL.ui.logNPCOnly == true)
    or prevHostileOnly ~= (TCL.ui.logHostileOnly == true)
    or prevVehicleOnly ~= (TCL.ui.logVehicleOnly == true) then
    _saveSettings()
  end

  TCL.scan.exportPath = _inputText('Export Path', TCL.scan.exportPath, 512)
  if ImGui.Button('Export Log') then _clearError(); _exportScans() end
  ImGui.SameLine()
  if ImGui.Button('Clear Log') then _clearError(); _clearScans() end

  ImGui.Columns(2, 'tcl_log_cols', true)
  ImGui.BeginChild('tcl_log_list', 0, 340, true)
  if #filtered == 0 then
    ImGui.TextWrapped('No log entries match the current filters yet.')
  else
    for n = 1, #filtered do
      local i = filtered[n]
      local e = TCL.scan.list[i]
      local name = tostring(e.displayName or e.className or '?')
      local label = string.format('%02d | %s | %s', i, name, tostring(e.recordId or e.entityHash or '?'))
      if ImGui.Selectable(label, TCL.scan.selectedIndex == i) then TCL.scan.selectedIndex = i end
    end
  end
  ImGui.EndChild()
  ImGui.NextColumn()

  ImGui.BeginChild('tcl_log_detail', 0, 340, true)
  local e = _selectedScanEntry()
  if not e then
    ImGui.TextWrapped('No logged target selected yet.')
  else
    _drawKV('Display Name:', e.displayName or '-')
    _drawKVCopy('Record:', e.recordId, 'log_record')
    _drawKV('Record Type:', e.recordType or '-')
    _drawKV('Type:', e.category or '-')
    _drawKV('Class:', e.className)
    _drawKV('Archetype:', e.archetype)
    _drawKVCopy('Appearance:', _prettyAppearanceName(e.appearance), 'log_appearance')
    _drawKVCopy('Entity Hash:', e.entityHash, 'log_hash')
    _drawKVCopy('Entity ID:', tostring(e.entityID or '-'), 'log_entityid')
    _drawKV('NPC:', e.isNPC and 'TRUE' or 'FALSE')
    _drawKV('Hostile:', e.hostile and 'TRUE' or 'FALSE')
    _drawKV('Health:', string.format('%.1f', tonumber(e.health or 0) or 0))
    _drawKVCopy('First Seen XYZ:', _fmtXYZ(e.firstSeenXYZ), 'log_first_xyz')
    _drawKVCopy('Latest Seen XYZ:', _fmtXYZ(e.latestSeenXYZ), 'log_latest_xyz')
    _drawKV('Boss:', e.boss and 'TRUE' or 'FALSE')
    _drawKV('Elite:', e.elite and 'TRUE' or 'FALSE')
    _drawKV('Classification Reason:', e.reason)
    _drawKV('First Seen At:', _fmtWallTime(e.firstSeenAt))
    _drawKV('First Seen:', _fmtAgo(e.firstSeen))
    _drawKV('Last Seen At:', _fmtWallTime(e.lastSeenAt))
    _drawKV('Last Seen:', _fmtAgo(e.lastSeen))
    _drawKV('Scan Count:', tostring(e.scanCount or 0))
    _drawKV('Active Effect Count:', tostring(e.activeEffectCount or 0))

    if ImGui.Button('Lock Selected Entry If Alive') then
      _clearError()
      local ok, msg = _lockScanEntry(e)
      if ok then _log(msg); _refreshTarget(true) else _setError(msg) end
    end
    ImGui.SameLine()
    if ImGui.Button('Load Selected Record In Browser') then
      _clearError()
      local ok, msg = _dbLoadRootRecord(e.recordId)
      if ok then _log(msg) else _setError(msg) end
    end
  end
  ImGui.EndChild()
  ImGui.Columns(1)
end


local function _drawCurrentTargetSection()
  local t = TCL.target or {}
  local entry = _currentTargetLogEntry()
  local hasTarget = (t and t.exists == true)

  _drawKV('Target Source:', (TCL.targetLock and TCL.targetLock.active == true) and 'Locked' or 'Live')
  _drawKV('Lock Status:', _targetLockLabel())
  if ImGui.Button((TCL.targetLock and TCL.targetLock.active == true) and 'Unlock To Live Target' or 'Lock Current Target') then
    _clearError()
    local ok, msg
    if TCL.targetLock and TCL.targetLock.active == true then
      ok, msg = _unlockCurrentTarget()
    else
      ok, msg = _lockCurrentTarget()
    end
    if ok then _log(msg); _refreshTarget(true) else _setError(msg) end
  end
  ImGui.SameLine()
  if ImGui.Button('Refresh Target Snapshot') then
    _clearError()
    _refreshTarget(true)
    _log('Refreshed target snapshot')
  end
  ImGui.SameLine()
  if ImGui.Button('Load Current Record In Browser') then
    _clearError()
    local ok, msg = _dbSyncToCurrentTarget(true)
    if not ok then _setError(msg or 'Current target has no record ID') else _log(msg) end
  end

  ImGui.Separator()
  ImGui.Columns(4, 'tcl_target_summary_cols', true)

  _drawKV('Display Name:', hasTarget and _noTargetValue(t.displayName) or 'No Target')
  _drawKVCopy('Record:', _noTargetValue(t.recordId), 'summary_record')
  _drawKV('Record Type:', hasTarget and _noTargetValue(t.recordType) or 'No Target')
  _drawKV('Class:', _noTargetValue(t.className))
  _drawKVCopy('Entity ID:', hasTarget and _noTargetValue(tostring(t.entityID or '-')) or 'No Target', 'summary_entity_id')
  _drawKVCopy('Entity Hash:', _noTargetValue(t.entityHash), 'summary_entity_hash')

  ImGui.NextColumn()

  _drawKV('Type:', hasTarget and _noTargetValue(t.category) or 'No Target')
  _drawKV('NPC:', hasTarget and (t.isNPC and 'TRUE' or 'FALSE') or 'No Target')
  _drawKV('Affiliation:', hasTarget and _noTargetValue(t.affiliation) or 'No Target')
  _drawKV('Archetype:', _noTargetValue(t.archetype))
  _drawKVCopy('Appearance:', _noTargetValue(_prettyAppearanceName(t.appearance)), 'summary_appearance')
  _drawKV('Attitude:', hasTarget and _noTargetValue(t.attitude) or 'No Target')
  _drawKV('Relation:', hasTarget and _noTargetValue(t.relation) or 'No Target')

  ImGui.NextColumn()

  _drawKV('Distance:', hasTarget and string.format('%.2f m', tonumber(t.distance or 0) or 0) or 'No Target')
  _drawKV('Speed:', hasTarget and string.format('%.2f', tonumber(t.speed or 0) or 0) or 'No Target')
  _drawKV('Health:', hasTarget and string.format('%.1f / %.1f', tonumber(t.health or 0) or 0, tonumber(t.healthMax or 0) or 0) or 'No Target')
  _drawKV('Health %:', hasTarget and string.format('%.1f%%', tonumber(t.healthPct or 0) or 0) or 'No Target')
  _drawKV('State:', hasTarget and _noTargetValue(t.state) or 'No Target')
  _drawKV('Combat:', hasTarget and _noTargetValue(t.combat) or 'No Target')
  _drawKV('Movement:', hasTarget and _noTargetValue(t.moveState) or 'No Target')
  _drawKVCopy('Current XYZ:', _safeTargetXYZ(t.xyz), 'summary_xyz')

  ImGui.NextColumn()

  _drawKV('Hostile:', hasTarget and (t.hostile and 'TRUE' or 'FALSE') or 'No Target')
  _drawKV('Boss:', hasTarget and (t.boss and 'TRUE' or 'FALSE') or 'No Target')
  _drawKV('Elite:', hasTarget and (t.elite and 'TRUE' or 'FALSE') or 'No Target')
  _drawKV('First Seen XYZ:', hasTarget and entry and _fmtXYZ(entry.firstSeenXYZ) or 'No Target')
  _drawKV('Latest Seen XYZ:', hasTarget and entry and _fmtXYZ(entry.latestSeenXYZ) or 'No Target')
  _drawKV('Active Effects:', hasTarget and tostring(TCL.statusFx.activeCount or 0) or 'No Target')
  _drawKV('Effects Refreshed:', hasTarget and _fmtAgo(TCL.statusFx.scannedAt) or 'No Target')
  _drawKV('Scan Count:', hasTarget and entry and tostring(entry.scanCount or 0) or 'No Target')
  _drawKV('First Seen At:', hasTarget and entry and _fmtWallTime(entry.firstSeenAt) or 'No Target')
  _drawKV('First Seen:', hasTarget and entry and _fmtAgo(entry.firstSeen) or 'No Target')
  _drawKV('Last Seen:', hasTarget and entry and _fmtAgo(entry.lastSeen) or 'No Target')

  ImGui.Columns(1)
  _drawKV('Status:', hasTarget and ((t.lockedSnapshot == true) and 'Locked Snapshot' or 'Target Acquired') or 'No Target')
  _drawKV('Classification Reason:', hasTarget and (t.reason or '-') or 'No Target')
  ImGui.TextWrapped('Use Actions for appearance, teleport, tether, and despawn. Use Status Effects for a dedicated active-effect workspace and TweakDB for record inspection.')
end


local function _drawAppearanceAndMoveSection()

  if ImGui.CollapsingHeader('Appearance / Despawn', ImGuiTreeNodeFlags.DefaultOpen or 32) then
    if ImGui.Button('Refresh Appearance Options') then
      local options = _refreshAppearanceStateForCurrentTarget(true)
      _log('Appearance options refreshed: ' .. tostring(#(options or {})))
    end
    ImGui.SameLine()
    if ImGui.Button('Cycle Previous') then
      _clearError()
      local ok, msg = _cycleAppearance(-1)
      if ok then _log(msg) else _setError(msg) end
    end
    ImGui.SameLine()
    if ImGui.Button('Cycle Next') then
      _clearError()
      local ok, msg = _cycleAppearance(1)
      if ok then _log(msg) else _setError(msg) end
    end
    ImGui.SameLine()
    if ImGui.Button('Restore Original Appearance') then
      _clearError()
      local ok, msg = _restoreOriginalAppearance()
      if ok then _log(msg) else _setError(msg) end
    end

    local t = TCL.target
    local options = (t and t.exists and t.handle) and (_getAppearanceOptionsForHandle(t.handle, false) or {}) or {}
    local filtered = _filteredAppearanceIndices(options)
    local idx = tonumber(TCL.appearance.selectedIndex or 1) or 1
    if idx < 1 then idx = 1 end
    if idx > #options then idx = #options end
    if #options > 0 then TCL.appearance.selectedIndex = idx else TCL.appearance.selectedIndex = 1 end

    local key = _appearanceKeyForTarget(t)
    local original = key and TCL.appearance.originalByKey[key] or nil
    local selectedName = (#options > 0 and tostring(options[TCL.appearance.selectedIndex])) or '(no appearance options)'
    local loadState = (t and t.exists and t.handle) and TCL.appearance.loadStateByKey[_appearanceOptionsCacheKeyForHandle(t.handle)] or nil

    _drawKVCopy('Current Appearance:', (t and t.exists) and _prettyAppearanceName(t.appearance) or 'No Target', 'act_current_app')
    _drawKVCopy('Original Appearance:', _prettyAppearanceName(original) or '-', 'act_original_app')
    _drawKVCopy('Selected Appearance:', selectedName, 'act_selected_app')
    _drawKV('Appearance Count:', string.format('%d visible / %d total', #filtered, #options))
    TCL.ui.appearanceSearch = _inputText('Appearance Search', TCL.ui.appearanceSearch, 256)

    local preview = selectedName
    if ImGui.BeginCombo('Appearance Options', tostring(preview)) then
      if #filtered == 0 then
        ImGui.TextWrapped('No appearance options match the current search.')
      else
        for n = 1, #filtered do
          local i = filtered[n]
          local selected = (TCL.appearance.selectedIndex == i)
          if ImGui.Selectable(tostring(options[i]), selected) then TCL.appearance.selectedIndex = i end
          if selected and ImGui.SetItemDefaultFocus then ImGui.SetItemDefaultFocus() end
        end
      end
      ImGui.EndCombo()
    end

    if loadState and tostring(loadState) ~= '' then
      ImGui.TextColored(0.75, 0.85, 1.00, 1.00, tostring(loadState))
    end

    if ImGui.Button('Apply Selected Appearance') then
      _clearError()
      if not t or not t.exists or not t.handle then
        _setError('No current target')
      elseif #options == 0 then
        _setError('No appearance options found')
      else
        local ok, msg = _applyAppearanceToHandle(t.handle, options[TCL.appearance.selectedIndex])
        if ok then _log(msg); _refreshTarget(true) else _setError(msg) end
      end
    end
    ImGui.SameLine()
    if ImGui.Button('Despawn Current Target') then
      _clearError()
      local ok, msg = _despawnCurrentTarget()
      if ok then _log(msg) else _setError(msg) end
    end
  end

  if ImGui.CollapsingHeader('Target XYZ Teleport / Tether', ImGuiTreeNodeFlags.DefaultOpen or 32) then
    local t = TCL.target
    local cur = (t and t.exists) and _cloneXYZ(t.xyz) or { x = 0, y = 0, z = 0 }
    _drawKVCopy('Current XYZ:', _fmtXYZ(cur), 'actions_current_xyz')
    _drawKV('Move Path:', 'Shared mover (TeleportationFacility / fallback)')

    if ImGui.Button('Load Exact XYZ From Current Target') then
      local rt = _refreshTarget(true)
      if rt and rt.exists then
        TCL.move.exactX = tonumber(rt.xyz and rt.xyz.x or 0) or 0
        TCL.move.exactY = tonumber(rt.xyz and rt.xyz.y or 0) or 0
        TCL.move.exactZ = tonumber(rt.xyz and rt.xyz.z or 0) or 0
      end
    end

    TCL.move.exactX = _inputFloat('Exact X', TCL.move.exactX, 0.10, 1.00, '%.2f')
    TCL.move.exactY = _inputFloat('Exact Y', TCL.move.exactY, 0.10, 1.00, '%.2f')
    TCL.move.exactZ = _inputFloat('Exact Z', TCL.move.exactZ, 0.10, 1.00, '%.2f')
    if ImGui.Button('Teleport Target To Exact XYZ') then
      _clearError()
      local ok, msg, before, dest = _moveCurrentTargetToExact(TCL.move.exactX, TCL.move.exactY, TCL.move.exactZ)
      if ok then
        _log(string.format('Teleport target: %s -> %s', _fmtXYZ(before), _fmtXYZ(dest)))
      else
        _setError(msg)
      end
    end

    ImGui.Separator()
    ImGui.Text('Tether To Player Location')
    TCL.move.tetherOffsetX = _inputFloat('Tether Offset X', TCL.move.tetherOffsetX, 0.10, 1.00, '%.2f')
    TCL.move.tetherOffsetY = _inputFloat('Tether Offset Y', TCL.move.tetherOffsetY, 0.10, 1.00, '%.2f')
    TCL.move.tetherOffsetZ = _inputFloat('Tether Offset Z', TCL.move.tetherOffsetZ, 0.10, 1.00, '%.2f')
    TCL.move.tetherEvery = _inputFloat('Tether Refresh (sec)', TCL.move.tetherEvery, 0.005, 0.05, '%.3f')
    if t and t.exists and t.isNPC == true then
      ImGui.TextWrapped('NPC tether is disabled in this build. Tether remains available for non-NPC targets.')
    else
      ImGui.TextWrapped('All current target actions stay shared across target types here. Only NPC tether remains blocked in this build.')
    end
    _drawKV('Tether Active:', TCL.move.tetherActive and 'TRUE' or 'FALSE')
    if TCL.move.tetherActive ~= true then
      if t and t.exists and t.isNPC == true then
        if ImGui.Button('Start Tether To Player') then
          _setError('NPC tether is disabled in this build')
        end
      elseif ImGui.Button('Start Tether To Player') then
        _clearError()
        local ok, msg = _startTetherToPlayer()
        if ok then _log(msg) else _setError(msg) end
      end
    else
      if ImGui.Button('Stop Tether') then
        _stopTether()
        _log('Stopped tether')
      end
    end
  end
end

local function _startsWith(s, prefix)
  s = tostring(s or '')
  prefix = tostring(prefix or '')
  return prefix == '' or string.sub(s, 1, #prefix) == prefix
end

local function _dbNormalizeTypeName(typeName)
  local s = _trim(typeName)
  s = s:gsub('^handle:', '')
  s = s:gsub('^whandle:', '')
  return s
end

local function _dbTryDumpType(typeName)
  if not DumpType then return nil, nil end
  local tries, seen = {}, {}
  local raw = _trim(typeName)
  if raw ~= '' then tries[#tries + 1] = raw end
  local normalized = _dbNormalizeTypeName(raw)
  if normalized ~= '' then tries[#tries + 1] = normalized end
  if normalized ~= '' and normalized ~= raw then tries[#tries + 1] = 'handle:' .. normalized end
  for i = 1, #tries do
    local candidate = tries[i]
    if candidate ~= '' and not seen[candidate] then
      seen[candidate] = true
      local dump = _pcall(function() return DumpType(candidate, false) end)
      if type(dump) == 'string' and dump ~= '' then return dump, candidate end
    end
  end
  return nil, nil
end

local function _dbExtractDumpName(dumpText)
  local s = tostring(dumpText or '')
  local name = s:match('name:%s*([%w_:]+)')
  if name and name ~= '' then return _trim(name) end
  return nil
end

local function _dbExtractBracedBlock(textValue, key)
  local s = tostring(textValue or '')
  local pattern = key .. '%s*:%s*%{'
  local startPos, endPos = string.find(s, pattern)
  if not startPos then return nil end
  local depth = 1
  local i = endPos + 1
  while i <= #s do
    local ch = string.sub(s, i, i)
    if ch == '{' then
      depth = depth + 1
    elseif ch == '}' then
      depth = depth - 1
      if depth == 0 then
        return string.sub(s, endPos + 1, i - 1)
      end
    end
    i = i + 1
  end
  return nil
end


local function _dbParsePropDefsFromDumpText(dumpText)
  local props = {}
  local seen = {}
  if type(dumpText) ~= 'string' or dumpText == '' then return props end
  local block = _dbExtractBracedBlock(dumpText, 'properties')
  if type(block) ~= 'string' or block == '' then return props end
  for line in string.gmatch(block, '[^\r\n]+') do
    local rawLine = _trim(line):gsub(',$', '')
    if rawLine ~= '' then
      local name, sig = rawLine:match('^([%w_]+)%s*=>%s*%((.-)%)$')
      if not name then name, sig = rawLine:match('^([%w_]+)%s*=>%s*(.-)$') end
      if not name then name, sig = rawLine:match('^([%w_]+)%s*:%s*(.-)$') end
      name = _trim(name)
      sig = _trim(sig)
      if name ~= '' and sig ~= '' and not seen[name] then
        seen[name] = true
        props[#props + 1] = { name = name, typeName = sig }
      end
    end
  end
  table.sort(props, function(a, b) return tostring(a.name or '') < tostring(b.name or '') end)
  return props
end

local function _dbBuildSchemaTables()
  if TCL.db and TCL.db.schemaBuilt == true then return end
  TCL.db.schemas = TCL.db.schemas or {}

  TCL.db.schemas['gamedataAffiliation_Record'] = {
    { name = 'enumComment', typeName = 'String' },
    { name = 'animWrappers', typeName = 'array:Name' },
    { name = 'localizedName', typeName = 'LocKey' },
    { name = 'enumName', typeName = 'Name' },
    { name = 'iconPath', typeName = 'Name' },
  }

  TCL.db.schemas['gamedataArchetypeData_Record'] = {
    { name = 'type', typeName = 'ForeignKey' },
    { name = 'statModifierGroups', typeName = 'array:ForeignKey' },
    { name = 'abilityGroups', typeName = 'array:ForeignKey' },
    { name = 'shootingPatternPackages', typeName = 'array:ForeignKey' },
  }

  TCL.db.schemas['gamedataNPCEquipmentGroup_Record'] = {
    { name = 'equipmentItems', typeName = 'array:ForeignKey' },
  }

  TCL.db.schemas['gamedataNPCEquipmentItem_Record'] = {
    { name = 'equipSlot', typeName = 'Name' },
    { name = 'item', typeName = 'ForeignKey' },
    { name = 'onBodySlot', typeName = 'Name' },
    { name = 'equipCondition', typeName = 'array:ForeignKey' },
    { name = 'unequipCondition', typeName = 'array:ForeignKey' },
  }

  TCL.db.schemas['gamedataNPCEquipmentItemPool_Record'] = {
    { name = 'pool', typeName = 'array:ForeignKey' },
  }

  TCL.db.schemas['gamedataNPCEquipmentItemsPoolEntry_Record'] = {
    { name = 'minLevel', typeName = 'Int32' },
    { name = 'maxLevel', typeName = 'Int32' },
    { name = 'weight', typeName = 'Float' },
    { name = 'items', typeName = 'array:ForeignKey' },
  }

  TCL.db.schemas['gamedataCharacter_Record'] = {
    { name = 'abilities', typeName = 'array:ForeignKey' },
    { name = 'actionMap', typeName = 'ForeignKey' },
    { name = 'affiliation', typeName = 'ForeignKey' },
    { name = 'alertedSensesPreset', typeName = 'ForeignKey' },
    { name = 'alternativeDisplayName', typeName = 'LocKey' },
    { name = 'alternativeFullDisplayName', typeName = 'LocKey' },
    { name = 'appearanceName', typeName = 'Name' },
    { name = 'archetypeData', typeName = 'ForeignKey' },
    { name = 'archetypeName', typeName = 'Name' },
    { name = 'attachmentSlots', typeName = 'array:Name' },
    { name = 'audioMeleeMaterial', typeName = 'Name' },
    { name = 'baseAttitudeGroup', typeName = 'Name' },
    { name = 'bossHealthBarThresholds', typeName = 'array:Float' },
    { name = 'bountyDrawTable', typeName = 'ForeignKey' },
    { name = 'canHaveGenericTalk', typeName = 'Bool' },
    { name = 'characterType', typeName = 'Name' },
    { name = 'combatSensesPreset', typeName = 'ForeignKey' },
    { name = 'communitySquad', typeName = 'ForeignKey' },
    { name = 'contentAssignment', typeName = 'ForeignKey' },
    { name = 'cpoCharacterBuild', typeName = 'ForeignKey' },
    { name = 'crowdAppearanceNames', typeName = 'array:Name' },
    { name = 'crowdMemberSettings', typeName = 'ForeignKey' },
    { name = 'defaultCrosshair', typeName = 'ForeignKey' },
    { name = 'despawnChildCommunityWhenPlayerInVehicle', typeName = 'Bool' },
    { name = 'devNotes', typeName = 'String' },
    { name = 'disableDefeatedState', typeName = 'Bool' },
    { name = 'displayName', typeName = 'LocKey' },
    { name = 'dropsAmmoOnDeathChance', typeName = 'Float' },
    { name = 'dropsControlledLoot', typeName = 'Bool' },
    { name = 'dropsMoneyOnDeath', typeName = 'Bool' },
    { name = 'dropsWeaponOnDeath', typeName = 'Bool' },
    { name = 'effectors', typeName = 'array:ForeignKey' },
    { name = 'enableSensesOnStart', typeName = 'Bool' },
    { name = 'entityTemplatePath', typeName = 'String' },
    { name = 'EquipmentAreas', typeName = 'array:ForeignKey' },
    { name = 'equipmentAreas', typeName = 'array:ForeignKey' },
    { name = 'forceCanHaveGenericTalk', typeName = 'Bool' },
    { name = 'forcedTBHZOffset', typeName = 'Float' },
    { name = 'fullDisplayName', typeName = 'LocKey' },
    { name = 'genders', typeName = 'array:Name' },
    { name = 'hasDirectionalStarts', typeName = 'Bool' },
    { name = 'hideUIDetection', typeName = 'Bool' },
    { name = 'hideUIElements', typeName = 'Bool' },
    { name = 'holocallInitializerPath', typeName = 'String' },
    { name = 'ignoreDetectionForAudioCue', typeName = 'Bool' },
    { name = 'isBumpable', typeName = 'Bool' },
    { name = 'isChild', typeName = 'Bool' },
    { name = 'isCrowd', typeName = 'Bool' },
    { name = 'isLightCrowd', typeName = 'Bool' },
    { name = 'itemGroups', typeName = 'array:ForeignKey' },
    { name = 'items', typeName = 'array:ForeignKey' },
    { name = 'lootBagEntity', typeName = 'Name' },
    { name = 'lootDrop', typeName = 'ForeignKey' },
    { name = 'lootInjectionParams', typeName = 'ForeignKey' },
    { name = 'minigameInstance', typeName = 'ForeignKey' },
    { name = 'multiplayerTemplatePaths', typeName = 'array:String' },
    { name = 'objectActions', typeName = 'array:ForeignKey' },
    { name = 'onSpawnGLPs', typeName = 'array:ForeignKey' },
    { name = 'primaryEquipment', typeName = 'ForeignKey' },
    { name = 'priority', typeName = 'Name' },
    { name = 'rarity', typeName = 'Name' },
    { name = 'reactionPreset', typeName = 'ForeignKey' },
    { name = 'relaxedSensesPreset', typeName = 'ForeignKey' },
    { name = 'savable', typeName = 'Bool' },
    { name = 'scannerModulePreset', typeName = 'ForeignKey' },
    { name = 'secondaryEquipment', typeName = 'ForeignKey' },
    { name = 'sensePreset', typeName = 'ForeignKey' },
    { name = 'skipDisplayArchetype', typeName = 'Bool' },
    { name = 'squadParamsID', typeName = 'ForeignKey' },
    { name = 'statModifierGroups', typeName = 'array:ForeignKey' },
    { name = 'statModifiers', typeName = 'array:ForeignKey' },
    { name = 'statPools', typeName = 'array:ForeignKey' },
    { name = 'staticCommunityAppearancesDistributionEnabled', typeName = 'Bool' },
    { name = 'tags', typeName = 'array:Name' },
    { name = 'threatTrackingPreset', typeName = 'ForeignKey' },
    { name = 'uiNameplate', typeName = 'ForeignKey' },
    { name = 'useForcedTBHZOffset', typeName = 'Bool' },
    { name = 'visualTags', typeName = 'array:Name' },
    { name = 'voiceTag', typeName = 'Name' },
    { name = 'weaponSlot', typeName = 'Name' },
    { name = 'weakspots', typeName = 'array:ForeignKey' },
  }

  for _, defs in pairs(TCL.db.schemas) do
    table.sort(defs, function(a, b) return tostring(a.name or '') < tostring(b.name or '') end)
  end
  TCL.db.schemaBuilt = true
end

local function _dbSchemaKeyForRecord(typeName, recordId)
  local tn = tostring(typeName or '')
  local rid = tostring(recordId or '')
  if TCL.db.schemas and TCL.db.schemas[tn] then return tn end
  if rid ~= '' then
    if _startsWith(rid, 'Character.') and TCL.db.schemas['gamedataCharacter_Record'] then return 'gamedataCharacter_Record' end
  end
  return nil
end

_dbGetSchemaProps = function(typeName, recordId)
  _dbBuildSchemaTables()
  local key = _dbSchemaKeyForRecord(typeName, recordId)
  if key and TCL.db.schemas and TCL.db.schemas[key] then return TCL.db.schemas[key], key end
  return {}, nil
end

_dbParseTypeProperties = function(typeName)
  local cache = TCL.db.typeCache or {}
  local key = _trim(typeName)
  if key ~= '' and cache[key] then return cache[key] end
  local dumpText, resolvedType = _dbTryDumpType(typeName)
  local props = _dbParsePropDefsFromDumpText(dumpText)
  if key ~= '' then cache[key] = props end
  if resolvedType and resolvedType ~= '' then cache[resolvedType] = props end
  local normalized = _dbNormalizeTypeName(typeName)
  if normalized ~= '' then cache[normalized] = props end
  TCL.db.typeCache = cache
  return props
end

_dbMergePropDefs = function(primary, secondary)
  local out = {}
  local seen = {}
  local function add(list)
    for i = 1, #(list or {}) do
      local def = list[i]
      local name = _trim(def and def.name or '')
      if name ~= '' and not seen[name] then
        seen[name] = true
        out[#out + 1] = { name = name, typeName = _trim(def and def.typeName or 'unknown') }
      end
    end
  end
  add(primary)
  add(secondary)
  table.sort(out, function(a, b) return tostring(a.name or '') < tostring(b.name or '') end)
  return out
end
local function _dbMaybeTDBIDToString(value)
  if value == nil then return nil end
  if type(value) == 'string' then return _trim(value) end
  local out = nil
  if TDBID and TDBID.ToStringDEBUG then
    out = _pcall(function() return TDBID.ToStringDEBUG(value) end)
    out = _trim(out)
    if out ~= '' and out ~= 'userdata' then return out end
  end
  out = _pcall(function() return tostring(value) end)
  out = _trim(out)
  if out ~= '' and out ~= 'userdata' then return out end
  return nil
end

local function _dbMaybeNameToString(value)
  if value == nil then return nil end
  if type(value) == 'string' then return _trim(value) end
  if Game and Game.NameToString then
    local out = _pcall(function() return Game.NameToString(value) end)
    out = _trim(out)
    if out ~= '' and out ~= 'userdata' then return out end
  end
  return nil
end

local function _dbResolveLocalizedText(value)
  if value == nil or not Game or not Game.GetLocalizedTextByKey then return nil end
  local tries = {}
  if type(value) == 'number' then tries[#tries + 1] = value end
  if type(value) == 'string' and value:match('^%-?%d+$') then tries[#tries + 1] = tonumber(value) end
  local fromValue = tonumber(value and value.value or nil)
  if fromValue then tries[#tries + 1] = fromValue end
  tries[#tries + 1] = value
  for i = 1, #tries do
    local v = tries[i]
    local out = _pcall(function() return Game.GetLocalizedTextByKey(v) end)
    out = _trim(out)
    if out ~= '' and out ~= 'nil' then return out end
  end
  return nil
end

local function _dbFormatScalar(typeName, value)
  if value == nil then return 'nil' end
  local vt = type(value)
  if vt == 'boolean' then return value and 'TRUE' or 'FALSE' end
  if vt == 'number' then return tostring(value) end
  if vt == 'string' then
    local s = value
    if string.find(string.lower(typeName or ''), 'lockey', 1, true) ~= nil then
      local loc = _dbResolveLocalizedText(s)
      if loc and loc ~= '' and loc ~= s then return s .. ' -> ' .. loc end
    end
    return s
  end
  local loc = nil
  if string.find(string.lower(typeName or ''), 'lockey', 1, true) ~= nil then
    loc = _dbResolveLocalizedText(value)
  end
  local s = _dbMaybeNameToString(value) or _dbMaybeTDBIDToString(value) or _trim(tostring(value))
  if s == '' then s = '<unprintable>' end
  if loc and loc ~= '' and loc ~= s then return s .. ' -> ' .. loc end
  return s
end

local function _dbTryResolveRecordId(typeName, value)
  if value == nil or not TweakDB or not TweakDB.GetRecord then return nil end
  local candidates = {}
  if type(value) == 'string' then candidates[#candidates + 1] = _trim(value) end
  local byTdbid = _dbMaybeTDBIDToString(value)
  if byTdbid and byTdbid ~= '' then candidates[#candidates + 1] = byTdbid end
  local byName = _dbMaybeNameToString(value)
  if byName and byName ~= '' then candidates[#candidates + 1] = byName end
  local baseType = string.lower(_dbNormalizeTypeName(typeName or ''))
  local preferRecord = string.find(baseType, '_record', 1, true) ~= nil or string.find(baseType, 'tweakdbid', 1, true) ~= nil
  local seen = {}
  for i = 1, #candidates do
    local candidate = _trim(candidates[i])
    if candidate ~= '' and not seen[candidate] then
      seen[candidate] = true
      if candidate ~= 'None' and not string.find(candidate, '0000000000000000', 1, true) then
        local rec = _pcall(function() return TweakDB:GetRecord(candidate) end)
        if rec then return candidate end
        if preferRecord and string.find(candidate, '.', 1, true) ~= nil then
          local rec2 = _pcall(function() return TweakDB:GetRecord(candidate) end)
          if rec2 then return candidate end
        end
      end
    end
  end
  return nil
end

local _dbLoadRecordNode

local function _dbMakeValueEntry(name, typeName, value, flatPath, depth)
  local entry = {
    name = tostring(name or ''),
    typeName = tostring(typeName or 'unknown'),
    flatPath = tostring(flatPath or ''),
    kind = 'scalar',
    display = '',
    childRecordId = nil,
    childNode = nil,
    children = nil,
    count = 0,
    error = nil,
    value = value,
    depth = tonumber(depth or 0) or 0,
  }

  local itemType = nil
  if _startsWith(entry.typeName, 'array:') then itemType = string.sub(entry.typeName, 7) end

  if type(value) == 'table' and itemType ~= nil then
    entry.kind = 'array'
    entry.children = {}
    entry.count = #(value or {})
    entry.display = tostring(entry.count) .. ' items'
    local limit = math.min(entry.count, tonumber(TCL.db.maxArrayPreview or 128) or 128)
    for i = 1, limit do
      local child = _dbMakeValueEntry('[' .. tostring(i) .. ']', itemType, value[i], entry.flatPath .. '[' .. tostring(i) .. ']', (entry.depth or 0) + 1)
      entry.children[#entry.children + 1] = child
    end
    if entry.count > limit then
      entry.children[#entry.children + 1] = {
        name = '...',
        typeName = itemType,
        flatPath = entry.flatPath .. '[...]',
        kind = 'scalar',
        display = tostring(entry.count - limit) .. ' more items not expanded',
      }
    end
    return entry
  end

  local childRecordId = _dbTryResolveRecordId(entry.typeName, value)
  if childRecordId and childRecordId ~= '' then
    entry.kind = 'recordRef'
    entry.childRecordId = childRecordId
    entry.display = childRecordId
    return entry
  end

  entry.display = _dbFormatScalar(entry.typeName, value)
  return entry
end

_dbLoadRecordNode = function(recordId, flatPath, depth)
  local rid = _trim(recordId)
  if rid == '' then return nil, 'No record ID' end
  local cache = TCL.db.recordCache or {}
  if cache[rid] and cache[rid].loaded == true then return cache[rid] end

  local node = cache[rid] or {
    kind = 'record',
    recordId = rid,
    flatPath = tostring(flatPath or rid),
    typeName = 'Unknown',
    loaded = false,
    props = {},
    error = nil,
    depth = tonumber(depth or 0) or 0,
  }
  cache[rid] = node
  TCL.db.recordCache = cache

  if not TweakDB or not TweakDB.GetRecord then
    node.error = 'TweakDB is unavailable'
    return node, node.error
  end

  local rec = _pcall(function() return TweakDB:GetRecord(rid) end)
  if not rec then
    node.error = 'Could not load record: ' .. rid
    return node, node.error
  end

  local dumpText = Dump and _pcall(function() return Dump(rec, false) end) or nil
  local typeName = _dbExtractDumpName(dumpText) or _toClassName(rec) or 'Unknown'
  node.typeName = typeName

  local directProps = _dbParsePropDefsFromDumpText(dumpText)
  local typeProps = _dbParseTypeProperties(typeName)
  if #typeProps == 0 then
    typeProps = _dbParseTypeProperties(_dbNormalizeTypeName(typeName))
  end
  local schemaProps, schemaKey = _dbGetSchemaProps(typeName, rid)
  local propDefs = _dbMergePropDefs(directProps, typeProps)
  propDefs = _dbMergePropDefs(propDefs, schemaProps)

  node.props = {}
  for i = 1, #propDefs do
    local def = propDefs[i]
    local path = rid .. '.' .. tostring(def.name)
    local value = _pcall(function() return TweakDB:GetFlat(path) end)
    node.props[#node.props + 1] = _dbMakeValueEntry(def.name, def.typeName, value, path, node.depth + 1)
  end

  node.loaded = true
  if #propDefs == 0 then
    node.error = 'No properties discovered for ' .. tostring(typeName)
  elseif #directProps == 0 and #typeProps == 0 and schemaKey ~= nil then
    node.error = 'Using built-in schema fallback for ' .. tostring(schemaKey)
  else
    node.error = nil
  end
  return node, node.error
end

local function _dbClearBrowser()
  TCL.db.rootRecordId = nil
  TCL.db.rootType = nil
  TCL.db.rootNode = nil
  TCL.db.rawDumpPreview = ''
  TCL.db.recordCache = {}
  TCL.db.status = 'Cleared TweakDB browser'
end

local function _dbLoadRootRecord(recordId)
  local rid = _trim(recordId)
  if rid == '' then
    TCL.db.status = 'Enter a root record ID first'
    return false, TCL.db.status
  end
  TCL.db.rootInput = rid
  TCL.db.rootRecordId = rid
  TCL.db.rootNode = nil
  TCL.db.rootType = nil
  TCL.db.recordCache = {}
  local node, err = _dbLoadRecordNode(rid, rid, 0)
  TCL.db.rootNode = node
  TCL.db.rootType = node and node.typeName or nil
  local rec = TweakDB and TweakDB.GetRecord and _pcall(function() return TweakDB:GetRecord(rid) end) or nil
  TCL.db.rawDumpPreview = (rec and GameDump and _pcall(function() return GameDump(rec) end)) or ''
  if node and node.loaded == true then
    TCL.db.status = 'Loaded ' .. rid .. ' as ' .. tostring(node.typeName or 'Unknown')
    return true, TCL.db.status
  end
  TCL.db.status = tostring(err or (node and node.error) or ('Failed to load ' .. rid))
  return false, TCL.db.status
end

local function _dbCountCachedNodes()
  local n = 0
  for _ in pairs(TCL.db.recordCache or {}) do n = n + 1 end
  return n
end

local function _dbSelfMatches(entry, query)
  local q = string.lower(_trim(query))
  if q == '' then return true end
  local bits = {
    tostring(entry and entry.name or ''),
    tostring(entry and entry.typeName or ''),
    tostring(entry and entry.flatPath or ''),
    tostring(entry and entry.display or ''),
    tostring(entry and entry.recordId or ''),
    tostring(entry and entry.childRecordId or ''),
  }
  local hay = string.lower(table.concat(bits, ' | '))
  return string.find(hay, q, 1, true) ~= nil
end

local function _dbMatchesRecursive(entry, query)
  local q = string.lower(_trim(query))
  if q == '' then return true end
  if _dbSelfMatches(entry, q) then return true end
  if not entry then return false end
  if entry.kind == 'record' then
    for i = 1, #(entry.props or {}) do
      if _dbMatchesRecursive(entry.props[i], q) then return true end
    end
  elseif entry.kind == 'array' then
    for i = 1, #(entry.children or {}) do
      if _dbMatchesRecursive(entry.children[i], q) then return true end
    end
  elseif entry.kind == 'recordRef' and entry.childNode then
    if _dbMatchesRecursive(entry.childNode, q) then return true end
  end
  return false
end

local function _dbRenderEntry(entry, query)
  if not entry or not _dbMatchesRecursive(entry, query) then return end

  if entry.kind == 'record' then
    for i = 1, #(entry.props or {}) do
      _dbRenderEntry(entry.props[i], query)
    end
    return
  end

  if entry.kind == 'scalar' then
    ImGui.BulletText(string.format('%s [%s] = %s', tostring(entry.name or '?'), tostring(entry.typeName or '?'), tostring(entry.display or 'nil')))
    return
  end

  if entry.kind == 'array' then
    local label = string.format('%s [%s] = %s', tostring(entry.name or '?'), tostring(entry.typeName or '?'), tostring(entry.display or '0 items'))
    if ImGui.TreeNode(label .. '##' .. tostring(entry.flatPath or label)) then
      for i = 1, #(entry.children or {}) do
        _dbRenderEntry(entry.children[i], query)
      end
      ImGui.TreePop()
    end
    return
  end

  if entry.kind == 'recordRef' then
    local label = string.format('%s [%s] = %s', tostring(entry.name or '?'), tostring(entry.typeName or '?'), tostring(entry.display or ''))
    if ImGui.TreeNode(label .. '##' .. tostring(entry.flatPath or label)) then
      if not entry.childNode and entry.childRecordId then
        local childNode = _dbLoadRecordNode(entry.childRecordId, entry.flatPath, (entry.depth or 0) + 1)
        entry.childNode = childNode
      end
      if entry.childNode then
        if entry.childNode.error then
          ImGui.TextWrapped('Load error: ' .. tostring(entry.childNode.error))
        end
        for i = 1, #(entry.childNode.props or {}) do
          _dbRenderEntry(entry.childNode.props[i], query)
        end
      else
        ImGui.TextWrapped('Could not resolve child record.')
      end
      ImGui.TreePop()
    end
    return
  end
end

local function _dbSyncToCurrentTarget(force)
  local rid = _trim(TCL.target and TCL.target.recordId or '')
  if rid == '' then return false end
  if force == true or (TCL.db.autoLoadCurrent == true and tostring(TCL.db.lastAutoRecordId or '') ~= rid) then
    TCL.db.lastAutoRecordId = rid
    TCL.db.rootInput = rid
    return _dbLoadRootRecord(rid)
  end
  return false
end

local function _drawTweakDBBrowserSection()
  ImGui.TextWrapped("Loads the current target's TweakDB record and shows record fields. For character records it now falls back to a built-in Character schema when CET dump metadata is incomplete.")

  TCL.db.autoLoadCurrent = _checkbox('Auto-load current target record', TCL.db.autoLoadCurrent == true)
  ImGui.SameLine()
  if ImGui.Button('Use Current Target Record') then
    _clearError()
    local ok, msg = _dbSyncToCurrentTarget(true)
    if not ok then _setError(msg or 'Current target has no record ID') else _log(msg) end
  end
  ImGui.SameLine()
  if ImGui.Button('Refresh Loaded Root') then
    _clearError()
    local ok, msg = _dbLoadRootRecord(TCL.db.rootInput)
    if ok then _log(msg) else _setError(msg) end
  end
  ImGui.SameLine()
  if ImGui.Button('Clear Browser') then
    _dbClearBrowser()
  end

  TCL.db.rootInput = _inputText('Root Record ID', TCL.db.rootInput, 256)
  TCL.db.search = _inputText('Browser Search', TCL.db.search, 256)

  _drawKV('Browser Status:', TCL.db.status)
  _drawKV('Root Record:', TCL.db.rootRecordId or 'None')
  _drawKV('Root Type:', TCL.db.rootType or 'Unknown')
  _drawKV('Cached Record Nodes:', tostring(_dbCountCachedNodes()))

  ImGui.BeginChild('tcl_tweakdb_browser_tree', 0, 360, true)
  local root = TCL.db.rootNode
  if not root then
    ImGui.TextWrapped('No record loaded yet. Scan a target, then use its record ID here.')
  else
    ImGui.TextWrapped(string.format('Root: %s [%s]', tostring(root.recordId or '?'), tostring(root.typeName or '?')))
    if root.error then
      ImGui.TextWrapped('Field discovery note: ' .. tostring(root.error))
    end
    for i = 1, #(root.props or {}) do
      _dbRenderEntry(root.props[i], TCL.db.search)
    end
  end
  ImGui.EndChild()

  if TCL.db.rawDumpPreview and TCL.db.rawDumpPreview ~= '' then
    if ImGui.CollapsingHeader('Raw GameDump Preview', ImGuiTreeNodeFlags.DefaultOpen or 32) then
      ImGui.BeginChild('tcl_tweakdb_raw_dump', 0, 130, true)
      ImGui.TextWrapped(tostring(TCL.db.rawDumpPreview))
      ImGui.EndChild()
    end
  end
end


local function _drawStatusEffectsSection()
  if not (TCL.runtime and TCL.runtime.armed == true) then
    ImGui.TextWrapped('Status effect browsing is only available while in game.')
    _drawKV('Cache Status:', TCL.runtime and TCL.runtime.waitingStatus or 'Only available while in game')
    _drawKV('Known Effect IDs:', 'Locked until runtime is armed')
    return
  end
  local prevLiveRefresh = TCL.statusFx.liveRefresh == true
  TCL.statusFx.liveRefresh = _checkbox('Live refresh current target', TCL.statusFx.liveRefresh == true)
  if prevLiveRefresh ~= (TCL.statusFx.liveRefresh == true) then _saveSettings() end
  _drawKV('Cache Status:', TCL.statusFx.status)
  _drawKV('Known Effect IDs:', tostring(#(TCL.statusFx.ids or {})))
  _drawKV('Last Scan:', _fmtAgo(TCL.statusFx.scannedAt))
  TCL.statusFx.search = _inputText('Effect Search', TCL.statusFx.search, 256)
  TCL.statusFx.manualEffectId = _inputText('Manual Effect ID Override', TCL.statusFx.manualEffectId, 256)

  local filtered = _filteredStatusIds()
  local preview = _effectIdFromUI(); if preview == '' then preview = '(no matching effects)' end
  _drawKV('Selected Effect:', preview)

  ImGui.BeginChild('tcl_effect_browser', 0, 170, true)
  if #filtered == 0 then
    ImGui.TextWrapped('No effect IDs match the current search yet.')
  else
    for i = 1, #filtered do
      if ImGui.Selectable(tostring(filtered[i]), TCL.statusFx.selectedIndex == i) then TCL.statusFx.selectedIndex = i; TCL.statusFx.selectedEffectId = tostring(filtered[i]) end
    end
  end
  ImGui.EndChild()

  if ImGui.Button('Scan Active Effects Now') then
    _clearError()
    local ok, msg = _scanCurrentTargetStatusEffects(false)
    if not ok then _setError(msg) end
  end
  ImGui.SameLine()
  if ImGui.Button('Apply Selected / Manual Effect To Current Target') then
    _clearError()
    local ok, msg = _applyStatusEffectToCurrentTarget(_effectIdFromUI())
    if ok then _log(msg) else _setError(msg) end
  end
end


local function _drawEmbeddedTargetHeader()
  local t = TCL.target or {}
  local hasTarget = (t and t.exists == true)
  ImGui.BeginChild('tcl_target_header', 0, 118, true)
  ImGui.Columns(3, 'tcl_target_header_cols', false)
  _drawKV('Name:', hasTarget and _noTargetValue(t.displayName) or 'No Target')
  _drawKV('Type:', hasTarget and _noTargetValue(t.category) or 'No Target')
  _drawKV('Class:', hasTarget and _noTargetValue(t.className) or 'No Target')
  _drawKVCopy('Record:', hasTarget and _noTargetValue(t.recordId) or 'No Target', 'hdr_record')
  _drawKVCopy('Entity ID:', hasTarget and _noTargetValue(tostring(t.entityID or '-')) or 'No Target', 'hdr_entity_id')
  _drawKVCopy('Appearance:', hasTarget and _noTargetValue(_prettyAppearanceName(t.appearance)) or 'No Target', 'hdr_appearance')
  ImGui.NextColumn()
  _drawKV('Target Source:', (TCL.targetLock and TCL.targetLock.active == true) and 'Locked' or 'Live')
  _drawKV('Lock Status:', _targetLockLabel())
  _drawKV('Status:', hasTarget and 'Target Acquired' or 'No Target')
  _drawKV('Distance:', hasTarget and string.format('%.2f m', tonumber(t.distance or 0) or 0) or 'No Target')
  _drawKV('Speed:', hasTarget and string.format('%.2f', tonumber(t.speed or 0) or 0) or 'No Target')
  _drawKV('Effects:', hasTarget and tostring(TCL.statusFx.activeCount or 0) or 'No Target')
  ImGui.NextColumn()
  _drawKVCopy('XYZ:', _safeTargetXYZ(t.xyz), 'hdr_xyz')
  _drawKV('Affiliation:', hasTarget and _noTargetValue(t.affiliation) or 'No Target')
  _drawKV('Attitude:', hasTarget and _noTargetValue(t.attitude) or 'No Target')
  _drawKV('Combat:', hasTarget and _noTargetValue(t.combat) or 'No Target')
  _drawKV('Health:', hasTarget and string.format('%.1f / %.1f', tonumber(t.health or 0) or 0, tonumber(t.healthMax or 0) or 0) or 'No Target')
  _drawKV('Last Seen:', hasTarget and _fmtAgo(t.scannedAt) or 'No Target')
  ImGui.Columns(1)
  if ImGui.Button((TCL.targetLock and TCL.targetLock.active == true) and 'Unlock To Live Target##header' or 'Lock Current Target##header') then
    _clearError()
    local ok, msg
    if TCL.targetLock and TCL.targetLock.active == true then
      ok, msg = _unlockCurrentTarget()
    else
      ok, msg = _lockCurrentTarget()
    end
    if ok then _log(msg); _refreshTarget(true) else _setError(msg) end
  end
  ImGui.SameLine()
  if ImGui.Button('Refresh Target Snapshot##header') then
    _clearError()
    _refreshTarget(true)
    _log('Refreshed target snapshot')
  end
  ImGui.SameLine()
  if ImGui.Button('Load Current Record In Browser##header') then
    _clearError()
    local ok, msg = _dbSyncToCurrentTarget(true)
    if not ok then _setError(msg or 'Current target has no record ID') else _log(msg) end
  end
  ImGui.SameLine()
  if ImGui.Button('Refresh Appearance Options##header') then
    local options = _refreshAppearanceStateForCurrentTarget(true)
    _log('Appearance options refreshed: ' .. tostring(#(options or {})))
  end
  ImGui.EndChild()
end

local function _drawEmbeddedSection(title, keyName, defaultOpen, fn)
  local ui = TCL.ui or {}
  local flags = ((ui[keyName] == nil and defaultOpen) or ui[keyName] == true) and (ImGuiTreeNodeFlags.DefaultOpen or 32) or 0
  local open = ImGui.CollapsingHeader(title, flags)
  ui[keyName] = (open == true)
  if open then
    fn()
  end
end

local function _drawEmbeddedLayout()
  _drawEmbeddedTargetHeader()
  ImGui.Separator()
  _drawEmbeddedSection('Target Summary', 'sectionSummaryOpen', true, _drawCurrentTargetSection)
  _drawEmbeddedSection('Actions', 'sectionActionsOpen', true, _drawAppearanceAndMoveSection)
  _drawEmbeddedSection('Logbook', 'sectionLogbookOpen', false, _drawLogSection)
  _drawEmbeddedSection('Status Effects', 'sectionStatusOpen', false, _drawStatusEffectsSection)
  _drawEmbeddedSection('TweakDB Browser', 'sectionTweakDBOpen', false, _drawTweakDBBrowserSection)
end


local function _drawWindow()
  if TCL.window.open ~= true then return end
  if (not TCL.overlayOpen) and (TCL.keepOpenWhenOverlayClosed ~= true) then return end
  if ImGui.SetNextWindowSize then ImGui.SetNextWindowSize(920, 960, ImGuiCond.FirstUseEver or 4) end
  ImGui.Begin(TCL.window.title)

  local runtimeReady = (TCL.runtime and TCL.runtime.armed == true)
  _drawKV('Status:', runtimeReady and TCL.status or (TCL.runtime.waitingStatus or TCL.status))
  if TCL.lastError then _drawKV('Last Error:', TCL.lastError) end
  if not runtimeReady then
    ImGui.TextWrapped('Only available while in game. The window can stay open here, but gameplay-facing controls stay locked until the player is attached to the world and the game is out of pre-game state.')
  end

  local prevSlowEnabled = TCL.slowmo.enabled == true
  local prevSlowScale = tonumber(TCL.slowmo.scale or 0.15) or 0.15
  local prevKeepOpen = TCL.keepOpenWhenOverlayClosed == true
  local prevSectionSummary = TCL.ui.sectionSummaryOpen == true
  local prevSectionActions = TCL.ui.sectionActionsOpen == true
  local prevSectionLogbook = TCL.ui.sectionLogbookOpen == true
  local prevSectionStatus = TCL.ui.sectionStatusOpen == true
  local prevSectionTweakDB = TCL.ui.sectionTweakDBOpen == true

  TCL.slowmo.enabled = _checkbox('Slow Mo', TCL.slowmo.enabled == true)
  ImGui.SameLine()
  ImGui.SetNextItemWidth(90)
  TCL.slowmo.scale = _inputFloat('##tcl_slowmo_scale', TCL.slowmo.scale, 0.05, 0.10, '%.2f')
  if TCL.slowmo.scale < 0.01 then TCL.slowmo.scale = 0.01 end
  if TCL.slowmo.scale > 1.00 then TCL.slowmo.scale = 1.00 end
  ImGui.SameLine()
  ImGui.Text(string.format('x%.2f', tonumber(TCL.slowmo.scale or 1.0) or 1.0))
  ImGui.SameLine()
  TCL.keepOpenWhenOverlayClosed = _checkbox('Keep Open', TCL.keepOpenWhenOverlayClosed == true)
  ImGui.SameLine()
  _drawKV('Target Mode:', (TCL.targetLock and TCL.targetLock.active == true) and 'Locked' or 'Live')

  if prevSlowEnabled ~= (TCL.slowmo.enabled == true)
    or math.abs(prevSlowScale - (tonumber(TCL.slowmo.scale or 0.15) or 0.15)) > 0.0001
    or prevKeepOpen ~= (TCL.keepOpenWhenOverlayClosed == true) then
    _saveSettings()
  end

  ImGui.Separator()
  _beginDisabled(not runtimeReady)

  _drawEmbeddedLayout()

  if prevSectionSummary ~= (TCL.ui.sectionSummaryOpen == true)
    or prevSectionActions ~= (TCL.ui.sectionActionsOpen == true)
    or prevSectionLogbook ~= (TCL.ui.sectionLogbookOpen == true)
    or prevSectionStatus ~= (TCL.ui.sectionStatusOpen == true)
    or prevSectionTweakDB ~= (TCL.ui.sectionTweakDBOpen == true) then
    _saveSettings()
  end

  _endDisabled(not runtimeReady)
  _drawCopyAssist()
  ImGui.End()
end

local function _clearRuntimeGameplayState()
  _unlockCurrentTarget()
  TCL.target = _captureTarget(nil)
  _clearActiveEffectsForNoTarget()
  TCL.refresh.nextTargetAt = 0
  TCL.refresh.nextScanAt = 0
  TCL.refresh.nextCacheRetryAt = 0
end

local function _disarmRuntime(reason)
  local rt = TCL.runtime
  local wasArmed = (rt.armed == true)
  rt.armed = false
  rt.waitingStatus = tostring(reason or 'Waiting to enter game world...')
  if TCL.move and TCL.move.tetherActive == true then _stopTether() end
  if wasArmed then
    _clearRuntimeGameplayState()
  end
  TCL.status = rt.waitingStatus
end

local function _armRuntime()
  local rt = TCL.runtime
  if rt.armed == true then return true end
  rt.armed = true
  rt.waitingStatus = 'Ready'
  TCL.refresh.nextTargetAt = 0
  TCL.refresh.nextScanAt = 0
  TCL.refresh.nextCacheRetryAt = 0
  TCL.status = 'Gameplay ready'
  print('[GTS][TargetControl] Gameplay ready')
  return true
end

local function _updateRuntimeGate()
  if not _isGameplayReady() then
    _disarmRuntime('Only available while in game')
    return false
  end
  return _armRuntime()
end


local _moduleInitialized = false

local function _ensureModuleInitialized()
  if _moduleInitialized then return end
  TCL.now = _now()
  _loadSettings()
  _disarmRuntime('Only available while in game')
  TCL.status = 'Loaded'
  _moduleInitialized = true
  print('[GTS][TargetControl] Embedded target control ready')
end

local function _drawEmbeddedTab(uiState)
  local runtimeReady = (TCL.runtime and TCL.runtime.armed == true)
  local externalKeepOpen = (type(uiState) == 'table' and uiState.keepMenuOpenWhenOverlayClosed == true)
  if externalKeepOpen or TCL.keepOpenWhenOverlayClosed == true then
    TCL.keepOpenWhenOverlayClosed = true
  end

  if ImGui.BeginChild then ImGui.BeginChild('gts_target_control_child', 0, 0, true) end

  _drawKV('Status:', runtimeReady and TCL.status or (TCL.runtime.waitingStatus or TCL.status))
  if TCL.lastError then _drawKV('Last Error:', TCL.lastError) end
  if not runtimeReady then
    ImGui.TextWrapped('Only available while in game. The tab can stay open here, but gameplay-facing controls stay locked until the player is attached to the world and the game is out of pre-game state.')
  end

  local prevSlowEnabled = TCL.slowmo.enabled == true
  local prevSlowScale = tonumber(TCL.slowmo.scale or 0.15) or 0.15
  local prevKeepOpen = TCL.keepOpenWhenOverlayClosed == true
  local prevSectionSummary = TCL.ui.sectionSummaryOpen == true
  local prevSectionActions = TCL.ui.sectionActionsOpen == true
  local prevSectionLogbook = TCL.ui.sectionLogbookOpen == true
  local prevSectionStatus = TCL.ui.sectionStatusOpen == true
  local prevSectionTweakDB = TCL.ui.sectionTweakDBOpen == true

  TCL.slowmo.enabled = _checkbox('Slow Mo', TCL.slowmo.enabled == true)
  ImGui.SameLine()
  ImGui.SetNextItemWidth(90)
  TCL.slowmo.scale = _inputFloat('##tcl_slowmo_scale', TCL.slowmo.scale, 0.05, 0.10, '%.2f')
  if TCL.slowmo.scale < 0.01 then TCL.slowmo.scale = 0.01 end
  if TCL.slowmo.scale > 1.00 then TCL.slowmo.scale = 1.00 end
  ImGui.SameLine()
  ImGui.Text(string.format('x%.2f', tonumber(TCL.slowmo.scale or 1.0) or 1.0))
  ImGui.SameLine()
  TCL.keepOpenWhenOverlayClosed = _checkbox('Keep Open', TCL.keepOpenWhenOverlayClosed == true)
  if type(uiState) == 'table' then
    uiState.keepMenuOpenWhenOverlayClosed = TCL.keepOpenWhenOverlayClosed == true
  end
  ImGui.SameLine()
  _drawKV('Target Mode:', (TCL.targetLock and TCL.targetLock.active == true) and 'Locked' or 'Live')

  if prevSlowEnabled ~= (TCL.slowmo.enabled == true)
    or math.abs(prevSlowScale - (tonumber(TCL.slowmo.scale or 0.15) or 0.15)) > 0.0001
    or prevKeepOpen ~= (TCL.keepOpenWhenOverlayClosed == true) then
    _saveSettings()
  end

  ImGui.Separator()
  _beginDisabled(not runtimeReady)
  _drawEmbeddedLayout()
  if prevSectionSummary ~= (TCL.ui.sectionSummaryOpen == true)
    or prevSectionActions ~= (TCL.ui.sectionActionsOpen == true)
    or prevSectionLogbook ~= (TCL.ui.sectionLogbookOpen == true)
    or prevSectionStatus ~= (TCL.ui.sectionStatusOpen == true)
    or prevSectionTweakDB ~= (TCL.ui.sectionTweakDBOpen == true) then
    _saveSettings()
  end
  _endDisabled(not runtimeReady)
  _drawCopyAssist()

  if ImGui.EndChild then ImGui.EndChild() end
end

function TargetControl.OnInit()
  _ensureModuleInitialized()
end

function TargetControl.OnOverlayStateChanged(isOpen)
  _ensureModuleInitialized()
  TCL.overlayOpen = isOpen == true
end

function TargetControl.OnUpdate(_)
  _ensureModuleInitialized()
  TCL.now = _now()
  if not _updateRuntimeGate() then
    return
  end
  _flushPendingNPCRefreeze()
  _syncSlowMo(false)
  _pollAppearanceTemplateLoads()
  _refreshTarget(false)
  if TCL.db.autoLoadCurrent == true then
    _dbSyncToCurrentTarget(false)
  end
  if TCL.move.tetherActive == true then
    if TCL.now >= (TCL.move.nextTetherAt or 0) then
      TCL.move.nextTetherAt = TCL.now + math.max(0.005, tonumber(TCL.move.tetherEvery or 0.03) or 0.03)
      _updateTether()
    end
  end
  if TCL.target and TCL.target.exists then
    _ensureCurrentTargetLogged(false)
  else
    _clearActiveEffectsForNoTarget()
  end

  if (TCL.statusFx.built ~= true or #(TCL.statusFx.ids or {}) == 0) and TCL.now >= (TCL.refresh.nextCacheRetryAt or 0) then
    TCL.refresh.nextCacheRetryAt = TCL.now + math.max(0.50, tonumber(TCL.refresh.cacheRetryEvery or 1.50) or 1.50)
    _ensureStatusEffectCache(true)
  end

  if TCL.statusFx.liveRefresh == true and TCL.statusFx.built == true and TCL.now >= (TCL.refresh.nextScanAt or 0) then
    TCL.refresh.nextScanAt = TCL.now + math.max(0.10, tonumber(TCL.refresh.scanEvery or 0.60) or 0.60)
    if TCL.target and TCL.target.exists and TCL.target.entityID then
      _scanCurrentTargetStatusEffects(true)
    else
      _clearActiveEffectsForNoTarget()
    end
  end
end

function TargetControl.OnShutdown()
  if not _moduleInitialized then return end
  _saveSettings()
  TCL.slowmo.enabled = false
  _syncSlowMo(true)
  _stopTether()
  _disarmRuntime('Shutting down')
end

function TargetControl.DrawTab(uiState)
  _ensureModuleInitialized()
  _drawEmbeddedTab(uiState)
end

function TargetControl.ReadWorldPosition(handle)
  return _readWorldPosition(handle)
end

function TargetControl.MoveHandleToDest(handle, dest, opts)
  return _moveHandleToDest(handle, dest, opts)
end

function TargetControl.CycleAppearance(step)
  return _cycleAppearance(tonumber(step) or 1)
end

function TargetControl.GetCurrentTargetSnapshot(force)
  _ensureModuleInitialized()
  return _refreshTarget(force == true)
end

function TargetControl.GetCurrentTargetHandle(force)
  _ensureModuleInitialized()
  local t = _refreshTarget(force == true)
  return t and t.handle or nil
end

function TargetControl.GetAppearanceOptionsForCurrentTarget(force)
  _ensureModuleInitialized()
  local options, idx = _refreshAppearanceStateForCurrentTarget(force == true)
  local t = TCL.target or {}
  return _cloneArray(options or {}), tonumber(idx or 0) or 0, tostring(_prettyAppearanceName(t.appearance) or '')
end

function TargetControl.ApplyAppearanceToCurrentTarget(appearance)
  _ensureModuleInitialized()
  local t = _refreshTarget(true)
  if not t or not t.exists or not t.handle then return false, 'No current target' end
  local ok, msg = _applyAppearanceToHandle(t.handle, appearance)
  if ok then _refreshTarget(true) end
  return ok, msg
end

function TargetControl.ApplyAppearanceToHandle(handle, appearance)
  _ensureModuleInitialized()
  if not handle then return false, 'No handle' end
  local ok, msg = _applyAppearanceToHandle(handle, appearance)
  local t = TCL.target or nil
  if ok and t and t.handle and tostring(t.handle) == tostring(handle) then _refreshTarget(true) end
  return ok, msg
end

function TargetControl.RestoreOriginalAppearance()
  _ensureModuleInitialized()
  return _restoreOriginalAppearance()
end

function TargetControl.GetStatusEffectIds(search)
  _ensureModuleInitialized()
  if type(search) == 'string' then TCL.statusFx.search = search end
  _ensureStatusEffectCache(false)
  return _cloneArray(_filteredStatusIds() or {})
end

function TargetControl.ApplyStatusEffectToCurrentTarget(effectId)
  _ensureModuleInitialized()
  return _applyStatusEffectToCurrentTarget(effectId)
end

function TargetControl.DespawnCurrentTarget()
  _ensureModuleInitialized()
  return _despawnCurrentTarget()
end

function TargetControl.StartTetherToPlayer()
  _ensureModuleInitialized()
  return _startTetherToPlayer()
end

function TargetControl.StopTether()
  _ensureModuleInitialized()
  _stopTether()
  return true, 'Stopped tether'
end

function TargetControl.IsTetherActive()
  _ensureModuleInitialized()
  return TCL.move and TCL.move.tetherActive == true
end

return TargetControl
