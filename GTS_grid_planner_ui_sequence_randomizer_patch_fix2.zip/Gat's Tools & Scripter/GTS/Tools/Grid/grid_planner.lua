-- GTS/Tools/Grid/grid_planner.lua
-- Spatial Radius Planner integrated into GTS as a real grid spawning module.
-- Workflow-focused redesign with persistent controls, workspace tabs, help tooltips,
-- separate presets/sequence pages, and a larger grid-driven layout.

local SpawnTools = require("GTS/Tools/spawn_tools")

local Planner = {
    visible = true,
    overlayOpen = false,
    lastClock = nil,

    -- world/grid settings
    gridSizeMeters = 50.0,
    halfGridMeters = 25.0,

    -- placement
    radiusMeters = 12.0,
    zOffsetMeters = 0.0,
    centerOffsetX = 0.0,
    centerOffsetY = 0.0,
    shapeMode = "circle", -- circle | square | diamond | triangle | star

    -- interaction / display
    snapEnabled = true,
    snapStepMeters = 1.0,
    showFill = true,
    showCrosshair = true,
    showMinorGrid = true,
    showMajorGrid = true,
    ghostOpacity = 0.30,

    -- denser grid
    canvasCells = 49,
    cellSizePx = 8.0,
    offsetSpacingPx = 1.0,

    -- workflow layout
    workspaceTab = "grid", -- grid | presets | sequence | summary | display
    currentGridWorkspace = "grid", -- active editable workspace context
    sequenceTab = "playback", -- playback | fill | exit
    toolMode = "paint", -- paint | move_center | set_reference | exclude | erase

    -- reference point
    referenceMode = "player", -- player | center | custom
    customReferenceX = 0.0,
    customReferenceY = 0.0,

    -- workspace anchor (player position/orientation captured for this grid)
    anchorHas = false,
    anchorX = 0.0,
    anchorY = 0.0,
    anchorZ = 0.0,
    anchorFwdX = 0.0,
    anchorFwdY = 1.0,

    pendingWorkspaceSwitch = nil,

    -- real spawn entries / manual fill
    curatedList = {},
    selectedCuratedIndex = 1,
    newItemName = "",
    newItemWeight = 1,
    allowMultiSpawn = true,
    maxStacksPerCell = 4,

    -- live spawn source / options (per-workspace, stored in snapshots)
    spawnMode = "Character",
    dbSearch = "",
    selectedDbIndex = 1,
    customRecordInput = "",
    liveSpawnWhileEditing = true,       -- grid workspace live-spawn flag
    liveSpawnPresets = true,            -- presets workspace live-spawn flag
    despawnAfterSeconds = 0.0,

    -- random/fx preview
    randomPreviewEnabled = false,
    randomDensity = 0.35,
    randomSeed = 1337,
    fxCoverEnabled = false,
    fxCoverName = "",

    -- runtime spawned state
    runtimeSpawns = { grid = {}, presets = {}, sequence = {} },

    -- sequence preview
    sequence = {
        playing = false,
        loop = true,
        mode = "static", -- static | grow | shrink | pulse
        duration = 6.0,
        elapsed = 0.0,
        useLiveRadius = true,
        useRadius = true,
        useRadiusAnimation = false,
        targetRadius = 12.0,
        usePatternPreset = false,
        pattern = "all_at_once",
        nextManualOrder = 1,
        autoFillPreview = false,
        randomizeDuringPlayback = false,
        eventLog = {},
        logLimit = 80,
        activeKeys = {},
        lastUseRadius = true,
        previewEntries = {},
        previewMap = {},
        hoveredTimelineKey = nil,
        -- world anchor: locked when sequence starts so player movement never shifts spawns
        hasAnchor = false,
        anchorX = 0.0, anchorY = 0.0, anchorZ = 0.0,
        anchorFwdX = 0.0, anchorFwdY = 1.0,
        -- timing randomizer: adds up to N extra seconds of random offset per entry spawn time
        timeRandomMax = 0.0,
        -- random fill mask: indices into curatedList eligible for random fill (empty = all)
        randomFillMask = {},
        randomRules = {},
        -- timeline right-click context menu state
        contextMenuKey = nil,
        clipboardKey   = nil,
        -- anchor out-of-area warning popup
        showAnchorWarnPopup = false,
    },

    -- exit behavior UI only
    exitAction = "despawn", -- despawn | none | explode_vehicle | remove_fx | disable_target

    -- runtime ui state
    cellStates = nil,
    cellStateCount = nil,
    dragCellKey = nil,
    hoverInfo = nil,
    workspaceStates = nil,
    lastPromptCenterX = 0.0,
    lastPromptCenterY = 0.0,
    lastPromptRadius = 12.0,
    outsidePrompt = nil,

    title = "Spatial Radius Planner###standalone_spatial_radius_planner"
}

local function clamp(v, minV, maxV)
    if v < minV then return minV end
    if v > maxV then return maxV end
    return v
end

local function trim(s)
    s = tostring(s or "")
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function roundToStep(value, step)
    if not step or step <= 0 then
        return value
    end
    return math.floor((value / step) + 0.5) * step
end

local function frac(v)
    return v - math.floor(v)
end

local function fmt1(v)
    return string.format("%.1f", v or 0)
end

local function fmt2(v)
    return string.format("%.2f", v or 0)
end

local function fmtPct(v)
    return string.format("%.0f%%", (v or 0) * 100.0)
end

local function rgba(r, g, b, a)
    return (r or 255) / 255.0, (g or 255) / 255.0, (b or 255) / 255.0, (a or 255) / 255.0
end

local function ensureSpawnDBReady()
    if SpawnTools and SpawnTools.RefreshDB and SpawnTools.state and SpawnTools.state.dbBuilt ~= true then
        pcall(function() SpawnTools.RefreshDB() end)
    end
end

local function plannerModeList()
    return { 'Character', 'Vehicle', 'Prop', 'FX', 'Attack', 'Entity' }
end

local function getPlannerDBResults()
    ensureSpawnDBReady()
    if SpawnTools and SpawnTools.GetRecordsForMode then
        local ok, results = pcall(function() return SpawnTools.GetRecordsForMode(Planner.spawnMode, Planner.dbSearch) end)
        if ok and type(results) == 'table' then return results end
    end
    return {}
end

local function getPlannerEntryLabel(entry)
    if type(entry) ~= 'table' then return nil end
    local label = trim(entry.label or '')
    if label ~= '' then return label end
    local record = tostring(entry.record or '')
    if record == '' then return nil end
    local base = record:gsub('\\', '/'):match('([^/]+)$') or record
    return tostring(entry.mode or 'Character') .. ': ' .. tostring(base)
end

local function getRecordDisplayLabel(record)
    local rec = tostring(record or '')
    if rec == '' then return '' end
    local base = rec:gsub('\\', '/'):match('([^/]+)$') or rec
    if #base > 52 then
        base = base:sub(1, 49) .. '...'
    end
    return base
end

local function ensurePlannerEntry(record, mode, weight)
    local rec = trim(record)
    local md = tostring(mode or 'Character')
    if rec == '' then return nil end
    for i = 1, #Planner.curatedList do
        local e = Planner.curatedList[i]
        if tostring(e.record or '') == rec and tostring(e.mode or 'Character') == md then
            if weight ~= nil then
                e.weight = clamp(tonumber(weight) or tonumber(e.weight) or 1, 1, 10)
            end
            Planner.selectedCuratedIndex = i
            return i
        end
    end
    table.insert(Planner.curatedList, {
        name = rec,
        label = rec,
        record = rec,
        mode = md,
        weight = clamp(tonumber(weight) or 1, 1, 10)
    })
    Planner.selectedCuratedIndex = #Planner.curatedList
    return Planner.selectedCuratedIndex
end

local function getPlannerEntry(itemIndex)
    if itemIndex == nil then return nil end
    return Planner.curatedList[itemIndex]
end

local function despawnPlannerItem(item)
    if not item then return false end
    local handle = item.handle
    if handle == nil and Game and Game.FindEntityByID and item.entityID then
        pcall(function() handle = Game.FindEntityByID(item.entityID) end)
    end
    if handle then pcall(function() handle:Dispose() end) end
    local des = (Game and Game.GetDynamicEntitySystem and Game.GetDynamicEntitySystem()) or nil
    if des and item.entityID then pcall(function() des:DeleteEntity(item.entityID) end) end
    item.exists = false
    return true
end

local function ensureRuntimeWorkspace(key)
    Planner.runtimeSpawns = Planner.runtimeSpawns or { grid = {}, presets = {}, sequence = {} }
    if Planner.runtimeSpawns[key] == nil then Planner.runtimeSpawns[key] = {} end
    return Planner.runtimeSpawns[key]
end

local function clearRuntimeCell(workspace, key)
    local ws = ensureRuntimeWorkspace(workspace)
    local bucket = ws[key]
    if type(bucket) == 'table' then
        for i = 1, #bucket do despawnPlannerItem(bucket[i]) end
    end
    ws[key] = nil
end

local function clearRuntimeWorkspace(workspace)
    local ws = ensureRuntimeWorkspace(workspace)
    for key, bucket in pairs(ws) do
        if type(bucket) == 'table' then
            for i = 1, #bucket do despawnPlannerItem(bucket[i]) end
        end
        ws[key] = nil
    end
end

local ensureCurrentWorkspaceAnchor

local function getPlannerWorldPoint(localX, localY)
    ensureCurrentWorkspaceAnchor()
    local p = Game and Game.GetPlayer and Game.GetPlayer() or nil
    local posX, posY, posZ = Planner.anchorX, Planner.anchorY, Planner.anchorZ
    local fx, fy = Planner.anchorFwdX, Planner.anchorFwdY

    if Planner.anchorHas ~= true then
        if not p then return nil end
        local pos = nil
        local fwd = nil
        pcall(function() pos = p:GetWorldPosition() end)
        pcall(function() fwd = p:GetWorldForward() end)
        if not pos or not fwd then return nil end
        posX, posY, posZ = (pos.x or 0), (pos.y or 0), (pos.z or 0)
        fx, fy = tonumber(fwd.x or 0) or 0, tonumber(fwd.y or 0) or 0
    end

    local flen = math.sqrt((fx * fx) + (fy * fy))
    if flen < 0.0001 then fx, fy, flen = 0, 1, 1 end
    fx, fy = fx / flen, fy / flen
    local rx, ry = -fy, fx
    return Vector4.new(
        (posX or 0) + (rx * (localX or 0)) + (fx * (localY or 0)),
        (posY or 0) + (ry * (localX or 0)) + (fy * (localY or 0)),
        (posZ or 0) + (tonumber(Planner.zOffsetMeters or 0) or 0),
        1
    )
end

-- Sequence world point: uses the anchored origin captured when playback started
-- so that player movement never shifts where sequence entries spawn.
local function getSequenceWorldPoint(localX, localY)
    local seq = Planner.sequence
    if not seq.hasAnchor then
        return getPlannerWorldPoint(localX, localY)
    end
    local fx, fy = seq.anchorFwdX, seq.anchorFwdY
    local flen = math.sqrt((fx * fx) + (fy * fy))
    if flen < 0.0001 then fx, fy = 0, 1 end
    fx, fy = fx / flen, fy / flen
    local rx, ry = -fy, fx
    return Vector4.new(
        seq.anchorX + (rx * (localX or 0)) + (fx * (localY or 0)),
        seq.anchorY + (ry * (localX or 0)) + (fy * (localY or 0)),
        seq.anchorZ + (tonumber(Planner.zOffsetMeters or 0) or 0),
        1
    )
end

-- Returns the player's current position expressed in grid-local space.
-- In grid/presets workspaces the player is always the origin (0, 0).
-- In the sequence workspace with an active anchor we invert the anchor
-- transform so the dot tracks the player as they walk around.
local function getPlayerLocalForGrid()
    local seq = Planner.sequence
    local useSeqAnchor = (Planner.currentGridWorkspace == 'sequence') and seq.hasAnchor
    local p = Game and Game.GetPlayer and Game.GetPlayer() or nil
    if not p then return 0.0, 0.0 end

    local anchorX, anchorY = Planner.anchorX, Planner.anchorY
    local fx, fy = Planner.anchorFwdX, Planner.anchorFwdY
    if useSeqAnchor then
        anchorX, anchorY = seq.anchorX, seq.anchorY
        fx, fy = seq.anchorFwdX, seq.anchorFwdY
    else
        ensureCurrentWorkspaceAnchor()
    end
    if (not useSeqAnchor) and Planner.anchorHas ~= true then
        return 0.0, 0.0
    end

    local pos = nil
    pcall(function() pos = p:GetWorldPosition() end)
    if not pos then return 0.0, 0.0 end
    local dx = (pos.x or 0) - anchorX
    local dy = (pos.y or 0) - anchorY
    local flen = math.sqrt((fx * fx) + (fy * fy))
    if flen < 0.0001 then fx, fy = 0, 1 end
    fx, fy = fx / math.max(flen, 1), fy / math.max(flen, 1)
    local rx, ry = -fy, fx
    local localX = dx * rx + dy * ry
    local localY = dx * fx + dy * fy
    return localX, localY
end

-- Capture the player's current world position and forward vector as the
-- sequence anchor.  Call this every time playback is started or restarted.
local function captureSequenceAnchor()
    local p = Game and Game.GetPlayer and Game.GetPlayer() or nil
    local seq = Planner.sequence
    if not p then
        seq.hasAnchor = false
        return
    end
    local pos, fwd = nil, nil
    pcall(function() pos = p:GetWorldPosition() end)
    pcall(function() fwd = p:GetWorldForward() end)
    if pos and fwd then
        seq.anchorX    = tonumber(pos.x) or 0
        seq.anchorY    = tonumber(pos.y) or 0
        seq.anchorZ    = tonumber(pos.z) or 0
        seq.anchorFwdX = tonumber(fwd.x) or 0
        seq.anchorFwdY = tonumber(fwd.y) or 1
        seq.hasAnchor  = true
        seq.showAnchorWarnPopup = false
        Planner.anchorHas = true
        Planner.anchorX = seq.anchorX
        Planner.anchorY = seq.anchorY
        Planner.anchorZ = seq.anchorZ
        Planner.anchorFwdX = seq.anchorFwdX
        Planner.anchorFwdY = seq.anchorFwdY
    end
end

local function spawnPlannerEntry(entry, point, despawnSeconds)
    if type(entry) ~= 'table' then return false, 'Missing entry' end
    if not SpawnTools or not SpawnTools.SpawnRecordAtPoint then return false, 'SpawnTools unavailable' end
    local record = tostring(entry.record or '')
    local mode = tostring(entry.mode or 'Character')
    if record == '' then return false, 'Missing record' end
    return SpawnTools.SpawnRecordAtPoint(record, mode, point, despawnSeconds)
end

local function respawnRuntimeCellForState(workspace, row, col, state, localX, localY)
    local entry = getPlannerEntry(state.manualItemIndex)
    local key = tostring(row) .. ':' .. tostring(col)
    clearRuntimeCell(workspace, key)
    if entry == nil or state.excluded then return false end
    local point = getPlannerWorldPoint(localX, localY)
    if not point then return false end
    local count = math.max(1, tonumber(state.stackCount) or 1)
    local bucket = {}
    for i = 1, count do
        local ok, itemOrErr = spawnPlannerEntry(entry, point, tonumber(Planner.despawnAfterSeconds or 0) or 0)
        if ok and type(itemOrErr) == 'table' then
            bucket[#bucket + 1] = itemOrErr
        else
            print('[Grid Planner] Spawn failed: ' .. tostring(itemOrErr))
        end
    end
    if #bucket > 0 then
        local ws = ensureRuntimeWorkspace(workspace)
        ws[key] = bucket
        return true
    end
    return false
end

local function syncRuntimeCellForCurrentWorkspace(row, col, state, localX, localY)
    local workspace = tostring(Planner.currentGridWorkspace or 'grid')
    if workspace ~= 'grid' and workspace ~= 'presets' then
        return false
    end
    -- Check the correct live-spawn flag for this workspace.
    local liveEnabled = (workspace == 'presets') and (Planner.liveSpawnPresets == true)
                     or (workspace == 'grid')    and (Planner.liveSpawnWhileEditing == true)
    if not liveEnabled then
        return false
    end
    if state == nil then
        clearRuntimeCell(workspace, tostring(row) .. ':' .. tostring(col))
        return false
    end
    if state.manualItemIndex == nil or state.excluded or (tonumber(state.stackCount) or 0) <= 0 then
        clearRuntimeCell(workspace, tostring(row) .. ':' .. tostring(col))
        return false
    end
    return respawnRuntimeCellForState(workspace, row, col, state, localX, localY)
end

local function applySequenceExitAction(info)
    if type(info) ~= 'table' then return end
    if Planner.exitAction == 'none' then return end
    if Planner.exitAction == 'explode_vehicle' and tostring(info.mode or '') == 'Vehicle' then
        local point = getPlannerWorldPoint(info.localX, info.localY)
        if point then pcall(function() SpawnTools.SpawnRecordAtPoint('Attacks.Explosion', 'Attack', point, 2.0) end) end
    end
    clearRuntimeCell('sequence', tostring(info.key or ''))
end

local function showHelpIfHovered(text)
    if ImGui.IsItemHovered() then
        ImGui.BeginTooltip()
        ImGui.PushTextWrapPos(360)
        ImGui.TextWrapped(text)
        ImGui.PopTextWrapPos()
        ImGui.EndTooltip()
    end
end

local function pushButtonColors(r1, g1, b1, a1, r2, g2, b2, a2, r3, g3, b3, a3)
    ImGui.PushStyleColor(ImGuiCol.Button, rgba(r1, g1, b1, a1))
    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, rgba(r2, g2, b2, a2))
    ImGui.PushStyleColor(ImGuiCol.ButtonActive, rgba(r3, g3, b3, a3))
end

local function popButtonColors()
    ImGui.PopStyleColor(3)
end

local function pushSelectedButtonStyle()
    pushButtonColors(36, 110, 198, 255, 56, 132, 224, 255, 26, 94, 176, 255)
end

local function pushUnselectedButtonStyle()
    pushButtonColors(42, 42, 46, 255, 58, 58, 66, 255, 34, 34, 38, 255)
end

local function pushAccentButtonStyle()
    pushButtonColors(162, 20, 26, 255, 188, 26, 34, 255, 138, 16, 22, 255)
end

local function parseSliderFloat(currentValue, label, minV, maxV, displayFormat)
    local a, b = ImGui.SliderFloat(label, currentValue, minV, maxV, displayFormat or "%.2f")

    if type(a) == "boolean" then
        if type(b) == "number" then
            return b
        end
        return currentValue
    end

    if type(a) == "number" then
        return a
    end

    return currentValue
end

local function parseSliderInt(currentValue, label, minV, maxV, displayFormat)
    local a, b = ImGui.SliderInt(label, currentValue, minV, maxV, displayFormat or "%d")

    if type(a) == "boolean" then
        if type(b) == "number" then
            return b
        end
        return currentValue
    end

    if type(a) == "number" then
        return a
    end

    return currentValue
end

local function parseInputText(currentValue, label, maxLen)
    local a, b = ImGui.InputText(label, currentValue, maxLen or 256)

    if type(a) == "boolean" then
        if type(b) == "string" then
            return b
        end
        return currentValue
    end

    if type(a) == "string" then
        return a
    end

    return currentValue
end

local function getPlayerWorld()
    local player = Game.GetPlayer()
    if not player then
        return false, 0.0, 0.0, 0.0
    end

    local pos = player:GetWorldPosition()
    if not pos then
        return false, 0.0, 0.0, 0.0
    end

    return true, pos.x or 0.0, pos.y or 0.0, pos.z or 0.0
end

local function getPlacedWorld(px, py, pz)
    local wx = px + Planner.centerOffsetX
    local wy = py + Planner.centerOffsetY
    local wz = pz + Planner.zOffsetMeters
    return wx, wy, wz
end

local function getGridStepMeters()
    return Planner.gridSizeMeters / Planner.canvasCells
end

local function getDistanceFromPlayer()
    return math.sqrt(
        (Planner.centerOffsetX * Planner.centerOffsetX) +
        (Planner.centerOffsetY * Planner.centerOffsetY)
    )
end

local function getCurrentReferenceLocal()
    if Planner.referenceMode == "center" then
        return Planner.centerOffsetX, Planner.centerOffsetY, "Shape Center"
    end

    if Planner.referenceMode == "custom" then
        return Planner.customReferenceX, Planner.customReferenceY, "Custom Reference"
    end

    return 0.0, 0.0, "Player"
end

local function getDistanceFromReference(localX, localY)
    local refX, refY = getCurrentReferenceLocal()
    local dx = localX - refX
    local dy = localY - refY
    return math.sqrt((dx * dx) + (dy * dy))
end

local function setPlacement(localX, localY)
    if Planner.snapEnabled then
        localX = roundToStep(localX, Planner.snapStepMeters)
        localY = roundToStep(localY, Planner.snapStepMeters)
    end

    Planner.centerOffsetX = clamp(localX, -Planner.halfGridMeters, Planner.halfGridMeters)
    Planner.centerOffsetY = clamp(localY, -Planner.halfGridMeters, Planner.halfGridMeters)
end

local function setCustomReference(localX, localY)
    if Planner.snapEnabled then
        localX = roundToStep(localX, Planner.snapStepMeters)
        localY = roundToStep(localY, Planner.snapStepMeters)
    end

    Planner.customReferenceX = clamp(localX, -Planner.halfGridMeters, Planner.halfGridMeters)
    Planner.customReferenceY = clamp(localY, -Planner.halfGridMeters, Planner.halfGridMeters)
    Planner.referenceMode = "custom"
end

local function getCellLocalXY(row, col)
    local cells = Planner.canvasCells
    local halfIndex = (cells - 1) / 2
    local stepMeters = getGridStepMeters()

    local localX = (col - 1 - halfIndex) * stepMeters
    local localY = (halfIndex - (row - 1)) * stepMeters

    return localX, localY
end

local function resetCellStates()
    Planner.cellStates = {}
    Planner.cellStateCount = Planner.canvasCells

    for row = 1, Planner.canvasCells do
        Planner.cellStates[row] = {}
        for col = 1, Planner.canvasCells do
            Planner.cellStates[row][col] = {
                excluded = false,
                manualItemIndex = nil,
                stackCount = 0,
                sequenceOrder = nil
            }
        end
    end
end

local function ensureCellStates()
    if Planner.cellStates == nil or Planner.cellStateCount ~= Planner.canvasCells then
        resetCellStates()
    end
end

local function getCellState(row, col)
    ensureCellStates()
    return Planner.cellStates[row][col]
end

local function clearCellState(state)
    state.excluded = false
    state.manualItemIndex = nil
    state.stackCount = 0
    state.sequenceOrder = nil
end

local function cloneCellStates(src)
    if src == nil then
        return nil
    end

    local out = {}
    for row = 1, #src do
        out[row] = {}
        for col = 1, #(src[row] or {}) do
            local s = src[row][col] or {}
            out[row][col] = {
                excluded = s.excluded == true,
                manualItemIndex = s.manualItemIndex,
                stackCount = tonumber(s.stackCount) or 0,
                sequenceOrder = tonumber(s.sequenceOrder)
            }
        end
    end
    return out
end

local function makeWorkspaceSnapshot()
    return {
        radiusMeters = Planner.radiusMeters,
        zOffsetMeters = Planner.zOffsetMeters,
        centerOffsetX = Planner.centerOffsetX,
        centerOffsetY = Planner.centerOffsetY,
        shapeMode = Planner.shapeMode,
        referenceMode = Planner.referenceMode,
        customReferenceX = Planner.customReferenceX,
        customReferenceY = Planner.customReferenceY,
        anchorHas = Planner.anchorHas == true,
        anchorX = Planner.anchorX or 0.0,
        anchorY = Planner.anchorY or 0.0,
        anchorZ = Planner.anchorZ or 0.0,
        anchorFwdX = Planner.anchorFwdX or 0.0,
        anchorFwdY = Planner.anchorFwdY or 1.0,
        cellStates = cloneCellStates(Planner.cellStates),
        cellStateCount = Planner.cellStateCount,
        lastPromptCenterX = Planner.lastPromptCenterX,
        lastPromptCenterY = Planner.lastPromptCenterY,
        lastPromptRadius = Planner.lastPromptRadius,
        -- per-workspace spawn source state
        spawnMode = Planner.spawnMode,
        dbSearch = Planner.dbSearch,
        selectedDbIndex = Planner.selectedDbIndex,
        liveSpawnWhileEditing = Planner.liveSpawnWhileEditing,
        despawnAfterSeconds = Planner.despawnAfterSeconds,
    }
end

local rebuildSequenceManualOrderCounter

local function applyWorkspaceSnapshot(snapshot)
    if snapshot == nil then
        return
    end

    Planner.radiusMeters = snapshot.radiusMeters or Planner.radiusMeters
    Planner.zOffsetMeters = snapshot.zOffsetMeters or 0.0
    Planner.centerOffsetX = snapshot.centerOffsetX or 0.0
    Planner.centerOffsetY = snapshot.centerOffsetY or 0.0
    Planner.shapeMode = snapshot.shapeMode or 'circle'
    Planner.referenceMode = snapshot.referenceMode or 'player'
    Planner.customReferenceX = snapshot.customReferenceX or 0.0
    Planner.customReferenceY = snapshot.customReferenceY or 0.0
    Planner.anchorHas = snapshot.anchorHas == true
    Planner.anchorX = snapshot.anchorX or 0.0
    Planner.anchorY = snapshot.anchorY or 0.0
    Planner.anchorZ = snapshot.anchorZ or 0.0
    Planner.anchorFwdX = snapshot.anchorFwdX or 0.0
    Planner.anchorFwdY = snapshot.anchorFwdY or 1.0
    Planner.cellStates = cloneCellStates(snapshot.cellStates)
    Planner.cellStateCount = snapshot.cellStateCount or Planner.canvasCells
    Planner.lastPromptCenterX = snapshot.lastPromptCenterX or Planner.centerOffsetX
    Planner.lastPromptCenterY = snapshot.lastPromptCenterY or Planner.centerOffsetY
    Planner.lastPromptRadius = snapshot.lastPromptRadius or Planner.radiusMeters
    -- restore per-workspace spawn source state
    Planner.spawnMode = snapshot.spawnMode or 'Character'
    Planner.dbSearch = snapshot.dbSearch or ''
    Planner.selectedDbIndex = snapshot.selectedDbIndex or 1
    Planner.liveSpawnWhileEditing = (snapshot.liveSpawnWhileEditing ~= false)
    Planner.despawnAfterSeconds = snapshot.despawnAfterSeconds or 0.0
    Planner.hoverInfo = nil
    Planner.outsidePrompt = nil
    ensureCellStates()
    rebuildSequenceManualOrderCounter()
end

local function makeBlankCellStates()
    local out = {}
    for row = 1, Planner.canvasCells do
        out[row] = {}
        for col = 1, Planner.canvasCells do
            out[row][col] = { excluded = false, manualItemIndex = nil, stackCount = 0, sequenceOrder = nil }
        end
    end
    return out
end

local function countPaintedCellsFromMatrix(matrix)
    if type(matrix) ~= 'table' then return 0 end
    local count = 0
    for row = 1, #matrix do
        for col = 1, #(matrix[row] or {}) do
            local s = matrix[row][col]
            if type(s) == 'table' and s.manualItemIndex ~= nil then
                count = count + 1
            end
        end
    end
    return count
end

local function captureCurrentWorkspaceAnchor()
    local p = Game and Game.GetPlayer and Game.GetPlayer() or nil
    if not p then return false end
    local pos, fwd = nil, nil
    pcall(function() pos = p:GetWorldPosition() end)
    pcall(function() fwd = p:GetWorldForward() end)
    if not pos or not fwd then return false end
    Planner.anchorHas = true
    Planner.anchorX = tonumber(pos.x) or 0.0
    Planner.anchorY = tonumber(pos.y) or 0.0
    Planner.anchorZ = tonumber(pos.z) or 0.0
    Planner.anchorFwdX = tonumber(fwd.x) or 0.0
    Planner.anchorFwdY = tonumber(fwd.y) or 1.0
    return true
end

ensureCurrentWorkspaceAnchor = function()
    if Planner.anchorHas ~= true then
        captureCurrentWorkspaceAnchor()
    end
end

local function teleportPlayerToCurrentWorkspaceCenter()
    local p = Game and Game.GetPlayer and Game.GetPlayer() or nil
    if not p then return false end
    ensureCurrentWorkspaceAnchor()
    if not Planner.anchorHas then return false end
    local tp = Vector4.new(Planner.anchorX, Planner.anchorY, Planner.anchorZ, 1)
    local ok = pcall(function() Game.GetTeleportationFacility():Teleport(p, tp, p:GetWorldOrientation()) end)
    return ok == true
end

local function makeFreshSnapshotFromSnapshot(snapshot)
    local snap = snapshot or makeWorkspaceSnapshot()
    snap.cellStates = makeBlankCellStates()
    snap.cellStateCount = Planner.canvasCells
    snap.anchorHas = false
    snap.anchorX = 0.0
    snap.anchorY = 0.0
    snap.anchorZ = 0.0
    snap.anchorFwdX = 0.0
    snap.anchorFwdY = 1.0
    return snap
end

local function ensureWorkspaceStates()
    if Planner.workspaceStates ~= nil then
        return
    end

    ensureCellStates()

    captureCurrentWorkspaceAnchor()
    local base = makeWorkspaceSnapshot()
    Planner.workspaceStates = {
        grid = base,
        presets = makeFreshSnapshotFromSnapshot(base),
        sequence = makeFreshSnapshotFromSnapshot(base)
    }
    Planner.currentGridWorkspace = 'grid'
end

local function saveCurrentWorkspaceState()
    ensureWorkspaceStates()
    local key = Planner.currentGridWorkspace or 'grid'
    if Planner.workspaceStates[key] ~= nil then
        Planner.workspaceStates[key] = makeWorkspaceSnapshot()
    end
end

local function remapEntryIndicesAfterRemoval(removedIndex)
    local function patchCellMatrix(matrix)
        if type(matrix) ~= 'table' then return end
        for row = 1, #matrix do
            local rowData = matrix[row] or {}
            for col = 1, #rowData do
                local s = rowData[col]
                if type(s) == 'table' then
                    if s.manualItemIndex == removedIndex then
                        clearCellState(s)
                    elseif s.manualItemIndex ~= nil and s.manualItemIndex > removedIndex then
                        s.manualItemIndex = s.manualItemIndex - 1
                    end
                end
            end
        end
    end

    patchCellMatrix(Planner.cellStates)
    ensureWorkspaceStates()
    for _, snap in pairs(Planner.workspaceStates or {}) do
        if type(snap) == 'table' then
            patchCellMatrix(snap.cellStates)
        end
    end
    local oldRules = Planner.sequence.randomRules or {}
    local newRules = {}
    for idx, rule in pairs(oldRules) do
        if tonumber(idx) ~= removedIndex then
            local newIdx = tonumber(idx)
            if newIdx and newIdx > removedIndex then newIdx = newIdx - 1 end
            if newIdx then newRules[newIdx] = rule end
        end
    end
    Planner.sequence.randomRules = newRules
end

local function switchWorkspaceContext(key)
    if key ~= 'grid' and key ~= 'presets' and key ~= 'sequence' then
        return
    end

    ensureWorkspaceStates()
    saveCurrentWorkspaceState()
    Planner.currentGridWorkspace = key
    applyWorkspaceSnapshot(Planner.workspaceStates[key])
    ensureCurrentWorkspaceAnchor()
end

local function hash01(a, b, c)
    local value = math.sin((a * 12.9898) + (b * 78.233) + (c * 37.719)) * 43758.5453
    return frac(math.abs(value))
end

local updateSequenceEventLog
local getDisplayedRadius
local getCellItemName
local isInsideShape

local function updateSequenceClock()
    local now = os.clock()
    if Planner.lastClock == nil then
        Planner.lastClock = now
    end

    local dt = now - Planner.lastClock
    Planner.lastClock = now

    if Planner.sequence.playing then
        Planner.sequence.elapsed = Planner.sequence.elapsed + dt
        local duration = math.max(0.05, Planner.sequence.duration)

        if Planner.sequence.elapsed >= duration then
            if Planner.sequence.loop then
                Planner.sequence.elapsed = Planner.sequence.elapsed - duration
                Planner.sequence.activeKeys = {}
                clearRuntimeWorkspace('sequence')
                -- Re-randomize seed each loop cycle if requested
                if Planner.sequence.randomizeDuringPlayback then
                    Planner.randomSeed = ((Planner.randomSeed + 31337) % 999999) + 1
                end
            else
                Planner.sequence.elapsed = duration
                Planner.sequence.playing = false
            end
        end

        updateSequenceEventLog()
    end
end

local function getSequenceTargetRadius()
    if Planner.sequence.useLiveRadius then
        return Planner.radiusMeters
    end
    return Planner.sequence.targetRadius
end

local function isRadiusEnabledForCurrentWorkspace()
    if Planner.currentGridWorkspace == 'sequence' and Planner.sequence.useRadius == false then
        return false
    end
    return true
end

local function appendSequenceLog(kind, textLine)
    local timestamp = fmt2(Planner.sequence.elapsed)
    table.insert(Planner.sequence.eventLog, 1, {
        kind = kind or 'info',
        time = timestamp,
        text = textLine or ''
    })

    while #Planner.sequence.eventLog > (Planner.sequence.logLimit or 80) do
        table.remove(Planner.sequence.eventLog)
    end
end

local function resetSequenceTracking(clearLog)
    Planner.sequence.activeKeys = {}
    Planner.sequence.lastUseRadius = Planner.sequence.useRadius
    if clearLog then
        Planner.sequence.eventLog = {}
    end
end


local function getRandomRule(entryIndex)
    Planner.sequence.randomRules = Planner.sequence.randomRules or {}
    local rule = Planner.sequence.randomRules[entryIndex]
    if type(rule) ~= 'table' then
        rule = {
            enabled = false,
            weight = tonumber((Planner.curatedList[entryIndex] or {}).weight) or 1,
            minDist = 0.0,
            maxDist = 50.0,
            bias = 'none'
        }
        Planner.sequence.randomRules[entryIndex] = rule
    end
    rule.weight = clamp(tonumber(rule.weight) or 1, 1, 100)
    rule.minDist = clamp(tonumber(rule.minDist) or 0.0, 0.0, 50.0)
    rule.maxDist = clamp(tonumber(rule.maxDist) or 50.0, 0.0, 50.0)
    if rule.maxDist < rule.minDist then rule.maxDist = rule.minDist end
    rule.bias = tostring(rule.bias or 'none')
    return rule
end

local function hasAnyEnabledRandomRule()
    Planner.sequence.randomRules = Planner.sequence.randomRules or {}
    for _, rule in pairs(Planner.sequence.randomRules) do
        if type(rule) == 'table' and rule.enabled == true then return true end
    end
    return false
end

rebuildSequenceManualOrderCounter = function()
    local maxOrder = 0
    ensureCellStates()
    for row = 1, Planner.canvasCells do
        for col = 1, Planner.canvasCells do
            local state = Planner.cellStates[row][col]
            local so = tonumber(state.sequenceOrder) or 0
            if so > maxOrder then
                maxOrder = so
            end
        end
    end
    Planner.sequence.nextManualOrder = maxOrder + 1
end

local function getSequencePatternFraction(total)
    if total <= 0 then
        return 0
    end

    local duration = math.max(0.05, Planner.sequence.duration)
    local progress = clamp(Planner.sequence.elapsed / duration, 0.0, 1.0)

    if (not Planner.sequence.useRadiusAnimation) or Planner.sequence.mode == "static" then
        return 1.0
    end

    if Planner.sequence.mode == "grow" then
        -- Grow from a small seed (5% of full set) so centre-point cells
        -- are always included even at T=0.
        return clamp(0.05 + progress * 0.95, 0.0, 1.0)
    end

    if Planner.sequence.mode == "shrink" then
        -- Shrink from full set down to a small seed so we never hit 0.
        return clamp(1.0 - progress * 0.95, 0.0, 1.0)
    end

    if Planner.sequence.mode == "pulse" then
        -- Use half-cosine so the pulse peaks in the middle of the cycle
        -- and never touches 0 (keeps at least ~5% of entries visible).
        local wave = 0.5 - 0.5 * math.cos(progress * 2.0 * math.pi)
        return clamp(0.05 + wave * 0.95, 0.0, 1.0)
    end

    return progress
end

local function sortSequenceEntries(entries)
    local pattern = Planner.sequence.pattern or "all_at_once"

    if not Planner.sequence.usePatternPreset then
        table.sort(entries, function(a, b)
            local ao = tonumber(a.sequenceOrder) or 999999999
            local bo = tonumber(b.sequenceOrder) or 999999999
            if ao ~= bo then return ao < bo end
            if a.row ~= b.row then return a.row < b.row end
            return a.col < b.col
        end)
        return
    end

    local function angleFor(e)
        return math.atan(e.dy, e.dx)
    end

    local function edgeFor(e)
        return math.max(math.abs(e.dx), math.abs(e.dy))
    end

    local function axisFor(e)
        return math.min(math.abs(e.dx), math.abs(e.dy))
    end

    local function diagFor(e)
        return math.abs(math.abs(e.dx) - math.abs(e.dy))
    end

    local function parityFor(e)
        return (e.row + e.col) % 2
    end

    table.sort(entries, function(a, b)
        if pattern == "rows_top" then
            if a.row ~= b.row then return a.row < b.row end
            return a.col < b.col
        elseif pattern == "rows_bottom" then
            if a.row ~= b.row then return a.row > b.row end
            return a.col < b.col
        elseif pattern == "cols_left" then
            if a.col ~= b.col then return a.col < b.col end
            return a.row < b.row
        elseif pattern == "cols_right" then
            if a.col ~= b.col then return a.col > b.col end
            return a.row < b.row
        elseif pattern == "zigzag_rows" then
            if a.row ~= b.row then return a.row < b.row end
            local aRev = (a.row % 2 == 0)
            if aRev then return a.col > b.col end
            return a.col < b.col
        elseif pattern == "diagonal_tl_br" then
            local ad, bd = a.row + a.col, b.row + b.col
            if ad ~= bd then return ad < bd end
            return a.row < b.row
        elseif pattern == "diagonal_tr_bl" then
            local ad, bd = a.row - a.col, b.row - b.col
            if ad ~= bd then return ad < bd end
            return a.row < b.row
        elseif pattern == "spiral_out" then
            local ae, be = edgeFor(a), edgeFor(b)
            if ae ~= be then return ae < be end
            return angleFor(a) < angleFor(b)
        elseif pattern == "spiral_in" then
            local ae, be = edgeFor(a), edgeFor(b)
            if ae ~= be then return ae > be end
            return angleFor(a) < angleFor(b)
        elseif pattern == "rings_out" then
            if a.dist ~= b.dist then return a.dist < b.dist end
            return angleFor(a) < angleFor(b)
        elseif pattern == "rings_in" then
            if a.dist ~= b.dist then return a.dist > b.dist end
            return angleFor(a) < angleFor(b)
        elseif pattern == "perimeter_in" then
            local ae, be = edgeFor(a), edgeFor(b)
            if ae ~= be then return ae > be end
            return angleFor(a) < angleFor(b)
        elseif pattern == "cross_expand" then
            local aa, ba = axisFor(a), axisFor(b)
            if aa ~= ba then return aa < ba end
            if a.dist ~= b.dist then return a.dist < b.dist end
            return angleFor(a) < angleFor(b)
        elseif pattern == "x_expand" then
            local adg, bdg = diagFor(a), diagFor(b)
            if adg ~= bdg then return adg < bdg end
            if a.dist ~= b.dist then return a.dist < b.dist end
            return angleFor(a) < angleFor(b)
        elseif pattern == "random_seeded" then
            if a.rand ~= b.rand then return a.rand < b.rand end
            return a.row < b.row
        elseif pattern == "checker_wave" then
            local ap, bp = parityFor(a), parityFor(b)
            if ap ~= bp then return ap < bp end
            if a.row ~= b.row then return a.row < b.row end
            return a.col < b.col
        end
        if a.row ~= b.row then return a.row < b.row end
        return a.col < b.col
    end)
end


local function getSequenceFinalRadius()
    if not Planner.sequence.useRadius then
        return 0.0
    end

    if Planner.sequence.useLiveRadius then
        return clamp(Planner.radiusMeters, 0.0, 50.0)
    end

    return clamp(Planner.sequence.targetRadius, 0.0, 50.0)
end

local function buildSequenceCandidateList(useDisplayedRadius)
    ensureCellStates()

    local candidates = {}
    local useRadius = Planner.sequence.useRadius == true
    local radiusForFilter = useDisplayedRadius and getDisplayedRadius() or getSequenceFinalRadius()

    for row = 1, Planner.canvasCells do
        for col = 1, Planner.canvasCells do
            local state = Planner.cellStates[row][col]
            if state.manualItemIndex ~= nil and not state.excluded then
                local localX, localY = getCellLocalXY(row, col)
                local dx = localX - Planner.centerOffsetX
                local dy = localY - Planner.centerOffsetY
                local enabled = true

                if useRadius then
                    enabled = isInsideShape(dx, dy, radiusForFilter, Planner.shapeMode)
                end

                if enabled then
                    local key = tostring(row) .. ':' .. tostring(col)
                    candidates[#candidates + 1] = {
                        key = key,
                        row = row,
                        col = col,
                        localX = localX,
                        localY = localY,
                        dx = dx,
                        dy = dy,
                        itemName = getCellItemName(state.manualItemIndex) or 'Unknown',
                        entryIndex = state.manualItemIndex,
                        mode = tostring(((getPlannerEntry(state.manualItemIndex) or {}).mode) or 'Character'),
                        record = tostring(((getPlannerEntry(state.manualItemIndex) or {}).record) or ''),
                        stackCount = math.max(1, tonumber(state.stackCount) or 1),
                        sequenceOrder = tonumber(state.sequenceOrder),
                        manualSpawnTime = state.manualSpawnTime,  -- per-cell time override
                        dist = math.sqrt((dx * dx) + (dy * dy)),
                        rand = hash01(row, col, Planner.randomSeed + 401.17)
                    }
                end
            end
        end
    end

    local total = #candidates
    if total <= 0 then
        return candidates
    end

    sortSequenceEntries(candidates)

    local duration = math.max(0.05, Planner.sequence.duration)
    local randMax = math.max(0.0, tonumber(Planner.sequence.timeRandomMax) or 0.0)
    for i = 1, total do
        local e = candidates[i]
        e.orderIndex = i
        if (Planner.sequence.usePatternPreset and Planner.sequence.pattern == 'all_at_once') or total == 1 then
            e.spawnTime = 0.0
        else
            e.spawnTime = ((i - 1) / math.max(1, total - 1)) * duration
        end
        -- Per-cell manual time override (set via timeline right-click)
        if e.manualSpawnTime ~= nil then
            e.spawnTime = clamp(tonumber(e.manualSpawnTime) or e.spawnTime, 0.0, duration)
        end
        -- Apply per-entry timing jitter if timeRandomMax > 0.
        if randMax > 0.0 then
            local jitter = hash01(e.row, e.col, Planner.randomSeed + 7777.77) * randMax
            e.spawnTime = clamp(e.spawnTime + jitter, 0.0, duration)
        end
    end

    return candidates
end

local function refreshSequencePreviewCache()
    if Planner.currentGridWorkspace ~= 'sequence' then
        Planner.sequence.previewEntries = {}
        Planner.sequence.previewMap = {}
        Planner.sequence.hoveredTimelineKey = nil
        return
    end

    local entries = buildSequenceCandidateList(false)
    local map = {}
    for i = 1, #entries do
        local e = entries[i]
        map[e.key] = e
    end

    Planner.sequence.previewEntries = entries
    Planner.sequence.previewMap = map
end

local function buildSequenceActiveMap()
    local active = {}
    local candidates = buildSequenceCandidateList(true)
    if #candidates == 0 then
        return active
    end

    local elapsed = tonumber(Planner.sequence.elapsed) or 0.0
    for i = 1, #candidates do
        local e = candidates[i]
        local shouldActivate = false
        if Planner.sequence.usePatternPreset and (Planner.sequence.pattern or 'all_at_once') == 'all_at_once' then
            shouldActivate = true
        else
            shouldActivate = (elapsed + 0.0001) >= (tonumber(e.spawnTime) or 0.0)
        end

        if shouldActivate then
            active[e.key] = {
                key = e.key,
                row = e.row,
                col = e.col,
                localX = e.localX,
                localY = e.localY,
                itemName = e.itemName,
                stackCount = e.stackCount,
                dist = e.dist,
                orderIndex = e.orderIndex,
                spawnTime = e.spawnTime,
                entryIndex = e.entryIndex,
                mode = e.mode,
                record = e.record,
            }
        end
    end

    return active
end

updateSequenceEventLog = function()
    if not Planner.sequence.playing then
        return
    end

    if Planner.sequence.lastUseRadius ~= Planner.sequence.useRadius then
        Planner.sequence.activeKeys = {}
        Planner.sequence.lastUseRadius = Planner.sequence.useRadius
        appendSequenceLog('info', Planner.sequence.useRadius and 'Sequence radius mode enabled.' or 'Sequence radius mode disabled. Manual timeline spawns will be logged instead.')
    end

    local previous = Planner.sequence.activeKeys or {}
    local current = buildSequenceActiveMap()

    for key, info in pairs(current) do
        if previous[key] == nil then
            clearRuntimeCell('sequence', key)
            if info.record ~= '' then
                local point = getSequenceWorldPoint(info.localX, info.localY)
                local bucket = {}
                if point then
                    for i = 1, math.max(1, tonumber(info.stackCount) or 1) do
                        local ok, itemOrErr = SpawnTools.SpawnRecordAtPoint(info.record, info.mode, point, tonumber(Planner.despawnAfterSeconds or 0) or 0)
                        if ok and type(itemOrErr) == 'table' then bucket[#bucket + 1] = itemOrErr end
                    end
                end
                if #bucket > 0 then
                    ensureRuntimeWorkspace('sequence')[key] = bucket
                end
            end
            if Planner.sequence.useRadius then
                appendSequenceLog('enter', info.itemName .. ' entered radius at T+' .. fmt2(Planner.sequence.elapsed) .. 's (' .. tostring(info.row) .. ',' .. tostring(info.col) .. ')')
            else
                appendSequenceLog('spawn', info.itemName .. ' spawned in timeline at T+' .. fmt2(Planner.sequence.elapsed) .. 's (' .. tostring(info.row) .. ',' .. tostring(info.col) .. ')')
            end
        end
    end

    for key, info in pairs(previous) do
        if current[key] == nil then
            if Planner.sequence.useRadius then
                appendSequenceLog('exit', info.itemName .. ' exited radius at T+' .. fmt2(Planner.sequence.elapsed) .. 's (' .. tostring(info.row) .. ',' .. tostring(info.col) .. ')')
            else
                appendSequenceLog('remove', info.itemName .. ' was removed from timeline at T+' .. fmt2(Planner.sequence.elapsed) .. 's (' .. tostring(info.row) .. ',' .. tostring(info.col) .. ')')
            end
            applySequenceExitAction(info)
        end
    end

    Planner.sequence.activeKeys = current
end

local function resetCurrentWorkspaceGrid()
    clearRuntimeWorkspace(Planner.currentGridWorkspace or 'grid')
    resetCellStates()
    Planner.hoverInfo = nil
    Planner.outsidePrompt = nil
    Planner.lastPromptCenterX = Planner.centerOffsetX
    Planner.lastPromptCenterY = Planner.centerOffsetY
    Planner.lastPromptRadius = Planner.radiusMeters
    if Planner.currentGridWorkspace == 'sequence' then
        Planner.sequence.nextManualOrder = 1
        resetSequenceTracking(true)
    end
end

-- Autofill the current sequence workspace grid with a single entry index.
-- Every cell that is inside the active shape (or all cells if radius is off)
-- gets stamped with the supplied entryIndex and a stackCount of 1.
local function autofillSequenceGrid(entryIndex)
    if entryIndex == nil or not Planner.curatedList[entryIndex] then return end
    ensureCellStates()
    local cells = Planner.canvasCells
    local useRadius = isRadiusEnabledForCurrentWorkspace()
    local radius   = getDisplayedRadius and getDisplayedRadius() or Planner.radiusMeters
    local order    = 1
    for row = 1, cells do
        for col = 1, cells do
            local lx, ly = getCellLocalXY(row, col)
            local dx = lx - Planner.centerOffsetX
            local dy = ly - Planner.centerOffsetY
            local inside = (not useRadius) or isInsideShape(dx, dy, radius, Planner.shapeMode)
            if inside then
                local state = Planner.cellStates[row][col]
                state.excluded      = false
                state.manualItemIndex = entryIndex
                state.stackCount    = 1
                state.sequenceOrder = order
                order = order + 1
            end
        end
    end
    Planner.sequence.nextManualOrder = order
end

-- Cut/copy one sequence cell state.  key = "row:col"
local function copySequenceCell(key)
    local r, c = key:match('^(%d+):(%d+)$')
    r, c = tonumber(r), tonumber(c)
    if not r or not c then return end
    local state = getCellState(r, c)
    Planner.sequence.clipboardKey = key
    Planner.sequence._clipboardState = {
        manualItemIndex = state.manualItemIndex,
        stackCount      = state.stackCount,
        sequenceOrder   = state.sequenceOrder,
        excluded        = state.excluded,
    }
end

local function pasteSequenceCell(destKey)
    if not Planner.sequence._clipboardState then return end
    local r, c = destKey:match('^(%d+):(%d+)$')
    r, c = tonumber(r), tonumber(c)
    if not r or not c then return end
    local src = Planner.sequence._clipboardState
    local state = getCellState(r, c)
    state.manualItemIndex = src.manualItemIndex
    state.stackCount      = src.stackCount
    state.sequenceOrder   = src.sequenceOrder
    state.excluded        = src.excluded
end

getDisplayedRadius = function()
    if not isRadiusEnabledForCurrentWorkspace() then
        return 0.0
    end

    local target = clamp(getSequenceTargetRadius(), 0.0, 50.0)

    if not Planner.sequence.playing then
        return target
    end

    local duration = math.max(0.05, Planner.sequence.duration)
    local progress = clamp(Planner.sequence.elapsed / duration, 0.0, 1.0)

    if (not Planner.sequence.useRadiusAnimation) or Planner.sequence.mode == "static" then
        return target
    end

    if Planner.sequence.mode == "grow" then
        return target * clamp(0.05 + progress * 0.95, 0.0, 1.0)
    end

    if Planner.sequence.mode == "shrink" then
        return target * clamp(1.0 - progress * 0.95, 0.0, 1.0)
    end

    if Planner.sequence.mode == "pulse" then
        local wave = 0.5 - 0.5 * math.cos(progress * 2.0 * math.pi)
        return target * clamp(0.05 + wave * 0.95, 0.0, 1.0)
    end

    return target * clamp(0.05 + progress * 0.95, 0.0, 1.0)
end

local function pointInPolygon(x, y, pts)
    local inside = false
    local j = #pts
    for i = 1, #pts do
        local xi, yi = pts[i][1], pts[i][2]
        local xj, yj = pts[j][1], pts[j][2]
        local intersects = ((yi > y) ~= (yj > y)) and (x < ((xj - xi) * (y - yi) / ((yj - yi) ~= 0 and (yj - yi) or 0.000001)) + xi)
        if intersects then
            inside = not inside
        end
        j = i
    end
    return inside
end

isInsideShape = function(dx, dy, radius, shapeMode)
    local r = math.max(0.0, radius or 0.0)
    local ax = math.abs(dx)
    local ay = math.abs(dy)

    if shapeMode == "square" then
        return math.max(ax, ay) <= r
    end

    if shapeMode == "diamond" then
        return (ax + ay) <= r
    end

    if shapeMode == "triangle" then
        if dy < -r or dy > r then
            return false
        end
        local halfWidth = (r - dy) * 0.5
        return ax <= halfWidth
    end

    if shapeMode == "star" then
        local pts = {}
        local outer = r
        local inner = r * 0.42
        local start = -math.pi * 0.5
        for i = 0, 9 do
            local ang = start + (i * math.pi / 5.0)
            local rr = (i % 2 == 0) and outer or inner
            pts[#pts + 1] = { math.cos(ang) * rr, math.sin(ang) * rr }
        end
        return pointInPolygon(dx, dy, pts)
    end

    return math.sqrt((dx * dx) + (dy * dy)) <= r
end

local function pickWeightedCuratedIndex(row, col, distFromPlayer)
    if #Planner.curatedList == 0 then
        return nil
    end

    local anyEnabled = hasAnyEnabledRandomRule()
    local pool = {}
    local totalWeight = 0.0
    local normDist = clamp((tonumber(distFromPlayer) or 0.0) / math.max(1.0, Planner.halfGridMeters), 0.0, 1.0)

    for i = 1, #Planner.curatedList do
        local entry = Planner.curatedList[i]
        local rule = getRandomRule(i)
        local enabled = (not anyEnabled) or rule.enabled == true
        local minDist = clamp(tonumber(rule.minDist) or 0.0, 0.0, 50.0)
        local maxDist = clamp(tonumber(rule.maxDist) or 50.0, 0.0, 50.0)
        if maxDist < minDist then maxDist = minDist end
        if enabled and (tonumber(distFromPlayer) or 0.0) >= minDist and (tonumber(distFromPlayer) or 0.0) <= maxDist then
            local w = clamp(tonumber(rule.weight) or tonumber(entry.weight) or 1, 1, 100)
            if tostring(rule.bias) == 'near' then
                w = w * (1.25 + (1.0 - normDist) * 1.75)
            elseif tostring(rule.bias) == 'far' then
                w = w * (1.25 + normDist * 1.75)
            end
            totalWeight = totalWeight + w
            pool[#pool + 1] = { idx = i, weight = w }
        end
    end

    if #pool == 0 or totalWeight <= 0.0 then
        return nil
    end

    local roll = hash01(row, col, Planner.randomSeed + 17.31) * totalWeight
    local running = 0.0
    for _, item in ipairs(pool) do
        running = running + item.weight
        if roll <= running then
            return item.idx
        end
    end

    return pool[#pool].idx
end

local function getRandomPreview(row, col, state, insideShape, distFromPlayer)
    if not Planner.randomPreviewEnabled or not insideShape or state.excluded or state.manualItemIndex ~= nil then
        return false, nil, 0
    end

    local chance = hash01(row, col, Planner.randomSeed)
    if chance > Planner.randomDensity then
        return false, nil, 0
    end

    local itemIndex = pickWeightedCuratedIndex(row, col, distFromPlayer)
    if itemIndex == nil then
        return false, nil, 0
    end

    local stacks = 1
    if Planner.allowMultiSpawn then
        local stackNoise = hash01(row, col, Planner.randomSeed + 91.77)
        stacks = 1 + math.floor(stackNoise * Planner.maxStacksPerCell)
        stacks = clamp(stacks, 1, Planner.maxStacksPerCell)
    end

    return true, itemIndex, stacks
end

getCellItemName = function(itemIndex)
    local entry = getPlannerEntry(itemIndex)
    return getPlannerEntryLabel(entry)
end

local function getCellContext(row, col, localX, localY)
    local state = getCellState(row, col)
    local activeRadius = getDisplayedRadius()
    local dx = localX - Planner.centerOffsetX
    local dy = localY - Planner.centerOffsetY
    local radiusEnabled = isRadiusEnabledForCurrentWorkspace()
    local insideShape = radiusEnabled and isInsideShape(dx, dy, activeRadius, Planner.shapeMode) or false
    local ghostVisible = radiusEnabled and insideShape

    local stepMeters = getGridStepMeters()
    -- In sequence workspace with an active anchor, the player dot moves live.
    -- In grid/presets, the player is always at local (0,0).
    local plx, ply = getPlayerLocalForGrid()
    local playerDist = math.sqrt(((localX - plx) * (localX - plx)) + ((localY - ply) * (localY - ply)))
    local nearRow, nearCol = getNearestCellIndices(plx, ply)
    local playerHit = (row == nearRow and col == nearCol)
    local centerHit = math.abs(localX - Planner.centerOffsetX) <= (stepMeters * 0.45)
        and math.abs(localY - Planner.centerOffsetY) <= (stepMeters * 0.45)

    local refX, refY, refLabel = getCurrentReferenceLocal()
    local refHit = math.abs(localX - refX) <= (stepMeters * 0.45)
        and math.abs(localY - refY) <= (stepMeters * 0.45)

    local ax = math.abs(localX)
    local ay = math.abs(localY)
    local isMajorX = math.abs((ax / 10.0) - math.floor((ax / 10.0) + 0.5)) < 0.001
    local isMajorY = math.abs((ay / 10.0) - math.floor((ay / 10.0) + 0.5)) < 0.001
    local isMajor = isMajorX or isMajorY

    local randomActive, randomItemIndex, randomStacks = false, nil, 0
    if radiusEnabled then
        randomActive, randomItemIndex, randomStacks = getRandomPreview(row, col, state, insideShape, playerDist)
    end

    local seqKey = tostring(row) .. ':' .. tostring(col)
    local sequencePreviewEntry = (Planner.currentGridWorkspace == 'sequence') and Planner.sequence.previewMap[seqKey] or nil
    local sequenceNowActive = (Planner.currentGridWorkspace == 'sequence') and Planner.sequence.playing and (Planner.sequence.activeKeys[seqKey] ~= nil)
    local timelineHighlighted = (Planner.currentGridWorkspace == 'sequence') and (Planner.sequence.hoveredTimelineKey == seqKey)

    return {
        state = state,
        insideShape = insideShape,
        ghostVisible = ghostVisible,
        radiusEnabled = radiusEnabled,
        sequencePreviewEntry = sequencePreviewEntry,
        sequencePreviewPlanned = sequencePreviewEntry ~= nil,
        sequenceNowActive = sequenceNowActive,
        timelineHighlighted = timelineHighlighted,
        isMajor = isMajor,
        playerHit = playerHit,
        centerHit = centerHit,
        refHit = refHit,
        refLabel = refLabel,
        randomActive = randomActive,
        randomItemIndex = randomItemIndex,
        randomStacks = randomStacks,
        manualActive = (state.manualItemIndex ~= nil) and ((insideShape and (not state.excluded)) or (not radiusEnabled and (not state.excluded))),
        manualDormant = radiusEnabled and (state.manualItemIndex ~= nil) and (not insideShape),
        excludedActive = state.excluded and (insideShape or (not radiusEnabled and state.manualItemIndex ~= nil)),
        stackedActive = (state.manualItemIndex ~= nil) and ((state.stackCount or 0) > 1) and ((insideShape and (not state.excluded)) or (not radiusEnabled and (not state.excluded))),
        fxGhost = Planner.fxCoverEnabled and ghostVisible,
        activeRadius = activeRadius
    }
end

local function pushDotStyle(context)
    local br, bg, bb, ba = 124, 14, 22, 210
    local hr, hg, hb, ha = 156, 22, 30, 240
    local ar, ag, ab, aa = 106, 10, 18, 255

    if Planner.showMajorGrid and context.isMajor then
        br, bg, bb, ba = 170, 26, 34, 220
        hr, hg, hb, ha = 198, 34, 42, 245
        ar, ag, ab, aa = 142, 20, 26, 255
    end

    if context.ghostVisible then
        local ghostAlpha = math.floor(255 * clamp(Planner.ghostOpacity, 0.05, 0.95))
        br, bg, bb, ba = 38, 138, 54, ghostAlpha
        hr, hg, hb, ha = 54, 164, 72, ghostAlpha + 24
        ar, ag, ab, aa = 30, 118, 44, ghostAlpha + 32

        if Planner.showMajorGrid and context.isMajor then
            br, bg, bb, ba = 46, 160, 66, ghostAlpha + 12
            hr, hg, hb, ha = 62, 186, 84, ghostAlpha + 28
            ar, ag, ab, aa = 36, 136, 54, ghostAlpha + 36
        end

        if context.fxGhost then
            br, bg, bb, ba = 60, 110, 220, ghostAlpha
            hr, hg, hb, ha = 80, 132, 238, ghostAlpha + 24
            ar, ag, ab, aa = 48, 92, 196, ghostAlpha + 32
        end
    end

    if context.excludedActive then
        br, bg, bb, ba = 82, 82, 88, 235
        hr, hg, hb, ha = 104, 104, 112, 255
        ar, ag, ab, aa = 64, 64, 70, 255
    end

    if context.randomActive then
        br, bg, bb, ba = 28, 182, 206, 245
        hr, hg, hb, ha = 44, 206, 232, 255
        ar, ag, ab, aa = 22, 154, 176, 255
    end

    if context.manualActive then
        br, bg, bb, ba = 236, 176, 44, 255
        hr, hg, hb, ha = 250, 198, 74, 255
        ar, ag, ab, aa = 208, 148, 34, 255

        if context.sequenceNowActive then
            br, bg, bb, ba = 255, 226, 92, 255
            hr, hg, hb, ha = 255, 238, 126, 255
            ar, ag, ab, aa = 228, 196, 66, 255
        end
    end

    if context.stackedActive then
        br, bg, bb, ba = 182, 76, 224, 255
        hr, hg, hb, ha = 204, 102, 246, 255
        ar, ag, ab, aa = 154, 58, 194, 255
    end
    if context.manualDormant and (context.state.stackCount or 0) > 1 then
        br, bg, bb, ba = 182, 76, 224, 230
        hr, hg, hb, ha = 204, 102, 246, 248
        ar, ag, ab, aa = 154, 58, 194, 248
    end

    if context.manualDormant then
        br, bg, bb, ba = 236, 176, 44, 220
        hr, hg, hb, ha = 250, 198, 74, 245
        ar, ag, ab, aa = 208, 148, 34, 245
    end

    if context.sequencePreviewPlanned then
        br, bg, bb, ba = 214, 148, 52, 244
        hr, hg, hb, ha = 232, 170, 76, 255
        ar, ag, ab, aa = 188, 124, 40, 255

        if context.state.stackCount ~= nil and context.state.stackCount > 1 then
            br, bg, bb, ba = 168, 82, 220, 244
            hr, hg, hb, ha = 194, 108, 244, 255
            ar, ag, ab, aa = 142, 62, 192, 255
        end
    end

    if context.sequenceNowActive then
        br, bg, bb, ba = 112, 236, 106, 255
        hr, hg, hb, ha = 138, 248, 132, 255
        ar, ag, ab, aa = 84, 206, 82, 255
    end

    if context.timelineHighlighted then
        local wave = 0.5 + (0.5 * math.sin(os.clock() * 3.2))
        local glow = math.floor(180 + (75 * wave))
        br, bg, bb, ba = 255, glow, 86, 255
        hr, hg, hb, ha = 255, math.min(255, glow + 18), 126, 255
        ar, ag, ab, aa = 232, math.max(110, glow - 24), 64, 255
    end

    if context.refHit and Planner.referenceMode == "custom" then
        br, bg, bb, ba = 88, 206, 255, 255
        hr, hg, hb, ha = 118, 224, 255, 255
        ar, ag, ab, aa = 70, 178, 228, 255
    end

    if context.centerHit and not context.playerHit then
        br, bg, bb, ba = 255, 206, 72, 255
        hr, hg, hb, ha = 255, 224, 106, 255
        ar, ag, ab, aa = 228, 176, 46, 255
    end

    if context.playerHit and not context.centerHit then
        br, bg, bb, ba = 240, 240, 240, 255
        hr, hg, hb, ha = 255, 255, 255, 255
        ar, ag, ab, aa = 206, 206, 206, 255
    end

    if context.playerHit and context.centerHit then
        br, bg, bb, ba = 92, 198, 255, 255
        hr, hg, hb, ha = 128, 218, 255, 255
        ar, ag, ab, aa = 74, 170, 230, 255
    end

    ImGui.PushStyleColor(ImGuiCol.Button, rgba(br, bg, bb, ba))
    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, rgba(hr, hg, hb, ha))
    ImGui.PushStyleColor(ImGuiCol.ButtonActive, rgba(ar, ag, ab, aa))
end

local function updateHoverInfo(row, col, localX, localY, hasPlayer, px, py, pz, context)
    local wx = px + localX
    local wy = py + localY
    local wz = pz + Planner.zOffsetMeters

    Planner.hoverInfo = {
        row = row,
        col = col,
        key = tostring(row) .. ':' .. tostring(col),
        localX = localX,
        localY = localY,
        worldX = wx,
        worldY = wy,
        worldZ = wz,
        distPlayer = math.sqrt((localX * localX) + (localY * localY)),
        distRef = getDistanceFromReference(localX, localY),
        referenceLabel = context.refLabel,
        insideShape = context.insideShape,
        excluded = context.state.excluded,
        manualItemName = getCellItemName(context.state.manualItemIndex),
        randomItemName = getCellItemName(context.randomItemIndex),
        stackCount = context.state.stackCount or 0,
        randomStacks = context.randomStacks or 0,
        hasPlayer = hasPlayer,
        sequenceOrder = context.sequencePreviewEntry and context.sequencePreviewEntry.orderIndex or nil,
        sequenceSpawnTime = context.sequencePreviewEntry and context.sequencePreviewEntry.spawnTime or nil,
        sequencePreviewPlanned = context.sequencePreviewPlanned,
        sequenceNowActive = context.sequenceNowActive
    }
end

local function drawCellTooltip(localX, localY)
    if not ImGui.IsItemHovered() then
        return
    end

    local info = Planner.hoverInfo
    if info == nil then
        return
    end

    ImGui.BeginTooltip()
    ImGui.Text("Grid Sample")
    ImGui.Separator()
    ImGui.Text("Local X: " .. fmt1(localX) .. " m")
    ImGui.Text("Local Y: " .. fmt1(localY) .. " m")
    if info.hasPlayer then
        ImGui.Text("World X: " .. fmt2(info.worldX))
        ImGui.Text("World Y: " .. fmt2(info.worldY))
        ImGui.Text("World Z: " .. fmt2(info.worldZ))
    end
    ImGui.Separator()
    ImGui.Text("Distance From Player: " .. fmt1(info.distPlayer) .. " m")
    ImGui.Text("Distance From Reference Point: " .. fmt1(info.distRef) .. " m")
    ImGui.Text("Reference Source: " .. tostring(info.referenceLabel))
    ImGui.Text("Inside Active Shape: " .. tostring(info.insideShape))
    ImGui.Text("Excluded: " .. tostring(info.excluded))
    if info.manualItemName ~= nil then
        ImGui.Text("Manual Item: " .. tostring(info.manualItemName))
        ImGui.Text("Manual Stack Count: " .. tostring(info.stackCount))
    end
    if info.randomItemName ~= nil then
        ImGui.Text("Random Preview: " .. tostring(info.randomItemName))
        ImGui.Text("Random Stack Count: " .. tostring(info.randomStacks))
    end
    if info.sequencePreviewPlanned then
        ImGui.Separator()
        ImGui.Text("Sequence Order: " .. tostring(info.sequenceOrder or '-'))
        ImGui.Text("Sequence Spawn Time: T+" .. fmt2(info.sequenceSpawnTime or 0.0) .. "s")
        ImGui.Text("Sequence Active Now: " .. tostring(info.sequenceNowActive))
    end
    ImGui.EndTooltip()
end

local function applyToolToCell(row, col, localX, localY, context)
    local state = context.state

    if Planner.toolMode == "move_center" then
        setPlacement(localX, localY)
        return
    end

    if Planner.toolMode == "set_reference" then
        setCustomReference(localX, localY)
        return
    end

    if Planner.toolMode == "exclude" then
        if context.insideShape then
            state.excluded = true
        end
        return
    end

    if Planner.toolMode == "erase" then
        clearCellState(state)
        -- Also despawn any live entity at this cell.
        local workspace = tostring(Planner.currentGridWorkspace or 'grid')
        if workspace == 'grid' or workspace == 'presets' then
            clearRuntimeCell(workspace, tostring(row) .. ':' .. tostring(col))
        end
        return
    end

    if Planner.toolMode == "paint" then
        if ((context.radiusEnabled and (not context.insideShape)) or #Planner.curatedList == 0) then
            return
        end

        state.excluded = false
        state.manualItemIndex = clamp(Planner.selectedCuratedIndex, 1, #Planner.curatedList)
        if Planner.allowMultiSpawn then
            local current = tonumber(state.stackCount) or 0
            state.stackCount = clamp(current + 1, 1, Planner.maxStacksPerCell)
        else
            state.stackCount = 1
        end
        if Planner.currentGridWorkspace == 'sequence' and tonumber(state.sequenceOrder) == nil then
            state.sequenceOrder = tonumber(Planner.sequence.nextManualOrder) or 1
            Planner.sequence.nextManualOrder = (tonumber(state.sequenceOrder) or 1) + 1
        end
        -- Live-spawn the painted entry into the world at this cell's world position.
        syncRuntimeCellForCurrentWorkspace(row, col, state, localX, localY)
    end
end

local function computePlacementStats()
    ensureCellStates()

    local closestDist = nil
    local furthestDist = nil
    local closestName = nil
    local furthestName = nil
    local plannedCount = 0
    local excludedCount = 0
    local stackedCount = 0
    local duplicateEntryIds = 0
    local uniqueEntryTypes = 0
    local activeRadius = getDisplayedRadius()
    local entryCounts = {}

    for row = 1, Planner.canvasCells do
        for col = 1, Planner.canvasCells do
            local state = Planner.cellStates[row][col]
            local localX, localY = getCellLocalXY(row, col)
            local dx = localX - Planner.centerOffsetX
            local dy = localY - Planner.centerOffsetY
            local insideShape = isInsideShape(dx, dy, activeRadius, Planner.shapeMode)

            if state.excluded and insideShape then
                excludedCount = excludedCount + 1
            end

            if state.manualItemIndex ~= nil then
                local dist = math.sqrt((dx * dx) + (dy * dy))
                local entry = getPlannerEntry(state.manualItemIndex)
                local name = getCellItemName(state.manualItemIndex) or "Unknown"
                local entryKey = tostring((entry and entry.mode) or 'Character') .. '|' .. tostring((entry and entry.record) or name)
                plannedCount = plannedCount + 1
                entryCounts[entryKey] = (entryCounts[entryKey] or 0) + 1
                if (state.stackCount or 0) > 1 then
                    stackedCount = stackedCount + 1
                end

                if closestDist == nil or dist < closestDist then
                    closestDist = dist
                    closestName = name
                end

                if furthestDist == nil or dist > furthestDist then
                    furthestDist = dist
                    furthestName = name
                end
            end
        end
    end

    for _, count in pairs(entryCounts) do
        uniqueEntryTypes = uniqueEntryTypes + 1
        if count > 1 then
            duplicateEntryIds = duplicateEntryIds + 1
        end
    end

    return {
        plannedCount = plannedCount,
        excludedCount = excludedCount,
        stackedCount = stackedCount,
        duplicateEntryIds = duplicateEntryIds,
        uniqueEntryTypes = uniqueEntryTypes,
        closestDist = closestDist,
        closestName = closestName,
        furthestDist = furthestDist,
        furthestName = furthestName
    }
end

local function getNearestCellIndices(localX, localY)
    local stepMeters = getGridStepMeters()
    local halfIndex = (Planner.canvasCells - 1) / 2
    local col = math.floor((localX / stepMeters) + halfIndex + 1.5)
    local row = math.floor(halfIndex - (localY / stepMeters) + 1.5)
    row = clamp(row, 1, Planner.canvasCells)
    col = clamp(col, 1, Planner.canvasCells)
    return row, col
end

local function countOutsidePlacements()
    ensureCellStates()
    if not isRadiusEnabledForCurrentWorkspace() then
        return 0, 0
    end
    local outsideCount = 0
    local outsideStacks = 0

    for row = 1, Planner.canvasCells do
        for col = 1, Planner.canvasCells do
            local state = Planner.cellStates[row][col]
            if state.manualItemIndex ~= nil then
                local localX, localY = getCellLocalXY(row, col)
                local dx = localX - Planner.centerOffsetX
                local dy = localY - Planner.centerOffsetY
                if not isInsideShape(dx, dy, getDisplayedRadius(), Planner.shapeMode) then
                    outsideCount = outsideCount + 1
                    outsideStacks = outsideStacks + math.max(1, tonumber(state.stackCount) or 1)
                end
            end
        end
    end

    return outsideCount, outsideStacks
end

local function transferPlacementsByDelta(dx, dy)
    ensureCellStates()
    local moved = {}
    local removed = 0

    for row = 1, Planner.canvasCells do
        for col = 1, Planner.canvasCells do
            local state = Planner.cellStates[row][col]
            if state.manualItemIndex ~= nil then
                local localX, localY = getCellLocalXY(row, col)
                local newX = localX + dx
                local newY = localY + dy

                if math.abs(newX) > Planner.halfGridMeters or math.abs(newY) > Planner.halfGridMeters then
                    removed = removed + 1
                else
                    table.insert(moved, {
                        x = newX,
                        y = newY,
                        manualItemIndex = state.manualItemIndex,
                        stackCount = math.max(1, tonumber(state.stackCount) or 1),
                        excluded = state.excluded == true,
                        sequenceOrder = tonumber(state.sequenceOrder)
                    })
                end
            end
        end
    end

    resetCellStates()

    for i = 1, #moved do
        local entry = moved[i]
        local row, col = getNearestCellIndices(entry.x, entry.y)
        local dest = Planner.cellStates[row][col]
        dest.excluded = entry.excluded
        dest.manualItemIndex = entry.manualItemIndex
        dest.sequenceOrder = entry.sequenceOrder
        if Planner.allowMultiSpawn then
            local cur = math.max(0, tonumber(dest.stackCount) or 0)
            dest.stackCount = clamp(cur + entry.stackCount, 1, Planner.maxStacksPerCell)
        else
            dest.stackCount = 1
        end
    end

    return removed
end

local function deleteOutsidePlacements()
    ensureCellStates()
    if not isRadiusEnabledForCurrentWorkspace() then
        return 0
    end
    local removed = 0

    for row = 1, Planner.canvasCells do
        for col = 1, Planner.canvasCells do
            local state = Planner.cellStates[row][col]
            if state.manualItemIndex ~= nil then
                local localX, localY = getCellLocalXY(row, col)
                local dx = localX - Planner.centerOffsetX
                local dy = localY - Planner.centerOffsetY
                if not isInsideShape(dx, dy, getDisplayedRadius(), Planner.shapeMode) then
                    clearCellState(state)
                    removed = removed + 1
                end
            end
        end
    end

    return removed
end

local function updateOutsidePromptState()
    if Planner.currentGridWorkspace == 'sequence' then
        Planner.outsidePrompt = nil
        return
    end

    if not isRadiusEnabledForCurrentWorkspace() then
        Planner.outsidePrompt = nil
        return
    end
    local currentRadius = getDisplayedRadius()
    if Planner.lastPromptCenterX == Planner.centerOffsetX and Planner.lastPromptCenterY == Planner.centerOffsetY and Planner.lastPromptRadius == currentRadius then
        return
    end

    local prevX = Planner.lastPromptCenterX
    local prevY = Planner.lastPromptCenterY
    local prevRadius = Planner.lastPromptRadius

    Planner.lastPromptCenterX = Planner.centerOffsetX
    Planner.lastPromptCenterY = Planner.centerOffsetY
    Planner.lastPromptRadius = currentRadius

    local outsideCount, outsideStacks = countOutsidePlacements()
    if outsideCount <= 0 then
        return
    end

    Planner.outsidePrompt = {
        outsideCount = outsideCount,
        outsideStacks = outsideStacks,
        deltaX = Planner.centerOffsetX - prevX,
        deltaY = Planner.centerOffsetY - prevY,
        oldRadius = prevRadius,
        newRadius = currentRadius
    }
    ImGui.OpenPopup('Placements Outside Active Area')
end

local function drawPopupBullet(label, text)
    ImGui.TextColored(0.96, 0.72, 0.24, 1.0, label)
    ImGui.SameLine()
    ImGui.TextWrapped(text)
end

local function drawOutsideAreaPopup()
    if Planner.outsidePrompt == nil then
        return
    end

    local prompt = Planner.outsidePrompt
    if ImGui.BeginPopupModal('Placements Outside Active Area', true, ImGuiWindowFlags.AlwaysAutoResize) then
        ImGui.TextWrapped('The active radius or center moved away from previously painted placements. Those placements are still part of the plan unless you choose to move or delete them.')
        ImGui.Separator()
        ImGui.Text('Outside placements: ' .. tostring(prompt.outsideCount))
        ImGui.Text('Outside stacks: ' .. tostring(prompt.outsideStacks))
        ImGui.Text('Center delta: ' .. fmt1(prompt.deltaX) .. ', ' .. fmt1(prompt.deltaY) .. ' m')
        ImGui.Text('Old / New displayed radius: ' .. fmt1(prompt.oldRadius) .. ' m -> ' .. fmt1(prompt.newRadius) .. ' m')

        ImGui.Spacing()
        drawPopupBullet('Keep in Place:', 'Leaves those placements exactly where they are. They stay color coded in the grid even while they sit outside the current ghost shape.')
        drawPopupBullet('Offset Transfer:', 'Moves the existing placements by the center delta so the pattern follows the new radius center. If a transferred placement lands outside the 50m planner bounds, it will no longer spawn.')
        drawPopupBullet('Delete Outside:', 'Removes only the placements that are currently outside the active shape. Placements still inside the current area are kept.')

        ImGui.Spacing()
        if ImGui.Button('Keep in Place', 130, 28) then
            Planner.outsidePrompt = nil
            ImGui.CloseCurrentPopup()
        end
        ImGui.SameLine()
        if ImGui.Button('Offset Transfer', 130, 28) then
            local removed = transferPlacementsByDelta(prompt.deltaX, prompt.deltaY)
            Planner.outsidePrompt = nil
            Planner.hoverInfo = nil
            if removed > 0 then
                print('[Spatial Radius Planner] Offset transfer moved placements. ' .. tostring(removed) .. ' placement(s) fell outside 50m and were not kept.')
            end
            ImGui.CloseCurrentPopup()
        end
        ImGui.SameLine()
        if ImGui.Button('Delete Outside', 130, 28) then
            deleteOutsidePlacements()
            Planner.outsidePrompt = nil
            Planner.hoverInfo = nil
            ImGui.CloseCurrentPopup()
        end

        if ImGui.Button('Review Later', 120, 24) then
            ImGui.CloseCurrentPopup()
        end

        ImGui.EndPopup()
    end
end

-- Anchor out-of-area warning popup (sequence workspace only)
local function drawAnchorWarnPopup()
    local seq = Planner.sequence
    if not seq.showAnchorWarnPopup then return end

    if not ImGui.IsPopupOpen('Sequence Anchor: Player Outside Grid') then
        ImGui.OpenPopup('Sequence Anchor: Player Outside Grid')
    end

    if ImGui.BeginPopupModal('Sequence Anchor: Player Outside Grid', false, ImGuiWindowFlags.AlwaysAutoResize) then
        ImGui.TextColored(0.98, 0.72, 0.24, 1.0, 'You have walked outside the sequence grid area.')
        ImGui.TextWrapped('The grid was anchored at your position when playback started. You are now outside its bounds. Spawns will continue at the original anchored location.')
        ImGui.Separator()

        drawPopupBullet('Teleport Back:', 'Moves the player back to the sequence grid center so you can keep editing or watching playback.')
        drawPopupBullet('Stop & Despawn:', 'Stops sequence playback and despawns all sequence objects.')
        drawPopupBullet('Leave & Keep:', 'Dismisses this warning. Sequence keeps running and spawned objects stay in place.')

        ImGui.Spacing()

        if ImGui.Button('Teleport Back to Grid', 170, 28) then
            -- Teleport player to anchor center
            local p = Game and Game.GetPlayer and Game.GetPlayer() or nil
            if p then
                local tp = Vector4.new(seq.anchorX, seq.anchorY, seq.anchorZ, 1)
                pcall(function() Game.GetTeleportationFacility():Teleport(p, tp, p:GetWorldOrientation()) end)
            end
            seq.showAnchorWarnPopup = false
        Planner.anchorHas = true
        Planner.anchorX = seq.anchorX
        Planner.anchorY = seq.anchorY
        Planner.anchorZ = seq.anchorZ
        Planner.anchorFwdX = seq.anchorFwdX
        Planner.anchorFwdY = seq.anchorFwdY
            ImGui.CloseCurrentPopup()
        end
        ImGui.SameLine()
        if ImGui.Button('Stop & Despawn All', 150, 28) then
            seq.playing = false
            seq.hasAnchor = false
            seq.showAnchorWarnPopup = false
        Planner.anchorHas = true
        Planner.anchorX = seq.anchorX
        Planner.anchorY = seq.anchorY
        Planner.anchorZ = seq.anchorZ
        Planner.anchorFwdX = seq.anchorFwdX
        Planner.anchorFwdY = seq.anchorFwdY
            clearRuntimeWorkspace('sequence')
            resetSequenceTracking(false)
            ImGui.CloseCurrentPopup()
        end
        ImGui.SameLine()
        if ImGui.Button('Leave & Keep Objects', 160, 28) then
            seq.showAnchorWarnPopup = false
        Planner.anchorHas = true
        Planner.anchorX = seq.anchorX
        Planner.anchorY = seq.anchorY
        Planner.anchorZ = seq.anchorZ
        Planner.anchorFwdX = seq.anchorFwdX
        Planner.anchorFwdY = seq.anchorFwdY
            ImGui.CloseCurrentPopup()
        end

        ImGui.EndPopup()
    end
end

local function drawLabelValue(label, value, r, g, b)
    ImGui.TextColored(r or 0.84, g or 0.36, b or 0.36, 1.0, label)
    ImGui.SameLine()
    ImGui.TextWrapped(value)
end

local function drawWorkflowHelpPanel()
    ImGui.Text("Workflow Help")
    ImGui.Separator()
    ImGui.TextWrapped("This tool is now split into pages. Persistent controls for radius, shape, offset spacing, and the active tool stay visible in the top header on every page, so the player does not need to scroll back to the top just to keep editing while a sequence is running.")
    ImGui.Spacing()
    ImGui.TextWrapped("Default click behavior is Paint. Clicking a sample fills it with the currently selected spawn entry. Moving the center now requires switching to the Move Center tool.")
end


local function getPlayerDistanceFromGridCenter()
    local plx, ply = getPlayerLocalForGrid()
    return math.sqrt((plx * plx) + (ply * ply)), plx, ply
end

local function drawPlayerDriftNotice()
    local dist, plx, ply = getPlayerDistanceFromGridCenter()
    if dist <= 0.25 then return end

    ImGui.BeginChild('##planner_drift_notice', 0, 46, true)
    ImGui.TextColored(0.98, 0.78, 0.28, 1.0, 'Player has moved away from the grid center')
    ImGui.SameLine()
    ImGui.Text('Distance: ' .. fmt1(dist) .. ' m   Local: ' .. fmt1(plx) .. ', ' .. fmt1(ply))
    ImGui.SameLine()
    if ImGui.Button('Teleport To Grid Center##notice', 170, 24) then
        teleportPlayerToCurrentWorkspaceCenter()
    end
    ImGui.EndChild()
end

local function drawWorkspaceTransferPopup()
    local pending = Planner.pendingWorkspaceSwitch
    if pending == nil then return end
    if not ImGui.IsPopupOpen('Switch Grid Workspace') then
        ImGui.OpenPopup('Switch Grid Workspace')
    end
    if ImGui.BeginPopupModal('Switch Grid Workspace', true, ImGuiWindowFlags.AlwaysAutoResize) then
        ImGui.TextWrapped('Grid, Presets, and Sequence now open with a fresh grid. You have painted entries in the current grid. Do you want to transfer them into the next workspace or start fresh?')
        ImGui.Separator()
        ImGui.Text('From: ' .. tostring(pending.from) .. '  ->  To: ' .. tostring(pending.to))
        ImGui.Text('Painted cells: ' .. tostring(pending.sourceCount or 0))
        ImGui.Spacing()
        if ImGui.Button('Transfer Current Grid', 170, 28) then
            ensureWorkspaceStates()
            saveCurrentWorkspaceState()
            local snap = makeWorkspaceSnapshot()
            snap.anchorHas = false
            Planner.workspaceStates[pending.to] = snap
            clearRuntimeWorkspace(pending.to)
            Planner.currentGridWorkspace = pending.to
            applyWorkspaceSnapshot(Planner.workspaceStates[pending.to])
            captureCurrentWorkspaceAnchor()
            Planner.workspaceTab = pending.to
            Planner.pendingWorkspaceSwitch = nil
            ImGui.CloseCurrentPopup()
        end
        ImGui.SameLine()
        if ImGui.Button('Start Fresh', 130, 28) then
            ensureWorkspaceStates()
            local fresh = makeFreshSnapshotFromSnapshot(Planner.workspaceStates[pending.to] or makeWorkspaceSnapshot())
            Planner.workspaceStates[pending.to] = fresh
            clearRuntimeWorkspace(pending.to)
            Planner.currentGridWorkspace = pending.to
            applyWorkspaceSnapshot(fresh)
            captureCurrentWorkspaceAnchor()
            Planner.workspaceTab = pending.to
            Planner.pendingWorkspaceSwitch = nil
            ImGui.CloseCurrentPopup()
        end
        ImGui.SameLine()
        if ImGui.Button('Cancel', 90, 28) then
            Planner.pendingWorkspaceSwitch = nil
            ImGui.CloseCurrentPopup()
        end
        ImGui.EndPopup()
    end
end

local function drawPersistentHeader()
    local displayRadius = getDisplayedRadius()
    local availW = ImGui.GetContentRegionAvail()

    ImGui.Text('Persistent Core Controls')
    ImGui.Separator()

    local sliderW = math.max(220, math.floor((availW - 18) * 0.39))
    ImGui.PushItemWidth(sliderW)
    Planner.radiusMeters = parseSliderFloat(Planner.radiusMeters, 'Radius', 0.5, 50.0, '%.1f m')
    showHelpIfHovered('Controls the base radius of the active shape.')
    ImGui.SameLine()
    ImGui.PushItemWidth(sliderW)
    Planner.zOffsetMeters = parseSliderFloat(Planner.zOffsetMeters, 'Z Offset', -20.0, 20.0, '%.1f m')
    showHelpIfHovered('Offsets the resolved world Z for hovered samples and spawned items.')
    ImGui.PopItemWidth()
    ImGui.PopItemWidth()

    ImGui.PushItemWidth(170)
    Planner.offsetSpacingPx = parseSliderFloat(Planner.offsetSpacingPx, 'Offset Spacing', 0.0, 3.0, '%.1f px')
    ImGui.PopItemWidth()
    ImGui.SameLine()
    Planner.snapEnabled = ImGui.Checkbox('Snap', Planner.snapEnabled)
    ImGui.SameLine()
    if ImGui.Button('0.5m', 46, 22) then Planner.snapStepMeters = 0.5 end
    ImGui.SameLine()
    if ImGui.Button('1m', 38, 22) then Planner.snapStepMeters = 1.0 end
    ImGui.SameLine()
    if ImGui.Button('2m', 38, 22) then Planner.snapStepMeters = 2.0 end
    ImGui.SameLine()
    if ImGui.Button('5m', 38, 22) then Planner.snapStepMeters = 5.0 end
    ImGui.SameLine()
    ImGui.Text('Snap: ' .. fmt1(Planner.snapStepMeters) .. 'm  |  Displayed: ' .. fmt1(displayRadius) .. 'm')

    local function wrappedChoiceRow(title, items, currentKey, setter, selectedStyleFn)
        ImGui.Text(title)
        ImGui.SameLine()
        local startX = nil
        for i = 1, #items do
            local it = items[i]
            local width = it.width or 76
            if i > 1 then
                local cursorX = ImGui.GetCursorPosX()
                if cursorX + width + 12 > availW then
                    -- wrap to next line and indent under label area
                else
                    ImGui.SameLine()
                end
            end
            if currentKey == it.key then (selectedStyleFn or pushSelectedButtonStyle)() else pushUnselectedButtonStyle() end
            if ImGui.Button(it.label .. '##' .. title .. '_' .. it.key, width, 22) then setter(it.key) end
            popButtonColors()
        end
    end

    wrappedChoiceRow('Shape', {
        {key='circle',label='Circle',width=62}, {key='square',label='Square',width=62}, {key='diamond',label='Diamond',width=70}, {key='triangle',label='Triangle',width=68}, {key='star',label='Star',width=52}
    }, Planner.shapeMode, function(v) Planner.shapeMode = v end)

    wrappedChoiceRow('Tool', {
        {key='paint',label='Paint',width=60}, {key='move_center',label='Move Center',width=92}, {key='set_reference',label='Reference',width=78}, {key='exclude',label='Exclude',width=62}, {key='erase',label='Erase',width=56}
    }, Planner.toolMode, function(v) Planner.toolMode = v end, pushAccentButtonStyle)

    if ImGui.Button('Center On Player', 118, 24) then
        Planner.centerOffsetX = 0.0
        Planner.centerOffsetY = 0.0
        captureCurrentWorkspaceAnchor()
    end
    ImGui.SameLine()
    if ImGui.Button('Teleport To Grid Center', 156, 24) then
        teleportPlayerToCurrentWorkspaceCenter()
    end
    ImGui.SameLine()
    if ImGui.Button('Reset Current Grid', 132, 24) then
        resetCurrentWorkspaceGrid()
    end
    ImGui.SameLine()
    ImGui.Text('Tool: ' .. tostring(Planner.toolMode))
    if #Planner.curatedList > 0 then
        ImGui.SameLine()
        local selected = Planner.curatedList[clamp(Planner.selectedCuratedIndex, 1, #Planner.curatedList)]
        ImGui.Text('Active Entry: ' .. tostring(getPlannerEntryLabel(selected) or 'none'))
    end
end

local function drawMainTabButton(key, label, helpText)
    if Planner.workspaceTab == key then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
    if ImGui.Button(label .. "##workspace_" .. key, 128, 28) then
        local isGridTarget = (key == 'grid' or key == 'presets' or key == 'sequence')
        local isGridCurrent = (Planner.currentGridWorkspace == 'grid' or Planner.currentGridWorkspace == 'presets' or Planner.currentGridWorkspace == 'sequence')
        if Planner.workspaceTab == 'sequence' and key ~= 'sequence' and Planner.sequence.playing then
            Planner.sequence.playing = false
            clearRuntimeWorkspace('sequence')
        end
        if isGridTarget and isGridCurrent and key ~= Planner.currentGridWorkspace then
            ensureWorkspaceStates()
            local sourceCount = countPaintedCellsFromMatrix(Planner.cellStates)
            Planner.pendingWorkspaceSwitch = { from = Planner.currentGridWorkspace, to = key, sourceCount = sourceCount }
            if sourceCount > 0 then
                ImGui.OpenPopup('Switch Grid Workspace')
            else
                local fresh = makeFreshSnapshotFromSnapshot(Planner.workspaceStates[key] or makeWorkspaceSnapshot())
                Planner.workspaceStates[key] = fresh
                clearRuntimeWorkspace(key)
                Planner.currentGridWorkspace = key
                applyWorkspaceSnapshot(fresh)
                captureCurrentWorkspaceAnchor()
                Planner.workspaceTab = key
                Planner.pendingWorkspaceSwitch = nil
            end
        else
            if isGridTarget then
                switchWorkspaceContext(key)
            end
            Planner.workspaceTab = key
        end
    end
    showHelpIfHovered(helpText)
    popButtonColors()
end

local function drawLeftRail(stats)
    ImGui.BeginChild("##planner_left_rail", 144, 700, true)
    ImGui.Text("Workspace")
    ImGui.Separator()

    drawMainTabButton("grid", "Grid", "Live spatial editing.")
    drawMainTabButton("presets", "Presets", "Build real spawn entries and test them on a clean grid.")
    drawMainTabButton("sequence", "Sequence", "Playback, pattern ordering, and timeline tools.")
    drawMainTabButton("summary", "Summary", "Condensed counts and distances.")
    drawMainTabButton("display", "Display", "Visual preferences and help.")

    ImGui.Spacing()
    ImGui.Text("Status")
    ImGui.Separator()
    ImGui.Text("Context: " .. tostring(Planner.currentGridWorkspace))
    ImGui.Text("Shape: " .. tostring(Planner.shapeMode))
    ImGui.Text("Radius: " .. fmt1(getDisplayedRadius()) .. ' m')
    ImGui.Text("Cells: " .. tostring(stats.plannedCount))
    local dist, plx, ply = getPlayerDistanceFromGridCenter()
    ImGui.Text('Player Offset: ' .. fmt1(dist) .. ' m')
    ImGui.EndChild()
end

local function drawMapGrid(hasPlayer, px, py, pz, forcedWidth, forcedHeight)
    local cells = Planner.canvasCells

    local childW = forcedWidth or 770
    local childH = forcedHeight or 590
    ImGui.BeginChild('##planner_grid_canvas', childW, childH, true)

    if not ImGui.IsMouseDown(0) then
        Planner.dragCellKey = nil
    end

    local availW, availH = ImGui.GetContentRegionAvail()
    local spacing = clamp(Planner.offsetSpacingPx, 0.0, 3.0)
    local usableW = math.max(100, availW - 8)
    local usableH = math.max(100, availH - 8)
    local cellSize = math.floor(math.min((usableW - ((cells - 1) * spacing)) / cells, (usableH - ((cells - 1) * spacing)) / cells))
    cellSize = clamp(cellSize, 4, 18)
    Planner.cellSizePx = cellSize

    local gridW = (cells * cellSize) + ((cells - 1) * spacing)
    local leftPad = math.max(0, math.floor((usableW - gridW) * 0.5))
    if leftPad > 0 then
        ImGui.Dummy(leftPad, 1)
        ImGui.SameLine()
    end

    ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, cellSize * 0.5)
    ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, spacing, spacing)

    for row = 1, cells do
        for col = 1, cells do
            local localX, localY = getCellLocalXY(row, col)
            local context = getCellContext(row, col, localX, localY)

            pushDotStyle(context)
            local id = '##cell_' .. tostring(row) .. '_' .. tostring(col)
            local clicked = ImGui.Button(id, cellSize, cellSize)
            local hovered = ImGui.IsItemHovered()

            if hovered then
                updateHoverInfo(row, col, localX, localY, hasPlayer, px, py, pz, context)
            end

            local dragKey = tostring(row) .. ':' .. tostring(col)
            if clicked or (hovered and ImGui.IsMouseDown(0) and Planner.dragCellKey ~= dragKey) then
                applyToolToCell(row, col, localX, localY, context)
                Planner.dragCellKey = dragKey
            end

            drawCellTooltip(localX, localY)
            popButtonColors()
            if col < cells then ImGui.SameLine() end
        end
        if row < cells and leftPad > 0 then
            ImGui.Dummy(leftPad, 1)
            ImGui.SameLine()
        end
    end

    ImGui.PopStyleVar(2)
    ImGui.EndChild()
end

local function drawInspectorPanel(hasPlayer, px, py, pz, stats, panelWidth, panelHeight)
    local refX, refY, refLabel = getCurrentReferenceLocal()
    local displayRadius = getDisplayedRadius()
    local playerDist, plx, ply = getPlayerDistanceFromGridCenter()
    local nearRow, nearCol = getNearestCellIndices(plx, ply)

    ImGui.BeginChild('##planner_inspector', panelWidth or 300, panelHeight or 700, true)
    ImGui.Text('Inspector')
    ImGui.Separator()

    if #Planner.curatedList > 0 then
        local selected = Planner.curatedList[clamp(Planner.selectedCuratedIndex, 1, #Planner.curatedList)]
        drawLabelValue('Active Entry:', tostring(getPlannerEntryLabel(selected) or 'none'), 0.94, 0.80, 0.34)
        drawLabelValue('Weight:', tostring(selected.weight), 0.94, 0.80, 0.34)
    else
        ImGui.TextWrapped('No active spawn entry selected yet.')
    end

    ImGui.Spacing()
    drawLabelValue('Shape:', tostring(Planner.shapeMode), 0.76, 0.92, 0.40)
    drawLabelValue('Displayed Radius:', fmt1(displayRadius) .. ' m', 0.76, 0.92, 0.40)
    drawLabelValue('Center:', fmt1(Planner.centerOffsetX) .. ', ' .. fmt1(Planner.centerOffsetY), 0.76, 0.92, 0.40)
    drawLabelValue('Reference:', tostring(refLabel), 0.76, 0.92, 0.40)
    drawLabelValue('Player Offset:', fmt1(playerDist) .. ' m', 0.76, 0.92, 0.40)
    drawLabelValue('Nearest Cell:', tostring(nearRow) .. ' / ' .. tostring(nearCol), 0.76, 0.92, 0.40)
    if playerDist > 0.25 then
        if ImGui.Button('Teleport To Grid Center##inspector', -1, 24) then
            teleportPlayerToCurrentWorkspaceCenter()
        end
    end

    ImGui.Spacing()
    drawLabelValue('Planned Cells:', tostring(stats.plannedCount), 0.76, 0.92, 0.40)
    drawLabelValue('Excluded Cells:', tostring(stats.excludedCount), 0.76, 0.92, 0.40)
    drawLabelValue('Stacked Cells:', tostring(stats.stackedCount), 0.76, 0.92, 0.40)
    drawLabelValue('Duplicate Entry IDs:', tostring(stats.duplicateEntryIds or 0), 0.76, 0.92, 0.40)
    drawLabelValue('Different Entry Types:', tostring(stats.uniqueEntryTypes or 0), 0.76, 0.92, 0.40)
    drawLabelValue('Outside Active Area:', tostring(select(1, countOutsidePlacements())), 0.76, 0.92, 0.40)

    ImGui.Spacing()
    if stats.closestDist ~= nil then drawLabelValue('Closest:', tostring(stats.closestName) .. ' @ ' .. fmt1(stats.closestDist) .. ' m', 0.90, 0.58, 0.58) else drawLabelValue('Closest:', 'none', 0.90, 0.58, 0.58) end
    if stats.furthestDist ~= nil then drawLabelValue('Furthest:', tostring(stats.furthestName) .. ' @ ' .. fmt1(stats.furthestDist) .. ' m', 0.90, 0.58, 0.58) else drawLabelValue('Furthest:', 'none', 0.90, 0.58, 0.58) end

    ImGui.Spacing()
    ImGui.Text('Hover')
    ImGui.Separator()
    if Planner.hoverInfo == nil then
        ImGui.TextWrapped('Hover a grid sample to inspect it.')
    else
        local info = Planner.hoverInfo
        drawLabelValue('Row / Col:', tostring(info.row) .. ' / ' .. tostring(info.col), 0.62, 0.82, 1.00)
        drawLabelValue('Local X/Y:', fmt1(info.localX) .. ', ' .. fmt1(info.localY), 0.62, 0.82, 1.00)
        drawLabelValue('Distance Ref:', fmt1(info.distRef) .. ' m', 0.62, 0.82, 1.00)
        drawLabelValue('Distance Player:', fmt1(info.distPlayer) .. ' m', 0.62, 0.82, 1.00)
        if info.manualItemName ~= nil then drawLabelValue('Manual:', tostring(info.manualItemName), 0.62, 0.82, 1.00) end
        if info.randomItemName ~= nil then drawLabelValue('Random:', tostring(info.randomItemName), 0.62, 0.82, 1.00) end
    end

    ImGui.EndChild()
end

local function drawGridPage(hasPlayer, px, py, pz, workspaceWidth, workspaceHeight)
    local availW, availH = ImGui.GetContentRegionAvail()
    local leftW = math.max(330, math.min(390, math.floor(availW * 0.32)))
    local gap = 8
    local rightW = math.max(420, availW - leftW - gap)

    ImGui.BeginChild('##grid_left_panel', leftW, availH - 2, true)
    ImGui.Text('Grid Spawn Source')
    ImGui.Separator()
    Planner.liveSpawnWhileEditing = ImGui.Checkbox('Live Spawn While Editing', Planner.liveSpawnWhileEditing)
    Planner.despawnAfterSeconds = parseSliderFloat(Planner.despawnAfterSeconds, 'Despawn After Seconds', 0.0, 60.0, '%.1f s')
    showHelpIfHovered('Optional despawn timer applied to live planner spawns and sequence spawns.')

    ensureSpawnDBReady()
    local modes = plannerModeList()
    for i = 1, #modes do
        local mode = modes[i]
        if Planner.spawnMode == mode then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
        if ImGui.Button(mode .. '##grid_mode_' .. mode, 72, 22) then
            Planner.spawnMode = mode
            Planner.selectedDbIndex = 1
        end
        popButtonColors()
        if i < #modes then ImGui.SameLine() end
    end

    Planner.dbSearch = parseInputText(Planner.dbSearch, 'DB Search##grid_db_search', 128)
    local results = getPlannerDBResults()
    if Planner.selectedDbIndex < 1 then Planner.selectedDbIndex = 1 end
    if Planner.selectedDbIndex > math.max(1, #results) then Planner.selectedDbIndex = math.max(1, #results) end

    ImGui.BeginChild('##grid_db_results', 0, math.max(160, math.floor(availH * 0.42)), true)
    for i = 1, #results do
        local rec = tostring(results[i])
        local sel = (Planner.selectedDbIndex == i)
        local shortLabel = getRecordDisplayLabel(rec)
        if sel then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
        if ImGui.Button(shortLabel .. '##grid_db_pick_' .. tostring(i), -1, 22) then
            Planner.selectedDbIndex = i
            ensurePlannerEntry(rec, Planner.spawnMode, Planner.newItemWeight)
        end
        if ImGui.IsItemHovered() then
            ImGui.BeginTooltip(); ImGui.PushTextWrapPos(520); ImGui.TextWrapped(rec); ImGui.PopTextWrapPos(); ImGui.EndTooltip()
        end
        popButtonColors()
    end
    ImGui.EndChild()

    ImGui.Spacing()
    local selected = (#Planner.curatedList > 0) and Planner.curatedList[clamp(Planner.selectedCuratedIndex, 1, #Planner.curatedList)] or nil
    ImGui.TextWrapped('Active Paint Entry: ' .. tostring(selected and (getPlannerEntryLabel(selected) or 'none') or 'none'))
    ImGui.TextWrapped('Paint on the grid to place the highlighted DB entry immediately. Move Center changes the origin, not the painted cells.')
    ImGui.EndChild()

    ImGui.SameLine()

    ImGui.BeginChild('##grid_canvas_panel', rightW, availH - 2, true)
    ImGui.Text('Grid Workspace')
    ImGui.Separator()
    local gridW, gridH = ImGui.GetContentRegionAvail()
    drawMapGrid(hasPlayer, px, py, pz, gridW, gridH - 4)
    ImGui.EndChild()
end

local function drawPresetsPage(hasPlayer, px, py, pz)
    local availW, availH = ImGui.GetContentRegionAvail()
    local leftW = math.max(360, math.min(430, math.floor(availW * 0.36)))
    local gap = 8
    local rightW = math.max(420, availW - leftW - gap)

    ImGui.BeginChild('##presets_left_panel', leftW, availH - 2, true)
    ImGui.Text('Spawn Entry Builder')
    ImGui.Separator()
    ensureSpawnDBReady()

    local modes = plannerModeList()
    for i = 1, #modes do
        local mode = modes[i]
        if Planner.spawnMode == mode then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
        if ImGui.Button(mode .. '##preset_mode_' .. mode, 72, 22) then
            Planner.spawnMode = mode
            Planner.selectedDbIndex = 1
        end
        popButtonColors()
        if i < #modes then ImGui.SameLine() end
    end

    Planner.dbSearch = parseInputText(Planner.dbSearch, 'DB Search##preset_db_search', 128)
    local results = getPlannerDBResults()
    if Planner.selectedDbIndex < 1 then Planner.selectedDbIndex = 1 end
    if Planner.selectedDbIndex > math.max(1, #results) then Planner.selectedDbIndex = math.max(1, #results) end

    ImGui.BeginChild('##preset_db_results', 0, math.max(170, math.floor(availH * 0.34)), true)
    for i = 1, #results do
        local rec = tostring(results[i])
        local selected = (Planner.selectedDbIndex == i)
        local shortLabel = getRecordDisplayLabel(rec)
        if selected then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
        if ImGui.Button(shortLabel .. '##planner_db_pick_' .. tostring(i), -1, 22) then
            Planner.selectedDbIndex = i
            ensurePlannerEntry(rec, Planner.spawnMode, Planner.newItemWeight)
        end
        if ImGui.IsItemHovered() then
            ImGui.BeginTooltip(); ImGui.PushTextWrapPos(520); ImGui.TextWrapped(rec); ImGui.PopTextWrapPos(); ImGui.EndTooltip()
        end
        popButtonColors()
    end
    ImGui.EndChild()

    Planner.customRecordInput = parseInputText(Planner.customRecordInput, 'Custom Record / Path', 256)
    Planner.newItemWeight = parseSliderInt(Planner.newItemWeight, 'Entry Weight', 1, 10, '%d')
    if ImGui.Button('Add Custom Entry', 132, 24) then
        local record = trim(Planner.customRecordInput)
        if record ~= '' then
            ensurePlannerEntry(record, Planner.spawnMode, Planner.newItemWeight)
            Planner.customRecordInput = ''
        end
    end

    ImGui.Spacing()
    ImGui.Text('Planner Spawn Entries')
    ImGui.Separator()
    ImGui.BeginChild('##preset_entry_list', 0, 180, true)
    for i = 1, #Planner.curatedList do
        local entry = Planner.curatedList[i]
        if Planner.selectedCuratedIndex == i then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
        if ImGui.Button((getPlannerEntryLabel(entry) or entry.name or ('Entry ' .. tostring(i))) .. '##preset_pick_' .. tostring(i), 210, 24) then
            Planner.selectedCuratedIndex = i
        end
        popButtonColors()
        ImGui.SameLine()
        entry.weight = parseSliderInt(tonumber(entry.weight) or 1, '##preset_weight_' .. tostring(i), 1, 10, '%d')
        ImGui.SameLine()
        if ImGui.Button('X##preset_remove_' .. tostring(i), 22, 22) then
            remapEntryIndicesAfterRemoval(i)
            table.remove(Planner.curatedList, i)
            if Planner.selectedCuratedIndex > #Planner.curatedList then
                Planner.selectedCuratedIndex = math.max(1, #Planner.curatedList)
            end
            break
        end
    end
    if #Planner.curatedList == 0 then ImGui.TextDisabled('No real spawn entries yet.') end
    ImGui.EndChild()
    ImGui.EndChild()

    ImGui.SameLine()

    ImGui.BeginChild('##presets_grid_panel', rightW, availH - 2, true)
    ImGui.Text('Presets Grid Workspace')
    ImGui.Separator()
    Planner.liveSpawnPresets = ImGui.Checkbox('Live Spawn In Presets Grid', Planner.liveSpawnPresets)
    local selected = (#Planner.curatedList > 0) and Planner.curatedList[clamp(Planner.selectedCuratedIndex, 1, #Planner.curatedList)] or nil
    ImGui.TextWrapped('Selected Entry: ' .. tostring(selected and (getPlannerEntryLabel(selected) or 'none') or 'none'))
    local gridW, gridH = ImGui.GetContentRegionAvail()
    drawMapGrid(hasPlayer, px, py, pz, gridW, gridH - 4)
    ImGui.EndChild()
end

local function drawSequenceTimelinePreview(hasPlayer, px, py, pz, width, height)
    Planner.sequence.hoveredTimelineKey = nil

    ImGui.BeginChild('##sequence_timeline_preview', width, height, true)
    ImGui.Text('Sequence Spawn Timeline')
    ImGui.Separator()
    ImGui.TextWrapped('Hover an entry to flash it in the grid. Right-click an entry for options: change spawn time, delete, cut, paste, or make it the active paint entry.')

    local entries = Planner.sequence.previewEntries or {}
    ImGui.Text('Spawn Count: ' .. tostring(#entries))
    if #Planner.curatedList > 0 then
        local selected = Planner.curatedList[clamp(Planner.selectedCuratedIndex, 1, #Planner.curatedList)]
        ImGui.Text('Paint Target: ' .. tostring(getPlannerEntryLabel(selected) or selected.name))
    end
    if Planner.sequence.clipboardKey then
        ImGui.TextColored(0.76, 0.92, 1.0, 1.0, 'Clipboard: ' .. tostring(Planner.sequence.clipboardKey))
    end

    ImGui.Separator()

    if #entries == 0 then
        ImGui.TextWrapped('No sequence spawn slots are painted yet. Use Paint in the Sequence grid to assign entries, or use Autofill below.')
        ImGui.EndChild()
        return
    end

    for i = 1, #entries do
        local entry = entries[i]
        local orderTag = Planner.sequence.usePatternPreset and ('#' .. tostring(entry.orderIndex or i)) or ('Paint #' .. tostring(entry.orderIndex or i))
        local label = string.format('[T+%.2fs] %s  %s  x%d  @ (%d,%d)', entry.spawnTime or 0.0, orderTag, tostring(entry.itemName), tonumber(entry.stackCount) or 1, entry.row, entry.col)
        local isActive = Planner.sequence.activeKeys[entry.key] ~= nil
        local isHovered = false

        if isActive then
            ImGui.TextColored(0.42, 0.94, 0.52, 1.0, label)
        else
            ImGui.TextColored(0.94, 0.82, 0.42, 1.0, label)
        end

        isHovered = ImGui.IsItemHovered()
        if isHovered then
            Planner.sequence.hoveredTimelineKey = entry.key
            local context = getCellContext(entry.row, entry.col, entry.localX, entry.localY)
            updateHoverInfo(entry.row, entry.col, entry.localX, entry.localY, hasPlayer, px, py, pz, context)
        end

        -- Right-click context menu on each timeline row
        local ctxId = 'seq_ctx_' .. entry.key
        if ImGui.BeginPopupContextItem(ctxId) then
            Planner.sequence.contextMenuKey = entry.key

            ImGui.TextColored(0.96, 0.82, 0.42, 1.0, entry.itemName or 'Unknown')
            ImGui.Text(string.format('Grid: (%d,%d)   T+%.2fs', entry.row, entry.col, entry.spawnTime or 0.0))
            ImGui.Separator()

            -- Change spawn time inline
            local r2, c2 = entry.key:match('^(%d+):(%d+)$')
            r2, c2 = tonumber(r2), tonumber(c2)
            if r2 and c2 then
                local state = getCellState(r2, c2)
                if not Planner.sequence._editTimeKey then Planner.sequence._editTimeKey = '' end
                if not Planner.sequence._editTimeVal then Planner.sequence._editTimeVal = entry.spawnTime or 0.0 end
                if Planner.sequence._editTimeKey ~= entry.key then
                    Planner.sequence._editTimeVal = entry.spawnTime or 0.0
                    Planner.sequence._editTimeKey = entry.key
                end
                Planner.sequence._editTimeVal = parseSliderFloat(
                    Planner.sequence._editTimeVal, 'Set Spawn Time (s)',
                    0.0, math.max(0.05, Planner.sequence.duration), '%.2f s')
                if ImGui.Button('Apply Time##ctx_time_' .. entry.key, 100, 22) then
                    -- Store manual override on the cell state (sequenceOrder doubles as
                    -- manual time when not using pattern preset)
                    state.manualSpawnTime = Planner.sequence._editTimeVal
                    Planner.sequence._editTimeKey = ''
                    ImGui.CloseCurrentPopup()
                end
                ImGui.SameLine()
                if ImGui.Button('Clear Override##ctx_clr_' .. entry.key, 110, 22) then
                    state.manualSpawnTime = nil
                    Planner.sequence._editTimeKey = ''
                    ImGui.CloseCurrentPopup()
                end
                ImGui.Separator()

                -- Make active DB entry
                local entryData = getPlannerEntry(state.manualItemIndex)
                if entryData then
                    if ImGui.Button('Make Active Paint Entry##ctx_act_' .. entry.key, -1, 22) then
                        -- Find this record in current DB results and select it
                        ensureSpawnDBReady()
                        local results = {}
                        if SpawnTools and SpawnTools.GetRecordsForMode then
                            local ok, r = pcall(function() return SpawnTools.GetRecordsForMode(entryData.mode, '') end)
                            if ok and type(r) == 'table' then results = r end
                        end
                        local rec = tostring(entryData.record or '')
                        Planner.spawnMode = tostring(entryData.mode or 'Character')
                        Planner.dbSearch = ''
                        for ri = 1, #results do
                            if tostring(results[ri]) == rec then
                                Planner.selectedDbIndex = ri
                                break
                            end
                        end
                        Planner.selectedCuratedIndex = state.manualItemIndex
                        ImGui.CloseCurrentPopup()
                    end
                    showHelpIfHovered('Switches the Spawn Source Mode to match this entry type and selects it as the active paint target.')
                end
                ImGui.Separator()

                -- Cut / Copy / Paste
                if ImGui.Button('Cut##ctx_cut_' .. entry.key, 60, 22) then
                    copySequenceCell(entry.key)
                    clearCellState(state)
                    clearRuntimeCell('sequence', entry.key)
                    ImGui.CloseCurrentPopup()
                end
                ImGui.SameLine()
                if ImGui.Button('Copy##ctx_copy_' .. entry.key, 60, 22) then
                    copySequenceCell(entry.key)
                    ImGui.CloseCurrentPopup()
                end
                ImGui.SameLine()
                if Planner.sequence._clipboardState and ImGui.Button('Paste Here##ctx_paste_' .. entry.key, 80, 22) then
                    pasteSequenceCell(entry.key)
                    ImGui.CloseCurrentPopup()
                end
                ImGui.Separator()

                -- Delete
                if ImGui.Button('Delete Entry##ctx_del_' .. entry.key, -1, 22) then
                    clearCellState(state)
                    clearRuntimeCell('sequence', entry.key)
                    ImGui.CloseCurrentPopup()
                end
            end

            ImGui.EndPopup()
        end
    end

    ImGui.EndChild()
end

local function drawSequenceSubTabButton(key, label, helpText)
    if Planner.sequenceTab == key then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
    if ImGui.Button(label .. "##seqtab_" .. key, 110, 24) then
        Planner.sequenceTab = key
    end
    showHelpIfHovered(helpText)
    popButtonColors()
end

local function drawSequencePage(hasPlayer, px, py, pz)
    refreshSequencePreviewCache()
    local availW, availH = ImGui.GetContentRegionAvail()
    -- Give the controls column a fixed comfortable width; the grid panel gets
    -- everything remaining so it is never squeezed to unusable size.
    local leftW = math.max(380, math.min(440, math.floor(availW * 0.38)))
    local gap = 10
    local rightW = math.max(420, availW - leftW - gap)
    -- Divide the left column: controls on top, log panel below.
    -- The fill tab is now taller, so give controls more room.
    local controlsH = math.max(320, availH - 200)
    local logH = math.max(130, availH - controlsH - 14)

    ImGui.Text("Sequence Builder")
    ImGui.Separator()
    ImGui.TextWrapped("This page is condensed into sequence-focused subtabs. Radius, shape, spacing, and tool stay in the persistent header, while the Sequence page holds timing, optional radius usage, activation presets like rows and spirals, and the event log. You can also turn radius use off and run a sequence purely from painted cells.")

    ImGui.BeginChild('##sequence_left_column', leftW, availH - 4, false)

    ImGui.BeginChild('##sequence_controls_panel', leftW - 4, controlsH, true)
    drawSequenceSubTabButton("playback", "Playback", "Playback controls for sequence growth, shrink, pulse, duration, looping, and whether the sequence uses the radius at all.")
    ImGui.SameLine()
    drawSequenceSubTabButton("fill", "Fill Rules", "How preview fill behaves during playback, including random preview and whether the preview should re-randomize.")
    ImGui.SameLine()
    drawSequenceSubTabButton("exit", "Exit Rules", "UI-only exit action controls for what should happen when entries leave the active radius later at runtime.")

    ImGui.Spacing()

    if Planner.sequenceTab == "playback" then
        Planner.sequence.duration = parseSliderFloat(Planner.sequence.duration, "Sequence Duration", 0.5, 20.0, "%.1f s")
        showHelpIfHovered("Sets the full playback duration for the current sequence loop.")

        Planner.sequence.loop = ImGui.Checkbox("Loop Sequence", Planner.sequence.loop)
        showHelpIfHovered("When enabled, the sequence restarts automatically when it reaches the end of its duration.")

        Planner.sequence.useRadius = ImGui.Checkbox("Use Radius / Shape During Sequence", Planner.sequence.useRadius)
        showHelpIfHovered("When enabled, entries are activated by entering and leaving the current radius / shape. When disabled, the sequence works without a radius and logs manual timeline spawns instead.")

        Planner.sequence.useRadiusAnimation = ImGui.Checkbox("Animate Radius Over Time", Planner.sequence.useRadiusAnimation)
        showHelpIfHovered("Makes Grow, Shrink, and Pulse optional. Turn this off to keep the sequence radius static while the sequence still runs.")

        Planner.sequence.usePatternPreset = ImGui.Checkbox("Use Spawn Pattern Preset", Planner.sequence.usePatternPreset)
        showHelpIfHovered("Makes the spawn preset order optional. Turn this off to use the manual paint order from the Sequence grid instead.")

        Planner.sequence.useLiveRadius = ImGui.Checkbox("Use Live Radius As Target", Planner.sequence.useLiveRadius)
        showHelpIfHovered("When enabled, the persistent Radius slider in the header becomes the target radius for sequence playback.")

        if Planner.sequence.useRadius and (not Planner.sequence.useLiveRadius) then
            Planner.sequence.targetRadius = parseSliderFloat(Planner.sequence.targetRadius, "Sequence Target Radius", 0.5, 50.0, "%.1f m")
            showHelpIfHovered("Sets a dedicated target radius for sequence playback when not using the persistent live radius control.")
        end

        ImGui.Spacing()
        local modes = {
            { key = "static", label = "Static" },
            { key = "grow", label = "Grow" },
            { key = "shrink", label = "Shrink" },
            { key = "pulse", label = "Pulse" }
        }

        if Planner.sequence.useRadius and Planner.sequence.useRadiusAnimation then
            for i = 1, #modes do
                local m = modes[i]
                if Planner.sequence.mode == m.key then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
                if ImGui.Button(m.label .. "##seqmode_" .. m.key, 78, 24) then
                    Planner.sequence.mode = m.key
                end
                showHelpIfHovered("Sets how the displayed radius behaves over time during sequence playback.")
                popButtonColors()
                if i < #modes then ImGui.SameLine() end
            end
        else
            Planner.sequence.mode = "static"
            ImGui.TextWrapped(Planner.sequence.useRadius and "Radius animation is turned off. The sequence will use a static radius." or "Radius usage is turned off. The sequence will run from painted cells only.")
        end

        ImGui.Spacing()
        local previewEntries = Planner.sequence.previewEntries or {}
        ImGui.Text('Selected Spawn Entry: ' .. ((#Planner.curatedList > 0) and tostring(getPlannerEntryLabel(Planner.curatedList[clamp(Planner.selectedCuratedIndex, 1, #Planner.curatedList)]) or 'none') or 'none'))
        ImGui.Text('Sequence Spawn Count: ' .. tostring(#previewEntries))
        if Planner.sequence.usePatternPreset then
            ImGui.TextWrapped('Sequence presets are spawn-order patterns. Empty cells stay empty. Paint the Sequence grid to choose which cells participate, then use a preset to decide the order they spawn in.')
        else
            ImGui.TextWrapped('Spawn pattern presets are off. The sequence uses the order you painted the Sequence grid instead, so you can just paint locations and run the sequence directly.')
        end
        ImGui.Spacing()
        ImGui.Text('Sequence Preset')
        ImGui.Separator()
        local presets = {
            { key = 'all_at_once', label = 'All' },
            { key = 'rows_top', label = 'Rows Down' },
            { key = 'rows_bottom', label = 'Rows Up' },
            { key = 'cols_left', label = 'Cols Right' },
            { key = 'cols_right', label = 'Cols Left' },
            { key = 'zigzag_rows', label = 'Zigzag' },
            { key = 'diagonal_tl_br', label = 'Diag TL-BR' },
            { key = 'diagonal_tr_bl', label = 'Diag TR-BL' },
            { key = 'spiral_out', label = 'Spiral Out' },
            { key = 'spiral_in', label = 'Spiral In' },
            { key = 'rings_out', label = 'Rings Out' },
            { key = 'rings_in', label = 'Rings In' },
            { key = 'perimeter_in', label = 'Perimeter In' },
            { key = 'cross_expand', label = 'Cross' },
            { key = 'x_expand', label = 'X Burst' },
            { key = 'checker_wave', label = 'Checker' },
            { key = 'random_seeded', label = 'Random' }
        }
        if Planner.sequence.usePatternPreset then
            for i = 1, #presets do
                local p = presets[i]
                if Planner.sequence.pattern == p.key then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
                if ImGui.Button(p.label .. '##seqpreset_' .. p.key, 96, 24) then
                    Planner.sequence.pattern = p.key
                    appendSequenceLog('info', 'Sequence preset changed to ' .. p.label .. '.')
                end
                showHelpIfHovered('Chooses how manual sequence entries activate over time. Rows, spirals, rings, diagonals, crosses, checker waves, and seeded random orders are all available.')
                popButtonColors()
                if (i % 3) ~= 0 and i < #presets then ImGui.SameLine() end
            end
        else
            ImGui.TextWrapped('Manual Paint Order is active. The first cell you paint is spawned first, the next painted cell is spawned second, and so on.')
        end

        if ImGui.Button(Planner.sequence.playing and "Stop Sequence" or "Start Sequence", 120, 26) then
            if Planner.sequence.playing then
                Planner.sequence.playing = false
                Planner.sequence.hasAnchor = false
            else
                captureSequenceAnchor()
                Planner.sequence.playing = true
                Planner.sequence.elapsed = 0.0
                clearRuntimeWorkspace('sequence')
                resetSequenceTracking(false)
                appendSequenceLog('info', 'Sequence started with ' .. (Planner.sequence.usePatternPreset and ('preset ' .. tostring(Planner.sequence.pattern)) or 'manual paint order') .. '.')
            end
        end
        showHelpIfHovered("Starts or stops sequence playback. Leaving the Sequence tab freezes playback automatically.")

        ImGui.SameLine()
        if ImGui.Button("Reset Timer", 100, 26) then
            captureSequenceAnchor()
            Planner.sequence.elapsed = 0.0
            clearRuntimeWorkspace('sequence')
            resetSequenceTracking(false)
            appendSequenceLog('info', 'Sequence timer reset.')
        end
        showHelpIfHovered("Resets the sequence timer and re-anchors the grid to the player's current position.")

        local duration = math.max(0.05, Planner.sequence.duration)
        local progress = clamp(Planner.sequence.elapsed / duration, 0.0, 1.0)
        ImGui.Text("Sequence Progress: " .. fmtPct(progress))
        ImGui.Text("Sequence Radius: " .. (Planner.sequence.useRadius and ((Planner.sequence.useLiveRadius and (fmt1(Planner.radiusMeters) .. ' m')) or (fmt1(Planner.sequence.targetRadius) .. ' m')) or 'Disabled'))
        ImGui.Text('Radius Animation: ' .. ((Planner.sequence.useRadius and Planner.sequence.useRadiusAnimation) and Planner.sequence.mode or 'Off'))
        ImGui.Text('Spawn Ordering: ' .. (Planner.sequence.usePatternPreset and tostring(Planner.sequence.pattern) or 'manual_paint_order'))
        local randMaxDisplay = tonumber(Planner.sequence.timeRandomMax) or 0.0
        if randMaxDisplay > 0.0 then
            ImGui.Text('Time Jitter Max: +' .. fmt2(randMaxDisplay) .. 's')
        end
        if Planner.sequence.hasAnchor then
            ImGui.TextColored(0.42, 0.94, 0.52, 1.0, 'Grid Anchored at: ' .. fmt1(Planner.sequence.anchorX) .. ', ' .. fmt1(Planner.sequence.anchorY))
        end
    elseif Planner.sequenceTab == "fill" then
        -- ── Autofill ──────────────────────────────────────────────────────
        ImGui.Text('Autofill Sequence Grid')
        ImGui.Separator()
        ImGui.TextWrapped('Instantly fill every cell inside the current shape with a single spawn entry.  Use this to quickly lay down a uniform grid of FX explosions, props, characters, etc.')
        if #Planner.curatedList > 0 then
            local selLabel = getPlannerEntryLabel(Planner.curatedList[clamp(Planner.selectedCuratedIndex, 1, #Planner.curatedList)]) or 'none'
            ImGui.Text('Will stamp: ' .. selLabel)
            if ImGui.Button('Autofill With Selected Entry', -1, 26) then
                autofillSequenceGrid(clamp(Planner.selectedCuratedIndex, 1, #Planner.curatedList))
                appendSequenceLog('info', 'Autofill applied: ' .. selLabel)
            end
            showHelpIfHovered('Stamps the selected entry into every cell inside the active shape (or all cells when radius is off), overwriting existing paint.')
        else
            ImGui.TextWrapped('Add spawn entries on the Presets page first, then return here to autofill.')
        end

        -- ── Timer Randomizer ──────────────────────────────────────────────
        ImGui.Spacing()
        ImGui.Text('Spawn Time Randomizer')
        ImGui.Separator()
        ImGui.TextWrapped('Adds a random extra delay (0 to Max) to each computed spawn time. Set Max to 0 to disable.')
        Planner.sequence.timeRandomMax = parseSliderFloat(Planner.sequence.timeRandomMax, 'Max Random Delay', 0.0, math.max(0.5, Planner.sequence.duration), '%.2f s')
        showHelpIfHovered('Each entry gets an independent random time offset between 0 and this value added on top of its pattern-assigned spawn time.')
        -- ── Random Fill Rules ────────────────────────────────────────────
        ImGui.Spacing()
        ImGui.Text('Randomizer Rules')
        ImGui.Separator()
        ImGui.TextWrapped('Fine tune which entries the randomizer may use, how likely each one is, and how near or far from the player each entry is allowed to appear.')
        if #Planner.curatedList == 0 then
            ImGui.TextDisabled('No entries yet.')
        else
            local totalEnabledWeight = 0.0
            local anyEnabled = false
            for i = 1, #Planner.curatedList do
                local rule = getRandomRule(i)
                if rule.enabled == true then
                    anyEnabled = true
                    totalEnabledWeight = totalEnabledWeight + (tonumber(rule.weight) or 1)
                end
            end
            ImGui.BeginChild('##sequence_random_rules', 0, 210, true)
            for i = 1, #Planner.curatedList do
                local entry = Planner.curatedList[i]
                local rule = getRandomRule(i)
                local baseOdds = 0.0
                if anyEnabled and totalEnabledWeight > 0 and rule.enabled then
                    baseOdds = (tonumber(rule.weight) or 1) / totalEnabledWeight
                elseif not anyEnabled then
                    baseOdds = 1.0 / math.max(1, #Planner.curatedList)
                end
                local label = getPlannerEntryLabel(entry) or ('Entry ' .. i)
                ImGui.PushID('rand_rule_' .. tostring(i))
                rule.enabled = ImGui.Checkbox('Use##enabled', rule.enabled == true)
                ImGui.SameLine()
                ImGui.Text(label)
                ImGui.SameLine()
                ImGui.TextColored(0.62, 0.82, 1.0, 1.0, 'Base Odds: ' .. fmtPct(baseOdds))

                rule.weight = parseSliderInt(tonumber(rule.weight) or 1, 'Weight', 1, 100, '%d')
                rule.minDist = parseSliderFloat(tonumber(rule.minDist) or 0.0, 'Min Distance', 0.0, 50.0, '%.1f m')
                rule.maxDist = parseSliderFloat(tonumber(rule.maxDist) or 50.0, 'Max Distance', 0.0, 50.0, '%.1f m')
                if rule.maxDist < rule.minDist then rule.maxDist = rule.minDist end

                if tostring(rule.bias) == 'none' then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
                if ImGui.Button('No Bias', 66, 20) then rule.bias = 'none' end
                popButtonColors()
                ImGui.SameLine()
                if tostring(rule.bias) == 'near' then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
                if ImGui.Button('Near', 52, 20) then rule.bias = 'near' end
                popButtonColors()
                ImGui.SameLine()
                if tostring(rule.bias) == 'far' then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
                if ImGui.Button('Far', 52, 20) then rule.bias = 'far' end
                popButtonColors()
                showHelpIfHovered('Near biases this entry toward cells closer to the player. Far biases it toward cells further away. Min/Max Distance hard-limit where it can appear.')
                ImGui.Separator()
                ImGui.PopID()
            end
            ImGui.EndChild()
            if ImGui.Button('Disable All Random Rules', -1, 22) then
                for i = 1, #Planner.curatedList do
                    local rule = getRandomRule(i)
                    rule.enabled = false
                end
            end
        end

        ImGui.Spacing()
        Planner.randomPreviewEnabled = ImGui.Checkbox("Random Preview Enabled", Planner.randomPreviewEnabled)
        showHelpIfHovered("Shows randomized highlighted cells inside the ghost shape. This is a preview only and does not spawn anything in-world yet.")
        Planner.randomDensity = parseSliderFloat(Planner.randomDensity, "Random Fill Density", 0.0, 1.0, "%.2f")
        showHelpIfHovered("Controls how many valid cells are highlighted by random preview inside the active ghost shape.")
        Planner.randomSeed = parseSliderInt(Planner.randomSeed, "Random Seed", 1, 999999, "%d")
        showHelpIfHovered("Changes the stable random layout used by random preview.")
        Planner.sequence.randomizeDuringPlayback = ImGui.Checkbox("Re-Randomize During Playback", Planner.sequence.randomizeDuringPlayback)
        showHelpIfHovered("When enabled, the random seed increments each loop cycle so the fill pattern changes on every repeat.")
    else
        local exits = {
            { key = "despawn", label = "Despawn" },
            { key = "none", label = "Do Nothing" },
            { key = "explode_vehicle", label = "Explode Vehicle" },
            { key = "remove_fx", label = "Remove FX" },
            { key = "disable_target", label = "Disable Target" }
        }

        for i = 1, #exits do
            local e = exits[i]
            if Planner.exitAction == e.key then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
            if ImGui.Button(e.label .. "##exit_" .. e.key, 116, 24) then
                Planner.exitAction = e.key
            end
            showHelpIfHovered("Selects the UI-only exit action preview for entries that leave the active radius later at runtime.")
            popButtonColors()
            if (i % 2) == 1 and i < #exits then ImGui.SameLine() end
        end
    end

    ImGui.EndChild()

    ImGui.Spacing()
    ImGui.BeginChild('##sequence_log_panel', leftW - 4, logH, true)
    local panelW, panelH = ImGui.GetContentRegionAvail()
    local timelineH = math.max(120, math.floor(panelH * 0.52))
    local eventH = math.max(70, panelH - timelineH - 10)

    drawSequenceTimelinePreview(hasPlayer, px, py, pz, panelW, timelineH)

    ImGui.Spacing()
    ImGui.BeginChild('##sequence_event_log_inner', panelW, eventH, true)
    ImGui.Text('Sequence Event Log')
    ImGui.Separator()
    ImGui.TextWrapped('Shows when entries entered / exited the radius. If radius usage is disabled, this log shows when manual entries spawned in the timeline instead.')
    if ImGui.Button('Clear Log', 80, 22) then
        resetSequenceTracking(true)
    end
    showHelpIfHovered('Clears the current sequence event log and active-entry tracking state.')

    ImGui.Separator()
    for i = 1, #Planner.sequence.eventLog do
        local entry = Planner.sequence.eventLog[i]
        local r, g, b = 0.82, 0.82, 0.84
        if entry.kind == 'enter' or entry.kind == 'spawn' then
            r, g, b = 0.42, 0.92, 0.54
        elseif entry.kind == 'exit' or entry.kind == 'remove' then
            r, g, b = 0.96, 0.56, 0.46
        elseif entry.kind == 'info' then
            r, g, b = 0.64, 0.82, 1.00
        end
        ImGui.TextColored(r, g, b, 1.0, '[' .. tostring(entry.time) .. 's] ' .. tostring(entry.text))
    end
    if #Planner.sequence.eventLog == 0 then
        ImGui.TextWrapped('No sequence events yet.')
    end
    ImGui.EndChild()
    ImGui.EndChild()

    ImGui.EndChild()

    ImGui.SameLine()

    ImGui.BeginChild('##sequence_grid_panel', rightW, availH - 4, true)
    ImGui.Text('Sequence Grid Workspace')
    ImGui.Separator()
    ImGui.TextWrapped('Build the sequence footprint here. Painted cells are spawn slots. Active playback highlights entries that have already fired. The live player dot moves as you walk when a sequence is anchored.')

    -- Compact Spawn Source Mode so the sequence grid is self-contained
    ImGui.Spacing()
    ImGui.Text('Spawn Source Mode')
    ImGui.Separator()
    ensureSpawnDBReady()
    local seqModes = plannerModeList()
    for i = 1, #seqModes do
        local mode = seqModes[i]
        if Planner.spawnMode == mode then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
        if ImGui.Button(mode .. '##seq_mode_' .. mode, 78, 22) then
            Planner.spawnMode = mode
            Planner.selectedDbIndex = 1
        end
        popButtonColors()
        if i < #seqModes then ImGui.SameLine() end
    end
    showHelpIfHovered('Select which GTS spawn database the Sequence grid is browsing.')

    Planner.dbSearch = parseInputText(Planner.dbSearch, 'Search##seq_db_search', 128)
    local seqResults = getPlannerDBResults()
    if Planner.selectedDbIndex < 1 then Planner.selectedDbIndex = 1 end
    if Planner.selectedDbIndex > math.max(1, #seqResults) then Planner.selectedDbIndex = math.max(1, #seqResults) end

    ImGui.BeginChild('##seq_db_results', 0, 110, true)
    for i = 1, #seqResults do
        local rec = tostring(seqResults[i])
        local sel = (Planner.selectedDbIndex == i)
        local shortLabel = getRecordDisplayLabel(rec)
        if sel then pushSelectedButtonStyle() else pushUnselectedButtonStyle() end
        if ImGui.Button(shortLabel .. '##seq_db_pick_' .. tostring(i), -1, 22) then
            Planner.selectedDbIndex = i
            ensurePlannerEntry(rec, Planner.spawnMode, Planner.newItemWeight)
        end
        if ImGui.IsItemHovered() then
            ImGui.BeginTooltip()
            ImGui.PushTextWrapPos(540)
            ImGui.TextWrapped(rec)
            ImGui.PopTextWrapPos()
            ImGui.EndTooltip()
        end
        popButtonColors()
    end
    ImGui.EndChild()

    if #Planner.curatedList > 0 then
        local sel = Planner.curatedList[clamp(Planner.selectedCuratedIndex, 1, #Planner.curatedList)]
        ImGui.Text('Paint Target: ' .. tostring(getPlannerEntryLabel(sel) or 'none'))
    else
        ImGui.TextWrapped('No entries yet. Select a record above to add it.')
    end

    -- Anchor status bar
    ImGui.Spacing()
    ImGui.Separator()
    local seq = Planner.sequence
    if seq.playing and seq.hasAnchor then
        local plx, ply = getPlayerLocalForGrid()
        ImGui.TextColored(0.42, 0.94, 0.52, 1.0, string.format('Anchored  |  Player: %.1f, %.1f m', plx, ply))
    elseif seq.playing then
        ImGui.TextColored(0.98, 0.72, 0.24, 1.0, 'Playing (no anchor)')
    else
        ImGui.TextDisabled('Sequence stopped')
    end
    ImGui.Separator()

    ImGui.Spacing()
    local gridW, gridH = ImGui.GetContentRegionAvail()
    drawMapGrid(hasPlayer, px, py, pz, gridW, gridH - 4)
    ImGui.EndChild()
end

local function drawSummaryPage(stats, hasPlayer, px, py, pz)
    local wx, wy, wz = getPlacedWorld(px, py, pz)
    local refX, refY, refLabel = getCurrentReferenceLocal()
    local playerDist, plx, ply = getPlayerDistanceFromGridCenter()

    ImGui.Text("Summary")
    ImGui.Separator()
    ImGui.TextWrapped("This page condenses the current plan into counts, location metrics, and closest/furthest placement summaries so the player can evaluate the layout quickly without hunting through the grid manually.")

    ImGui.Text("Counts")
    ImGui.Separator()
    ImGui.Text("Planned Cells: " .. tostring(stats.plannedCount))
    ImGui.Text("Excluded Cells: " .. tostring(stats.excludedCount))
    ImGui.Text("Stacked Cells: " .. tostring(stats.stackedCount))

    ImGui.Spacing()
    ImGui.Text("Closest / Furthest From Center")
    ImGui.Separator()
    if stats.closestDist ~= nil then
        ImGui.TextWrapped("Closest planned item: " .. tostring(stats.closestName) .. " @ " .. fmt1(stats.closestDist) .. " m")
    else
        ImGui.TextWrapped("Closest planned item: none")
    end
    if stats.furthestDist ~= nil then
        ImGui.TextWrapped("Furthest planned item: " .. tostring(stats.furthestName) .. " @ " .. fmt1(stats.furthestDist) .. " m")
    else
        ImGui.TextWrapped("Furthest planned item: none")
    end

    ImGui.Spacing()
    ImGui.Text("Reference")
    ImGui.Separator()
    ImGui.Text("Reference Source: " .. tostring(refLabel))
    ImGui.Text("Reference X/Y: " .. fmt1(refX) .. ", " .. fmt1(refY))
    ImGui.Text("Shape Center X/Y: " .. fmt1(Planner.centerOffsetX) .. ", " .. fmt1(Planner.centerOffsetY))
    ImGui.Text("Player Offset From Grid Center: " .. fmt1(playerDist) .. " m")
    ImGui.Text("Player Local X/Y: " .. fmt1(plx) .. ", " .. fmt1(ply))
    if playerDist > 0.25 and ImGui.Button('Teleport To Grid Center##summary', 180, 24) then
        teleportPlayerToCurrentWorkspaceCenter()
    end

    ImGui.Spacing()
    ImGui.Text("Resolved World Position")
    ImGui.Separator()
    if hasPlayer then
        ImGui.Text("Player X/Y/Z: " .. fmt2(px) .. ", " .. fmt2(py) .. ", " .. fmt2(pz))
        ImGui.Text("Placed X/Y/Z: " .. fmt2(wx) .. ", " .. fmt2(wy) .. ", " .. fmt2(wz))
    else
        ImGui.TextWrapped("World position unavailable")
    end
end

local function drawDisplayPage()
    ImGui.Text("Display & Help")
    ImGui.Separator()
    ImGui.TextWrapped("This page holds the visual grid and help options that do not belong in Presets or Sequence. It keeps one long list from becoming the entire menu flow.")

    Planner.showFill = ImGui.Checkbox("Show Ghost Shape", Planner.showFill)
    showHelpIfHovered("Shows or hides the ghost shape in the grid. The ghost shape is the low-opacity preview of the active area, separate from the actual highlighted samples the player is planning to use.")
    Planner.showCrosshair = ImGui.Checkbox("Show Selection Crosshair", Planner.showCrosshair)
    showHelpIfHovered("Keeps the shape center visually distinct inside the grid.")
    Planner.showMinorGrid = ImGui.Checkbox("Show Minor Grid", Planner.showMinorGrid)
    showHelpIfHovered("Toggles the lower-importance sample background rhythm in the grid.")
    Planner.showMajorGrid = ImGui.Checkbox("Show Major Grid", Planner.showMajorGrid)
    showHelpIfHovered("Highlights major 10m rows and columns so the player can orient more quickly without relying on text characters inside the samples.")
    Planner.ghostOpacity = parseSliderFloat(Planner.ghostOpacity, "Ghost Opacity", 0.05, 0.90, "%.2f")
    showHelpIfHovered("Controls how strongly the ghost shape shows in the grid compared with manual placements, exclusions, and random preview highlights.")
    Planner.fxCoverEnabled = ImGui.Checkbox("FX Cover Ghost", Planner.fxCoverEnabled)
    showHelpIfHovered("Changes the ghost preview to an FX-coverage style layer without spawning any real FX. This keeps the concept visible while the runtime side is still being built.")
    Planner.fxCoverName = parseInputText(Planner.fxCoverName, "FX Name", 128)
    showHelpIfHovered("Name of the FX used by the ghost coverage preview. This is UI-only right now.")

    ImGui.Spacing()
    drawWorkflowHelpPanel()
end

local function drawCenterWorkspace(stats, hasPlayer, px, py, pz, width, height)
    ImGui.BeginChild('##planner_workspace', width, height, true)

    if Planner.workspaceTab == 'grid' then
        drawGridPage(hasPlayer, px, py, pz, width, height)
    elseif Planner.workspaceTab == 'presets' then
        drawPresetsPage(hasPlayer, px, py, pz)
    elseif Planner.workspaceTab == 'sequence' then
        drawSequencePage(hasPlayer, px, py, pz)
    elseif Planner.workspaceTab == 'summary' then
        drawSummaryPage(stats, hasPlayer, px, py, pz)
    else
        drawDisplayPage()
    end

    ImGui.EndChild()
end

local function drawWindow()
    ensureWorkspaceStates()
    ensureCellStates()

    if Planner.workspaceTab ~= 'sequence' and Planner.sequence.playing then
        Planner.sequence.playing = false
        clearRuntimeWorkspace('sequence')
    end
    if Planner.workspaceTab ~= 'sequence' then
        Planner.sequence.hoveredTimelineKey = nil
    end

    local hasPlayer, px, py, pz = getPlayerWorld()
    local stats = computePlacementStats()

    ImGui.SetNextWindowPos(86, 70, ImGuiCond.FirstUseEver)
    ImGui.SetNextWindowSize(1460, 900, ImGuiCond.FirstUseEver)

    if ImGui.Begin(Planner.title) then
        ImGui.Text('Grid Planner')
        ImGui.Separator()
        ImGui.TextWrapped('A grid-based spawning tool for authoring real placements, sequence playback, and exclusions around the player using the same spawn databases and spawn helpers as Spawn Tools.')

        drawPersistentHeader()
        drawPlayerDriftNotice()
        updateOutsidePromptState()

        local bodyW, bodyH = ImGui.GetContentRegionAvail()
        local leftW = 144
        local inspectorW = 330
        local gap = 8
        local centerW = math.max(560, bodyW - leftW - inspectorW - (gap * 2))

        drawLeftRail(stats)
        ImGui.SameLine()
        drawCenterWorkspace(stats, hasPlayer, px, py, pz, centerW, bodyH - 4)
        ImGui.SameLine()
        drawInspectorPanel(hasPlayer, px, py, pz, stats, inspectorW, bodyH - 4)

        saveCurrentWorkspaceState()
        drawOutsideAreaPopup()
        drawWorkspaceTransferPopup()
    end

    ImGui.End()
end



Planner.OnUpdate = function(delta)
    updateSequenceClock()
end

Planner.OnOverlayStateChanged = function(open)
    if open ~= true then
        Planner.sequence.playing = false
        clearRuntimeWorkspace('sequence')
    end
end

Planner.DrawTab = function(uiState)
    ensureWorkspaceStates()
    ensureCellStates()

    if Planner.workspaceTab ~= 'sequence' and Planner.sequence.playing then
        Planner.sequence.playing = false
        clearRuntimeWorkspace('sequence')
    end
    if Planner.workspaceTab ~= 'sequence' then
        Planner.sequence.hoveredTimelineKey = nil
    end

    local hasPlayer, px, py, pz = getPlayerWorld()
    local stats = computePlacementStats()

    ImGui.Text('Grid Planner')
    ImGui.Separator()
    ImGui.TextWrapped('Standalone-style spatial planning system integrated into GTS as its own tool module. This module is separate from Spawn Tools and keeps its own planner, spawn-entry, and sequence workspaces.')

    drawPersistentHeader()
    drawPlayerDriftNotice()
    updateOutsidePromptState()

    local bodyW = (ImGui.GetContentRegionAvail and ImGui.GetContentRegionAvail()) or 0
    local bodyH = (ImGui.GetContentRegionAvailY and ImGui.GetContentRegionAvailY()) or 680
    if type(bodyW) ~= 'number' then bodyW = 1040 end
    if type(bodyH) ~= 'number' then bodyH = 680 end
    local leftW = 144
    local inspectorW = 330
    local gap = 8
    local centerW = math.max(500, bodyW - leftW - inspectorW - (gap * 2))

    drawLeftRail(stats)
    ImGui.SameLine()
    drawCenterWorkspace(stats, hasPlayer, px, py, pz, centerW, bodyH - 4)
    ImGui.SameLine()
    drawInspectorPanel(hasPlayer, px, py, pz, stats, inspectorW, bodyH - 4)

    saveCurrentWorkspaceState()
    drawOutsideAreaPopup()
    drawWorkspaceTransferPopup()
end

return Planner
