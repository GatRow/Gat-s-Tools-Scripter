
local Utils = require("GTS/Tools/MenuMaker/menu_maker_utils")
local Store = require("GTS/Tools/MenuMaker/menu_maker_store")
local Assets = require("GTS/Tools/MenuMaker/menu_maker_assets")

local Editor = Editor or {}

Editor.state = Editor.state or {
  projects = {},
  selectedProjectIndex = 1,
  selectedPageIndex = 1,
  selectedSubtabIndex = 1,
  selectedGroupIndex = 1,
  selectedWidgetIndex = 1,
  activeRootTab = "Projects",
  lastMessage = "Menu Maker ready.",
  assetSearch = "",
  assetTypeFilter = "All",
  previewPageIndex = 1,
  previewSubtabIndex = 1,
  previewOpen = true,
  nextProjectId = 1,
  nextNodeId = 1,
}

local SHELL_OPTIONS = {
  "Top Tabs",
  "Sidebar",
  "Inventory Categories",
  "Hybrid",
}

local MENU_SHELL_OPTIONS = {
  "Top Tabs",
  "Sidebar",
}

local WIDGET_OPTIONS = {
  "Button",
  "Toggle",
  "Text",
  "Separator",
  "Status",
}

local ASSET_TYPES = {
  "All",
  "rule",
  "macro",
  "custom_code",
  "launcher",
  "teleport_preset",
  "stat_preset",
  "condition_preset",
  "spawn_set",
  "spawn_grid",
  "inventory_bundle",
  "shooter_profile",
}

local ROOT_TAB_LABELS = {
  projects = '1. Project',
  designer = '2. Build Menu',
  assets = '3. Bind Assets',
  preview = '4. Live Preview',
}

local function _defaultLayout()
  return {
    shellMode = "Top Tabs",
    compact = false,
    showHeader = true,
    windowWidth = 1080,
    windowHeight = 700,
    sidebarWidth = 220,
    pageButtonHeight = 28,
    sectionSpacing = 8,
    showPageCounts = true,
    inventoryCatMode = false,
  }
end

local function _clone(value, seen)
  if type(value) ~= 'table' then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do out[_clone(k, seen)] = _clone(v, seen) end
  return out
end

local function _availRegion()
  if type(ImGui.GetContentRegionAvail) ~= 'function' then return 0, 0 end
  local ok, a, b = pcall(ImGui.GetContentRegionAvail)
  if not ok then return 0, 0 end
  if type(a) == 'table' then
    return tonumber(a.x or a[1] or 0) or 0, tonumber(a.y or a[2] or 0) or 0
  end
  return tonumber(a or 0) or 0, tonumber(b or 0) or 0
end

local function _newWidget(kind, asset)
  local id = string.format("widget_%03d", tonumber(Editor.state.nextNodeId or 1))
  Editor.state.nextNodeId = (tonumber(Editor.state.nextNodeId or 1) or 1) + 1
  local widget = {
    id = id,
    type = string.lower(tostring(kind or "Button")),
    label = tostring((asset and asset.name) or (kind or "Widget")),
    help = "",
    assetId = asset and asset.id or "",
    assetType = asset and asset.type or "",
    embeddedAsset = asset and _clone(asset) or nil,
    text = asset and asset.name or "Text",
    widthMode = "fill",
  }
  if widget.type == 'toggle' and asset then
    widget.label = tostring(asset.name or asset.id)
  elseif widget.type == 'button' and asset then
    widget.label = tostring(asset.name or asset.id)
  elseif widget.type == 'status' and asset then
    widget.label = tostring(asset.name or asset.id)
  elseif widget.type == 'separator' then
    widget.label = 'Separator'
  elseif widget.type == 'text' then
    widget.text = asset and tostring(asset.name or asset.id) or 'New text'
  end
  return widget
end

local function _newGroup(name)
  local id = string.format("group_%03d", tonumber(Editor.state.nextNodeId or 1))
  Editor.state.nextNodeId = (tonumber(Editor.state.nextNodeId or 1) or 1) + 1
  return { id = id, title = tostring(name or 'Group'), widgets = {} }
end

local function _newSubtab(name)
  local id = string.format("subtab_%03d", tonumber(Editor.state.nextNodeId or 1))
  Editor.state.nextNodeId = (tonumber(Editor.state.nextNodeId or 1) or 1) + 1
  return { id = id, title = tostring(name or 'Subtab'), groups = { _newGroup('Main Group') } }
end

local function _newPage(name)
  local id = string.format("page_%03d", tonumber(Editor.state.nextNodeId or 1))
  Editor.state.nextNodeId = (tonumber(Editor.state.nextNodeId or 1) or 1) + 1
  return { id = id, title = tostring(name or 'Page'), groups = { _newGroup('Main Group') }, subtabs = {} }
end

local function _newProject(name)
  local id = string.format("project_%03d", tonumber(Editor.state.nextProjectId or 1))
  Editor.state.nextProjectId = (tonumber(Editor.state.nextProjectId or 1) or 1) + 1
  return {
    id = id,
    name = tostring(name or 'New Menu Project'),
    createdAtText = Utils.NowText(),
    updatedAtText = Utils.NowText(),
    layout = _defaultLayout(),
    schema = {
      pages = { _newPage('Main') },
    },
  }
end

local function _projects()
  return Editor.state.projects
end

local function _currentProject()
  return _projects()[math.max(1, math.min(#_projects(), Editor.state.selectedProjectIndex or 1))]
end

local function _currentPages(project)
  project = project or _currentProject()
  local pages = (((project or {}).schema or {}).pages)
  return type(pages) == 'table' and pages or {}
end

local function _currentPage(project)
  local pages = _currentPages(project)
  return pages[math.max(1, math.min(#pages, Editor.state.selectedPageIndex or 1))]
end

local function _currentSubtabs(page)
  page = page or _currentPage()
  local subtabs = (page or {}).subtabs
  return type(subtabs) == 'table' and subtabs or {}
end

local function _currentSubtab(page)
  local subtabs = _currentSubtabs(page)
  return subtabs[math.max(1, math.min(#subtabs, Editor.state.selectedSubtabIndex or 1))]
end

local function _effectiveGroups(page)
  local pageObj = page or _currentPage()
  local project = _currentProject()
  if not pageObj then return {} end
  local shell = tostring((((project or {}).layout or {}).shellMode) or 'Top Tabs')
  if (shell == 'Hybrid' or shell == 'Top Tabs') and #_currentSubtabs(pageObj) > 0 then
    local sub = _currentSubtab(pageObj)
    local groups = sub and sub.groups or {}
    return type(groups) == 'table' and groups or {}
  end
  local groups = pageObj.groups
  return type(groups) == 'table' and groups or {}
end

local function _currentGroup()
  local groups = _effectiveGroups()
  return groups[math.max(1, math.min(#groups, Editor.state.selectedGroupIndex or 1))]
end

local function _currentWidgets()
  local group = _currentGroup()
  local widgets = group and group.widgets or {}
  return type(widgets) == 'table' and widgets or {}
end

local function _currentWidget()
  local widgets = _currentWidgets()
  return widgets[math.max(1, math.min(#widgets, Editor.state.selectedWidgetIndex or 1))]
end

local function _refreshAssets(forceDisk)
  if forceDisk == true then
    local ok, msg = Assets.ReloadFromDisk()
    Editor.state.lastMessage = ok and tostring(msg or 'Reloaded GTS assets from disk.') or tostring(msg or 'Failed to reload GTS assets from disk.')
  else
    local info = Assets.GetInfo()
    Editor.state.lastMessage = 'Live registry sees ' .. tostring(info.total or 0) .. ' saved asset(s).'
  end
end

local function _ensureSelectionBounds()
  local ps = _projects()
  if #ps == 0 then
    Editor.state.selectedProjectIndex = 1
    return
  end
  if Editor.state.selectedProjectIndex < 1 then Editor.state.selectedProjectIndex = 1 end
  if Editor.state.selectedProjectIndex > #ps then Editor.state.selectedProjectIndex = #ps end

  local pages = _currentPages()
  if #pages < 1 then
    local project = _currentProject()
    project.schema.pages = { _newPage('Main') }
    pages = project.schema.pages
  end
  if Editor.state.selectedPageIndex < 1 then Editor.state.selectedPageIndex = 1 end
  if Editor.state.selectedPageIndex > #pages then Editor.state.selectedPageIndex = #pages end

  local subtabs = _currentSubtabs()
  if Editor.state.selectedSubtabIndex < 1 then Editor.state.selectedSubtabIndex = 1 end
  if #subtabs < Editor.state.selectedSubtabIndex then Editor.state.selectedSubtabIndex = math.max(1, #subtabs) end

  local groups = _effectiveGroups()
  if #groups < 1 then
    local page = _currentPage()
    local shell = tostring((((_currentProject() or {}).layout or {}).shellMode) or 'Top Tabs')
    if (shell == 'Hybrid' or shell == 'Top Tabs') and #_currentSubtabs(page) > 0 then
      local sub = _currentSubtab(page)
      sub.groups = { _newGroup('Main Group') }
    else
      page.groups = { _newGroup('Main Group') }
    end
    groups = _effectiveGroups()
  end
  if Editor.state.selectedGroupIndex < 1 then Editor.state.selectedGroupIndex = 1 end
  if Editor.state.selectedGroupIndex > #groups then Editor.state.selectedGroupIndex = #groups end

  local widgets = _currentWidgets()
  if Editor.state.selectedWidgetIndex < 1 then Editor.state.selectedWidgetIndex = 1 end
  if #widgets < Editor.state.selectedWidgetIndex then Editor.state.selectedWidgetIndex = math.max(1, #widgets) end
end

local function _projectIndexById(projectId)
  for i = 1, #Editor.state.projects do
    if tostring(Editor.state.projects[i].id or '') == tostring(projectId or '') then return i end
  end
  return nil
end

local function _saveCurrentProject()
  local project = _currentProject()
  if not project then return end
  local ok, msg = Store.SaveProject(project, Editor.state.projects)
  if ok then
    Editor.state.lastMessage = 'Saved project to ' .. tostring(msg)
  else
    Editor.state.lastMessage = tostring(msg)
  end
end

local function _deleteCurrentProject()
  local project = _currentProject()
  if not project then return end
  local doomedId = project.id
  table.remove(Editor.state.projects, Editor.state.selectedProjectIndex)
  if #Editor.state.projects < 1 then Editor.state.projects[1] = _newProject('New Menu Project') end
  if Editor.state.selectedProjectIndex > #Editor.state.projects then Editor.state.selectedProjectIndex = #Editor.state.projects end
  local ok, msg = Store.DeleteProject(doomedId, Editor.state.projects)
  if ok then Editor.state.lastMessage = 'Deleted project.' else Editor.state.lastMessage = tostring(msg) end
  _ensureSelectionBounds()
end

local function _duplicateCurrentProject()
  local project = _currentProject()
  if not project then return end
  local copy = Utils.Clone(project)
  copy.id = string.format('project_%03d', tonumber(Editor.state.nextProjectId or 1))
  Editor.state.nextProjectId = (tonumber(Editor.state.nextProjectId or 1) or 1) + 1
  copy.name = tostring(copy.name or 'Project') .. ' Copy'
  copy.createdAtText = Utils.NowText()
  copy.updatedAtText = Utils.NowText()
  Editor.state.projects[#Editor.state.projects + 1] = copy
  Editor.state.selectedProjectIndex = #Editor.state.projects
  Editor.state.lastMessage = 'Duplicated project.'
end

local function _addPage()
  local project = _currentProject()
  if not project then return end
  local pages = _currentPages(project)
  pages[#pages + 1] = _newPage('New Page')
  project.schema.pages = pages
  Editor.state.selectedPageIndex = #pages
  Editor.state.selectedGroupIndex = 1
  Editor.state.selectedWidgetIndex = 1
end

local function _deletePage()
  local project = _currentProject()
  if not project then return end
  local pages = _currentPages(project)
  if #pages <= 1 then return end
  table.remove(pages, Editor.state.selectedPageIndex)
  if Editor.state.selectedPageIndex > #pages then Editor.state.selectedPageIndex = #pages end
  _ensureSelectionBounds()
end

local function _addSubtab()
  local page = _currentPage()
  if not page then return end
  page.subtabs = page.subtabs or {}
  page.subtabs[#page.subtabs + 1] = _newSubtab('New Subtab')
  Editor.state.selectedSubtabIndex = #page.subtabs
  Editor.state.selectedGroupIndex = 1
  Editor.state.selectedWidgetIndex = 1
end

local function _deleteSubtab()
  local page = _currentPage()
  if not page or type(page.subtabs) ~= 'table' or #page.subtabs < 1 then return end
  table.remove(page.subtabs, Editor.state.selectedSubtabIndex)
  if Editor.state.selectedSubtabIndex > #page.subtabs then Editor.state.selectedSubtabIndex = math.max(1, #page.subtabs) end
  _ensureSelectionBounds()
end

local function _addGroup()
  local groups = _effectiveGroups()
  groups[#groups + 1] = _newGroup('New Group')
  Editor.state.selectedGroupIndex = #groups
end

local function _deleteGroup()
  local groups = _effectiveGroups()
  if #groups <= 1 then return end
  table.remove(groups, Editor.state.selectedGroupIndex)
  if Editor.state.selectedGroupIndex > #groups then Editor.state.selectedGroupIndex = #groups end
  _ensureSelectionBounds()
end

local function _addWidget(kind, asset)
  local widgets = _currentWidgets()
  widgets[#widgets + 1] = _newWidget(kind, asset)
  Editor.state.selectedWidgetIndex = #widgets
  Editor.state.lastMessage = 'Added ' .. tostring(kind) .. ' widget.'
end

local function _deleteWidget()
  local widgets = _currentWidgets()
  if #widgets < 1 then return end
  table.remove(widgets, Editor.state.selectedWidgetIndex)
  if Editor.state.selectedWidgetIndex > #widgets then Editor.state.selectedWidgetIndex = math.max(1, #widgets) end
  _ensureSelectionBounds()
end

local function _drawHeader(text)
  ImGui.Separator()
  ImGui.Text(text)
end

local function _drawInfoPanel(_id, title, body, r, g, b)
  ImGui.Separator()
  if type(ImGui.TextColored) == 'function' then
    ImGui.TextColored(tonumber(r or 0.95) or 0.95, tonumber(g or 0.82) or 0.82, tonumber(b or 0.28) or 0.28, 1.0, tostring(title or 'Info'))
  else
    ImGui.Text(tostring(title or 'Info'))
  end
  ImGui.TextWrapped(tostring(body or ''))
end

local function _drawStepList(_id, currentStep, steps)
  if type(steps) ~= 'table' or #steps < 1 then return end
  ImGui.Separator()
  ImGui.Text('Recommended Order')
  for i = 1, #steps do
    local prefix = (i == tonumber(currentStep or 0)) and '>> ' or '   '
    ImGui.TextWrapped(prefix .. tostring(i) .. '. ' .. tostring(steps[i] or ''))
  end
end

local function _countProjectObjects(project)
  project = type(project) == 'table' and project or {}
  local pageCount, subtabCount, groupCount, widgetCount = 0, 0, 0, 0
  local schema = type(project.schema) == 'table' and project.schema or {}
  local pages = type(schema.pages) == 'table' and schema.pages or {}
  for i = 1, #pages do
    local page = type(pages[i]) == 'table' and pages[i] or {}
    pageCount = pageCount + 1
    local groups = type(page.groups) == 'table' and page.groups or {}
    groupCount = groupCount + #groups
    for g = 1, #groups do
      local widgets = type(groups[g].widgets) == 'table' and groups[g].widgets or {}
      widgetCount = widgetCount + #widgets
    end
    local subtabs = type(page.subtabs) == 'table' and page.subtabs or {}
    subtabCount = subtabCount + #subtabs
    for s = 1, #subtabs do
      local sub = type(subtabs[s]) == 'table' and subtabs[s] or {}
      local subGroups = type(sub.groups) == 'table' and sub.groups or {}
      groupCount = groupCount + #subGroups
      for sg = 1, #subGroups do
        local widgets = type(subGroups[sg].widgets) == 'table' and subGroups[sg].widgets or {}
        widgetCount = widgetCount + #widgets
      end
    end
  end
  return pageCount, subtabCount, groupCount, widgetCount
end

local function _drawProjectStats(project)
  local pageCount, subtabCount, groupCount, widgetCount = _countProjectObjects(project)
  ImGui.Text('Pages: ' .. tostring(pageCount) .. '   Subtabs: ' .. tostring(subtabCount) .. '   Groups: ' .. tostring(groupCount) .. '   Widgets: ' .. tostring(widgetCount))
end

local function _drawProjectSelector()
  if ImGui.BeginChild('gmm_projects_list', 260, 0, true) then
    _drawInfoPanel('project_selector', 'Project List', 'A project is one custom menu blueprint. Create a project, build its pages and widgets, then save it to keep working on it later.', 0.92, 0.82, 0.26)
    if ImGui.Button('New Project') then
      Editor.state.projects[#Editor.state.projects + 1] = _newProject('New Menu Project')
      Editor.state.selectedProjectIndex = #Editor.state.projects
      Editor.state.lastMessage = 'Created new menu project.'
    end
    ImGui.SameLine()
    if ImGui.Button('Duplicate Project') then _duplicateCurrentProject() end
    ImGui.SameLine()
    if ImGui.Button('Delete Project') then _deleteCurrentProject() end
    ImGui.Separator()
    ImGui.Text('Saved Projects')
    for i = 1, #Editor.state.projects do
      local project = Editor.state.projects[i]
      if ImGui.Selectable(tostring(project.name or project.id), i == Editor.state.selectedProjectIndex) then
        Editor.state.selectedProjectIndex = i
        Editor.state.selectedPageIndex = 1
        Editor.state.selectedSubtabIndex = 1
        Editor.state.selectedGroupIndex = 1
        Editor.state.selectedWidgetIndex = 1
      end
    end
    ImGui.EndChild()
  end
end

local function _drawProjectInspector()
  local project = _currentProject()
  if not project then return end
  _drawInfoPanel('project_start', 'Start Here', 'Use this tab to manage the menu project itself. Name it, choose the shell style, refresh the asset library, and save the menu layout before you move on to building pages and widgets.', 0.20, 0.85, 0.45)
  _drawStepList('project_flow', 1, {
    'Create or pick a project.',
    'Choose the shell style here.',
    'Build the menu structure in Build Menu.',
    'Bind saved GTS assets in Bind Assets.',
    'Test the result in the live preview window.',
  })
  project.name = Utils.InputTextValue('Project Name', project.name or '', 160)
  local layout = project.layout or _defaultLayout()
  project.layout = layout
  local currentShell = tostring(layout.shellMode or 'Top Tabs')
  if currentShell ~= 'Top Tabs' and currentShell ~= 'Sidebar' then currentShell = 'Top Tabs' end
  layout.shellMode = Utils.EnumButtonsSelect('Shell Mode', currentShell, MENU_SHELL_OPTIONS)
  layout.showHeader = Utils.CheckboxValue('Show Menu Header', layout.showHeader ~= false)
  _drawProjectStats(project)
  ImGui.Spacing()
  if ImGui.Button('Check Live Assets') then _refreshAssets(false) end
  ImGui.SameLine()
  if ImGui.Button('Reload Assets From Disk') then _refreshAssets(true) end
  ImGui.SameLine()
  if ImGui.Button('Save Project') then _saveCurrentProject() end

  ImGui.Spacing()
  local info = Assets.GetInfo()
  _drawHeader('Asset Library Status')
  ImGui.Text('Source: ' .. tostring(info.source or '-'))
  ImGui.Text('Saved Assets Seen: ' .. tostring(info.total or 0))
  if info.userDir then ImGui.TextWrapped('GTS User Folder: ' .. tostring(info.userDir)) end
  if info.lastLoadAt then ImGui.Text('Last Disk Load: ' .. tostring(info.lastLoadAt)) end
  if info.lastSaveAt then ImGui.Text('Last Asset Save: ' .. tostring(info.lastSaveAt)) end
  if info.lastError then ImGui.TextWrapped('Asset Persistence: ' .. tostring(info.lastError)) end

  local pinfo = Store.GetInfo()
  ImGui.Spacing()
  _drawHeader('Project Save Location')
  ImGui.TextWrapped('Menu Maker User Folder: ' .. tostring(pinfo.userDir or '-'))
  if pinfo.lastSavePath then ImGui.TextWrapped('Last Save Path: ' .. tostring(pinfo.lastSavePath)) end
  if pinfo.lastError then ImGui.TextWrapped('Persistence: ' .. tostring(pinfo.lastError)) end

  ImGui.Spacing()
  _drawInfoPanel('project_files', 'What gets saved', 'Your custom menu project stores the shell settings, pages, groups, and widgets. Each bound widget also stores an embedded copy of the saved asset it needs, so the menu can still work later even if the original asset file is missing.', 0.60, 0.78, 1.00)
end

local function _drawPagesDesigner()
  local page = _currentPage()
  local project = _currentProject()
  _drawInfoPanel('designer_pages', 'Build the menu structure', 'Pages are the big sections of the menu. Groups are boxes inside a page or subtab. If the shell mode is Top Tabs or Hybrid, you can also create subtabs under a page.', 0.20, 0.75, 1.00)
  local _, pagePaneH = _availRegion()
  pagePaneH = math.max(190, math.min(300, math.floor((tonumber(pagePaneH or 0) or 0) * 0.42)))
  if ImGui.BeginChild('gmm_pages_col', 220, pagePaneH, true) then
    if ImGui.Button('+ Page') then _addPage() end
    ImGui.SameLine()
    if ImGui.Button('- Page') then _deletePage() end
    ImGui.Separator()
    local pages = _currentPages(project)
    for i = 1, #pages do
      if ImGui.Selectable(tostring(pages[i].title or pages[i].id), i == Editor.state.selectedPageIndex) then
        Editor.state.selectedPageIndex = i
        Editor.state.selectedSubtabIndex = 1
        Editor.state.selectedGroupIndex = 1
        Editor.state.selectedWidgetIndex = 1
      end
    end
    ImGui.EndChild()
  end
  ImGui.SameLine()

  if ImGui.BeginChild('gmm_page_editor', 0, pagePaneH, true) then
    if page then
      ImGui.Text('Selected Page Setup')
      page.title = Utils.InputTextValue('Page Title', page.title or '', 128)
      local shell = tostring((((project or {}).layout or {}).shellMode) or 'Top Tabs')
      ImGui.TextWrapped('This page will render using the selected shell mode. Hybrid and Top Tabs can optionally use subtabs below the page level. Sidebar and Inventory Categories keep the page as the main container.')
      ImGui.Spacing()
      if shell == 'Hybrid' or shell == 'Top Tabs' then
        _drawHeader('Subtabs')
        if ImGui.Button('+ Subtab') then _addSubtab() end
        ImGui.SameLine()
        if ImGui.Button('- Subtab') then _deleteSubtab() end
        local subtabs = _currentSubtabs(page)
        if #subtabs > 0 then
          for i = 1, #subtabs do
            if ImGui.Selectable(tostring(subtabs[i].title or subtabs[i].id) .. '##subtab', i == Editor.state.selectedSubtabIndex) then
              Editor.state.selectedSubtabIndex = i
              Editor.state.selectedGroupIndex = 1
              Editor.state.selectedWidgetIndex = 1
            end
          end
          local sub = _currentSubtab(page)
          if sub then sub.title = Utils.InputTextValue('Selected Subtab Title', sub.title or '', 128) end
        else
          ImGui.TextDisabled('No subtabs yet. Add one if you want page-level subtabs like BFM.')
        end
      end

      _drawHeader('Groups')
      if ImGui.Button('+ Group') then _addGroup() end
      ImGui.SameLine()
      if ImGui.Button('- Group') then _deleteGroup() end
      local groups = _effectiveGroups(page)
      for i = 1, #groups do
        if ImGui.Selectable(tostring(groups[i].title or groups[i].id) .. '##group', i == Editor.state.selectedGroupIndex) then
          Editor.state.selectedGroupIndex = i
          Editor.state.selectedWidgetIndex = 1
        end
      end
      local group = _currentGroup()
      if group then group.title = Utils.InputTextValue('Selected Group Title', group.title or '', 128) end
    end
    ImGui.EndChild()
  end
end

local function _displayAssetType(assetType)
  local key = tostring(assetType or '')
  if key == 'observer_preset' then return 'condition_preset' end
  return key
end

local function _assetMode(asset)
  return tostring((((asset or {}).data or {}).mode) or 'button')
end

local function _widgetCanBindAsset(widgetType, asset)
  widgetType = tostring(widgetType or '')
  local assetType = tostring((asset or {}).type or '')
  if assetType == '' then return false end
  if widgetType == 'button' or widgetType == 'text' then return true end
  if widgetType == 'toggle' or widgetType == 'status' then
    if assetType == 'macro' or assetType == 'custom_code' or assetType == 'launcher' then
      return _assetMode(asset) == 'toggle'
    end
    return false
  end
  return false
end

local function _bindWidgetToAsset(widget, asset)
  if type(widget) ~= 'table' or type(asset) ~= 'table' then return false, 'Missing widget or asset.' end
  if not _widgetCanBindAsset(widget.type, asset) then
    return false, 'That widget type is not compatible with this saved asset.'
  end
  widget.assetId = asset.id
  widget.assetType = asset.type
  widget.embeddedAsset = _clone(asset)
  if widget.type == 'text' then widget.text = asset.name or asset.id else widget.label = asset.name or asset.id end
  return true
end

local function _widgetRuntimeKey(widget)
  return 'menu_widget:' .. tostring((widget or {}).id or 'widget')
end

local function _drawWidgetDesigner()
  local widget = _currentWidget()
  _drawInfoPanel('designer_widgets', 'Widget setup', 'Controls are now added from Bind Assets only. Use this area to organize and edit widgets that were created from real saved GTS assets.', 0.95, 0.70, 0.20)
  local _, widgetPaneH = _availRegion()
  widgetPaneH = math.max(210, math.min(320, math.floor((tonumber(widgetPaneH or 0) or 0) * 0.90)))
  if ImGui.BeginChild('gmm_widgets_left', 260, widgetPaneH, true) then
    ImGui.TextDisabled('Add widgets from Bind Assets.')
    if ImGui.Button('- Widget') then _deleteWidget() end
    ImGui.Separator()
    local widgets = _currentWidgets()
    for i = 1, #widgets do
      local w = widgets[i]
      local title = tostring(w.type or 'widget') .. ': ' .. tostring(w.label or w.text or w.id)
      if ImGui.Selectable(title, i == Editor.state.selectedWidgetIndex) then
        Editor.state.selectedWidgetIndex = i
      end
    end
    ImGui.EndChild()
  end
  ImGui.SameLine()

  if ImGui.BeginChild('gmm_widgets_right', 0, widgetPaneH, true) then
    if widget then
      ImGui.Text('Selected Widget Setup')
      widget.type = string.lower(Utils.BeginComboSelect('Widget Type', ({ button='Button', toggle='Toggle', text='Text', separator='Separator', status='Status' })[widget.type] or 'Button', WIDGET_OPTIONS))
      local resolvedAsset = select(1, Assets.ResolveEmbeddedAsset(widget.assetId, widget.embeddedAsset))
      if resolvedAsset and not _widgetCanBindAsset(widget.type, resolvedAsset) then
        widget.type = 'button'
      end
      widget.label = Utils.InputTextValue('Label', widget.label or '', 128)
      widget.help = Utils.InputTextValue('Help', widget.help or '', 256)
      widget.widthMode = Utils.BeginComboSelect('Width Mode', widget.widthMode or 'fill', { 'fill', 'auto', 'half' })

      if widget.type == 'text' then
        widget.text = Utils.InputTextValue('Text', widget.text or '', 256)
      end

      if widget.type ~= 'separator' and widget.type ~= 'text' then
        local selectedAssetName = '(none)'
        if tostring(widget.assetId or '') ~= '' then
          local asset = Assets.Get(widget.assetId)
          if asset then selectedAssetName = tostring(asset.name or asset.id) .. ' [' .. _displayAssetType(asset.type) .. ']' end
        end
        ImGui.TextWrapped('Bound Asset: ' .. selectedAssetName)
      end

      ImGui.Spacing()
      ImGui.TextWrapped('Widgets are created from Bind Assets. Each widget stores an embedded copy of the bound asset so the saved menu can still work later even if the original asset file is gone.')
    else
      ImGui.TextDisabled('No widget selected yet.')
    end
    ImGui.EndChild()
  end
end

local function _drawAssetSummary(asset)
  asset = asset or {}
  ImGui.Text('Type: ' .. tostring(_displayAssetType(asset.type) or '-'))
  ImGui.Text('ID: ' .. tostring(asset.id or '-'))
  if asset.createdAtText then ImGui.Text('Created: ' .. tostring(asset.createdAtText)) end
  if asset.updatedAtText then ImGui.Text('Updated: ' .. tostring(asset.updatedAtText)) end
  local data = asset.data or {}
  if tostring(asset.type or '') == 'rule' then
    local conds = 0
    if type(data.conditionGroups) == 'table' then
      for i = 1, #data.conditionGroups do
        local group = data.conditionGroups[i] or {}
        conds = conds + (type(group.conditions) == 'table' and #group.conditions or 0)
      end
    else
      conds = type(data.conditions) == 'table' and #data.conditions or 0
    end
    local acts = type(data.actionGroups) == 'table' and #data.actionGroups or (type(data.actions) == 'table' and #data.actions or 0)
    ImGui.Text('Conditions: ' .. tostring(conds))
    ImGui.Text('Action Groups: ' .. tostring(acts))
    if type(data.execution) == 'table' then
      ImGui.Text('Trigger: ' .. tostring(data.execution.triggerMode or '-'))
      ImGui.Text('Cadence: ' .. tostring(data.execution.cadence or '-'))
    end
  elseif tostring(asset.type or '') == 'macro' then
    ImGui.Text('Mode: ' .. tostring((data.mode or 'button')))
    ImGui.Text('On Groups: ' .. tostring(type(data.onActionGroups) == 'table' and #data.onActionGroups or 0))
    ImGui.Text('Off Groups: ' .. tostring(type(data.offActionGroups) == 'table' and #data.offActionGroups or 0))
  elseif tostring(asset.type or '') == 'launcher' then
    ImGui.Text('Entries: ' .. tostring(type(data.entries) == 'table' and #data.entries or 0))
    ImGui.Text('Mode: ' .. tostring(data.mode or 'button'))
  elseif tostring(asset.type or '') == 'custom_code' then
    ImGui.Text('Mode: ' .. tostring(data.mode or 'button'))
  elseif tostring(asset.type or '') == 'teleport_preset' then
    ImGui.Text('XYZ: ' .. tostring(data.x or 0) .. ', ' .. tostring(data.y or 0) .. ', ' .. tostring(data.z or 0))
  end
end

local function _matchesAssetFilter(asset)
  if not asset then return false end
  local wantedType = tostring(Editor.state.assetTypeFilter or '')
  if wantedType == 'condition_preset' then wantedType = 'observer_preset' end
  if wantedType ~= 'All' and tostring(asset.type or '') ~= wantedType then return false end
  local needle = string.lower(tostring(Editor.state.assetSearch or ''))
  if needle == '' then return true end
  local hay = string.lower(tostring(asset.name or '') .. ' ' .. tostring(asset.id or '') .. ' ' .. tostring(asset.type or ''))
  return hay:find(needle, 1, true) ~= nil
end

local function _drawAssetsTab()
  _drawInfoPanel('assets_intro', 'Bind saved GTS assets to the menu', 'This tab shows the real macros, rules, scripts, teleports, launchers, and presets already saved in GTS. Pick one, inspect it, then either create a widget from it or bind it to the widget you already selected in Build Menu.', 0.25, 0.85, 0.60)
  if ImGui.BeginChild('gmm_assets_left', 360, 0, true) then
    ImGui.TextUnformatted(type(IconGlyphs)=="table" and (_glyphFromKeys and _glyphFromKeys({"Magnify","Search"},"?") or "?") or "?")
    ImGui.SameLine()
    Editor.state.assetSearch = Utils.InputTextValue('##menu_asset_search', Editor.state.assetSearch or '', 128)
    Editor.state.assetTypeFilter = Utils.BeginComboSelect('Asset Type', Editor.state.assetTypeFilter or 'All', ASSET_TYPES)
    if ImGui.Button('Reload From Disk') then _refreshAssets(true) end
    ImGui.Separator()
    local assets = Assets.List()
    for i = 1, #assets do
      local asset = assets[i]
      if _matchesAssetFilter(asset) then
        local title = tostring(asset.name or asset.id) .. ' [' .. _displayAssetType(asset.type) .. ']'
        if ImGui.Selectable(title, Editor.state.selectedAssetId == asset.id) then
          Editor.state.selectedAssetId = asset.id
        end
      end
    end
    ImGui.EndChild()
  end
  ImGui.SameLine()

  if ImGui.BeginChild('gmm_assets_right', 0, 0, true) then
    local asset = Assets.Get(Editor.state.selectedAssetId)
    if asset then
      ImGui.Text(tostring(asset.name or asset.id))
      _drawAssetSummary(asset)
      ImGui.Spacing()
      if ImGui.Button('Create Button Widget From Asset') then _addWidget('Button', asset) end
      ImGui.SameLine()
      if _widgetCanBindAsset('toggle', asset) then
        if ImGui.Button('Create Toggle Widget From Asset') then _addWidget('Toggle', asset) end
      else
        if ImGui.BeginDisabled then ImGui.BeginDisabled() end
        ImGui.Button('Create Toggle Widget From Asset')
        if ImGui.EndDisabled then ImGui.EndDisabled() end
      end
      ImGui.SameLine()
      if _widgetCanBindAsset('status', asset) then
        if ImGui.Button('Create Status Widget From Asset') then _addWidget('Status', asset) end
      else
        if ImGui.BeginDisabled then ImGui.BeginDisabled() end
        ImGui.Button('Create Status Widget From Asset')
        if ImGui.EndDisabled then ImGui.EndDisabled() end
      end
      if ImGui.Button('Create Text Widget From Asset') then _addWidget('Text', asset) end
      ImGui.SameLine()
      if ImGui.Button('Run Asset Now') then
        local ok, msg = Assets.RunAsset(asset.id)
        Editor.state.lastMessage = ok and ('Ran ' .. tostring(asset.name or asset.id)) or tostring(msg)
      end

      local widget = _currentWidget()
      if widget then
        ImGui.Spacing()
        if ImGui.Button('Bind Selected Widget To Asset') then
          local okBind, bindMsg = _bindWidgetToAsset(widget, asset)
          Editor.state.lastMessage = okBind and ('Bound selected widget to ' .. tostring(asset.name or asset.id)) or tostring(bindMsg)
        end
      end
    else
      ImGui.TextDisabled('Select a saved GTS asset to inspect it here.')
      ImGui.TextWrapped('These are the same saved GTS assets you already use elsewhere in the mod. Pick one here, then bind it to a button, toggle, text block, or status widget in your menu project.')
    end
    ImGui.EndChild()
  end
end

local function _withPreviewLayout(project, drawFn)
  project = project or {}
  local layout = project.layout or _defaultLayout()
  project.layout = layout
  if type(drawFn) == 'function' then drawFn(nil, layout) end
end


local function _drawWidget(widget)
  if not widget then return end

  if widget.type == 'button' then
    if widget.widthMode == 'fill' and type(ImGui.SetNextItemWidth) == 'function' then ImGui.SetNextItemWidth(-1) end
    local clicked = ImGui.Button(tostring(widget.label or 'Button'))
    if clicked and (tostring(widget.assetId or '') ~= '' or type(widget.embeddedAsset) == 'table') then
      local ok, msg = Assets.RunResolvedAsset(widget.assetId, widget.embeddedAsset, nil, _widgetRuntimeKey(widget))
      Editor.state.lastMessage = ok and ('Ran ' .. tostring(widget.label or widget.assetId)) or tostring(msg)
    end
  elseif widget.type == 'toggle' then
    local current = Assets.IsResolvedAssetEnabled(widget.assetId, widget.embeddedAsset, _widgetRuntimeKey(widget))
    local newValue = Utils.CheckboxValue(tostring(widget.label or 'Toggle'), current)
    if newValue ~= current and (tostring(widget.assetId or '') ~= '' or type(widget.embeddedAsset) == 'table') then
      local ok, msg = Assets.RunResolvedAsset(widget.assetId, widget.embeddedAsset, newValue, _widgetRuntimeKey(widget))
      Editor.state.lastMessage = ok and ('Set ' .. tostring(widget.label or widget.assetId) .. ' to ' .. tostring(newValue)) or tostring(msg)
    end
  elseif widget.type == 'text' then
    ImGui.TextWrapped(tostring(widget.text or widget.label or 'Text'))
  elseif widget.type == 'separator' then
    ImGui.Separator()
  elseif widget.type == 'status' then
    local enabled = Assets.IsResolvedAssetEnabled(widget.assetId, widget.embeddedAsset, _widgetRuntimeKey(widget))
    ImGui.Text(tostring(widget.label or 'Status') .. ': ' .. (enabled and 'ON' or 'OFF'))
  else
    ImGui.TextWrapped(tostring(widget.label or widget.id or 'Widget'))
  end

  if tostring(widget.help or '') ~= '' then ImGui.TextDisabled(tostring(widget.help)) end
end

local function _drawGroup(group)
  if not group then return end

  local headerOpen = true
  if type(ImGui.CollapsingHeader) == 'function' then
    local flags = (ImGuiTreeNodeFlags and ImGuiTreeNodeFlags.DefaultOpen) or 32
    headerOpen = ImGui.CollapsingHeader(tostring(group.title or 'Group') .. '##grp_header_' .. tostring(group.id or ''), flags)
  else
    ImGui.Text(tostring(group.title or 'Group'))
  end

  if not headerOpen then return end

  if ImGui.BeginChild('grp_' .. tostring(group.id), 0, 150, true) then
    local widgets = type(group.widgets) == 'table' and group.widgets or {}
    if #widgets == 0 then
      ImGui.TextDisabled('No widgets in this group yet. Add them from Bind Assets.')
    end
    for i = 1, #widgets do _drawWidget(widgets[i]) end
    ImGui.EndChild()
  end
end

local function _drawPageContent(page)
  local project = _currentProject()
  if not page then return end
  local shell = tostring((((project or {}).layout or {}).shellMode) or 'Top Tabs')
  local spacing = tonumber(((((project or {}).layout) or {}).sectionSpacing) or 8) or 8
  local subtabs = _currentSubtabs(page)
  if (shell == 'Top Tabs') and #subtabs > 0 then
    if ImGui.BeginTabBar('preview_subtabs_' .. tostring(page.id)) then
      for i = 1, #subtabs do
        local sub = subtabs[i]
        if ImGui.BeginTabItem(tostring(sub.title or sub.id)) then
          Editor.state.previewSubtabIndex = i
          local groups = type(sub.groups) == 'table' and sub.groups or {}
          for g = 1, #groups do
            _drawGroup(groups[g])
            if g < #groups then ImGui.Dummy(1, spacing) end
          end
          ImGui.EndTabItem()
        end
      end
      ImGui.EndTabBar()
    end
  else
    local groups = type(page.groups) == 'table' and page.groups or {}
    for i = 1, #groups do
      _drawGroup(groups[i])
      if i < #groups then ImGui.Dummy(1, spacing) end
    end
  end
end

local function _drawPreviewInner(layout)
  local project = _currentProject()
  if not project then return end
  local pages = _currentPages(project)
  local shell = tostring(layout.shellMode or 'Top Tabs')

  if layout.showHeader ~= false then
    ImGui.Text(tostring(project.name or 'Menu Project'))
    ImGui.Separator()
  end

  if #pages == 0 then
    ImGui.TextDisabled('No pages yet. Add a page in Build Menu to start laying out the menu.')
    return
  end

  if shell == 'Top Tabs' then
    if ImGui.BeginTabBar('preview_pages') then
      for i = 1, #pages do
        local page = pages[i]
        local label = tostring(page.title or page.id)
        if layout.showPageCounts then label = label .. '##' .. tostring(i) end
        if ImGui.BeginTabItem(label) then
          Editor.state.previewPageIndex = i
          _drawPageContent(page, nil)
          ImGui.EndTabItem()
        end
      end
      ImGui.EndTabBar()
    end
  else
    local sideW = tonumber(layout.sidebarWidth or 220) or 220
    local buttonH = tonumber(layout.pageButtonHeight or 28) or 28
    if ImGui.BeginChild('preview_sidebar', sideW, 0, true) then
      for i = 1, #pages do
        local label = tostring(pages[i].title or pages[i].id)
        if ImGui.Button(label, sideW - 18, buttonH) then Editor.state.previewPageIndex = i end
      end
      ImGui.EndChild()
    end
    ImGui.SameLine()
    if ImGui.BeginChild('preview_content', 0, 0, true) then
      _drawPageContent(pages[math.max(1, math.min(#pages, Editor.state.previewPageIndex or 1))], nil)
      ImGui.EndChild()
    end
  end
end

local function _previewWindowTitle(project)
  project = project or {}
  local name = tostring(project.name or 'Menu Project')
  local token = Utils.SafeToken(project.id or name)
  return 'Menu Preview - ' .. name .. '##gmm_preview_window_' .. token
end

local function _drawPreviewWindow()
  local project = _currentProject()
  if not project or Editor.state.previewOpen == false then return end
  local layout = project.layout or _defaultLayout()
  project.layout = layout
  local width = tonumber(layout.windowWidth or 1080) or 1080
  local height = tonumber(layout.windowHeight or 700) or 700

  if type(ImGui.SetNextWindowSize) == 'function' then
    ImGui.SetNextWindowSize(width, height, ImGuiCond.FirstUseEver)
  end

  _withPreviewLayout(project, function(_unused, previewLayout)
    local draw = ImGui.Begin(_previewWindowTitle(project))

    if draw then
      if type(ImGui.GetWindowSize) == 'function' then
        local ok, a, b = pcall(ImGui.GetWindowSize)
        if ok then
          if type(a) == 'table' then
            layout.windowWidth = math.max(420, math.floor(tonumber(a.x or a[1] or layout.windowWidth or 1080) or 1080))
            layout.windowHeight = math.max(320, math.floor(tonumber(a.y or a[2] or layout.windowHeight or 700) or 700))
          else
            layout.windowWidth = math.max(420, math.floor(tonumber(a or layout.windowWidth or 1080) or 1080))
            layout.windowHeight = math.max(320, math.floor(tonumber(b or layout.windowHeight or 700) or 700))
          end
        end
      end
      if type(ImGui.SmallButton) == 'function' and ImGui.SmallButton('Hide Preview Window##gmm_hide_preview_window') then
        Editor.state.previewOpen = false
      end
      ImGui.SameLine()
      ImGui.TextDisabled('Live menu window. Designer and Asset changes appear here immediately.')
      ImGui.Separator()
      _drawPreviewInner(previewLayout or layout)
    end
    ImGui.End()
  end)
end

local function _drawPreviewTab()
  local project = _currentProject()
  if not project then return end
  _drawInfoPanel('preview_intro', 'Test the finished menu here', 'The preview is a real separate window now. Leave it open while you edit so you can see live changes to pages, widgets, shell mode, and asset bindings as you build.', 0.30, 0.90, 0.90)
  local layout = project.layout or _defaultLayout()
  project.layout = layout

  ImGui.TextWrapped('Preview now renders as its own live window instead of an embedded tab pane.')
  ImGui.Spacing()
  if Editor.state.previewOpen == true then
    ImGui.TextColored(0.20, 0.80, 0.35, 1.00, 'Preview Window: OPEN')
    if type(ImGui.SmallButton) == 'function' and ImGui.SmallButton('Hide Preview Window##gmm_hide_preview_window_tab') then
      Editor.state.previewOpen = false
    end
  else
    ImGui.TextColored(0.90, 0.70, 0.20, 1.00, 'Preview Window: HIDDEN')
    if type(ImGui.SmallButton) == 'function' and ImGui.SmallButton('Open Preview Window##gmm_open_preview_window_tab') then
      Editor.state.previewOpen = true
    end
  end

  ImGui.Spacing()
  ImGui.TextWrapped('Anything you change in Projects, Build Menu, or Assets is reflected in the live preview window. Resize that window directly by dragging its edges or corners.')
  ImGui.Separator()
  ImGui.Text('Current Project: ' .. tostring(project.name or 'Menu Project'))
  ImGui.Text('Window Size: ' .. tostring(layout.windowWidth or 1080) .. ' x ' .. tostring(layout.windowHeight or 700) .. ' (drag to resize)')
  ImGui.Text('Shell Mode: ' .. tostring(layout.shellMode or 'Top Tabs'))
  ImGui.TextWrapped('Add pages, groups, widgets, and asset-bound controls in Designer/Assets and watch them update live in the separate preview window.')
end

function Editor.OnInit()
  local projects = Store.LoadProjects()
  if type(projects) == 'table' and #projects > 0 then
    Editor.state.projects = projects
    for i = 1, #projects do
      projects[i].layout = projects[i].layout or _defaultLayout()
      local pid = tostring(projects[i].id or ''):match('_(%d+)$')
      pid = tonumber(pid)
      if pid and pid >= (Editor.state.nextProjectId or 1) then Editor.state.nextProjectId = pid + 1 end
    end
  else
    Editor.state.projects = { _newProject('New Menu Project') }
  end
  _refreshAssets(false)
  _ensureSelectionBounds()
end

function Editor.OnUpdate(_)
end

function Editor.DrawWindows(_)
  _drawPreviewWindow()
end

function Editor.DrawTab()
  _ensureSelectionBounds()

  local project = _currentProject()
  _drawInfoPanel('top_intro', 'Menu Maker Workflow', 'Move left to right: create a project, choose the shell style, build pages and widgets, bind saved GTS assets, then watch the result in the live preview window.', 0.98, 0.86, 0.20)
  if project then
    ImGui.Text('Current Project: ' .. tostring(project.name or project.id or 'Menu Project'))
    _drawProjectStats(project)
    ImGui.Spacing()
  end

  if ImGui.BeginTabBar('gmm_root_tabs') then
    if ImGui.BeginTabItem(ROOT_TAB_LABELS.projects) then
      Editor.state.activeRootTab = 'Projects'
      _drawProjectSelector()
      ImGui.SameLine()
      if ImGui.BeginChild('gmm_project_inspector', 0, 0, true) then
        _drawProjectInspector()
        ImGui.EndChild()
      end
      ImGui.EndTabItem()
    end

    if ImGui.BeginTabItem(ROOT_TAB_LABELS.designer) then
      Editor.state.activeRootTab = 'Designer'
      _drawPagesDesigner()
      ImGui.Separator()
      _drawWidgetDesigner()
      ImGui.EndTabItem()
    end


    if ImGui.BeginTabItem(ROOT_TAB_LABELS.assets) then
      Editor.state.activeRootTab = 'Assets'
      _drawAssetsTab()
      ImGui.EndTabItem()
    end

    if ImGui.BeginTabItem(ROOT_TAB_LABELS.preview) then
      Editor.state.activeRootTab = 'Preview'
      _drawPreviewTab()
      ImGui.EndTabItem()
    end

    ImGui.EndTabBar()
  end

  ImGui.Spacing()
  ImGui.TextWrapped('Status: ' .. tostring(Editor.state.lastMessage or '-'))
end

return Editor
