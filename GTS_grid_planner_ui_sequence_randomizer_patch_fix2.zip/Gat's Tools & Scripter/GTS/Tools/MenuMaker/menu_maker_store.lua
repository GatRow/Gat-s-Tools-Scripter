local Utils = require("GTS/Tools/MenuMaker/menu_maker_utils")
local Persistence = require("GTS/Core/persistence")
local AssetRegistry = require("GTS/Core/asset_registry")

local Store = Store or {}
Store.state = Store.state or {
  lastError = nil,
  lastSavePath = nil,
  lastLoadPath = nil,
}

local function _quote(s)
  return string.format('%q', tostring(s or ''))
end

local function _clone(value, seen)
  if type(value) ~= 'table' then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do out[_clone(k, seen)] = _clone(v, seen) end
  return out
end

local function _embedMenuProjectAssets(project)
  project = _clone(project)
  local schema = type(project.schema) == 'table' and project.schema or {}
  project.schema = schema

  local function touchWidget(widget)
    if type(widget) ~= 'table' then return end
    local ref = tostring(widget.assetId or '')
    if ref ~= '' then
      local asset = AssetRegistry.Get and AssetRegistry.Get(ref) or nil
      if type(asset) == 'table' then
        widget.embeddedAsset = _clone(asset)
      elseif type(widget.embeddedAsset) ~= 'table' then
        widget.embeddedAsset = nil
      end
    end
  end

  local function walkGroups(groups)
    groups = type(groups) == 'table' and groups or {}
    for i = 1, #groups do
      local g = groups[i]
      local widgets = type((g or {}).widgets) == 'table' and g.widgets or {}
      for wi = 1, #widgets do
        touchWidget(widgets[wi])
      end
    end
  end

  local pages = type(schema.pages) == 'table' and schema.pages or {}
  for i = 1, #pages do
    local page = pages[i]
    walkGroups(page and page.groups)
    local subtabs = type((page or {}).subtabs) == 'table' and page.subtabs or {}
    for si = 1, #subtabs do
      walkGroups((subtabs[si] or {}).groups)
    end
  end
  return project
end

local function _sanitize(v, seen, depth)
  seen = seen or {}
  depth = depth or 0
  local tv = type(v)
  if tv ~= 'nil' and tv ~= 'number' and tv ~= 'string' and tv ~= 'boolean' and tv ~= 'table' then return nil end
  if tv ~= 'table' then return v end
  if seen[v] then return nil end
  if depth > 32 then return nil end
  seen[v] = true
  local out = {}
  for k, vv in pairs(v) do
    local tk = type(k)
    if tk == 'string' or tk == 'number' then
      local sv = _sanitize(vv, seen, depth + 1)
      if sv ~= nil then out[k] = sv end
    end
  end
  seen[v] = nil
  return out
end

local function _isArray(t)
  if type(t) ~= 'table' then return false end
  local n = 0
  for k, _ in pairs(t) do
    if type(k) ~= 'number' or k < 1 or math.floor(k) ~= k then return false end
    if k > n then n = k end
  end
  return true, n
end

local function _serializeLua(value, indent, seen)
  indent = indent or 0
  seen = seen or {}
  local tv = type(value)
  if tv == 'nil' then return 'nil' end
  if tv == 'number' then return tostring(value) end
  if tv == 'boolean' then return value and 'true' or 'false' end
  if tv == 'string' then return _quote(value) end
  if tv ~= 'table' then return 'nil' end
  if seen[value] then return 'nil' end
  seen[value] = true
  local pad = string.rep('  ', indent)
  local child = string.rep('  ', indent + 1)
  local arr, n = _isArray(value)
  local out = {'{'}
  if arr then
    for i = 1, n do out[#out + 1] = child .. _serializeLua(value[i], indent + 1, seen) .. ',' end
  else
    local keys = {}
    for k in pairs(value) do keys[#keys + 1] = k end
    table.sort(keys, function(a, b)
      local ta, tb = type(a), type(b)
      if ta ~= tb then return tostring(ta) < tostring(tb) end
      if ta == 'number' then return a < b end
      return tostring(a) < tostring(b)
    end)
    for _, k in ipairs(keys) do
      local keyText
      if type(k) == 'string' and k:match('^[_%a][_%w]*$') then keyText = k else keyText = '[' .. _serializeLua(k, indent + 1, seen) .. ']' end
      out[#out + 1] = child .. keyText .. ' = ' .. _serializeLua(value[k], indent + 1, seen) .. ','
    end
  end
  out[#out + 1] = pad .. '}'
  seen[value] = nil
  return table.concat(out, '\n')
end

local function _jsonString(s)
  s = tostring(s or '')
  s = s:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', '\\n'):gsub('\r', '\\r'):gsub('\t', '\\t')
  return '"' .. s .. '"'
end

local function _serializeJson(value, seen)
  seen = seen or {}
  local tv = type(value)
  if tv == 'nil' then return 'null' end
  if tv == 'number' then return tostring(value) end
  if tv == 'boolean' then return value and 'true' or 'false' end
  if tv == 'string' then return _jsonString(value) end
  if tv ~= 'table' then return 'null' end
  if seen[value] then return 'null' end
  seen[value] = true
  local arr, n = _isArray(value)
  local out = {}
  if arr then
    for i = 1, n do out[#out + 1] = _serializeJson(value[i], seen) end
    seen[value] = nil
    return '[' .. table.concat(out, ',') .. ']'
  end
  local keys = {}
  for k in pairs(value) do keys[#keys + 1] = k end
  table.sort(keys, function(a, b)
    local ta, tb = type(a), type(b)
    if ta ~= tb then return tostring(ta) < tostring(tb) end
    if ta == 'number' then return a < b end
    return tostring(a) < tostring(b)
  end)
  for _, k in ipairs(keys) do out[#out + 1] = _jsonString(k) .. ':' .. _serializeJson(value[k], seen) end
  seen[value] = nil
  return '{' .. table.concat(out, ',') .. '}'
end

local function _ensureDir(path)
  local dir = Utils.NormalizePath(path)
  if dir == '' or not io or not io.open then return false end

  local probe = io.open(dir .. '/.probe', 'w')
  if probe then
    probe:close()
    if os and os.remove then os.remove(dir .. '/.probe') end
    return true
  end

  local acc = ''
  local first = true
  for part in string.gmatch(dir, '[^/]+') do
    if first and part:match('^[A-Za-z]:$') then
      acc = part
      first = false
    else
      if acc == '' then acc = part else acc = acc .. '/' .. part end
      local test = io.open(acc .. '/.probe', 'w')
      if test then
        test:close()
        if os and os.remove then os.remove(acc .. '/.probe') end
      elseif os and os.execute then
        os.execute('mkdir "' .. acc:gsub('/', '\\\\') .. '" >nul 2>nul')
        os.execute('mkdir -p "' .. acc .. '" >/dev/null 2>/dev/null')
      end
      first = false
    end
  end

  probe = io.open(dir .. '/.probe', 'w')
  if probe then
    probe:close()
    if os and os.remove then os.remove(dir .. '/.probe') end
    return true
  end
  return false
end

local function _readLuaTable(path)
  local loader, err = loadfile(path)
  if not loader then return nil, tostring(err or ('Failed to load ' .. tostring(path))) end
  local ok, data = pcall(loader)
  if not ok or type(data) ~= 'table' then return nil, tostring(data or ('File did not return a table: ' .. tostring(path))) end
  return data, nil
end

local function _writePair(stem, payload, header)
  local safePayload = _sanitize(payload) or {}
  local dir = Utils.Dirname(stem)
  if not _ensureDir(dir) then return false, 'Could not create folder: ' .. tostring(dir) end

  local luaPath = Utils.NormalizePath(stem) .. '.lua'
  local jsonPath = Utils.NormalizePath(stem) .. '.json'

  local fh, err = io.open(luaPath, 'w+')
  if not fh then return false, tostring(err or ('Failed to open ' .. luaPath)) end
  if header and header ~= '' then fh:write('-- ' .. tostring(header) .. '\n') end
  if os and os.date then fh:write('-- ' .. os.date('%Y-%m-%d %H:%M:%S') .. '\n\n') end
  fh:write('return ')
  fh:write(_serializeLua(safePayload, 0, {}))
  fh:write('\n')
  fh:close()

  local jh = io.open(jsonPath, 'w+')
  if jh then
    jh:write(_serializeJson(safePayload, {}))
    jh:write('\n')
    jh:close()
  end
  return true, luaPath
end

local function _deletePair(stem)
  local ok = false
  if os and os.remove then
    if os.remove(stem .. '.lua') then ok = true end
    if os.remove(stem .. '.json') then ok = true end
  end
  return ok
end

local function _userDir()
  return Utils.NormalizePath((Persistence.GetUserDir and Persistence.GetUserDir()) or './mods/Gat\'s Tools & Scripter/User')
end

local function _projectRoot(baseDir)
  return Utils.NormalizePath(baseDir) .. '/menu_projects'
end

local function _projectDir(baseDir, projectId)
  return _projectRoot(baseDir) .. '/' .. Utils.SafeToken(projectId)
end

local function _projectStem(baseDir, projectId, name)
  return _projectDir(baseDir, projectId) .. '/' .. tostring(name)
end

local function _indexStem(baseDir)
  return _projectRoot(baseDir) .. '/index'
end

local function _projectSummary(project)
  return {
    id = tostring(project and project.id or ''),
    name = tostring(project and project.name or ''),
    updatedAtText = project and project.updatedAtText or nil,
    file = 'menu_projects/' .. Utils.SafeToken(project and project.id or 'project') .. '/project.lua',
  }
end

local function _writeIndex(baseDir, summaries)
  return _writePair(_indexStem(baseDir), { version = 1, projects = summaries or {} }, 'GTS Menu Maker project index (auto)')
end

local function _loadIndex(baseDir)
  local path = _indexStem(baseDir) .. '.lua'
  local data = _readLuaTable(path)
  if type(data) == 'table' then return type(data.projects) == 'table' and data.projects or {} end
  return {}
end

local function _loadProjectFromBaseDir(baseDir, projectId)
  local proj = _readLuaTable(_projectStem(baseDir, projectId, 'project') .. '.lua')
  if type(proj) ~= 'table' then return nil end
  local schema = _readLuaTable(_projectStem(baseDir, projectId, 'schema') .. '.lua')
  proj.schema = (type(schema) == 'table' and schema) or proj.schema or {}
  return proj
end

function Store.GetUserDir()
  return _userDir()
end

function Store.LoadProjects()
  local dir = _userDir()
  local index = _loadIndex(dir)
  if type(index) ~= 'table' or #index == 0 then
    Store.state.lastError = 'No saved menu projects yet.'
    return {}, Store.state.lastError
  end
  local out = {}
  for i = 1, #index do
    local summary = index[i]
    local project = _loadProjectFromBaseDir(dir, summary.id)
    if type(project) == 'table' then out[#out + 1] = project end
  end
  Store.state.lastLoadPath = _projectRoot(dir)
  Store.state.lastError = nil
  return out, nil
end

function Store.SaveProject(project, allProjects)
  if type(project) ~= 'table' then return false, 'Missing project' end
  local dir = _userDir()
  if not _ensureDir(_projectRoot(dir)) then
    Store.state.lastError = 'Could not create menu_projects folder in User directory'
    return false, Store.state.lastError
  end

  local packed = _embedMenuProjectAssets(project)
  packed.updatedAtText = Utils.NowText()
  if packed.createdAtText == nil then packed.createdAtText = packed.updatedAtText end
  project.updatedAtText = packed.updatedAtText
  if project.createdAtText == nil then project.createdAtText = packed.createdAtText end

  local ok1, err1 = _writePair(_projectStem(dir, packed.id, 'project'), {
    version = 2,
    id = packed.id,
    name = packed.name,
    createdAtText = packed.createdAtText,
    updatedAtText = packed.updatedAtText,
    layout = _sanitize(packed.layout) or {},
  }, 'GTS Menu Maker project meta (auto)')

  local ok2, err2 = _writePair(_projectStem(dir, packed.id, 'schema'), _sanitize(packed.schema) or {}, 'GTS Menu Maker project schema (auto)')

  local summaries = {}
  if type(allProjects) == 'table' then
    for i = 1, #allProjects do
      local p = allProjects[i]
      if type(p) == 'table' then summaries[#summaries + 1] = _projectSummary(p) end
    end
  else
    summaries[1] = _projectSummary(project)
  end
  local ok3, err3 = _writeIndex(dir, summaries)

  if ok1 and ok2 and ok3 then
    Store.state.lastSavePath = _projectDir(dir, project.id)
    Store.state.lastError = nil
    return true, Store.state.lastSavePath
  end

  Store.state.lastError = tostring(err1 or err2 or err3)
  return false, Store.state.lastError
end

function Store.DeleteProject(projectId, allProjects)
  if tostring(projectId or '') == '' then return false, 'Missing project id' end
  local dir = _userDir()
  _deletePair(_projectStem(dir, projectId, 'project'))
  _deletePair(_projectStem(dir, projectId, 'schema'))

  local summaries = {}
  if type(allProjects) == 'table' then
    for i = 1, #allProjects do
      local p = allProjects[i]
      if type(p) == 'table' and tostring(p.id or '') ~= tostring(projectId) then summaries[#summaries + 1] = _projectSummary(p) end
    end
  end
  local ok, err = _writeIndex(dir, summaries)
  if not ok then
    Store.state.lastError = err
    return false, err
  end
  Store.state.lastError = nil
  return true, _projectRoot(dir)
end

function Store.GetInfo()
  return {
    userDir = Store.GetUserDir(),
    lastError = Store.state.lastError,
    lastSavePath = Store.state.lastSavePath,
    lastLoadPath = Store.state.lastLoadPath,
  }
end

return Store
