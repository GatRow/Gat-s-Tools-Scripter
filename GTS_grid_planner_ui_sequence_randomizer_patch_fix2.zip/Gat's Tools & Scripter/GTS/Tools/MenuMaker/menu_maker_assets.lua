local AssetRegistry = require("GTS/Core/asset_registry")
local RuleRunner = require("GTS/Builders/rule_runner")

local Assets = Assets or {}

local function _clone(value, seen)
  if type(value) ~= 'table' then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do out[_clone(k, seen)] = _clone(v, seen) end
  return out
end

function Assets.List(assetType)
  if type(AssetRegistry.ListCreatedAssets) == 'function' and assetType == nil then
    return AssetRegistry.ListCreatedAssets()
  end
  return AssetRegistry.List(assetType)
end

function Assets.Get(assetId)
  return AssetRegistry.Get(assetId)
end

function Assets.ReloadFromDisk()
  if type(AssetRegistry.ReloadFromDisk) == 'function' then
    return AssetRegistry.ReloadFromDisk()
  end
  return false, 'Reload not available.'
end

function Assets.ResolveEmbeddedAsset(assetId, embeddedAsset)
  local asset = nil
  if tostring(assetId or '') ~= '' then asset = AssetRegistry.Get(assetId) end
  if type(asset) == 'table' then return asset, false end
  if type(embeddedAsset) == 'table' then return _clone(embeddedAsset), true end
  return nil, false
end

function Assets.RunResolvedAsset(assetId, embeddedAsset, desiredState, runtimeKey)
  local asset = nil
  if tostring(assetId or '') ~= '' then asset = AssetRegistry.Get(assetId) end
  if type(asset) == 'table' and type(RuleRunner.RunCreatedAssetById) == 'function' then
    local ok, success, msg = pcall(RuleRunner.RunCreatedAssetById, tostring(assetId or ''), desiredState)
    if ok then return success == true, msg end
    return false, tostring(success)
  end
  if type(embeddedAsset) == 'table' and type(RuleRunner.RunCreatedAssetDraft) == 'function' then
    local key = tostring(runtimeKey or assetId or ((embeddedAsset or {}).id) or 'menu_embedded_asset')
    local ok, success, msg = pcall(RuleRunner.RunCreatedAssetDraft, _clone(embeddedAsset), desiredState, key)
    if ok then return success == true, msg end
    return false, tostring(success)
  end
  return false, 'Saved asset is missing and no embedded menu copy is available.'
end

function Assets.RunAsset(assetId, desiredState)
  return Assets.RunResolvedAsset(assetId, nil, desiredState, tostring(assetId or 'menu_asset'))
end

function Assets.IsResolvedAssetEnabled(assetId, embeddedAsset, runtimeKey)
  if type(RuleRunner.IsCreatedAssetEnabled) ~= 'function' then return false end
  if tostring(assetId or '') ~= '' and AssetRegistry.Get(assetId) ~= nil then
    local ok, result = pcall(RuleRunner.IsCreatedAssetEnabled, tostring(assetId or ''))
    if ok then return result == true end
  end
  if type(embeddedAsset) == 'table' then
    local ok, result = pcall(RuleRunner.IsCreatedAssetEnabled, tostring(runtimeKey or ((embeddedAsset or {}).id) or 'menu_embedded_asset'))
    if ok then return result == true end
  end
  return false
end

function Assets.IsAssetEnabled(assetId)
  return Assets.IsResolvedAssetEnabled(assetId, nil, tostring(assetId or ''))
end

function Assets.GetInfo()
  local info = AssetRegistry.GetPersistenceInfo and AssetRegistry.GetPersistenceInfo() or {}
  return {
    source = 'GTS asset registry',
    total = #(AssetRegistry.ListCreatedAssets and AssetRegistry.ListCreatedAssets() or AssetRegistry.List() or {}),
    userDir = info.userDir,
    lastLoadAt = info.lastLoadAt,
    lastSaveAt = info.lastSaveAt,
    lastError = info.lastError,
  }
end

return Assets
