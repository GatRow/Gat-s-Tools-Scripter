local Utils = Utils or {}

function Utils.Clone(value, seen)
  if type(value) ~= "table" then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do
    out[Utils.Clone(k, seen)] = Utils.Clone(v, seen)
  end
  return out
end

function Utils.NowText()
  if os and os.date then return os.date("%Y-%m-%d %H:%M:%S") end
  return "-"
end

function Utils.SafeToken(text)
  local s = tostring(text or "")
  s = s:gsub('[\\/:*?"<>|]', '_')
  s = s:gsub('%s+', '_')
  s = s:gsub('[^%w%._%-]', '_')
  s = s:gsub('_+', '_')
  s = s:gsub('^_+', ''):gsub('_+$', '')
  if s == '' then s = 'item' end
  return s
end

function Utils.NormalizePath(path)
  return tostring(path or ''):gsub('\\', '/')
end

function Utils.Dirname(path)
  local p = Utils.NormalizePath(path)
  return p:match('^(.*)/[^/]+$') or p
end

function Utils.InputTextValue(label, value, bufSize, flags)
  value = tostring(value or "")
  local a, b
  if flags ~= nil then
    a, b = ImGui.InputText(label, value, bufSize or 256, flags)
  else
    a, b = ImGui.InputText(label, value, bufSize or 256)
  end
  if type(a) == "boolean" and type(b) == "string" then return b end
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return value
end

function Utils.InputIntValue(label, value, step, fast)
  local a, b = ImGui.InputInt(label, math.floor(tonumber(value or 0) or 0), step or 1, fast or 10)
  if type(a) == "boolean" and type(b) == "number" then return math.floor(b) end
  if type(a) == "number" then return math.floor(a) end
  if type(b) == "number" then return math.floor(b) end
  return math.floor(tonumber(value or 0) or 0)
end

function Utils.InputFloatValue(label, value, step, fast, fmt)
  if type(ImGui.InputFloat) == "function" then
    local a, b = ImGui.InputFloat(label, tonumber(value or 0) or 0, step or 0.05, fast or 0.25, fmt or "%.2f")
    if type(a) == "boolean" and type(b) == "number" then return b end
    if type(a) == "number" then return a end
    if type(b) == "number" then return b end
  end
  return tonumber(value or 0) or 0
end

function Utils.SliderFloatValue(label, value, minv, maxv, fmt)
  if type(ImGui.SliderFloat) == "function" then
    local a, b = ImGui.SliderFloat(label, tonumber(value or minv) or minv, minv, maxv, fmt or "%.2f")
    if type(a) == "boolean" and type(b) == "number" then return b end
    if type(a) == "number" then return a end
    if type(b) == "number" then return b end
  end
  return Utils.InputFloatValue(label, value, 0.05, 0.25, fmt)
end

function Utils.CheckboxValue(label, current)
  local a, b = ImGui.Checkbox(label, current == true)
  if type(a) == "boolean" and type(b) == "boolean" then
    if b == (a ~= current) then return a == true end
    if a == (b ~= current) then return b == true end
    return b == true
  end
  if type(a) == "boolean" then return a == true end
  if type(b) == "boolean" then return b == true end
  return current == true
end

function Utils.BeginComboSelect(label, currentValue, labels)
  if type(labels) ~= "table" or #labels == 0 then return currentValue end
  local current = currentValue
  local found = false
  for i = 1, #labels do if labels[i] == current then found = true break end end
  if not found then current = labels[1] end

  if type(ImGui.SetNextItemWidth) == "function" then ImGui.SetNextItemWidth(-1) end
  if type(ImGui.BeginCombo) == "function" then
    if ImGui.BeginCombo(label, tostring(current or "")) then
      for i = 1, #labels do
        local item = labels[i]
        local selected = (item == current)
        if ImGui.Selectable(item, selected) then current = item end
        if selected and ImGui.SetItemDefaultFocus then ImGui.SetItemDefaultFocus() end
      end
      ImGui.EndCombo()
    end
    return current
  end
  return current
end

function Utils.PushTextColor(color)
  if type(color) == "table" and type(ImGui.PushStyleColor) == "function" and ImGuiCol and ImGuiCol.Text then
    ImGui.PushStyleColor(ImGuiCol.Text, tonumber(color[1] or 1), tonumber(color[2] or 1), tonumber(color[3] or 1), tonumber(color[4] or 1))
    return true
  end
  return false
end

function Utils.PopStyleColor(count)
  if type(ImGui.PopStyleColor) == "function" then ImGui.PopStyleColor(count or 1) end
end


local function _mm_clamp(value, minv, maxv)
  value = tonumber(value or 0) or 0
  if minv ~= nil and value < minv then value = minv end
  if maxv ~= nil and value > maxv then value = maxv end
  return value
end

function Utils.EnumButtonsSelect(label, currentValue, labels)
  labels = type(labels) == "table" and labels or {}
  local current = currentValue
  ImGui.Text(tostring(label or "Option"))
  for i = 1, #labels do
    local item = tostring(labels[i])
    if i > 1 then ImGui.SameLine() end
    local selected = (item == tostring(current or ""))
    if selected and type(ImGui.PushStyleColor) == 'function' and ImGuiCol and ImGuiCol.Button then
      ImGui.PushStyleColor(ImGuiCol.Button, 0.20, 0.45, 0.80, 0.80)
      ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.26, 0.51, 0.86, 0.90)
      ImGui.PushStyleColor(ImGuiCol.ButtonActive, 0.18, 0.40, 0.75, 1.00)
    end
    if ImGui.SmallButton(item .. '##' .. tostring(label) .. '_' .. tostring(i)) then current = item end
    if selected and type(ImGui.PopStyleColor) == 'function' and ImGuiCol and ImGuiCol.Button then ImGui.PopStyleColor(3) end
  end
  return current
end

function Utils.StepperFloatValue(label, value, step, minv, maxv, fmt)
  local current = _mm_clamp(value, minv, maxv)
  ImGui.Text(tostring(label or 'Value'))
  ImGui.SameLine()
  if ImGui.SmallButton('-##' .. tostring(label)) then current = _mm_clamp(current - (tonumber(step or 0.05) or 0.05), minv, maxv) end
  ImGui.SameLine()
  local display = fmt and string.format(fmt, current) or tostring(current)
  local typed = Utils.InputTextValue('##' .. tostring(label) .. '_input', display, 32)
  local parsed = tonumber(tostring(typed or ''):match('[-+]?[0-9]*%.?[0-9]+'))
  if parsed ~= nil then current = _mm_clamp(parsed, minv, maxv) end
  ImGui.SameLine()
  if ImGui.SmallButton('+##' .. tostring(label)) then current = _mm_clamp(current + (tonumber(step or 0.05) or 0.05), minv, maxv) end
  return current
end

return Utils
