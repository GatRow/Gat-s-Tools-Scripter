local WeaponsData = require("GTS/Inventory/weapons_grenades")
local ClothingData = require("GTS/Inventory/clothing")
local JunkData = require("GTS/Inventory/junk_consumables")
local CyberData = require("GTS/Inventory/cyberware_attachments")
local Equip = require("GTS/Actions/macro_actions_equipment")

local InventoryTab = {}

local function subsetData(data, names)
  local order, groups = {}, {}
  if not data or not data.groups then return { order = {}, groups = {} } end
  for _, name in ipairs(names or {}) do
    if data.groups[name] then
      table.insert(order, name)
      groups[name] = data.groups[name]
    end
  end
  return { order = order, groups = groups }
end

local State = {
  sections = {
    { name = "Weapons", data = WeaponsData },
    { name = "Clothing", data = ClothingData },
    { name = "Junk", data = subsetData(JunkData, {"Junk", "Shards", "Ammo"}) },
    { name = "Consumables", data = subsetData(JunkData, {"Food", "Drink", "Alcohol", "Boosters", "Inhalers"}) },
    { name = "Quickhacks", data = subsetData(JunkData, {"Quickhack - Covert", "Quickhack - Ultimate", "Quickhack - Control", "Quickhack - Combat"}) },
    { name = "Crafting", data = subsetData(JunkData, {"Crafting - Components", "Crafting - Combat", "Crafting - Cyberdeck"}) },
    { name = "Cyberware", data = subsetData(CyberData, {"Arms", "Skeleton", "Integumentary System", "Circulatory System", "Nervous System", "Legs", "Operating System", "Hands", "Frontal Cortex", "Face"}) },
    { name = "Attachments", data = subsetData(CyberData, {"Optics", "Silencers", "Muzzle Brakes", "Mods"}) },
  },
  sectionIndex = 1,
  subIndex = 1,
  search = "",
  selected = 1,
  selectedId = nil,
  amount = "1",
  ownedOnly = false,
  filtered = {},
  filterKey = "",
  maxRows = 350,
  ownedCache = {},
  ownedBuiltAt = 0,
  ownedRefreshEvery = 0.75,
  listHeight = 460,
}

local function lower(s) return tostring(s or ""):lower() end

-- Inventory bookmark helper — uses global GTS_Bookmarks
local function _invBmBtn(itemId, itemLabel, uid)
  if type(GTS_Bookmarks) ~= "table" then GTS_Bookmarks = {} end
  local on = GTS_Bookmarks["inventory_item:" .. tostring(itemId)] ~= nil
  local gOn  = type(IconGlyphs)=="table" and (IconGlyphs["Bookmark"] or "*") or "*"
  local gOff = type(IconGlyphs)=="table" and (IconGlyphs["BookmarkOutline"] or "o") or "o"
  if ImGui.SmallButton((on and gOn or gOff) .. "##invbm_" .. tostring(uid or itemId)) then
    local key = "inventory_item:" .. tostring(itemId)
    if on then
      GTS_Bookmarks[key] = nil
    else
      GTS_Bookmarks[key] = { type="inventory_item", id=tostring(itemId),
        label=tostring(itemLabel or itemId),
        savedAt=(os and os.date and os.date("%Y-%m-%d %H:%M")) or "" }
    end
    on = not on
    local ok, P = pcall(require, "GTS/Core/persistence")
    if ok and P and P.SaveBookmarks then pcall(P.SaveBookmarks) end
  end
  if ImGui.IsItemHovered() then
    ImGui.BeginTooltip()
    ImGui.TextUnformatted(on and "Remove bookmark" or "Bookmark this item")
    ImGui.EndTooltip()
  end
  return on
end

local function checkboxValue(label, current)
  local a, b = ImGui.Checkbox(label, current)
  if type(a) == "boolean" and type(b) == "boolean" then
    if a ~= b then
      if a == current then return b end
      if b == current then return a end
    end
    return b
  end
  if type(a) == "boolean" then
    if a ~= current then return a end
    return current
  end
  if type(b) == "boolean" then
    if b ~= current then return b end
    return current
  end
  return current
end

local function inputTextValue(label, current, bufSize, flags)
  local a, b = ImGui.InputText(label, tostring(current or ""), bufSize or 256, flags)
  if type(a) == "boolean" and type(b) == "string" then return b end
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return tostring(current or "")
end

local function comboValue(label, currentIndex, values)
  local idx = math.max(0, (tonumber(currentIndex) or 1) - 1)
  local a, b = ImGui.Combo(label, idx, values, #values)
  if type(a) == "boolean" then
    if a then return (tonumber(b or 0) + 1) end
    return tonumber(currentIndex) or 1
  end
  if type(a) == "number" then return tonumber(a or 0) + 1 end
  if type(b) == "number" then return tonumber(b or 0) + 1 end
  return tonumber(currentIndex) or 1
end

local function copyToClipboard(text)
  local ok = false
  pcall(function()
    if ImGui.SetClipboardText then
      ImGui.SetClipboardText(tostring(text or ""))
      ok = true
    end
  end)
  return ok
end

local function readOnlyInput(label, value, width)
  if width and width > 0 then ImGui.PushItemWidth(width) end
  local flags = nil
  pcall(function() flags = ImGuiInputTextFlags.ReadOnly end)
  inputTextValue(label, tostring(value or ""), math.max(64, #tostring(value or "") + 16), flags)
  if width and width > 0 then ImGui.PopItemWidth() end
end

local function getCurrentSection()
  return State.sections[State.sectionIndex]
end

local function getCurrentGroupName()
  local sec = getCurrentSection()
  if not sec or not sec.data or not sec.data.order then return nil end
  if #sec.data.order < 1 then return nil end
  if State.subIndex < 1 then State.subIndex = 1 end
  if State.subIndex > #sec.data.order then State.subIndex = #sec.data.order end
  return sec.data.order[State.subIndex]
end

local function getCurrentItems()
  local sec = getCurrentSection()
  local grp = getCurrentGroupName()
  if not sec or not grp then return {} end
  return (sec.data.groups and sec.data.groups[grp]) or {}
end

local function ownedQtyFromCache(itemId)
  return tonumber(State.ownedCache[tostring(itemId or "")] or 0) or 0
end

local function getQuantity(itemId)
  local cached = ownedQtyFromCache(itemId)
  if cached > 0 then return cached end
  if not itemId or itemId == "" then return 0 end

  local p = (GetPlayer and GetPlayer()) or (Game.GetPlayer and Game.GetPlayer()) or nil
  local ts = (Game.GetTransactionSystem and Game.GetTransactionSystem()) or nil
  if not p or not ts then return 0 end

  local candidates = { tostring(itemId) }
  local function addCandidate(v)
    if v ~= nil then table.insert(candidates, v) end
  end

  if TweakDBID and TweakDBID.new and ItemID and ItemID.FromTDBID then
    pcall(function() addCandidate(ItemID.FromTDBID(TweakDBID.new(tostring(itemId)))) end)
  end
  if TweakDBID and TweakDBID.new then
    pcall(function() addCandidate(TweakDBID.new(tostring(itemId))) end)
  end

  for _, candidate in ipairs(candidates) do
    local ok, qty = pcall(function() return ts:GetItemQuantity(p, candidate) end)
    if ok and type(qty) == "number" then return qty end
    ok, qty = pcall(function() return ts:GetItemQuantity(candidate) end)
    if ok and type(qty) == "number" then return qty end
  end

  return 0
end

local function rebuildSelectionFromId()
  if not State.selectedId or State.selectedId == "" then
    State.selected = (#State.filtered > 0) and 1 or 0
    local item = State.filtered[State.selected]
    State.selectedId = item and item.id or nil
    return
  end
  for i, item in ipairs(State.filtered) do
    if item.id == State.selectedId then
      State.selected = i
      return
    end
  end
  State.selected = (#State.filtered > 0) and 1 or 0
  local item = State.filtered[State.selected]
  State.selectedId = item and item.id or nil
end

local function cacheOwnedItem(id, qty)
  id = tostring(id or "")
  qty = tonumber(qty or 0) or 0
  if id == "" or qty <= 0 then return end
  local cur = tonumber(State.ownedCache[id] or 0) or 0
  if qty > cur then State.ownedCache[id] = qty end
end

local function extractOwnedFromListItem(ts, player, item)
  local itemID = nil
  pcall(function() itemID = item:GetID() end)
  if itemID == nil then return end

  local recordId = nil
  pcall(function()
    if itemID.id ~= nil and TDBID and TDBID.ToStringDEBUG then
      recordId = TDBID.ToStringDEBUG(itemID.id)
    elseif itemID.id ~= nil then
      recordId = tostring(itemID.id)
    end
  end)
  if recordId == nil or recordId == "" then return end

  local qty = 0
  pcall(function() qty = ts:GetItemQuantity(player, itemID) end)
  if type(qty) ~= "number" then qty = 0 end
  cacheOwnedItem(recordId, qty)
end

local function rebuildOwnedCache(force)
  local now = (os and os.clock and os.clock()) or 0
  if not force and (now - (State.ownedBuiltAt or 0)) < (State.ownedRefreshEvery or 0.75) then return end

  local p = (GetPlayer and GetPlayer()) or (Game.GetPlayer and Game.GetPlayer()) or nil
  local ts = (Game.GetTransactionSystem and Game.GetTransactionSystem()) or nil
  if not p or not ts then
    State.ownedCache = {}
    State.ownedBuiltAt = now
    return
  end

  local r1, r2 = ts:GetItemList(p)
  local list = nil
  if type(r2) == "table" then
    list = r2
  elseif type(r1) == "table" then
    list = r1
  elseif type(r1) == "userdata" then
    list = r1
  end

  local tmp = {}
  if type(list) == "userdata" then
    pcall(function() for _, it in ipairs(list) do tmp[#tmp + 1] = it end end)
    list = tmp
  end

  State.ownedCache = {}
  if type(list) == "table" then
    for _, item in ipairs(list) do
      pcall(function() extractOwnedFromListItem(ts, p, item) end)
    end
  end

  State.ownedBuiltAt = now
end

local function refreshFiltered()
  local key = tostring(State.sectionIndex) .. "|" .. tostring(State.subIndex) .. "|" .. tostring(State.search) .. "|" .. (State.ownedOnly and "1" or "0")
  if key == State.filterKey then return end
  State.filterKey = key
  State.filtered = {}
  local search = lower(State.search)
  for _, item in ipairs(getCurrentItems()) do
    local hay = lower((item.label or "") .. " " .. (item.id or ""))
    local ok = (search == "") or (hay:find(search, 1, true) ~= nil)
    if ok and State.ownedOnly then ok = ownedQtyFromCache(item.id) > 0 end
    if ok then table.insert(State.filtered, item) end
  end
  table.sort(State.filtered, function(a, b)
    local aq, bq = ownedQtyFromCache(a.id), ownedQtyFromCache(b.id)
    if State.ownedOnly and aq ~= bq then return aq > bq end
    return lower(a.label or a.id) < lower(b.label or b.id)
  end)
  rebuildSelectionFromId()
end

local function getSelectedItem()
  for _, entry in ipairs(State.filtered or {}) do
    if entry.id == State.selectedId then return entry end
  end
  return State.filtered[1]
end

local function drawHeaderControls()
  local sectionNames = {}
  for i = 1, #State.sections do sectionNames[i] = State.sections[i].name end
  local newSection = comboValue("Section##inventory_section_combo", State.sectionIndex, sectionNames)
  if newSection ~= State.sectionIndex then
    State.sectionIndex = newSection
    State.subIndex = 1
    State.filterKey = ""
  end

  local sec = getCurrentSection()
  local order = (sec and sec.data and sec.data.order) or {}
  if #order > 0 then
    ImGui.SameLine()
    local newGroup = comboValue("Group##inventory_group_combo", State.subIndex, order)
    if newGroup ~= State.subIndex then
      State.subIndex = newGroup
      State.filterKey = ""
    end
  end

  do local _mg = type(IconGlyphs)=="table" and (IconGlyphs["Magnify"] or IconGlyphs["MagnifyPlus"] or IconGlyphs["Search"]) or nil; ImGui.TextUnformatted(_mg and _mg or "?") end
  ImGui.SameLine()
  local changed, newSearch = ImGui.InputText("##inventory_search", State.search, 128)
  if changed then
    State.search = newSearch
    State.filterKey = ""
  end

  local newOwned = checkboxValue("Owned Only##inventory_owned", State.ownedOnly)
  if newOwned ~= State.ownedOnly then
    State.ownedOnly = newOwned
    State.filterKey = ""
  end
  ImGui.SameLine()
  if ImGui.SmallButton("Refresh##inventory_refresh_owned") then
    rebuildOwnedCache(true)
    State.filterKey = ""
  end
end

local function drawListPane(listWidth, listHeight)
  ImGui.BeginChild("inventory_list", listWidth, listHeight, true)

  local shown = math.min(#State.filtered, State.maxRows)
  if ImGui.BeginTable and ImGuiTableFlags and ImGui.TableSetupColumn then
    local flags = (ImGuiTableFlags.RowBg or 0) + (ImGuiTableFlags.Borders or 0) + (ImGuiTableFlags.ScrollY or 0) + (ImGuiTableFlags.SizingStretchProp or 0)
    if ImGui.BeginTable("inventory_tbl", 2, flags) then
      ImGui.TableSetupColumn("Item", ImGuiTableColumnFlags and ImGuiTableColumnFlags.WidthStretch or 0)
      ImGui.TableSetupColumn("Owned", ImGuiTableColumnFlags and ImGuiTableColumnFlags.WidthFixed or 0, 70)
      if ImGui.TableHeadersRow then ImGui.TableHeadersRow() end
      for i = 1, shown do
        local item = State.filtered[i]
        local qty = ownedQtyFromCache(item.id)
        local isSelected = (item.id == State.selectedId)
        ImGui.TableNextRow()
        ImGui.TableSetColumnIndex(0)
        local rowLabel = tostring(item.label or item.id)
        _invBmBtn(tostring(item.id or ""), tostring(item.name or item.label or item.id or ""), "inv1_" .. tostring(i))
        ImGui.SameLine()
        if ImGui.Selectable(rowLabel .. "##inv_item_" .. tostring(i), isSelected, ImGuiSelectableFlags and ImGuiSelectableFlags.SpanAllColumns or 0) then
          State.selected = i
          State.selectedId = item.id
        end
        if ImGui.IsItemHovered and ImGui.IsItemHovered() and ImGui.BeginTooltip then
          ImGui.BeginTooltip()
          ImGui.TextUnformatted(tostring(item.id or ""))
          ImGui.EndTooltip()
        end
        if ImGui.BeginPopupContextItem and ImGui.BeginPopupContextItem("inv_item_ctx_" .. tostring(i)) then
          if ImGui.MenuItem("Copy ID") then copyToClipboard(item.id) end
          if ImGui.MenuItem("Copy Label") then copyToClipboard(item.label or item.id) end
          ImGui.EndPopup()
        end

        ImGui.TableSetColumnIndex(1)
        ImGui.TextUnformatted(tostring(qty))
      end
      ImGui.EndTable()
    end
  else
    for i = 1, shown do
      local item = State.filtered[i]
      local qty = ownedQtyFromCache(item.id)
      local rowLabel = string.format("%s  [%d]", tostring(item.label or item.id), qty)
      if ImGui.Selectable(rowLabel .. "##inv_item_" .. tostring(i), item.id == State.selectedId) then
        State.selected = i
        State.selectedId = item.id
      end
    end
  end

  ImGui.EndChild()
end

local function drawDetailsPane(item, paneWidth, paneHeight)
  ImGui.BeginChild("inventory_details", paneWidth, paneHeight, true)

  if not item then
    ImGui.TextWrapped("Select an item from the list.")
    ImGui.EndChild()
    return
  end

  local owned = getQuantity(item.id)

  ImGui.TextWrapped(tostring(item.label or item.id))
  ImGui.Separator()

  ImGui.TextDisabled("TweakDBID")
  readOnlyInput("##inventory_selected_id", tostring(item.id or ""), -110)
  ImGui.SameLine()
  if ImGui.SmallButton("Copy ID##inventory_copy_id") then
    copyToClipboard(item.id)
  end

  ImGui.TextDisabled("Label")
  readOnlyInput("##inventory_selected_label", tostring(item.label or item.id), -110)
  ImGui.SameLine()
  if ImGui.SmallButton("Copy Name##inventory_copy_label") then
    copyToClipboard(item.label or item.id)
  end

  ImGui.Separator()
  ImGui.Text("Owned: " .. tostring(owned))
  ImGui.Text("Category: " .. tostring(getCurrentGroupName() or "-"))
  ImGui.Text("Section: " .. tostring(getCurrentSection() and getCurrentSection().name or "-"))

  local amtChanged, amt = ImGui.InputText("Amount##inventory_amount", State.amount, 16)
  if amtChanged then State.amount = amt end
  local n = tonumber(State.amount) or 1
  if n < 1 then n = 1 end

  if ImGui.Button("Add To Inventory##inventory_add", -1, 0) then
    pcall(function() Game.AddToInventory(item.id, n) end)
    rebuildOwnedCache(true)
    State.filterKey = ""
  end

  if ImGui.Button("Equip To Player##inventory_equip", -1, 0) then
    if n > 0 then
      pcall(function() Game.AddToInventory(item.id, n) end)
    else
      pcall(function() Game.AddToInventory(item.id, 1) end)
    end
    pcall(function() Equip.EquipItemRecord(item.id) end)
    rebuildOwnedCache(true)
    State.filterKey = ""
  end

  ImGui.Separator()
  ImGui.TextWrapped("Tip: right-click any item in the list to copy its ID or label.")

  ImGui.EndChild()
end

function InventoryTab.OnUpdate()
  rebuildOwnedCache(false)
  if State.ownedOnly then State.filterKey = "" end
  refreshFiltered()
end

function InventoryTab.DrawTab()
  local sec = getCurrentSection()
  if not sec then
    ImGui.Text("Inventory data not available.")
    return
  end

  rebuildOwnedCache(false)
  drawHeaderControls()
  refreshFiltered()
  rebuildSelectionFromId()

  local item = getSelectedItem()
  if item then State.selectedId = item.id end

  ImGui.Separator()
  ImGui.TextDisabled(string.format("Results: %d   |   Section: %s   |   Group: %s", #State.filtered, tostring(sec.name or "-"), tostring(getCurrentGroupName() or "-")))
  ImGui.Separator()

  local availX = 0
  pcall(function() availX = ImGui.GetContentRegionAvail() end)
  if type(availX) ~= "number" then
    local ax, _ = ImGui.GetContentRegionAvail()
    availX = tonumber(ax or 0) or 0
  end
  if availX <= 0 then availX = 900 end

  local leftW = math.floor(availX * 0.58)
  if leftW < 360 then leftW = 360 end
  local rightW = availX - leftW - 10
  if rightW < 260 then rightW = 260 end

  drawListPane(leftW, State.listHeight)
  ImGui.SameLine()
  drawDetailsPane(item, rightW, State.listHeight)
end

function InventoryTab.GetSelectedItemInfo()
  local item = getSelectedItem()
  if item then
    return {
      id = tostring(item.id),
      label = tostring(item.label or item.id),
      amount = tonumber(State.amount or "1") or 1,
    }
  end
  return nil
end

function InventoryTab.ExportCurrentBundle(name)
  local item = getSelectedItem()
  if not item then return nil, "Select an inventory item first." end
  local amt = tonumber(State.amount or "1") or 1
  if amt < 1 then amt = 1 end
  return {
    type = "inventory_bundle",
    name = (type(name) == "string" and name ~= "") and name or tostring(item.label or item.id),
    data = {
      entries = {
        { id = tostring(item.id), amount = amt, label = tostring(item.label or item.id) }
      }
    }
  }, nil
end

function InventoryTab.ApplyInventoryBundle(entries)
  if type(entries) ~= "table" then return false end
  local ran = 0
  for i = 1, #entries do
    local e = entries[i]
    if e and e.id and e.id ~= "" then
      local amt = tonumber(e.amount or 1) or 1
      if amt < 1 then amt = 1 end
      pcall(function() Game.AddToInventory(tostring(e.id), amt) end)
      ran = ran + 1
    end
  end
  if ran > 0 then
    rebuildOwnedCache(true)
    State.filterKey = ""
    return true
  end
  return false
end

return InventoryTab
