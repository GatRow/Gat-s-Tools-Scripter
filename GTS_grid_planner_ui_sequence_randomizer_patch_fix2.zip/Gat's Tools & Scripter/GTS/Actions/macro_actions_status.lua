local StatusActions = StatusActions or {}

StatusActions.state = StatusActions.state or {
  built = false,
  ids = {},
  seen = {},
}

local function _pcall(fn)
  local ok, a, b, c = pcall(fn)
  if ok then return a, b, c end
  return nil, nil, nil
end

local function _trim(s)
  return tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function _normalizeEffectId(raw)
  local s = _trim(raw)
  if s == "" then return "" end

  local inner = s:match('^TweakDBID%.new%([%s]*"([^"]+)"[%s]*%)$')
  if inner and inner ~= "" then return inner end
  inner = s:match("^TweakDBID%.new%([%s]*'([^']+)'[%s]*%)$")
  if inner and inner ~= "" then return inner end

  s = s:gsub("^TweakDBID%(", ""):gsub("%)$", "")
  s = s:gsub("^RecordID%(", ""):gsub("%)$", "")
  return _trim(s)
end

local function _recordPathFromRec(rec)
  if not rec then return nil end

  local id = _pcall(function() return rec:GetID() end)
  if id and type(id.value) == "string" and id.value ~= "" then
    return _normalizeEffectId(id.value)
  end

  local rid = _pcall(function() return rec:GetRecordID() end)
  if rid and type(rid.value) == "string" and rid.value ~= "" then
    return _normalizeEffectId(rid.value)
  end

  local tries = {
    function() return tostring(rec:GetID()) end,
    function() return tostring(rec:GetRecordID()) end,
    function() return tostring(rec) end,
  }
  for _, fn in ipairs(tries) do
    local s = _pcall(fn)
    if type(s) == "string" and s ~= "" then
      s = _normalizeEffectId(s)
      if s ~= "" then return s end
    end
  end

  return nil
end

local function _addRecordType(recordType)
  local st = StatusActions.state
  local records = _pcall(function() return TweakDB:GetRecords(recordType) end)
  if type(records) ~= "table" then return end
  for i = 1, #records do
    local id = _recordPathFromRec(records[i])
    if id and id ~= "" and not st.seen[id] then
      st.seen[id] = true
      st.ids[#st.ids + 1] = id
    end
  end
end

function StatusActions.RebuildStatusEffectCache()
  local st = StatusActions.state
  st.built = false
  st.ids = {}
  st.seen = {}
  _addRecordType("gamedataStatusEffect_Record")
  _addRecordType("gamedataGameplayRestrictionStatusEffect_Record")
  table.sort(st.ids, function(a, b) return tostring(a) < tostring(b) end)
  st.built = true
  print("[GTS][Status] Built status cache: " .. tostring(#st.ids) .. " ids")
  return st.ids
end

function StatusActions.ListStatusEffectIds(search)
  local st = StatusActions.state
  if st.built ~= true then StatusActions.RebuildStatusEffectCache() end

  local q = _trim(search):lower()
  if q == "" then
    local out = {}
    for i = 1, #st.ids do out[i] = st.ids[i] end
    return out
  end

  local out = {}
  for i = 1, #st.ids do
    local id = st.ids[i]
    if tostring(id):lower():find(q, 1, true) then
      out[#out + 1] = id
    end
  end
  return out
end

function StatusActions.NormalizeEffectId(raw)
  return _normalizeEffectId(raw)
end

local function _getPlayer()
  return (Game and Game.GetPlayer and Game.GetPlayer()) or nil
end

local function _getEID(player)
  if not player or player.GetEntityID == nil then return nil end
  local eid = _pcall(function() return player:GetEntityID() end)
  return eid
end

local function _getRID(player)
  if not player or player.GetRecordID == nil then return nil end
  local rid = _pcall(function() return player:GetRecordID() end)
  return rid
end

local function _getToken(effectId)
  if TweakDBID and TweakDBID.new then
    local tok = _pcall(function() return TweakDBID.new(effectId) end)
    if tok ~= nil then return tok end
  end
  return nil
end

function StatusActions.IsStatusEffectActive(rawEffectId)
  local effectId = _normalizeEffectId(rawEffectId)
  if effectId == "" then return false end
  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  local player = _getPlayer()
  local eid = _getEID(player)
  if not ses or not eid then return false end

  local tok = _getToken(effectId)
  if tok ~= nil and ses.HasStatusEffect ~= nil then
    local active = _pcall(function() return ses:HasStatusEffect(eid, tok) end)
    if type(active) == "boolean" then return active end
  end
  if ses.HasStatusEffect ~= nil then
    local active = _pcall(function() return ses:HasStatusEffect(eid, effectId) end)
    if type(active) == "boolean" then return active end
  end
  return false
end

function StatusActions.ApplyStatusEffect(rawEffectId)
  local effectId = _normalizeEffectId(rawEffectId)
  if effectId == "" then return false, "Enter status effect ID" end

  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  local player = _getPlayer()
  local eid = _getEID(player)
  if not ses then return false, "StatusEffectSystem unavailable" end
  if not player or not eid then return false, "Player unavailable" end

  local tok = _getToken(effectId)
  local rid = _getRID(player)
  local attempts = {}
  if tok ~= nil then
    attempts[#attempts + 1] = { tag = "token2", fn = function() ses:ApplyStatusEffect(eid, tok) end }
    if rid ~= nil then
      attempts[#attempts + 1] = { tag = "token4", fn = function() ses:ApplyStatusEffect(eid, tok, rid, eid) end }
    end
  end
  attempts[#attempts + 1] = { tag = "string2", fn = function() ses:ApplyStatusEffect(eid, effectId) end }
  if rid ~= nil then
    attempts[#attempts + 1] = { tag = "string4", fn = function() ses:ApplyStatusEffect(eid, effectId, rid, eid) end }
  end

  local lastErr = "ApplyStatusEffect failed"
  for i = 1, #attempts do
    local step = attempts[i]
    local ok, err = pcall(step.fn)
    if ok then
      print("[GTS][Status] Applied '" .. tostring(effectId) .. "' via " .. tostring(step.tag))
      return true, "Applied " .. tostring(effectId)
    end
    lastErr = tostring(err)
  end

  print("[GTS][Status] Failed to apply '" .. tostring(effectId) .. "': " .. tostring(lastErr))
  return false, tostring(lastErr)
end

function StatusActions.RemoveStatusEffect(rawEffectId)
  local effectId = _normalizeEffectId(rawEffectId)
  if effectId == "" then return false, "Enter status effect ID" end

  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  local player = _getPlayer()
  local eid = _getEID(player)
  if not ses then return false, "StatusEffectSystem unavailable" end
  if not player or not eid then return false, "Player unavailable" end

  local tok = _getToken(effectId)
  local attempts = {}
  if tok ~= nil then
    attempts[#attempts + 1] = { tag = "token", fn = function() ses:RemoveStatusEffect(eid, tok) end }
  end
  attempts[#attempts + 1] = { tag = "string", fn = function() ses:RemoveStatusEffect(eid, effectId) end }

  local lastErr = "RemoveStatusEffect failed"
  for i = 1, #attempts do
    local step = attempts[i]
    local ok, err = pcall(step.fn)
    if ok then
      print("[GTS][Status] Removed '" .. tostring(effectId) .. "' via " .. tostring(step.tag))
      return true, "Removed " .. tostring(effectId)
    end
    lastErr = tostring(err)
  end

  print("[GTS][Status] Failed to remove '" .. tostring(effectId) .. "': " .. tostring(lastErr))
  return false, tostring(lastErr)
end


function StatusActions.ApplyStatusEffectToEntity(rawEffectId, entityID, recordID)
  local effectId = _normalizeEffectId(rawEffectId)
  if effectId == "" then return false, "Enter status effect ID" end
  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  if not ses then return false, "StatusEffectSystem unavailable" end
  if entityID == nil then return false, "Target entity unavailable" end
  local tok = _getToken(effectId)
  local attempts = {}
  if tok ~= nil and recordID ~= nil then
    attempts[#attempts + 1] = { tag = "native_exact", fn = function() ses:ApplyStatusEffect(entityID, tok, recordID, entityID) end }
  end
  if tok ~= nil then
    attempts[#attempts + 1] = { tag = "token2", fn = function() ses:ApplyStatusEffect(entityID, tok) end }
  end
  if recordID ~= nil then
    attempts[#attempts + 1] = { tag = "string4", fn = function() ses:ApplyStatusEffect(entityID, effectId, recordID, entityID) end }
  end
  attempts[#attempts + 1] = { tag = "string2", fn = function() ses:ApplyStatusEffect(entityID, effectId) end }

  local lastErr = "ApplyStatusEffect failed"
  for _, step in ipairs(attempts) do
    local ok, err = pcall(step.fn)
    if ok then
      local verified = false
      if type(StatusActions.HasStatusEffectOnEntity) == 'function' then
        verified = StatusActions.HasStatusEffectOnEntity(effectId, entityID) == true
      end
      if verified then
        return true, "Applied " .. tostring(effectId) .. " via " .. tostring(step.tag)
      end
      return true, "Applied call sent for " .. tostring(effectId) .. " via " .. tostring(step.tag)
    end
    lastErr = tostring(err)
  end
  return false, lastErr
end

function StatusActions.HasStatusEffectOnEntity(rawEffectId, entityID)
  local effectId = _normalizeEffectId(rawEffectId)
  if effectId == "" or entityID == nil then return false end
  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  if not ses then return false end
  local tok = _getToken(effectId)
  if tok ~= nil and ses.HasStatusEffect ~= nil then
    local active = _pcall(function() return ses:HasStatusEffect(entityID, tok) end)
    if type(active) == 'boolean' then return active end
  end
  if ses.HasStatusEffect ~= nil then
    local active = _pcall(function() return ses:HasStatusEffect(entityID, effectId) end)
    if type(active) == 'boolean' then return active end
  end
  return false
end

return StatusActions
