local Interface = Interface or {}

local function _getUI()
  if Game and Game.GetUISystem then return Game.GetUISystem() end
  return nil
end

local function _getSettingsGroup(path)
  local ss = (Game and Game.GetSettingsSystem and Game.GetSettingsSystem()) or nil
  if not ss or not ss.GetGroup then return nil end
  local ok, grp = pcall(function() return ss:GetGroup(path) end)
  if ok then return grp end
  return nil
end

local function _getPreventionSystem()
  if _G and _G.PreventionSystem then return _G.PreventionSystem end
  if Game and Game.GetScriptableSystemsContainer then
    local ok, ps = pcall(function() return Game.GetScriptableSystemsContainer():Get("PreventionSystem") end)
    if ok then return ps end
  end
  return nil
end

function Interface.SetHUDEnabled(enabled)
  local hud = _getSettingsGroup("/interface/hud")
  if not hud or not hud.GetVars then return false, "HUD settings group unavailable" end
  local vars = hud:GetVars(false) or {}
  local ok, err = pcall(function()
    for _, v in ipairs(vars) do v:SetValue(enabled == true) end
  end)
  if not ok then return false, tostring(err) end
  return true, ((enabled == true) and "HUD ON" or "HUD OFF")
end

function Interface.SetJohnnyHUD(enabled)
  local ui = _getUI()
  if not ui then return false, "UISystem unavailable" end
  local ok, err = pcall(function()
    if enabled == true then ui:SetGlobalThemeOverride("Possessed")
    else ui:ClearGlobalThemeOverride() end
  end)
  if not ok then return false, tostring(err) end
  return true, ((enabled == true) and "Johnny HUD ON" or "Johnny HUD OFF")
end

function Interface.SetArasakaHUD(enabled)
  local ok, err = pcall(function()
    local hud = _getSettingsGroup("/interface/hud")
    if hud and hud.GetVars then
      for _, v in ipairs(hud:GetVars(false) or {}) do v:SetValue(true) end
    end
    local qs = (Game and Game.GetQuestsSystem and Game.GetQuestsSystem()) or nil
    if not qs or not qs.SetFactStr then error("QuestsSystem unavailable") end
    qs:SetFactStr("q000_var_arasaka_ui_on", enabled == true and 1 or 0)
  end)
  if not ok then return false, tostring(err) end
  return true, ((enabled == true) and "Arasaka HUD ON" or "Arasaka HUD OFF")
end

function Interface.OpenFastTravelMenu()
  local ui = _getUI()
  if not ui or not ui.RequestFastTravelMenu then return false, "Fast Travel menu API unavailable" end
  local ok, err = pcall(function() ui:RequestFastTravelMenu() end)
  if not ok then return false, tostring(err) end
  return true, "Opened Fast Travel menu"
end

function Interface.ShowAlert(text, duration)
  local msg = tostring(text or "")
  if msg == "" then msg = "Alert" end
  local secs = tonumber(duration or 5.0) or 5.0
  if secs < 0.5 then secs = 0.5 end
  if secs > 30.0 then secs = 30.0 end
  local ps = _getPreventionSystem()
  if ps and ps.ShowMessage then
    local ok, err = pcall(function() ps:ShowMessage(msg, secs) end)
    if ok then return true, msg end
    return false, tostring(err)
  end
  return false, "PreventionSystem unavailable"
end

return Interface
