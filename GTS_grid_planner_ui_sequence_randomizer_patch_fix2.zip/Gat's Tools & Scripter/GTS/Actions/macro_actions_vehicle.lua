local VehicleActions = VehicleActions or {}

function VehicleActions.RepairCurrentVehicle()
  local ok, result = pcall(function()
    local p = Game and Game.GetPlayer and Game.GetPlayer() or nil
    if not p then return false, "Player unavailable" end
    local v = p.GetMountedVehicle and p:GetMountedVehicle() or nil
    if not v then return false, "Mount a vehicle first" end
    local vc = v.GetVehicleComponent and v:GetVehicleComponent() or nil
    if vc ~= nil then
      if vc.FixAllDamages ~= nil then pcall(function() vc:FixAllDamages() end) end
      if vc.RepairVehicle ~= nil then pcall(function() vc:RepairVehicle() end) end
      if vc.VehicleVisualDestructionSetup ~= nil then pcall(function() vc:VehicleVisualDestructionSetup() end) end
      return true, "Vehicle repaired"
    end
    return false, "Vehicle component unavailable"
  end)
  if not ok then return false, tostring(result) end
  return result
end

return VehicleActions
