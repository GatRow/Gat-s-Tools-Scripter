local Area = Area or {}

local function _showAlert(msg)
  local text = tostring(msg or "")
  local ps = (_G and _G.PreventionSystem) or nil
  if not ps and Game and Game.GetScriptableSystemsContainer then
    local ok, sys = pcall(function() return Game.GetScriptableSystemsContainer():Get("PreventionSystem") end)
    if ok then ps = sys end
  end
  if ps and ps.ShowMessage then pcall(function() ps:ShowMessage(text, 5.0) end) end
end

function Area.ForceKillLookAtNPC()
  local player = (Game and Game.GetPlayer and Game.GetPlayer()) or nil
  local ts = (Game and Game.GetTargetingSystem and Game.GetTargetingSystem()) or nil
  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  if not player or not ts or not ses then return false, "Required game systems unavailable" end

  local ok, ttlo = pcall(function() return ts:GetLookAtObject(player, false, false) end)
  if not ok then return false, tostring(ttlo) end
  if ttlo == nil or (ttlo.ToString and ttlo:ToString() ~= "NPCPuppet") then
    _showAlert("LOOK AT THE NPC FIRST")
    return false, "Look at the NPC first"
  end

  local ok2, err = pcall(function()
    ses:ApplyStatusEffect(ttlo:GetEntityID(), "BaseStatusEffect.ForceKill")
  end)
  if not ok2 then return false, tostring(err) end
  _showAlert("Bye Bye...")
  return true, "Force-killed looked-at NPC"
end

return Area
