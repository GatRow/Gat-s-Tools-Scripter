local PlayerActions = PlayerActions or {}

local function _getPlayer()
  if Game and Game.GetPlayer then return Game.GetPlayer() end
  return nil
end

function PlayerActions.SetPassiveMode(enable)
  local p = _getPlayer()
  if not p or not p.GetEntityID then return false, "Player unavailable" end
  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  if not ses then return false, "StatusEffectSystem unavailable" end
  local ok, eid = pcall(function() return p:GetEntityID() end)
  if not ok then return false, "Could not read player entity id" end
  local eff = (TweakDBID and TweakDBID.new and TweakDBID.new("GameplayRestriction.NoCombat")) or "GameplayRestriction.NoCombat"
  local done, err = pcall(function()
    if enable then
      if type(eff) ~= "string" and p.GetRecordID ~= nil then
        ses:ApplyStatusEffect(eid, eff, p:GetRecordID(), eid)
      else
        ses:ApplyStatusEffect(eid, eff)
      end
    else
      ses:RemoveStatusEffect(eid, eff)
    end
  end)
  if not done then return false, tostring(err) end
  return true, (enable and "Passive mode ON" or "Passive mode OFF")
end

local function _preventionSystem()
  if Game and Game.GetScriptableSystemsContainer then
    local ok, ps = pcall(function() return Game.GetScriptableSystemsContainer():Get("PreventionSystem") end)
    if ok then return ps end
  end
  return nil
end

function PlayerActions.SetWantedSystemEnabled(enable)
  local ps = _preventionSystem()
  if not ps then return false, "PreventionSystem unavailable" end
  local ok, err = pcall(function()
    if enable then
      ps:TogglePreventionSystem(true)
    else
      pcall(function() ps:ChangeHeatStage(EPreventionHeatStage.Heat_0, "") end)
      ps:TogglePreventionSystem(false)
    end
  end)
  if not ok then return false, tostring(err) end
  return true, (enable and "Wanted system ON" or "Wanted system OFF")
end

function PlayerActions.ClearWantedLevel()
  local ps = _preventionSystem()
  if not ps then return false, "PreventionSystem unavailable" end
  local ok, err = pcall(function() ps:ChangeHeatStage(EPreventionHeatStage.Heat_0, "") end)
  if not ok then return false, tostring(err) end
  return true, "Wanted level cleared"
end

function PlayerActions.SetWantedLevel(level)
  local ps = _preventionSystem()
  if not ps then return false, "PreventionSystem unavailable" end
  local lv = math.floor(tonumber(level or 0) or 0)
  if lv < 0 then lv = 0 end
  if lv > 5 then lv = 5 end
  local stage = EPreventionHeatStage.Heat_0
  if lv == 1 then stage = EPreventionHeatStage.Heat_1 end
  if lv == 2 then stage = EPreventionHeatStage.Heat_2 end
  if lv == 3 then stage = EPreventionHeatStage.Heat_3 end
  if lv == 4 then stage = EPreventionHeatStage.Heat_4 end
  if lv == 5 then stage = EPreventionHeatStage.Heat_5 end
  local ok, err = pcall(function() ps:ChangeHeatStage(stage, "") end)
  if not ok then return false, tostring(err) end
  return true, string.format("Wanted level set to %d", lv)
end


function PlayerActions.SetJohnnySilverhandArm(mode)
  local arm = "Items.PlayerSilverhandArm"
  local armID = ItemID.FromTDBID(arm)
  local P = _getPlayer()
  local TS = (Game and Game.GetTransactionSystem and Game.GetTransactionSystem()) or nil
  local SSC = (Game and Game.GetScriptableSystemsContainer and Game.GetScriptableSystemsContainer()) or nil
  if not P or not TS or not SSC then return false, "Required systems unavailable" end
  local eq = SSC:Get('EquipmentSystem')
  if not eq or not eq.GetPlayerData then return false, "EquipmentSystem unavailable" end
  local ESPD = eq:GetPlayerData(P)
  if not ESPD then return false, "Equipment player data unavailable" end

  local armInInv = TS:GetItemQuantity(P, armID)
  local slotItem = nil
  local okSlot = pcall(function() slotItem = ESPD:GetItemInEquipSlot(34, 0) end)
  local armInSlot = ""
  if okSlot and slotItem and slotItem.id then
    local okStr, txt = pcall(function() return TDBID.ToStringDEBUG(slotItem.id) end)
    if okStr and txt then armInSlot = tostring(txt) end
  end

  local desired = tostring(mode or "toggle")
  local shouldEnable = nil
  if desired == "on" then shouldEnable = true
  elseif desired == "off" then shouldEnable = false
  else shouldEnable = (armInSlot ~= arm) end

  local ok, err = pcall(function()
    if shouldEnable then
      if armInInv == 0 then
        TS:GiveItem(P, armID, 1)
      elseif armInInv > 1 then
        TS:GiveItem(P, armID, 1 - armInInv)
      end
      ESPD:EquipItem(ItemID.FromTDBID(arm))
    else
      ESPD:UnequipItem(armID)
      if armInInv > 0 then TS:GiveItem(P, armID, -armInInv) end
    end
  end)
  if not ok then return false, tostring(err) end
  return true, shouldEnable and "Johnny Silverhand arm ON" or "Johnny Silverhand arm OFF"
end

return PlayerActions
