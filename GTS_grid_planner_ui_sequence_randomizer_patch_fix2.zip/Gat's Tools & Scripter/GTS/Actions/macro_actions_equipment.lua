local Equip = Equip or {}

function Equip.EquipItemRecord(idStr)
  local p = (Game ~= nil and Game.GetPlayer ~= nil) and Game.GetPlayer() or nil
  if p == nil then return false, "Player unavailable" end
  local raw = tostring(idStr or "")
  if raw == "" then return false, "Enter an item record ID" end

  local full = raw
  if not full:match("^Items%.") then
    if not full:match("^%w+%.%w+") then full = "Items." .. full end
  end
  local short = full:gsub("^Items%.", "")

  if Game ~= nil and Game.AddToInventory ~= nil then pcall(function() Game.AddToInventory(full, 1) end) end

  local itemID = nil
  local tdb = nil
  if TweakDBID ~= nil and TweakDBID.new ~= nil then pcall(function() tdb = TweakDBID.new(full) end) end
  if tdb == nil and TDBID ~= nil then
    if TDBID.Create ~= nil then pcall(function() tdb = TDBID.Create(full) end) end
    if tdb == nil and TDBID.new ~= nil then pcall(function() tdb = TDBID.new(full) end) end
  end
  if ItemID ~= nil and ItemID.FromTDBID ~= nil and tdb ~= nil then pcall(function() itemID = ItemID.FromTDBID(tdb) end) end

  local ok, err = pcall(function()
    if RPGManager ~= nil and RPGManager.ForceEquipItemOnPlayer ~= nil then
      pcall(function() RPGManager.ForceEquipItemOnPlayer(p, full, true) end)
      pcall(function() RPGManager.ForceEquipItemOnPlayer(p, short, true) end)
    end
    if Game ~= nil and Game.GetRPGManager ~= nil then
      local rm = nil
      pcall(function() rm = Game.GetRPGManager() end)
      if rm ~= nil and rm.ForceEquipItemOnPlayer ~= nil then
        pcall(function() rm:ForceEquipItemOnPlayer(p, full, true) end)
        pcall(function() rm:ForceEquipItemOnPlayer(p, short, true) end)
      end
    end
    local ts = (Game ~= nil and Game.GetTransactionSystem ~= nil) and Game.GetTransactionSystem() or nil
    if ts ~= nil and itemID ~= nil then
      pcall(function() ts:GiveItem(p, itemID, 1) end)
      pcall(function() ts:GiveItem(p, itemID, 1, false) end)
      if ts.AddItem ~= nil then pcall(function() ts:AddItem(p, itemID, 1) end) end
      if ts.EquipItem ~= nil then pcall(function() ts:EquipItem(p, itemID, true, false) end) end
    end
  end)
  if not ok then return false, tostring(err) end
  return true, "Equip requested"
end

return Equip
