local CameraActions = CameraActions or {}

CameraActions.state = CameraActions.state or {
  spawned = false,
  active = false,
  pendingBind = false,
  entityID = nil,
  handle = nil,
  component = nil,
  path = "base\\entities\\cameras\\simple_free_camera.ent",
  speed = 0.18,
  zoom = 1.0,
  fov = 60.0,
  status = "Idle",
  playerLockPos = nil,
  playerLockRot = nil,
  noClip = false,
  noClipZOffset = 0.0,
  disableMode = "manual",
  disableAfterSeconds = 5.0,
  disableStillSeconds = 3.0,
  sessionStartedAt = 0,
  lastMoveAt = 0,
  lastPos = nil,
  sessionTokenCounter = 0,
  currentSessionToken = 0,
  completedSessions = {},
  hooksInstalled = false,
  observeInstalled = false,
  overrideInstalled = false,
  dir = {
    forward = false,
    backwards = false,
    right = false,
    left = false,
    up = false,
    down = false,
    rotateLeft = false,
    rotateRight = false,
  },
  analog = {
    forward = 0,
    backwards = 0,
    right = 0,
    left = 0,
    up = 0,
    down = 0,
  }
}

local _installHooks
local _disableCamera

local function _player()
  return (Game and Game.GetPlayer and Game.GetPlayer()) or nil
end

local function _log(msg)
  local s = CameraActions.state
  local txt = tostring(msg or "")
  s.status = txt
  print("[GTS][CameraAction] " .. txt)
end

local function _resetDirections()
  local s = CameraActions.state
  for k, _ in pairs(s.dir) do s.dir[k] = false end
  for k, _ in pairs(s.analog) do s.analog[k] = 0 end
end

local function _clonePos(pos)
  if not pos then return nil end
  return Vector4.new(pos.x, pos.y, pos.z, pos.w)
end

local function _getEuler(handle)
  if not handle then return nil end
  local ok, rot = pcall(function() return handle:GetWorldOrientation():ToEulerAngles() end)
  if ok and rot then return rot end
  return nil
end

local function _getPlayerEuler(p)
  if not p then return nil end
  local ok, rot = pcall(function() return p:GetWorldOrientation():ToEulerAngles() end)
  if ok and rot then return rot end
  return nil
end

local function _distSq(a, b)
  if not a or not b then return 0 end
  local dx = (a.x or 0) - (b.x or 0)
  local dy = (a.y or 0) - (b.y or 0)
  local dz = (a.z or 0) - (b.z or 0)
  return dx * dx + dy * dy + dz * dz
end

local function _now()
  return (os and os.clock and os.clock()) or 0
end

local function _normalizeDisableMode(mode)
  mode = tostring(mode or "manual")
  if mode == "after_time" or mode == "while_still" or mode == "either" then return mode end
  return "manual"
end

local function _clampAutoSeconds(value, default)
  local v = tonumber(value or default) or tonumber(default) or 1.0
  if v < 0.10 then v = 0.10 end
  if v > 3600.0 then v = 3600.0 end
  return v
end

local function _resetSessionTracking()
  local s = CameraActions.state
  s.sessionStartedAt = 0
  s.lastMoveAt = 0
  s.lastPos = nil
end

local function _nextSessionToken()
  local s = CameraActions.state
  s.sessionTokenCounter = math.max(0, math.floor(tonumber(s.sessionTokenCounter or 0) or 0)) + 1
  s.currentSessionToken = s.sessionTokenCounter
  s.completedSessions[s.currentSessionToken] = nil
  return s.currentSessionToken
end

local function _getOrCreateSessionToken()
  local s = CameraActions.state
  local token = math.floor(tonumber(s.currentSessionToken or 0) or 0)
  if token <= 0 then token = _nextSessionToken() end
  return token
end

local function _beginSessionTracking()
  local s = CameraActions.state
  local now = _now()
  _getOrCreateSessionToken()
  s.sessionStartedAt = now
  s.lastMoveAt = now
  s.lastPos = s.handle and _clonePos(s.handle:GetWorldPosition()) or nil
end

local function _teleportEntity(handle, pos, rot)
  if not handle or not pos then return end
  local tf = (Game and Game.GetTeleportationFacility and Game.GetTeleportationFacility()) or nil
  if not tf then return end
  pcall(function() tf:Teleport(handle, pos, rot) end)
end

local function _lockPlayerAnchor()
  local s = CameraActions.state
  local p = _player()
  if not p then
    s.playerLockPos = nil
    s.playerLockRot = nil
    return
  end
  s.playerLockPos = _clonePos(p:GetWorldPosition())
  s.playerLockRot = _getPlayerEuler(p)
end

local function _clearPlayerAnchor()
  local s = CameraActions.state
  s.playerLockPos = nil
  s.playerLockRot = nil
end

local function _trackCameraMovement(now)
  local s = CameraActions.state
  if not s.active or not s.handle then return end
  local pos = _clonePos(s.handle:GetWorldPosition())
  if not pos then return end
  if not s.lastPos then
    s.lastPos = pos
    s.lastMoveAt = now or _now()
    return
  end
  if _distSq(pos, s.lastPos) > 0.00001 then
    s.lastMoveAt = now or _now()
  end
  s.lastPos = pos
end

local function _checkAutoDisable()
  local s = CameraActions.state
  if not s.active then return false end

  local mode = _normalizeDisableMode(s.disableMode)
  if mode == "manual" then return false end

  local now = _now()
  local startedAt = tonumber(s.sessionStartedAt or 0) or 0
  local lastMoveAt = tonumber(s.lastMoveAt or startedAt) or startedAt
  if startedAt <= 0 then
    _beginSessionTracking()
    startedAt = tonumber(s.sessionStartedAt or now) or now
    lastMoveAt = tonumber(s.lastMoveAt or now) or now
  end

  local afterSeconds = _clampAutoSeconds(s.disableAfterSeconds, 5.0)
  local stillSeconds = _clampAutoSeconds(s.disableStillSeconds, 3.0)
  local elapsed = now - startedAt
  local stillElapsed = now - lastMoveAt

  local hitTime = (mode == "after_time" or mode == "either") and elapsed >= afterSeconds
  local hitStill = (mode == "while_still" or mode == "either") and stillElapsed >= stillSeconds
  if not hitTime and not hitStill then return false end

  local reason = nil
  if hitTime and hitStill then
    reason = string.format("Camera auto-disabled after %.2f sec / still %.2f sec", elapsed, stillElapsed)
  elseif hitTime then
    reason = string.format("Camera auto-disabled after %.2f sec", elapsed)
  else
    reason = string.format("Camera auto-disabled after being still %.2f sec", stillElapsed)
  end

  _disableCamera()
  _log(reason)
  return true
end

local function _holdPlayerStill()
  local s = CameraActions.state
  if not s.active or s.noClip then return end
  local p = _player()
  if not p or not s.playerLockPos then return end
  local current = p:GetWorldPosition()
  if _distSq(current, s.playerLockPos) > 0.0004 then
    _teleportEntity(p, s.playerLockPos, s.playerLockRot or _getPlayerEuler(p))
  end
end

local function _tetherPlayerToCamera()
  local s = CameraActions.state
  if not s.active or not s.noClip then return end
  local p = _player()
  if not p or not s.handle then return end
  local camPos = s.handle:GetWorldPosition()
  local targetPos = Vector4.new(camPos.x, camPos.y, camPos.z + (s.noClipZOffset or 0.0), camPos.w)
  local current = p:GetWorldPosition()
  if _distSq(current, targetPos) > 0.0004 then
    _teleportEntity(p, targetPos, s.playerLockRot or _getPlayerEuler(p))
  end
end

local function _isBlockedAction(actionName)
  return actionName == "MoveX"
    or actionName == "MoveY"
    or actionName == "Forward"
    or actionName == "Back"
    or actionName == "Left"
    or actionName == "Right"
    or actionName == "Jump"
    or actionName == "Crouch"
    or actionName == "ToggleSprint"
    or actionName == "Sprint"
    or actionName == "CameraMouseX"
    or actionName == "CameraMouseY"
    or actionName == "CameraX"
    or actionName == "CameraY"
    or actionName == "PhotoMode_CameraMovementX"
    or actionName == "PhotoMode_CameraMovementY"
    or actionName == "PhotoMode_CameraMouseX"
    or actionName == "PhotoMode_CameraMouseY"
    or actionName == "PhotoMode_CameraRotationX"
    or actionName == "PhotoMode_CameraRotationY"
    or actionName == "PhotoMode_CraneUp"
    or actionName == "PhotoMode_CraneDown"
    or actionName == "right_trigger"
    or actionName == "left_trigger"
    or actionName == "Attack"
    or actionName == "Shoot"
    or actionName == "RangedAttack"
    or actionName == "MeleeAttack"
    or actionName == "Reload"
    or actionName == "Aim"
    or actionName == "ToggleAim"
end

local function _deactivateCamera()
  local s = CameraActions.state
  if s.component then
    pcall(function() s.component:Deactivate(0, false) end)
  end
  local p = _player()
  if p and p.GetFPPCameraComponent then
    pcall(function() p:GetFPPCameraComponent():Activate() end)
  end
  s.active = false
  _resetDirections()
  _clearPlayerAnchor()
  _resetSessionTracking()
  _log("Returned to player camera")
end

local function _disposeCamera()
  local s = CameraActions.state
  if s.handle then
    pcall(function() s.handle:Dispose() end)
  end
  s.entityID = nil
  s.handle = nil
  s.component = nil
  s.spawned = false
  s.pendingBind = false
  s.active = false
  _resetDirections()
  _clearPlayerAnchor()
  _resetSessionTracking()
  _log("Camera disposed")
end

local function _applySettings(options)
  local s = CameraActions.state
  options = options or {}

  local mode = tostring(options.mode or (s.noClip and "noclip" or "detached"))
  s.noClip = (mode == "noclip")

  local speed = tonumber(options.speed or s.speed) or s.speed or 0.18
  if speed < 0.02 then speed = 0.02 end
  if speed > 1.00 then speed = 1.00 end
  s.speed = speed

  local zoff = tonumber(options.noClipZOffset or s.noClipZOffset) or s.noClipZOffset or 0.0
  if zoff < -2.0 then zoff = -2.0 end
  if zoff > 2.0 then zoff = 2.0 end
  s.noClipZOffset = zoff

  local fov = tonumber(options.fov or s.fov) or s.fov or 60.0
  if fov < 20.0 then fov = 20.0 end
  if fov > 120.0 then fov = 120.0 end
  s.fov = fov

  s.disableMode = _normalizeDisableMode(options.disableMode or s.disableMode)
  s.disableAfterSeconds = _clampAutoSeconds(options.disableAfterSeconds or s.disableAfterSeconds, 5.0)
  s.disableStillSeconds = _clampAutoSeconds(options.disableStillSeconds or s.disableStillSeconds, 3.0)

  if s.component then
    pcall(function() s.component:SetZoom(s.zoom) end)
    pcall(function() s.component:SetFOV(s.fov) end)
  end

  if s.active and not s.noClip then
    _lockPlayerAnchor()
  end
end

local function _bindSpawnedCamera()
  local s = CameraActions.state
  if not s.pendingBind or not s.entityID then return end
  local ok, ent = pcall(function() return Game.FindEntityByID(s.entityID) end)
  if not ok or not ent then return end

  local comp = nil
  local compOk, compRes = pcall(function() return ent:FindComponentByName("camera") end)
  if compOk then comp = compRes end
  if not comp then
    s.pendingBind = false
    _log("Spawned entity has no camera component")
    return
  end

  s.handle = ent
  s.component = comp
  s.pendingBind = false
  pcall(function() s.component:SetZoom(s.zoom) end)
  pcall(function() s.component:SetFOV(s.fov) end)
  pcall(function() s.component:Activate(0, false) end)
  s.active = true
  _lockPlayerAnchor()
  _beginSessionTracking()
  _log(s.noClip and "Camera active (No Clip)" or "Camera active")
end

local function _ensureCameraOn(options)
  local s = CameraActions.state
  _applySettings(options)

  if s.active and s.handle and s.component then
    pcall(function() s.component:Activate(0, false) end)
    s.active = true
    if not s.noClip then _lockPlayerAnchor() end
    local token = _getOrCreateSessionToken()
    return true, (s.noClip and "Camera active (No Clip)" or "Camera active"), { pendingType = "camera_session", token = token }
  end

  if s.pendingBind and s.entityID then
    local token = _getOrCreateSessionToken()
    return true, "Camera spawn pending", { pendingType = "camera_session", token = token }
  end

  local p = _player()
  if not p then return false, "Player unavailable" end
  if not exEntitySpawner then return false, "exEntitySpawner not available" end

  local transform = p:GetWorldTransform()
  local pos = p:GetWorldPosition()
  local fwd = p:GetWorldForward()
  local spawnPos = Vector4.new(pos.x + fwd.x * 1.2, pos.y + fwd.y * 1.2, pos.z + 1.5, pos.w)
  transform:SetPosition(spawnPos)

  local ok, id = pcall(function()
    return exEntitySpawner.Spawn(s.path, transform, '')
  end)
  if not ok or not id then
    return false, "Spawn failed"
  end

  s.entityID = id
  s.pendingBind = true
  s.spawned = true
  local token = _nextSessionToken()
  _log("Spawned camera, waiting for bind...")
  return true, "Spawned camera", { pendingType = "camera_session", token = token }
end

_disableCamera = function()
  local s = CameraActions.state
  if not s.active and not s.pendingBind and not s.handle then
    return true, "Camera already off"
  end
  local finishedToken = math.floor(tonumber(s.currentSessionToken or 0) or 0)
  _deactivateCamera()
  _disposeCamera()
  if finishedToken > 0 then
    s.completedSessions[finishedToken] = true
    if s.currentSessionToken == finishedToken then s.currentSessionToken = 0 end
  end
  return true, "Camera disabled"
end

local function _handleInput(_self, action)
  local s = CameraActions.state
  if not s.active or not action then return end

  local okName, actionName = pcall(function() return Game.NameToString(action:GetName(action)) end)
  local okType, actionType = pcall(function() return action:GetType(action).value end)
  if not okName or not okType or not actionName or not actionType then return end

  local val = 0
  local okVal, rawVal = pcall(function() return action:GetValue(action) end)
  if okVal and type(rawVal) == "number" then val = rawVal end

  if actionName == "MoveX" or actionName == "PhotoMode_CameraMovementX" then
    if val < 0 then
      s.dir.left = true
      s.dir.right = false
      s.analog.left = -val
      s.analog.right = 0
    elseif val > 0 then
      s.dir.right = true
      s.dir.left = false
      s.analog.right = val
      s.analog.left = 0
    else
      s.dir.left = false
      s.dir.right = false
      s.analog.left = 0
      s.analog.right = 0
    end

  elseif actionName == "MoveY" or actionName == "PhotoMode_CameraMovementY" then
    if val < 0 then
      s.dir.backwards = true
      s.dir.forward = false
      s.analog.backwards = -val
      s.analog.forward = 0
    elseif val > 0 then
      s.dir.forward = true
      s.dir.backwards = false
      s.analog.forward = val
      s.analog.backwards = 0
    else
      s.dir.backwards = false
      s.dir.forward = false
      s.analog.backwards = 0
      s.analog.forward = 0
    end

  elseif actionName == "Jump" or ((actionName == "right_trigger" or actionName == "PhotoMode_CraneUp") and actionType == "AXIS_CHANGE") then
    if val == 0 or actionType == "BUTTON_RELEASED" then
      s.dir.up = false
      s.analog.up = 0
    else
      s.dir.up = true
      s.analog.up = (val ~= 0 and val or 1)
    end

  elseif actionName == "ToggleSprint" or actionName == "Sprint" or ((actionName == "left_trigger" or actionName == "PhotoMode_CraneDown") and actionType == "AXIS_CHANGE") then
    if val == 0 or actionType == "BUTTON_RELEASED" then
      s.dir.down = false
      s.analog.down = 0
    else
      s.dir.down = true
      s.analog.down = (val ~= 0 and val or 1)
    end
  end

  if actionName == "Forward" then
    if actionType == "BUTTON_PRESSED" then
      s.dir.forward = true
      s.analog.forward = 1
    elseif actionType == "BUTTON_RELEASED" then
      s.dir.forward = false
      s.analog.forward = 0
    end
  elseif actionName == "Back" then
    if actionType == "BUTTON_PRESSED" then
      s.dir.backwards = true
      s.analog.backwards = 1
    elseif actionType == "BUTTON_RELEASED" then
      s.dir.backwards = false
      s.analog.backwards = 0
    end
  elseif actionName == "Right" then
    if actionType == "BUTTON_PRESSED" then
      s.dir.right = true
      s.analog.right = 1
    elseif actionType == "BUTTON_RELEASED" then
      s.dir.right = false
      s.analog.right = 0
    end
  elseif actionName == "Left" then
    if actionType == "BUTTON_PRESSED" then
      s.dir.left = true
      s.analog.left = 1
    elseif actionType == "BUTTON_RELEASED" then
      s.dir.left = false
      s.analog.left = 0
    end
  elseif actionName == "DescriptionChange" or actionName == "PhotoMode_Next_Menu" then
    if actionType == "BUTTON_PRESSED" then
      s.dir.rotateRight = true
    elseif actionType == "BUTTON_RELEASED" then
      s.dir.rotateRight = false
    end
  elseif actionName == "Ping" or actionName == "PhotoMode_Prior_Menu" then
    if actionType == "BUTTON_PRESSED" then
      s.dir.rotateLeft = true
    elseif actionType == "BUTTON_RELEASED" then
      s.dir.rotateLeft = false
    end
  end

  local rot = nil
  if actionName == "CameraMouseX" or actionName == "CameraX" or actionName == "PhotoMode_CameraMouseX" or actionName == "PhotoMode_CameraRotationX" then
    local factor = 0.5
    if actionName == "CameraMouseX" or actionName == "PhotoMode_CameraMouseX" then factor = 45 end
    if s.zoom > 0 then factor = factor * s.zoom end
    if s.component then
      local okRot, r = pcall(function() return s.component:GetLocalOrientation():ToEulerAngles() end)
      if okRot and r then
        rot = r
        rot.yaw = rot.yaw - (val / factor)
      end
    end
  end

  if actionName == "CameraMouseY" or actionName == "CameraY" or actionName == "PhotoMode_CameraMouseY" or actionName == "PhotoMode_CameraRotationY" then
    local factor = 0.5
    if actionName == "CameraMouseY" or actionName == "PhotoMode_CameraMouseY" then factor = 45 end
    if s.zoom > 0 then factor = factor * s.zoom end
    if s.component then
      local okRot, r = pcall(function() return s.component:GetLocalOrientation():ToEulerAngles() end)
      if okRot and r then
        rot = r
        local newPitch = rot.pitch + (val / factor)
        rot.pitch = math.max(-85, math.min(85, newPitch))
      end
    end
  end

  if rot and s.component then
    pcall(function() s.component:SetLocalOrientation(rot:ToQuat()) end)
  end
end

local function _moveCamera()
  local s = CameraActions.state
  if not s.active or not s.handle then return end
  local speed = tonumber(s.speed) or 0.18

  local pos = s.handle:GetWorldPosition()
  local newPos = Vector4.new(pos.x, pos.y, pos.z, pos.w)

  local function _calc(direction)
    local step = speed
    if direction == "forward" then step = step * ((s.analog.forward > 0) and s.analog.forward or 1)
    elseif direction == "backwards" then step = step * ((s.analog.backwards > 0) and s.analog.backwards or 1)
    elseif direction == "right" then step = step * ((s.analog.right > 0) and s.analog.right or 1)
    elseif direction == "left" then step = step * ((s.analog.left > 0) and s.analog.left or 1)
    elseif direction == "up" then step = step * ((s.analog.up > 0) and s.analog.up or 1)
    elseif direction == "down" then step = step * ((s.analog.down > 0) and s.analog.down or 1) end

    local dir = nil
    if direction == "forward" or direction == "backwards" then
      dir = Game.GetCameraSystem():GetActiveCameraForward()
    elseif direction == "right" or direction == "left" then
      dir = Game.GetCameraSystem():GetActiveCameraRight()
    end

    if direction == "forward" or direction == "right" then
      newPos.x = newPos.x + (dir.x * step)
      newPos.y = newPos.y + (dir.y * step)
      newPos.z = newPos.z + (dir.z * step)
    elseif direction == "backwards" or direction == "left" then
      newPos.x = newPos.x - (dir.x * step)
      newPos.y = newPos.y - (dir.y * step)
      newPos.z = newPos.z - (dir.z * step)
    elseif direction == "up" then
      newPos.z = newPos.z + (0.7 * step)
    elseif direction == "down" then
      newPos.z = newPos.z - (0.7 * step)
    elseif direction == "rotateLeft" or direction == "rotateRight" then
      if s.component then
        local okRot, rot = pcall(function() return s.component:GetLocalOrientation():ToEulerAngles() end)
        if okRot and rot then
          local delta = 7 * step
          if direction == "rotateLeft" then rot.roll = rot.roll - delta else rot.roll = rot.roll + delta end
          pcall(function() s.component:SetLocalOrientation(rot:ToQuat()) end)
        end
      end
    end
  end

  for k, state in pairs(s.dir) do
    if state then _calc(k) end
  end

  _teleportEntity(s.handle, newPos, _getEuler(s.handle))
end

function CameraActions.IsActive()
  return CameraActions.state.active == true
end

function CameraActions.IsSessionComplete(token)
  local s = CameraActions.state
  token = math.floor(tonumber(token or 0) or 0)
  if token <= 0 then return true end
  return s.completedSessions[token] == true
end

function CameraActions.Execute(action)
  action = action or {}
  if CameraActions.state.hooksInstalled ~= true then
    pcall(_installHooks)
  end
  local command = tostring(action.command or "on")
  if command ~= "off" and command ~= "toggle" then command = "on" end

  if command == "off" then
    return _disableCamera()
  elseif command == "toggle" then
    if CameraActions.state.active or CameraActions.state.pendingBind then
      return _disableCamera()
    end
    return _ensureCameraOn(action)
  end

  local success, message, pending = _ensureCameraOn(action)
  if success and _normalizeDisableMode(action.disableMode or CameraActions.state.disableMode) == "manual" then
    pending = nil
  end
  return success, message, pending
end

function CameraActions.OnUpdate(_delta)
  if CameraActions.state.hooksInstalled ~= true then
    pcall(_installHooks)
  end
  _bindSpawnedCamera()
  _moveCamera()
  _trackCameraMovement(_now())
  if _checkAutoDisable() then
    return
  end
  if CameraActions.state.noClip then
    _tetherPlayerToCamera()
  else
    _holdPlayerStill()
  end
end

_installHooks = function()
  local s = CameraActions.state
  if s.hooksInstalled == true then return true end

  local installedAny = false
  local errors = {}

  local function _rememberError(prefix, err)
    errors[#errors + 1] = tostring(prefix) .. tostring(err)
  end

  if type(Observe) == "function" and not s.observeInstalled then
    local ok, err = pcall(function()
      Observe("PlayerPuppet", "OnAction", function(self, action)
        if CameraActions.state.active then
          _handleInput(self, action)
        end
      end)
    end)
    if ok then
      s.observeInstalled = true
      installedAny = true
    else
      _rememberError("Observe failed: ", err)
    end
  elseif s.observeInstalled then
    installedAny = true
  end

  if type(Override) == "function" and not s.overrideInstalled then
    local ok, err = pcall(function()
      Override("PlayerPuppet", "OnAction", function(self, action, ...)
        local argc = select('#', ...)
        local wrapped = argc >= 1 and select(argc, ...) or nil
        local okName, actionName = pcall(function() return Game.NameToString(action:GetName(action)) end)
        if CameraActions.state.active then
          _handleInput(self, action)
          if okName and actionName and _isBlockedAction(actionName) then
            return
          end
        end
        if type(wrapped) == "function" then
          local pass = { action }
          for i = 1, math.max(0, argc - 1) do
            pass[#pass + 1] = select(i, ...)
          end
          return wrapped(table.unpack(pass, 1, #pass))
        end
        return nil
      end)
    end)
    if ok then
      s.overrideInstalled = true
      installedAny = true
    else
      _rememberError("Override failed: ", err)
    end
  elseif s.overrideInstalled then
    installedAny = true
  end

  s.hooksInstalled = installedAny
  if installedAny then
    _log("Camera action hooks ready")
    return true
  end

  _log("Camera hook install pending")
  return false, table.concat(errors, " | ")
end

registerForEvent("onInit", function()
  local ok, err = pcall(_installHooks)
  if not ok then
    CameraActions.state.hooksInstalled = false
    _log("Camera hook install failed: " .. tostring(err))
  end
end)

local _eagerOk, _eagerErr = pcall(_installHooks)
if not _eagerOk then
  CameraActions.state.hooksInstalled = false
  _log("Camera eager hook install deferred: " .. tostring(_eagerErr))
end

return CameraActions
