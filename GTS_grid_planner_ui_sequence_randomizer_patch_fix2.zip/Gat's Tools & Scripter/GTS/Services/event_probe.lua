local EventProbe = EventProbe or {}

local GLOBAL_KEY = "__GTS_EVENT_PROBE_STATE"
local DEFAULT_METHODS = {"OnEnter", "OnExit", "OnForcedExit", "OnUpdate"}
local PULSE_WINDOW = 0.35

local function _ensureGlobalState()
  _G[GLOBAL_KEY] = _G[GLOBAL_KEY] or {
    version = 1,
    pulseWindow = PULSE_WINDOW,
    registered = false,
    registerMode = "",
    lastRegisterError = "",
    ui = {compact=false, colors=true},
    entriesOrder = {},
    entriesByKey = {},
  }
  return _G[GLOBAL_KEY]
end

local State = _ensureGlobalState()

local EVENT_NAMES = {
  "SandevistanEvents",
  "KerenzikovEvents",
  "TimeDilationFocusModeEvents",
  "FallEvents",
  "HardLandEvents",
  "AbstractLandEvents",
  "SuperheroFallEvents",
  "SuperheroLandEvents",
  "SuperheroLandRecoveryEvents",
  "VaultEvents",
  "ClimbEvents",
  "LadderEvents",
  "LadderSprintEvents",
  "LadderSlideEvents",
  "EquippedEvents",
  "UnequippedEvents",
  "EmptyHandsEvents",
  "FullAutoEvents",
  "SemiAutoEvents",
  "BurstEvents",
  "ChargeEvents",
  "ChargeReadyEvents",
  "ChargeMaxEvents",
  "DischargeEvents",
  "DoubleJumpEvents",
  "TakedownBeginEvents",
  "TakedownEndEvents",
  "TakedownGrapplePreyEvents",
  "TakedownLeapToPreyEvents",
  "GrappleStandEvents",
  "GrappleStruggleEvents",
  "KnockdownEvents",
  "HoverJumpEvents",
}

local function _now()
  if type(os) == "table" and type(os.clock) == "function" then return os.clock() end
  return 0
end

local function _safeToString(v)
  local ok, text = pcall(function() return tostring(v) end)
  text = ok and text or "<tostring error>"
  text = string.gsub(text or "", "[\r\n\t]", " ")
  if #text > 80 then text = string.sub(text, 1, 77) .. "..." end
  return text
end

local function _formatAgo(ts)
  if type(ts) ~= "number" or ts <= 0 then return "-" end
  local dt = _now() - ts
  if dt < 0 then dt = 0 end
  return string.format("%.2fs ago", dt)
end

local function _entryTitle(name)
  return tostring(name or "Event")
end

local function _ensureEntry(name)
  local key = tostring(name or "")
  if key == "" then return nil end
  local entry = State.entriesByKey[key]
  if entry then return entry end
  entry = {
    key = key,
    label = _entryTitle(key),
    active = false,
    lastFireAt = 0,
    lastActiveAt = 0,
    lastInactiveAt = 0,
    pulseUntil = 0,
    lastMethod = "",
    lastArgs = "",
    totalCount = 0,
    counts = {},
    registeredMethods = {},
    failedMethods = {},
    modeByMethod = {},
    detailOpen = false,
  }
  for i=1,#DEFAULT_METHODS do entry.counts[DEFAULT_METHODS[i]] = 0 end
  State.entriesByKey[key] = entry
  State.entriesOrder[#State.entriesOrder + 1] = key
  return entry
end

for i=1,#EVENT_NAMES do _ensureEntry(EVENT_NAMES[i]) end

local function _liveValue(entry)
  if not entry then return false end
  if entry.active == true then return true end
  return type(entry.pulseUntil) == "number" and entry.pulseUntil > _now()
end

local function _captureArgs(...)
  local n = select('#', ...)
  if n <= 0 then return "(no args)" end
  local parts = {}
  local limit = n
  if limit > 4 then limit = 4 end
  for i=1,limit do
    parts[#parts + 1] = _safeToString(select(i, ...))
  end
  if n > limit then parts[#parts + 1] = "+" .. tostring(n - limit) .. " more" end
  return table.concat(parts, " | ")
end

local function _markEvent(className, methodName, ...)
  local entry = _ensureEntry(className)
  if not entry then return end
  local now = _now()
  methodName = tostring(methodName or "")
  entry.totalCount = (tonumber(entry.totalCount or 0) or 0) + 1
  entry.counts[methodName] = (tonumber(entry.counts[methodName] or 0) or 0) + 1
  entry.lastFireAt = now
  entry.lastMethod = methodName
  entry.lastArgs = _captureArgs(...)
  entry.pulseUntil = now + (tonumber(State.pulseWindow or PULSE_WINDOW) or PULSE_WINDOW)
  if methodName == "OnEnter" then
    entry.active = true
    entry.lastActiveAt = now
  elseif methodName == "OnExit" or methodName == "OnForcedExit" then
    entry.active = false
    entry.lastInactiveAt = now
  end
end

local function _registerOne(className, methodName)
  if type(Observe) == "function" then
    local ok, err = pcall(function()
      Observe(className, methodName, function(...)
        _markEvent(className, methodName, ...)
      end)
    end)
    if ok then return true, "Observe" end
    if type(ObserveAfter) == "function" then
      local ok2, err2 = pcall(function()
        ObserveAfter(className, methodName, function(...)
          _markEvent(className, methodName, ...)
        end)
      end)
      if ok2 then return true, "ObserveAfter" end
      return false, tostring(err2 or err)
    end
    return false, tostring(err)
  elseif type(ObserveAfter) == "function" then
    local ok, err = pcall(function()
      ObserveAfter(className, methodName, function(...)
        _markEvent(className, methodName, ...)
      end)
    end)
    if ok then return true, "ObserveAfter" end
    return false, tostring(err)
  end
  return false, "Observe / ObserveAfter unavailable"
end

function EventProbe.OnInit()
  if State.registered == true then return end
  local successCount = 0
  local failureCount = 0
  for i=1,#State.entriesOrder do
    local key = State.entriesOrder[i]
    local entry = State.entriesByKey[key]
    if entry then
      for m=1,#DEFAULT_METHODS do
        local methodName = DEFAULT_METHODS[m]
        local ok, detail = _registerOne(entry.key, methodName)
        if ok then
          entry.registeredMethods[methodName] = true
          entry.modeByMethod[methodName] = tostring(detail or "Observe")
          successCount = successCount + 1
        else
          entry.failedMethods[methodName] = tostring(detail or "unknown error")
          failureCount = failureCount + 1
        end
      end
    end
  end
  State.registered = true
  State.registerMode = string.format("Registered %d hooks, %d failed", successCount, failureCount)
  State.lastRegisterError = failureCount > 0 and ("Some methods did not register. See details below.") or ""
end

function EventProbe.OnUpdate(_)
  if State.registered ~= true then
    EventProbe.OnInit()
  end
end

local function _drawValueText(text, isBoolTrue, isBool)
  if State.ui.colors then
    if isBool then
      if isBoolTrue then ImGui.PushStyleColor(ImGuiCol.Text, 0xFF00FF00) else ImGui.PushStyleColor(ImGuiCol.Text, 0xFF0000FF) end
    else
      ImGui.PushStyleColor(ImGuiCol.Text, 0xFFAAAAAA)
    end
  end
  ImGui.Text(text)
  if State.ui.colors then ImGui.PopStyleColor(1) end
end

local function _drawMiniRows(rows, childId, width, height)
  if ImGui.BeginChild(childId, width, height, false) then
    ImGui.Columns(2, childId .. "_cols", false)
    for i=1,#rows do
      local r = rows[i]
      ImGui.Text(r.label)
      ImGui.NextColumn()
      if r.isBool then
        _drawValueText(r.value and "TRUE" or "FALSE", r.value, true)
      else
        _drawValueText(tostring(r.value), false, false)
      end
      ImGui.NextColumn()
    end
    ImGui.Columns(1)
    ImGui.EndChild()
  end
end

local function _rowForEntry(entry)
  return {
    label = entry.label,
    isBool = true,
    value = _liveValue(entry),
  }
end

local function _drawDetails(entry, idx)
  local live = _liveValue(entry)
  if ImGui.CollapsingHeader(string.format("[%s] %s##event_probe_%d", live and "LIVE" or "IDLE", entry.label, idx)) then
    ImGui.Text("Current: " .. tostring(live and "TRUE" or "FALSE"))
    ImGui.Text("Total Fires: " .. tostring(entry.totalCount or 0))
    ImGui.Text("Last Method: " .. tostring(entry.lastMethod ~= "" and entry.lastMethod or "-"))
    ImGui.Text("Last Fire: " .. tostring(_formatAgo(entry.lastFireAt)))
    ImGui.Text("Last Set TRUE: " .. tostring(_formatAgo(entry.lastActiveAt)))
    ImGui.Text("Last Set FALSE: " .. tostring(_formatAgo(entry.lastInactiveAt)))
    if tostring(entry.lastArgs or "") ~= "" then
      ImGui.TextWrapped("Last Args: " .. tostring(entry.lastArgs or ""))
    end

    local reg = {}
    for _, methodName in ipairs(DEFAULT_METHODS) do
      if entry.registeredMethods[methodName] then
        reg[#reg + 1] = tostring(methodName) .. " (" .. tostring(entry.modeByMethod[methodName] or "Observe") .. ")"
      end
    end
    ImGui.TextWrapped("Registered: " .. (#reg > 0 and table.concat(reg, ", ") or "None"))

    local fail = {}
    for _, methodName in ipairs(DEFAULT_METHODS) do
      if entry.failedMethods[methodName] then
        fail[#fail + 1] = tostring(methodName)
      end
    end
    ImGui.TextWrapped("Failed: " .. (#fail > 0 and table.concat(fail, ", ") or "None"))

    ImGui.Separator()
    for _, methodName in ipairs(DEFAULT_METHODS) do
      ImGui.Text(string.format("%s Count: %s", tostring(methodName), tostring(entry.counts[methodName] or 0)))
    end
  end
end

function EventProbe.DrawTab(ui)
  ui = ui or {compact=false, colors=true}
  State.ui.compact = ui.compact == true
  State.ui.colors = ui.colors ~= false
  if State.registered ~= true then EventProbe.OnInit() end

  ImGui.TextWrapped("Standalone event probe for NativeDB event classes. This does not wire anything into GTS scripting; it only shows whether these classes are producing live event activity in CET.")
  ImGui.TextWrapped("Rows go TRUE when the event is active or when a pulse was seen recently. Use the details section below to see which methods registered and how many times each one fired.")
  ImGui.Separator()
  ImGui.Text("Hook Status: " .. tostring(State.registerMode ~= "" and State.registerMode or "Pending"))
  if tostring(State.lastRegisterError or "") ~= "" then
    ImGui.TextWrapped("Note: " .. tostring(State.lastRegisterError))
  end
  if ImGui.SmallButton("Clear Event Counts##event_probe_clear") then
    for i=1,#State.entriesOrder do
      local entry = State.entriesByKey[State.entriesOrder[i]]
      if entry then
        entry.active = false
        entry.lastFireAt = 0
        entry.lastActiveAt = 0
        entry.lastInactiveAt = 0
        entry.pulseUntil = 0
        entry.lastMethod = ""
        entry.lastArgs = ""
        entry.totalCount = 0
        for m=1,#DEFAULT_METHODS do entry.counts[DEFAULT_METHODS[m]] = 0 end
      end
    end
  end

  local rowsLeft, rowsRight = {}, {}
  local total = #State.entriesOrder
  local split = math.ceil(total * 0.5)
  for i=1,total do
    local entry = State.entriesByKey[State.entriesOrder[i]]
    if entry then
      local row = _rowForEntry(entry)
      if i <= split then rowsLeft[#rowsLeft + 1] = row else rowsRight[#rowsRight + 1] = row end
    end
  end

  local availW = ImGui.GetContentRegionAvail()
  local totalW = tonumber((type(availW) == "table" and availW.x) or availW) or tonumber(ImGui.GetWindowWidth and (ImGui.GetWindowWidth() - 36) or 0) or 600
  local gap = 20
  local colW = math.max(200, (totalW - gap) * 0.5)
  _drawMiniRows(rowsLeft, "event_probe_left", colW, 430)
  ImGui.SameLine()
  _drawMiniRows(rowsRight, "event_probe_right", 0, 430)

  ImGui.Separator()
  if ImGui.CollapsingHeader("Event Probe Details") then
    for i=1,#State.entriesOrder do
      local entry = State.entriesByKey[State.entriesOrder[i]]
      if entry then _drawDetails(entry, i) end
    end
  end
end

return EventProbe
