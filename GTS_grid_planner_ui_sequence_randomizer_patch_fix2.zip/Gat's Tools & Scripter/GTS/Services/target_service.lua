local TargetService = TargetService or {}

TargetService.state = TargetService.state or {
  refreshEvery = 0.05,
  _nextRefresh = 0,
  snapshot = {
    exists = false,
    isNPC = false,
    faction = nil,
    hostile = false,
    aggro = false,
    distance = 0,
    speed = 0,
    health = 0,
    className = nil,
    recordId = nil,
    appearance = nil,
    entityID = nil,
    xyz = { x = 0, y = 0, z = 0 },
    handle = nil,
  }
}

local function _pcall(fn)
  local ok, res = pcall(fn)
  if ok then return res end
  return nil
end

local function _len3(x, y, z)
  return math.sqrt((x * x) + (y * y) + (z * z))
end

local function _copy(src, seen)
  if type(src) ~= 'table' then return src end
  seen = seen or {}
  if seen[src] then return seen[src] end
  local out = {}
  seen[src] = out
  for k, v in pairs(src) do out[_copy(k, seen)] = _copy(v, seen) end
  return out
end

local function _reset(out)
  out.exists = false
  out.isNPC = false
  out.faction = nil
  out.hostile = false
  out.aggro = false
  out.distance = 0
  out.speed = 0
  out.health = 0
  out.className = nil
  out.recordId = nil
  out.appearance = nil
  out.entityID = nil
  out.xyz = { x = 0, y = 0, z = 0 }
  out.handle = nil
end

function TargetService.Refresh(force)
  local st = TargetService.state
  local now = os.clock()
  if not force and now < (st._nextRefresh or 0) then
    return st.snapshot
  end
  st._nextRefresh = now + (tonumber(st.refreshEvery or 0.05) or 0.05)

  local T = st.snapshot
  _reset(T)

  local p = Game.GetPlayer and Game.GetPlayer() or nil
  local ts = Game.GetTargetingSystem and Game.GetTargetingSystem() or nil
  if not p or not ts or type(ts.GetLookAtObject) ~= 'function' then return T end

  local o = _pcall(function() return ts:GetLookAtObject(p, false, false) end)
  if not o then
    o = _pcall(function() return ts:GetLookAtObject(p, true, false) end)
  end
  if not o then return T end

  T.handle = o
  T.exists = true

  do
    local cn = _pcall(function() return o:ToString() end)
    if (not cn or cn == '') and o.GetClassName then
      local cls = _pcall(function() return o:GetClassName() end)
      cn = cls and (cls.value or tostring(cls)) or nil
    end
    T.className = cn or 'Unknown'
    T.isNPC = (T.className == 'NPCPuppet')
  end

  do
    local rid = nil
    if o.GetRecordID then
      rid = _pcall(function()
        local r = o:GetRecordID()
        return r and TDBID and TDBID.ToStringDEBUG and TDBID.ToStringDEBUG(r) or tostring(r)
      end)
    end
    T.recordId = rid
  end

  T.entityID = _pcall(function() return o:GetEntityID() end)

  T.appearance = _pcall(function() return o:GetCurrentAppearanceName() end)

  do
    local faction = _pcall(function() return o:GetFactionID() end)
    if faction ~= nil then faction = tostring((type(faction) == 'table' and faction.value) or faction) end
    if (not faction or faction == '') and T.recordId then faction = T.recordId end
    T.faction = faction
  end

  do
    local hostile = false
    local att = _pcall(function() return GameObject.GetAttitudeTowards(o, p) end)
    if att ~= nil then
      local attText = tostring(att)
      if string.find(attText, 'Hostile', 1, true) or string.find(attText, 'AIA_Hostile', 1, true) then
        hostile = true
      elseif type(att) == 'number' and att > 1 then
        hostile = true
      end
    end
    if not hostile then hostile = (_pcall(function() return o:IsHostile() end) == true) end
    T.hostile = hostile == true
  end

  do
    local aggro = false
    if _pcall(function() return o:IsAggressive() end) == true then aggro = true end
    if not aggro and _pcall(function() return o:IsInCombat() end) == true then aggro = true end
    if not aggro and _pcall(function() return o:IsAlerted() end) == true then aggro = true end
    T.aggro = aggro == true
  end

  do
    local posP = _pcall(function() return p:GetWorldPosition() end)
    local posO = _pcall(function() return o:GetWorldPosition() end)
    if posO then T.xyz = { x = posO.x or 0, y = posO.y or 0, z = posO.z or 0 } end
    if posP and posO then
      local dx = (posP.x or 0) - (posO.x or 0)
      local dy = (posP.y or 0) - (posO.y or 0)
      local dz = (posP.z or 0) - (posO.z or 0)
      T.distance = math.sqrt(dx * dx + dy * dy + dz * dz)
    end
  end

  do
    local vel = _pcall(function() return o:GetVelocity() end)
    if vel then T.speed = _len3(vel.x or 0, vel.y or 0, vel.z or 0) end
  end

  do
    local sps = Game.GetStatPoolsSystem and Game.GetStatPoolsSystem() or nil
    local tid = _pcall(function() return o:GetEntityID() end)
    if sps and tid then
      T.health = _pcall(function() return sps:GetStatPoolValue(tid, gamedataStatPoolType.Health) end) or 0
    end
  end

  return T
end

function TargetService.GetSnapshot(force)
  return _copy(TargetService.Refresh(force))
end

function TargetService.GetHandle(force)
  local snap = TargetService.Refresh(force)
  return snap and snap.handle or nil
end

function TargetService.OnUpdate(_)
  TargetService.Refresh(false)
end

return TargetService
