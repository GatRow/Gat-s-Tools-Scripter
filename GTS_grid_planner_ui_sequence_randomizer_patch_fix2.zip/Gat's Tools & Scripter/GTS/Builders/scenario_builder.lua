
local ScenarioBuilder = ScenarioBuilder or {}

local AssetRegistry = require("GTS/Core/asset_registry")
local SpawnTools = require("GTS/Tools/spawn_tools")
local TargetService = require("GTS/Services/target_service")
local TargetControl = require("GTS/Tools/target_control")
local PoseBuilder = require("GTS/Builders/pose_builder")
local StatusActions = require("GTS/Actions/macro_actions_status")
local Equip = require("GTS/Actions/macro_actions_equipment")
local PlayerActions = require("GTS/Actions/macro_actions_player")
local World = require("GTS/Actions/macro_actions_world")
local Utils = require("GTS/Core/utils")

-- Scenario builder bookmark helper — uses global GTS_Bookmarks store
local function _scBmBtn(itemType, itemId, uid)
  if type(GTS_Bookmarks) ~= "table" then GTS_Bookmarks = {} end
  local on = GTS_Bookmarks[tostring(itemType)..":"..tostring(itemId)] ~= nil
  local gOn  = type(IconGlyphs)=="table" and (IconGlyphs["Bookmark"] or "*") or "*"
  local gOff = type(IconGlyphs)=="table" and (IconGlyphs["BookmarkOutline"] or "o") or "o"
  local lbl = (on and gOn or gOff) .. "##scbm_" .. tostring(uid or itemId)
  if ImGui.SmallButton(lbl) then
    local key = tostring(itemType)..":"..tostring(itemId)
    if on then GTS_Bookmarks[key] = nil
    else GTS_Bookmarks[key] = { type=tostring(itemType), id=tostring(itemId), label=tostring(itemId),
      savedAt=(os and os.date and os.date("%Y-%m-%d %H:%M")) or "" } end
    on = not on
    local ok, P = pcall(require, "GTS/Core/persistence")
    if ok and P and P.SaveBookmarks then pcall(P.SaveBookmarks) end
  end
  return on
end
local RuleRunner = require("GTS/Builders/rule_runner")

ScenarioBuilder.state = ScenarioBuilder.state or {
  name = "",
  mode = "relative", -- relative / absolute / anchored
  teleportPlayer = false,
  captureClothing = false,
  forceEquipCurrentWeapon = false,
  forceEquipWeapon = false,
  customWeaponId = "",
  captureTimeOfDay = false,
  frozenTime = false,
  captureJohnnyArm = false,
  playerState = {
    clothing = {},
    currentWeapon = "",
    weaponId = "",
    hour = 12,
    minute = 0,
    johnnyArmOn = false,
  },
  origin = { x = 0, y = 0, z = 0, yaw = 0 },
  entities = {},
  selectedIndex = 0,
  savedSelectedId = nil,
  loadedAssetId = nil,
  status = "Ready.",
  pendingFinalize = {},
  runtimeJobs = {},
  scenarioSpawnedIds = {},  -- entityIDs spawned by the last ApplyScenarioAsset run
  deathWatchers = {},       -- { entityID, scriptId, fired } for on-death script triggers
  _nextHealthPoll = 0,      -- throttle health reads to every 0.25s
  liveNudge = 0.10,
  yawNudge = 15,
  appendCapture = false,
  targetForge = {
    pos = { x = 0, y = 0, z = 0, w = 1 },
    yaw = 0,
    appearanceSearch = '',
    appearanceSelected = '',
    statusSearch = '',
    statusSelected = '',
    manualStatusId = '',
    action = { sourceMode = 'pose_db', rig = 'Man Average', poseSearch = '', poseName = '', instant = true, freezeAfterSeconds = 0, stopAfterSeconds = 0 },
    previewResetAnimation = false,
    previewResetAnimationAfter = 2.0,
    previewRestoreAppearance = false,
    previewRestoreAppearanceAfter = 2.0,
    previewRemoveStatus = false,
    previewRemoveStatusAfter = 2.0,
  },
  timeline = { playing = false, startedAt = 0, duration = 0, playhead = 0, events = {} },
  quickSpawn = {
    mode = 'Character',
    search = '',
    selectedIndex = 1,
    spawnLocation = 'in_front',
    customXYZ = { x = '0', y = '0', z = '0' },
    dangerPopupOpen = false,
    pendingDanger = nil,
  },
  spawnCaptureOpen = false,   -- whether the spawn-picker popup is open
  spawnCaptureChecked = {},   -- [spawnId] = true/false checkbox state
  suppressedWarnings = {},    -- [entryId] = true when player dismisses location warning
}

local sb_clone = Utils.clone
local sb_inputText = Utils.inputTextValue
local sb_checkbox = Utils.checkboxValue

local function sb_trim(s)
  s = tostring(s or '')
  return s:match('^%s*(.-)%s*$') or s
end

local function sb_basename(s)
  s = tostring(s or '')
  -- Strip TweakDB prefix path (e.g. "Character.gang_maelstrom_mace" -> "gang_maelstrom_mace")
  local dot = s:match('%.([^%.]+)$')
  if dot and dot ~= '' then return dot end
  -- Strip file path separators
  local slash = s:match('[/\\]([^/\\]+)$')
  if slash and slash ~= '' then return slash end
  return s ~= '' and s or '(unnamed)'
end

local function sb_combo(label, current, values)
  local idx = 0
  for i = 1, #values do
    if values[i].id == current or values[i] == current then idx = i - 1 break end
  end
  local labels = {}
  for i = 1, #values do labels[i] = values[i].label or values[i] end
  local changed, newIdx = ImGui.Combo(label, idx, labels, #labels)
  local outIdx = nil
  if type(changed) == 'boolean' then
    if not changed then return current end
    outIdx = (newIdx or idx) + 1
  elseif type(changed) == 'number' then
    outIdx = changed + 1
  end
  local chosen = values[outIdx or (idx + 1)]
  return (type(chosen) == 'table' and chosen.id) or chosen or current
end

local function sb_safePlayer()
  local ok, p = pcall(function() return Game.GetPlayer() end)
  return ok and p or nil
end

local function sb_sameEntity(a, b)
  if not a or not b then return false end
  local okA, ida = pcall(function() return a:GetEntityID() end)
  local okB, idb = pcall(function() return b:GetEntityID() end)
  return okA and okB and tostring(ida) == tostring(idb)
end

local function sb_getQuaternion()
  if not GetSingleton then return nil end
  local ok, q = pcall(function() return GetSingleton('Quaternion') end)
  return ok and q or nil
end

local function sb_readEuler(handle)
  if not handle then return EulerAngles.new(0, 0, 0) end
  local ok, ori = pcall(function() return handle:GetWorldOrientation() end)
  if ok and ori then
    local q = sb_getQuaternion()
    if q and q.ToEulerAngles then
      local ok2, ea = pcall(function() return q:ToEulerAngles(ori) end)
      if ok2 and ea then return ea end
    end
  end
  return EulerAngles.new(0, 0, 0)
end

local function sb_yaw(handle)
  local ea = sb_readEuler(handle)
  return tonumber(ea and ea.yaw or 0) or 0
end

local function sb_pos(handle)
  if not handle then return nil end
  -- Never pre-check fields like handle.GetWorldPosition — on a partially-initialized
  -- entity this reads a null vtable offset and crashes. Use pcall for everything.
  local ok, pos = pcall(function() return handle:GetWorldPosition() end)
  if not ok or not pos then
    ok, pos = pcall(function() return handle:GetPosition() end)
  end
  if not ok or not pos then return nil end
  return {
    x = tonumber(pos.x or pos.X or 0) or 0,
    y = tonumber(pos.y or pos.Y or 0) or 0,
    z = tonumber(pos.z or pos.Z or 0) or 0,
    w = tonumber(pos.w or pos.W or 1) or 1,
  }
end

local function sb_entityId(handle)
  if not handle then return nil end
  local ok, eid = pcall(function() return handle:GetEntityID() end)
  return ok and eid or nil
end

local function sb_isHandleReady(handle)
  -- Safely test that the entity's C++ object is fully initialized before
  -- touching any fields. Field access on a partially-initialized entity
  -- (e.g. right after CreateEntity + FindEntityByID) reads a null vtable
  -- pointer and causes EXCEPTION_ACCESS_VIOLATION at 0xB0.
  if not handle then return false end
  local ok, eid = pcall(function() return handle:GetEntityID() end)
  if not ok or eid == nil then return false end
  -- A second safe probe: GetWorldPosition must succeed without error.
  local ok2 = pcall(function()
    if handle.GetWorldPosition then handle:GetWorldPosition() end
  end)
  return ok2 == true
end

local function sb_teleportHandle(handle, pos, yaw)
  if not handle or not pos then return false, "Missing handle or position" end
  -- Guard: never touch handle fields/methods unless the entity is fully ready
  if not sb_isHandleReady(handle) then return false, "Entity not ready" end
  local tf = (Game and Game.GetTeleportationFacility and Game.GetTeleportationFacility()) or nil
  local dest = Vector4.new(
    tonumber(pos.x or 0) or 0,
    tonumber(pos.y or 0) or 0,
    tonumber(pos.z or 0) or 0,
    tonumber(pos.w or 1) or 1)
  local ori = EulerAngles.new(0, 0, tonumber(yaw or 0) or 0)
  local moved = false
  if tf then
    local ok = pcall(function() tf:Teleport(handle, dest, ori) end)
    if ok then moved = true end
  end
  if not moved then
    -- Fallback: SetWorldPosition (safe because isHandleReady passed)
    local ok2 = pcall(function()
      if handle.SetWorldPosition then handle:SetWorldPosition(dest) end
    end)
    moved = ok2
  end
  return moved, nil
end

local function sb_teleportPlayer(pos, yaw)
  local p = sb_safePlayer()
  if not p then return false, "Player unavailable" end
  return sb_teleportHandle(p, pos, yaw)
end

local function sb_rotateOffset(dx, dy, yawDeg)
  local r = math.rad(tonumber(yawDeg or 0) or 0)
  local c, s = math.cos(r), math.sin(r)
  return (dx * c) - (dy * s), (dx * s) + (dy * c)
end

local function sb_worldFromRelative(origin, rel)
  local rx, ry = sb_rotateOffset(tonumber(rel.x or 0) or 0, tonumber(rel.y or 0) or 0, tonumber(origin.yaw or 0) or 0)
  return {
    x = (tonumber(origin.x or 0) or 0) + rx,
    y = (tonumber(origin.y or 0) or 0) + ry,
    z = (tonumber(origin.z or 0) or 0) + (tonumber(rel.z or 0) or 0),
    w = 1,
  }
end

local function sb_relativeFromWorld(origin, world)
  local dx = (tonumber(world.x or 0) or 0) - (tonumber(origin.x or 0) or 0)
  local dy = (tonumber(world.y or 0) or 0) - (tonumber(origin.y or 0) or 0)
  local r = math.rad(-(tonumber(origin.yaw or 0) or 0))
  local c, s = math.cos(r), math.sin(r)
  return {
    x = (dx * c) - (dy * s),
    y = (dx * s) + (dy * c),
    z = (tonumber(world.z or 0) or 0) - (tonumber(origin.z or 0) or 0),
  }
end

local function sb_currentPlayerOrigin()
  local p = sb_safePlayer()
  if not p then return { x = 0, y = 0, z = 0, yaw = 0 } end
  local pos = sb_pos(p) or { x = 0, y = 0, z = 0, w = 1 }
  return { x = pos.x, y = pos.y, z = pos.z, yaw = sb_yaw(p) }
end

local function sb_sequenceAssets()
  local assets = (AssetRegistry.List and AssetRegistry.List('animation_sequence')) or {}
  table.sort(assets, function(a, b) return tostring(a.name or a.id or ''):lower() < tostring(b.name or b.id or ''):lower() end)
  return assets
end

local function sb_captureSequenceAsset(ref)
  if not ref or not AssetRegistry.Get then return nil end
  local asset = AssetRegistry.Get(ref)
  if type(asset) == 'table' and tostring(asset.type or '') == 'animation_sequence' then
    return sb_clone(asset)
  end
  return nil
end

local function sb_guessModeFromRecord(record, className)
  local s = tostring(record or '')
  if s:match('^Character%.') then return 'Character' end
  if s:match('^Vehicle%.') then return 'Vehicle' end
  if s:match('^Attacks%.') then return 'Attack' end
  if s:match('%.ent$') or s:find('\\', 1, true) or s:find('/', 1, true) then return 'Entity' end
  if tostring(className or '') == 'vehicle' then return 'Vehicle' end
  return 'Character'
end


local function sb_cleanEntry(entry)
  local action = type(entry.action) == 'table' and sb_clone(entry.action) or nil
  local out = {
    id = tostring(entry.id or ('scenario_entry_' .. tostring(os.clock()))),
    label = tostring(entry.label or entry.record or entry.id or 'Entry'),
    enabled = entry.enabled ~= false,
    mode = tostring(entry.mode or 'Character'),
    record = tostring(entry.record or ''),
    worldPos = {
      x = tonumber((((entry.worldPos or {}).x) or entry.x) or 0) or 0,
      y = tonumber((((entry.worldPos or {}).y) or entry.y) or 0) or 0,
      z = tonumber((((entry.worldPos or {}).z) or entry.z) or 0) or 0,
      w = 1,
    },
    worldYaw = tonumber(entry.worldYaw or entry.yaw or 0) or 0,
    relPos = {
      x = tonumber((((entry.relPos or {}).x) or 0)) or 0,
      y = tonumber((((entry.relPos or {}).y) or 0)) or 0,
      z = tonumber((((entry.relPos or {}).z) or 0)) or 0,
    },
    relYaw = tonumber(entry.relYaw or 0) or 0,
    appearance = tostring(entry.appearance or ''),
    appearanceApplyDelaySeconds = tonumber(entry.appearanceApplyDelaySeconds or 0) or 0,
    sequenceRef = entry.sequenceRef,
    sequenceAsset = type(entry.sequenceAsset) == 'table' and sb_clone(entry.sequenceAsset) or nil,
    action = action,
    spawnDelaySeconds = tonumber(entry.spawnDelaySeconds or 0) or 0,
    freezeOnSpawn = entry.freezeOnSpawn ~= false,
    unfreezeAfterSeconds = tonumber(entry.unfreezeAfterSeconds or 0) or 0,
    actionDelaySeconds = tonumber(entry.actionDelaySeconds or 0) or 0,
    statusEffectId = tostring(entry.statusEffectId or ''),
    statusApplyDelaySeconds = tonumber(entry.statusApplyDelaySeconds or 0) or 0,
    statusRemoveDelaySeconds = tonumber(entry.statusRemoveDelaySeconds or 0) or 0,
    despawnAfterSeconds = tonumber(entry.despawnAfterSeconds or 0) or 0,
    onDeathScriptId   = tostring(entry.onDeathScriptId   or ''),
    onDeathAssetType  = tostring(entry.onDeathAssetType  or 'rule'),
    sourceSpawnId = entry.sourceSpawnId,
    sourceEntityID = entry.sourceEntityID,
  }
  return out
end



local function sb_vecDist(a, b)
  local dx = (tonumber((a or {}).x or 0) or 0) - (tonumber((b or {}).x or 0) or 0)
  local dy = (tonumber((a or {}).y or 0) or 0) - (tonumber((b or {}).y or 0) or 0)
  local dz = (tonumber((a or {}).z or 0) or 0) - (tonumber((b or {}).z or 0) or 0)
  return math.sqrt(dx*dx + dy*dy + dz*dz)
end

local function sb_inputNumber(label, current, size)
  local text = sb_inputText(label, tostring(current or ''), size or 24)
  local num = tonumber(text)
  if num == nil then return current end
  return num
end

-- Mode capability helpers.
-- Animations (workspot poses) only make sense on Character NPCs.
-- Appearance changes work on Characters and Vehicles (they have named looks).
-- Status effects are NPC-only.
-- Position/teleport works on everything except FX/Attack (they are fire-and-forget).
local function sb_modeSupportsTargetActions(mode)
  local m = tostring(mode or '')
  return m ~= 'FX' and m ~= 'Attack'
end

local function sb_modeSupportsAnimation(mode)
  local m = tostring(mode or '')
  return m == 'Character'
end

local function sb_modeSupportsAppearance(mode)
  local m = tostring(mode or '')
  return m == 'Character' or m == 'Vehicle'
end

local function sb_modeSupportsStatus(mode)
  local m = tostring(mode or '')
  return m == 'Character'
end

-- Probe a boolean method on a CET entity handle safely.
-- Mirrors TargetControl._probeBoolMethod exactly — field access then pcall(fn, obj).
local function sb_probeBool(obj, methodName)
  if not obj then return nil end
  local fn = obj[methodName]
  if type(fn) ~= 'function' then return nil end
  local ok, val = pcall(fn, obj)
  return (ok and type(val) == 'boolean') and val or nil
end

local function sb_scheduleJob(job)
  local st = ScenarioBuilder.state
  st.runtimeJobs = st.runtimeJobs or {}
  st.runtimeJobs[#st.runtimeJobs + 1] = job
end

local function sb_stopPoseOnHandle(handle)
  if not handle then return false, 'Missing handle' end
  local ws = Game and Game.GetWorkspotSystem and Game.GetWorkspotSystem() or nil
  if not ws then return false, 'WorkspotSystem unavailable' end
  local ok, err = pcall(function() ws:StopInDevice(handle) end)
  if PoseBuilder and type(PoseBuilder.SetFrozen) == 'function' then
    pcall(function() PoseBuilder:SetFrozen(handle, false, false) end)
  end
  return ok == true, ok and 'Stopped current animation' or tostring(err or 'StopInDevice failed')
end

local function sb_applyAppearanceToHandle(handle, appearance)
  if not handle then return false, 'Missing handle' end
  if not TargetControl or type(TargetControl.ApplyAppearanceToHandle) ~= 'function' then
    return false, 'Appearance handle apply unavailable'
  end
  return TargetControl.ApplyAppearanceToHandle(handle, appearance)
end

local function sb_clearLiveSpawnedScene()
  local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
  for i = #spawned, 1, -1 do
    local item = spawned[i]
    pcall(function() sb_despawnHandle(item and item.handle or nil, item and item.entityID or nil) end)
  end
  return true
end

local function sb_rebuildDraftSceneLater(seconds)
  sb_scheduleJob({ kind = 'rebuild_draft_scene', dueAt = os.clock() + math.max(0.05, tonumber(seconds or 0.35) or 0.35) })
end

local function sb_spawnScenarioQuickPayload(payload, resetScene)
  local st = ScenarioBuilder.state
  if type(payload) ~= 'table' then return false, 'Missing quick-spawn payload' end
  local ok, itemOrErr = SpawnTools.SpawnRecordAtPoint(payload.record, payload.mode, payload.point, 0)
  if ok and resetScene == true then
    sb_rebuildDraftSceneLater(0.40)
  end
  if ok then
    if resetScene == true then
      return true, 'Spawned ' .. tostring(sb_basename(payload.record)) .. ' and queued scene reset.'
    end
    return true, 'Spawned ' .. tostring(sb_basename(payload.record))
  end
  return false, tostring(itemOrErr or 'Spawn failed.')
end

local function sb_entryAction(entry)
  if type(entry) == 'table' and type(entry.action) == 'table' then
    return entry.action
  end
  if type(entry) == 'table' and (entry.sequenceRef or entry.sequenceAsset) then
    return {
      sourceMode = 'saved_sequence',
      sequenceRef = entry.sequenceRef,
      sequenceAsset = type(entry.sequenceAsset) == 'table' and sb_clone(entry.sequenceAsset) or nil,
      instant = true,
    }
  end
  return nil
end

local function sb_actionSummary(action)
  if type(action) ~= 'table' then return '(none)' end
  if PoseBuilder and type(PoseBuilder.DescribeActionTarget) == 'function' then
    local ok, out = pcall(function() return PoseBuilder.DescribeActionTarget(action) end)
    if ok and type(out) == 'string' and out ~= '' then return out end
  end
  if tostring(action.sourceMode or 'pose_db') == 'saved_sequence' then
    local asset = action.sequenceAsset or (action.sequenceRef and AssetRegistry.Get and AssetRegistry.Get(action.sequenceRef)) or nil
    return asset and tostring(asset.name or asset.id or 'Saved Sequence') or 'Saved Sequence'
  end
  return tostring(action.poseName or action.name or '(choose animation)')
end

local function sb_copyForgeActionIntoEntry(entry)
  local forge = (ScenarioBuilder.state or {}).targetForge or {}
  if type(forge.action) ~= 'table' then return false end
  entry.action = sb_clone(forge.action)
  if tostring((entry.action or {}).sourceMode or 'pose_db') == 'saved_sequence' then
    entry.sequenceRef = entry.action.sequenceRef
    if entry.action.sequenceRef and not entry.action.sequenceAsset then
      entry.action.sequenceAsset = sb_captureSequenceAsset(entry.action.sequenceRef)
    end
    entry.sequenceAsset = type(entry.action.sequenceAsset) == 'table' and sb_clone(entry.action.sequenceAsset) or sb_captureSequenceAsset(entry.sequenceRef)
  end
  return true
end

local function sb_removeStatusEffectFromEntity(rawEffectId, entityID)
  local effectId = sb_trim(rawEffectId)
  if effectId == '' or entityID == nil then return false, 'Missing status effect or target' end
  local ses = (Game and Game.GetStatusEffectSystem and Game.GetStatusEffectSystem()) or nil
  if not ses then return false, 'StatusEffectSystem unavailable' end
  local attempts = {
    function() ses:RemoveStatusEffect(entityID, effectId) end,
  }
  if TweakDB and TweakDB.GetRecord then
    attempts[#attempts + 1] = function()
      local rec = TweakDB:GetRecord(effectId)
      local tok = rec and rec:GetID() or nil
      if tok then ses:RemoveStatusEffect(entityID, tok) end
    end
  end
  local lastErr = 'RemoveStatusEffect failed'
  for i = 1, #attempts do
    local ok, err = pcall(attempts[i])
    if ok then return true, 'Removed ' .. tostring(effectId) end
    lastErr = tostring(err)
  end
  return false, lastErr
end

local function sb_findSpawnedEntryByEntityID(entityID)
  local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
  if entityID == nil then return nil end
  for i = 1, #spawned do
    if tostring((spawned[i] or {}).entityID) == tostring(entityID) then return spawned[i], i end
  end
  return nil, nil
end

local function sb_despawnHandle(handle, entityID)
  local des = (Game and Game.GetDynamicEntitySystem and Game.GetDynamicEntitySystem()) or nil
  if handle then pcall(function() handle:Dispose() end) end
  if des and entityID then pcall(function() des:DeleteEntity(entityID) end) end
  local entry, idx = sb_findSpawnedEntryByEntityID(entityID)
  if idx then table.remove((((SpawnTools or {}).state or {}).spawned) or {}, idx) end
  return true
end

local function sb_buildTimelineEventsFromEntries(entities)
  local events = {}
  for i = 1, #(entities or {}) do
    local e = sb_cleanEntry(entities[i])
    if e.enabled ~= false and e.record ~= '' then
      local spawnAt = math.max(0, tonumber(e.spawnDelaySeconds or 0) or 0)
      events[#events + 1] = { time = spawnAt, kind = 'spawn', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' spawn' }
      if e.freezeOnSpawn then
        events[#events + 1] = { time = spawnAt, kind = 'freeze', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' freeze on spawn' }
      end
      local unfreezeAt = tonumber(e.unfreezeAfterSeconds or 0) or 0
      if unfreezeAt > 0 then
        events[#events + 1] = { time = spawnAt + unfreezeAt, kind = 'unfreeze', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' unfreeze' }
      end
      local appearanceId = sb_trim(e.appearance or '')
      local appearanceAt = tonumber(e.appearanceApplyDelaySeconds or 0) or 0
      if appearanceId ~= '' then
        events[#events + 1] = { time = spawnAt + appearanceAt, kind = 'appearance_apply', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' appearance: ' .. appearanceId }
      end
      local action = sb_entryAction(e)
      local actionDelay = tonumber(e.actionDelaySeconds or 0) or 0
      if action then
        events[#events + 1] = { time = spawnAt + actionDelay, kind = 'animation', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' animation: ' .. sb_actionSummary(action) }
      end
      local statusId = sb_trim(e.statusEffectId or '')
      if statusId ~= '' then
        local applyAt = tonumber(e.statusApplyDelaySeconds or 0) or 0
        events[#events + 1] = { time = spawnAt + applyAt, kind = 'status_apply', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' apply ' .. statusId }
        local removeAt = tonumber(e.statusRemoveDelaySeconds or 0) or 0
        if removeAt > 0 then
          events[#events + 1] = { time = spawnAt + removeAt, kind = 'status_remove', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' remove ' .. statusId }
        end
      end
      local despawnAt = tonumber(e.despawnAfterSeconds or 0) or 0
      if despawnAt > 0 then
        events[#events + 1] = { time = spawnAt + despawnAt, kind = 'despawn', entryIndex = i, entryId = e.id, label = tostring(e.label or e.record) .. ' despawn' }
      end
    end
  end
  table.sort(events, function(a, b)
    if tonumber(a.time or 0) == tonumber(b.time or 0) then return tostring(a.label or '') < tostring(b.label or '') end
    return tonumber(a.time or 0) < tonumber(b.time or 0)
  end)
  return events
end

local function sb_refreshTimelineFromDraft()
  local st = ScenarioBuilder.state
  st.timeline = st.timeline or { playing = false, startedAt = 0, duration = 0, playhead = 0, events = {} }
  st.timeline.events = sb_buildTimelineEventsFromEntries(st.entities or {})
  local maxT = 0
  for i = 1, #(st.timeline.events or {}) do
    maxT = math.max(maxT, tonumber((st.timeline.events[i] or {}).time or 0) or 0)
  end
  st.timeline.duration = maxT
  if st.timeline.playing ~= true then
    st.timeline.playhead = math.min(tonumber(st.timeline.playhead or 0) or 0, maxT)
  end
end

local function sb_findLiveHandleForEntry(entry)
  if type(entry) ~= 'table' then return nil end
  local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
  for i = 1, #spawned do
    local e = spawned[i]
    if type(entry.sourceSpawnId) == 'number' and tonumber(e.id) == tonumber(entry.sourceSpawnId) then
      return e.handle or (e.entityID and Game.FindEntityByID and Game.FindEntityByID(e.entityID)) or nil
    end
    if entry.sourceEntityID ~= nil and e.entityID ~= nil and tostring(e.entityID) == tostring(entry.sourceEntityID) then
      return e.handle or (e.entityID and Game.FindEntityByID and Game.FindEntityByID(e.entityID)) or nil
    end
  end
  return nil
end

local function sb_recomputeRelativeForAll()
  local st = ScenarioBuilder.state
  for i = 1, #st.entities do
    local e = st.entities[i]
    e.relPos = sb_relativeFromWorld(st.origin, e.worldPos or {})
    e.relYaw = (tonumber(e.worldYaw or 0) or 0) - (tonumber(st.origin.yaw or 0) or 0)
  end
end

local function sb_addCapturedEntry(entry, append)
  local st = ScenarioBuilder.state
  if not append then st.entities = {} end
  st.entities[#st.entities + 1] = sb_cleanEntry(entry)
  st.selectedIndex = #st.entities > 0 and #st.entities or 0
end

local function sb_captureSpawnedScene(append)
  local st = ScenarioBuilder.state
  local origin = sb_currentPlayerOrigin()
  st.origin = sb_clone(origin)
  if not append then st.entities = {} end
  local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
  local added = 0
  for i = 1, #spawned do
    local s = spawned[i]
    if s and s.exists ~= false and tostring(s.record or '') ~= '' then
      local handle = s.handle or (s.entityID and Game.FindEntityByID and Game.FindEntityByID(s.entityID)) or nil
      local pos = (handle and sb_pos(handle)) or { x = tonumber(((s.xyz or {}).x) or 0) or 0, y = tonumber(((s.xyz or {}).y) or 0) or 0, z = tonumber(((s.xyz or {}).z) or 0) or 0, w = 1 }
      local yaw = handle and sb_yaw(handle) or 0
      st.entities[#st.entities + 1] = sb_cleanEntry({
        id = 'spawned_' .. tostring(s.id or i),
        label = sb_basename(s.record or ('Spawn ' .. tostring(i))),
        mode = tostring(s.mode or 'Character'),
        record = tostring(s.record or ''),
        worldPos = pos,
        worldYaw = yaw,
        relPos = sb_relativeFromWorld(origin, pos),
        relYaw = yaw - (tonumber(origin.yaw or 0) or 0),
        freezeOnSpawn = true,
        sourceSpawnId = s.id,
        sourceEntityID = s.entityID,
      })
      added = added + 1
    end
  end
  st.selectedIndex = (#st.entities > 0) and 1 or 0
  sb_refreshTimelineFromDraft()
  st.status = string.format('Captured %d spawned entr%s.', added, added == 1 and 'y' or 'ies')
end

local function sb_captureCurrentTarget()
  local st = ScenarioBuilder.state
  local snap = TargetService.GetSnapshot and TargetService.GetSnapshot(true) or nil
  if not snap or not snap.exists or not snap.handle then
    st.status = 'No current target to capture.'
    return false
  end
  local record = tostring(snap.recordId or '')
  -- Guard against junk TweakDBID tostring output (e.g. "userdata: 0x...")
  if record == '' or record:find('^userdata') or record:find('^table') or record:find('^0x') then
    st.status = 'Current target has no usable record ID. Try targeting a spawned NPC or vehicle.'
    return false
  end
  -- Only update origin when this is the first capture; preserve it for subsequent appends
  if #st.entities == 0 then
    st.origin = sb_clone(sb_currentPlayerOrigin())
  end
  local origin = st.origin
  local pos = sb_pos(snap.handle) or {
    x = tonumber(((snap.xyz or {}).x) or 0) or 0,
    y = tonumber(((snap.xyz or {}).y) or 0) or 0,
    z = tonumber(((snap.xyz or {}).z) or 0) or 0,
    w = 1,
  }
  local yaw = sb_yaw(snap.handle)
  -- Upsert: update existing entry if one matches this entity, don't duplicate
  local existingIdx = nil
  for idx = 1, #st.entities do
    local e = st.entities[idx]
    if snap.entityID ~= nil and e.sourceEntityID ~= nil
        and tostring(e.sourceEntityID) == tostring(snap.entityID) then
      existingIdx = idx
      break
    end
  end

  local newEntry = sb_cleanEntry({
    id         = existingIdx and st.entities[existingIdx].id or ('target_' .. tostring(#st.entities + 1)),
    label      = sb_basename(record),
    mode       = sb_guessModeFromRecord(record, snap.className),
    record     = record,
    worldPos   = pos,
    worldYaw   = yaw,
    relPos     = sb_relativeFromWorld(origin, pos),
    relYaw     = yaw - (tonumber(origin.yaw or 0) or 0),
    appearance = tostring(snap.appearance or ''),
    freezeOnSpawn   = true,
    sourceEntityID  = snap.entityID,
  })

  if existingIdx then
    -- Preserve saved animation/status/onDeath from the existing entry
    local old = st.entities[existingIdx]
    newEntry.action               = old.action or newEntry.action
    newEntry.actionDelaySeconds   = old.actionDelaySeconds
    newEntry.statusEffectId       = old.statusEffectId
    newEntry.onDeathScriptId      = old.onDeathScriptId
    newEntry.onDeathAssetType     = old.onDeathAssetType
    st.entities[existingIdx] = newEntry
    st.selectedIndex = existingIdx
    st.status = 'Updated entry for ' .. sb_basename(record) .. '.'
  else
    st.entities[#st.entities + 1] = newEntry
    st.selectedIndex = #st.entities
    st.status = 'Captured current target into scenario.'
  end
  sb_refreshTimelineFromDraft()
  return true
end

local function sb_resolveEquipmentPlayerData()
  local p = sb_safePlayer()
  if not p then return nil end
  local ssc = Game and Game.GetScriptableSystemsContainer and Game.GetScriptableSystemsContainer() or nil
  if not ssc then return nil end
  local ok, es = pcall(function() return ssc:Get('EquipmentSystem') end)
  if not ok or not es or not es.GetPlayerData then return nil end
  local ok2, pd = pcall(function() return es:GetPlayerData(p) end)
  return ok2 and pd or nil
end

local function sb_getItemInSlot(areaName, index)
  local pd = sb_resolveEquipmentPlayerData()
  if not pd then return nil end
  local areaToken = areaName
  if type(areaName) == 'string' and gamedataEquipmentArea and gamedataEquipmentArea[areaName] ~= nil then
    areaToken = gamedataEquipmentArea[areaName]
  end
  local attempts = {
    function() if pd.GetItemInEquipSlot2 then return pd:GetItemInEquipSlot2(areaToken, index or 0) end end,
    function() if pd.GetItemInEquipSlot then return pd:GetItemInEquipSlot(areaToken, index or 0) end end,
    function() if pd.GetItemInEquipSlot then return pd:GetItemInEquipSlot(areaName, index or 0) end end,
  }
  for i = 1, #attempts do
    local ok, value = pcall(attempts[i])
    if ok and value ~= nil then return value end
  end
  return nil
end

local function sb_extractItemId(value)
  if value == nil then return nil end
  local probes = {
    function() return value.id end,
    function() if value.GetID then return value:GetID() end end,
    function() if value.GetItemID then return value:GetItemID() end end,
    function() if value.GetRecordID then return value:GetRecordID() end end,
    function() if value.GetTDBID then return value:GetTDBID() end end,
  }
  for i = 1, #probes do
    local ok, v = pcall(probes[i])
    if ok and v ~= nil then
      local s = tostring(v)
      local items = s:match('(Items%.[%w_%.%-]+)')
      if items and items ~= '' then return items end
    end
  end
  local s = tostring(value)
  return s:match('(Items%.[%w_%.%-]+)')
end

local function sb_captureClothing()
  local slots = {
    { key = 'Head', area = 'Head' },
    { key = 'Face', area = 'Face' },
    { key = 'Outer Torso', area = 'OuterChest' },
    { key = 'Inner Torso', area = 'InnerChest' },
    { key = 'Legs', area = 'Legs' },
    { key = 'Feet', area = 'Feet' },
    { key = 'Outfit', area = 'Outfit' },
  }
  local out = {}
  for i = 1, #slots do
    local slot = slots[i]
    out[slot.key] = sb_extractItemId(sb_getItemInSlot(slot.area, 0)) or ''
  end
  ScenarioBuilder.state.playerState.clothing = out
  ScenarioBuilder.state.status = 'Captured equipped clothing.'
end

local function sb_captureCurrentWeapon()
  local candidates = {
    sb_getItemInSlot('Weapon', 0),
    sb_getItemInSlot('WeaponRight', 0),
    sb_getItemInSlot('RightHand', 0),
  }
  local itemId = ''
  for i = 1, #candidates do
    itemId = sb_extractItemId(candidates[i]) or ''
    if itemId ~= '' then break end
  end
  ScenarioBuilder.state.playerState.currentWeapon = itemId
  if itemId ~= '' then
    ScenarioBuilder.state.status = 'Captured current weapon: ' .. tostring(itemId)
  else
    ScenarioBuilder.state.status = 'Could not capture current weapon.'
  end
end

local function sb_captureJohnnyArm()
  local item = sb_extractItemId(sb_getItemInSlot('ArmsCW', 0)) or ''
  local enabled = string.find(string.lower(item), 'silverhandarm', 1, true) ~= nil
  ScenarioBuilder.state.playerState.johnnyArmOn = enabled
  ScenarioBuilder.state.status = enabled and 'Captured Johnny arm as ON.' or 'Captured Johnny arm as OFF.'
end

local function sb_tryCaptureTimeOfDay()
  local ts = Game and Game.GetTimeSystem and Game.GetTimeSystem() or nil
  local st = ScenarioBuilder.state
  if not ts then st.status = 'TimeSystem unavailable.' return false end
  local probes = {
    function() return ts:GetGameTime() end,
    function() return ts:GetGameTimeStamp() end,
    function() return ts:GetGameTimeByHMS() end,
  }
  local raw = nil
  for i = 1, #probes do
    local ok, value = pcall(probes[i])
    if ok and value ~= nil then raw = value break end
  end
  local h, m = nil, nil
  if type(raw) == 'table' then
    h = tonumber(raw.hour or raw.hours or raw.Hours)
    m = tonumber(raw.minute or raw.minutes or raw.Minutes)
  else
    local s = tostring(raw or '')
    h, m = s:match('(%d+):(%d+)')
    h = tonumber(h)
    m = tonumber(m)
  end
  if h == nil or m == nil then
    st.status = 'Could not capture current time; set it manually if needed.'
    return false
  end
  st.playerState.hour = math.max(0, math.min(23, math.floor(h)))
  st.playerState.minute = math.max(0, math.min(59, math.floor(m)))
  st.status = string.format('Captured time of day: %02d:%02d', st.playerState.hour, st.playerState.minute)
  return true
end

local function sb_applyPlayerState(ps)
  if type(ps) ~= 'table' then return true, nil end
  if ps.captureClothing == true and type(ps.clothing) == 'table' then
    for _, itemId in pairs(ps.clothing) do
      if tostring(itemId or '') ~= '' and Equip and type(Equip.EquipItemRecord) == 'function' then
        pcall(function() Equip.EquipItemRecord(itemId) end)
      end
    end
  end
  if ps.forceEquipCurrentWeapon == true and tostring(ps.currentWeapon or '') ~= '' and Equip and type(Equip.EquipItemRecord) == 'function' then
    pcall(function() Equip.EquipItemRecord(ps.currentWeapon) end)
  end
  if ps.forceEquipWeapon == true and tostring(ps.weaponId or '') ~= '' and Equip and type(Equip.EquipItemRecord) == 'function' then
    pcall(function() Equip.EquipItemRecord(ps.weaponId) end)
  end
  if ps.captureTimeOfDay == true and World and type(World.SetTimeOfDay) == 'function' then
    pcall(function() World.SetTimeOfDay(ps.hour or 12, ps.minute or 0) end)
  end
  if ps.frozenTime == true and World and type(World.SetTimeDilation) == 'function' then
    pcall(function() World.SetTimeDilation('world_only', 0.01) end)
  end
  if ps.captureJohnnyArm == true and PlayerActions and type(PlayerActions.SetJohnnySilverhandArm) == 'function' then
    pcall(function() PlayerActions.SetJohnnySilverhandArm(ps.johnnyArmOn and 'on' or 'off') end)
  end
  return true, nil
end

local function sb_buildScenarioAsset(name, existing)
  local st = ScenarioBuilder.state
  local asset = type(existing) == 'table' and sb_clone(existing) or ((AssetRegistry.MakeEmptyScenario and AssetRegistry.MakeEmptyScenario()) or { type = 'scenario', data = {} })
  asset.type = 'scenario'
  asset.name = sb_trim(name)
  if asset.name == '' then asset.name = 'Scenario' end
  asset.data = asset.data or {}
  asset.data.mode = tostring(st.mode or 'relative')
  asset.data.teleportPlayer = st.teleportPlayer == true
  asset.data.origin = sb_clone(st.origin)
  asset.data.playerState = {
    captureClothing = st.captureClothing == true,
    clothing = sb_clone((st.playerState or {}).clothing or {}),
    forceEquipCurrentWeapon = st.forceEquipCurrentWeapon == true,
    currentWeapon = tostring((st.playerState or {}).currentWeapon or ''),
    forceEquipWeapon = st.forceEquipWeapon == true,
    weaponId = tostring(st.customWeaponId or ''),
    captureTimeOfDay = st.captureTimeOfDay == true,
    hour = tonumber((st.playerState or {}).hour or 12) or 12,
    minute = tonumber((st.playerState or {}).minute or 0) or 0,
    frozenTime = st.frozenTime == true,
    captureJohnnyArm = st.captureJohnnyArm == true,
    johnnyArmOn = (st.playerState or {}).johnnyArmOn == true,
  }
  asset.data.entities = {}
  for i = 1, #st.entities do
    local e = sb_cleanEntry(st.entities[i])
    if e.sequenceRef and not e.sequenceAsset then
      e.sequenceAsset = sb_captureSequenceAsset(e.sequenceRef)
    end
    if type(e.action) == 'table' and tostring((e.action or {}).sourceMode or 'pose_db') == 'saved_sequence' then
      if e.action.sequenceRef and not e.action.sequenceAsset then
        e.action.sequenceAsset = sb_captureSequenceAsset(e.action.sequenceRef)
      end
    end
    e.sourceSpawnId = nil
    e.sourceEntityID = nil
    asset.data.entities[#asset.data.entities + 1] = e
  end
  return asset
end

function ScenarioBuilder.SaveScenarioAsset(name, existingId)
  local existing = existingId and AssetRegistry.Get and AssetRegistry.Get(existingId) or nil
  local asset = sb_buildScenarioAsset(name, existing)
  local saved, err
  if existingId and existing then
    saved, err = AssetRegistry.Upsert and AssetRegistry.Upsert(asset)
  else
    saved, err = (AssetRegistry.UpsertNew and AssetRegistry.UpsertNew(asset, name)) or (AssetRegistry.Upsert and AssetRegistry.Upsert(asset))
  end
  if not saved then return nil, err end
  ScenarioBuilder.state.loadedAssetId = saved.id
  return saved, nil
end

function ScenarioBuilder.GetScenarioAssets()
  local items = (AssetRegistry.List and AssetRegistry.List('scenario')) or {}
  table.sort(items, function(a, b) return tostring(a.name or a.id or ''):lower() < tostring(b.name or b.id or ''):lower() end)
  return items
end

function ScenarioBuilder.LoadScenarioAssetIntoBuilder(assetOrId)
  local asset = assetOrId
  if type(assetOrId) ~= 'table' then
    asset = AssetRegistry.Get and AssetRegistry.Get(assetOrId) or nil
  end
  if type(asset) ~= 'table' or tostring(asset.type or '') ~= 'scenario' then
    return false, 'Missing scenario asset'
  end
  local st = ScenarioBuilder.state
  local data = asset.data or {}
  st.name = tostring(asset.name or '')
  st.mode = tostring(data.mode or 'relative')
  st.teleportPlayer = data.teleportPlayer == true
  st.origin = sb_clone(data.origin or sb_currentPlayerOrigin())
  local ps = data.playerState or {}
  st.captureClothing = ps.captureClothing == true
  st.forceEquipCurrentWeapon = ps.forceEquipCurrentWeapon == true
  st.forceEquipWeapon = ps.forceEquipWeapon == true
  st.customWeaponId = tostring(ps.weaponId or '')
  st.captureTimeOfDay = ps.captureTimeOfDay == true
  st.frozenTime = ps.frozenTime == true
  st.captureJohnnyArm = ps.captureJohnnyArm == true
  st.playerState = {
    clothing = sb_clone(ps.clothing or {}),
    currentWeapon = tostring(ps.currentWeapon or ''),
    weaponId = tostring(ps.weaponId or ''),
    hour = tonumber(ps.hour or 12) or 12,
    minute = tonumber(ps.minute or 0) or 0,
    johnnyArmOn = ps.johnnyArmOn == true,
  }
  st.entities = {}
  local entities = type(data.entities) == 'table' and data.entities or {}
  for i = 1, #entities do st.entities[#st.entities + 1] = sb_cleanEntry(entities[i]) end
  st.selectedIndex = (#st.entities > 0) and 1 or 0
  st.loadedAssetId = asset.id
  sb_refreshTimelineFromDraft()
  st.status = 'Loaded scenario: ' .. tostring(asset.name or asset.id)
  return true
end


-- Despawn only the entities that the PREVIOUS scenario run spawned.
-- This avoids wiping manually-spawned build entities while still clearing
-- stale scenario actors so you never get duplicates on re-run.
local function sb_clearPreviousScenarioSpawns()
  local st  = ScenarioBuilder.state
  local ids = st.scenarioSpawnedIds or {}
  for _, eid in ipairs(ids) do
    -- Find the matching entry in SpawnTools.state.spawned and remove it
    local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
    for j = #spawned, 1, -1 do
      local s = spawned[j]
      if s and tostring(s.entityID or '') == tostring(eid) then
        pcall(function() sb_despawnHandle(s.handle, s.entityID) end)
        break
      end
    end
    -- Also try a direct DES delete in case SpawnTools doesn't have it
    pcall(function()
      local des = Game and Game.GetDynamicEntitySystem and Game.GetDynamicEntitySystem()
      if des and eid then des:DeleteEntity(eid) end
    end)
  end
  st.scenarioSpawnedIds = {}
end

function ScenarioBuilder.ApplyScenarioAsset(assetOrId)
  local asset = assetOrId
  if type(assetOrId) ~= 'table' then asset = AssetRegistry.Get and AssetRegistry.Get(assetOrId) or nil end
  if type(asset) ~= 'table' or tostring(asset.type or '') ~= 'scenario' then return false, 'Missing scenario asset' end
  local data  = asset.data or {}
  local mode  = tostring(data.mode or 'relative')
  local origin = sb_clone(data.origin or sb_currentPlayerOrigin())
  if mode == 'relative' then origin = sb_currentPlayerOrigin() end

  local st = ScenarioBuilder.state
  -- Despawn entities from the previous run before spawning new ones.
  -- This prevents duplicate NPCs when the scenario is run multiple times.
  sb_clearPreviousScenarioSpawns()
  st.pendingFinalize    = {}
  st.runtimeJobs        = {}
  st.scenarioSpawnedIds = {}
  st.deathWatchers      = {}
  st.timeline = st.timeline or { playing = false, startedAt = 0, duration = 0, playhead = 0, events = {} }

  local entities = type(data.entities) == 'table' and data.entities or {}
  st.timeline.events   = sb_buildTimelineEventsFromEntries(entities)
  local maxT = 0
  for i = 1, #(st.timeline.events or {}) do
    maxT = math.max(maxT, tonumber((st.timeline.events[i] or {}).time or 0) or 0)
  end
  st.timeline.duration = maxT
  st.timeline.playhead = 0
  st.timeline.playing  = true

  -- Step 1: teleport the player IMMEDIATELY if requested, before anything else.
  local didTeleport = false
  if data.teleportPlayer == true and (mode == 'anchored' or mode == 'absolute') then
    sb_teleportPlayer(origin, tonumber(origin.yaw or 0) or 0)
    didTeleport = true
  end

  -- Step 2: apply player state (clothing, weapon, time, arm).
  -- These are UI-only changes and don't depend on the world having streamed in.
  sb_applyPlayerState(data.playerState or {})

  -- Step 3: schedule spawn jobs. If we just teleported we add a flat settle delay
  -- so the world has time to stream in before entities are created. Without this,
  -- CreateEntity fires into an unloaded cell and produces partially-initialised
  -- handles that crash on first method call (EXCEPTION_ACCESS_VIOLATION 0xB0).
  local now         = os.clock()
  local settleDelay = didTeleport and 2.5 or 0.0   -- seconds to wait after teleport
  st.timeline.startedAt = now

  local spawned = 0
  for i = 1, #entities do
    local e = sb_cleanEntry(entities[i])
    if e.enabled ~= false and e.record ~= '' then
      local spawnPos, spawnYaw
      if mode == 'relative' then
        spawnPos = sb_worldFromRelative(origin, e.relPos or {})
        spawnYaw = (tonumber(origin.yaw or 0) or 0) + (tonumber(e.relYaw or 0) or 0)
      else
        spawnPos = sb_clone(e.worldPos or {})
        spawnYaw = tonumber(e.worldYaw or 0) or 0
      end
      -- Per-entity spawn delay is additive on top of the settle delay.
      local entityDelay = math.max(0, tonumber(e.spawnDelaySeconds or 0) or 0)
      st.runtimeJobs[#st.runtimeJobs + 1] = {
        kind      = 'spawn',
        dueAt     = now + settleDelay + entityDelay,
        entry     = e,
        spawnPos  = spawnPos,
        spawnYaw  = spawnYaw,
      }
      spawned = spawned + 1
    end
  end

  if didTeleport and spawned > 0 then
    st.status = string.format(
      'Teleported. Spawning %d entr%s in %.1fs once world loads.',
      spawned, spawned == 1 and 'y' or 'ies', settleDelay)
  else
    st.status = string.format(
      'Applied scenario "%s" (%d scheduled).',
      tostring(asset.name or asset.id or 'Scenario'), spawned)
  end
  return spawned > 0 or (spawned == 0 and not didTeleport) == false, st.status
end
function ScenarioBuilder.OnUpdate(delta)
  local st = ScenarioBuilder.state
  local now = os.clock()
  if st.timeline and st.timeline.playing == true then
    st.timeline.playhead = math.max(0, now - (tonumber(st.timeline.startedAt or now) or now))
    if st.timeline.playhead >= (tonumber(st.timeline.duration or 0) or 0) + 0.50 and #((st.runtimeJobs or {})) == 0 then
      st.timeline.playing = false
    end
  end

  local jobs = st.runtimeJobs or {}

  -- Poll death state of tracked entities for on-death asset triggers.
  -- Throttled to every 0.25s — death detection doesn't need per-frame precision.
  if now >= (tonumber(st._nextHealthPoll or 0) or 0) then
    st._nextHealthPoll = now + 0.25
    local watchers = st.deathWatchers or {}
    local sps = Game and Game.GetStatPoolsSystem and Game.GetStatPoolsSystem() or nil

    for wi = 1, #watchers do
      local w = watchers[wi]
      if not (w and not w.fired and tostring(w.assetId or '') ~= '') then
        -- skip: already fired, empty, or nil
      else
        -- Resolve handle: use stored reference, fall back to FindEntityByID.
        local h = w.handle
        if not h then
          pcall(function() h = Game.FindEntityByID and Game.FindEntityByID(w.entityID) end)
          if h then w.handle = h end  -- cache for next poll
        end

        if h then
          -- Step 1: confirm the entity was alive at least once.
          -- Prevents false triggers during the first frames when IsDead() or
          -- health may not yet be initialized on a freshly spawned NPC.
          if not w.seenAlive then
            local dead = sb_probeBool(h, 'IsDead')
            if dead == false then
              w.seenAlive = true
            elseif dead == nil and sps and w.entityID then
              -- IsDead unavailable — accept alive if health > 0.
              local hp = nil
              pcall(function()
                hp = sps:GetStatPoolValue(w.entityID, gamedataStatPoolType.Health)
              end)
              if type(hp) == 'number' and hp > 0 then w.seenAlive = true end
            end
          end

          -- Step 2: watch for death once we know the entity was alive.
          if w.seenAlive then
            local isDead = false
            local deadResult = sb_probeBool(h, 'IsDead')
            if deadResult == true then
              isDead = true
            elseif deadResult == nil and sps and w.entityID then
              local hp = nil
              pcall(function()
                hp = sps:GetStatPoolValue(w.entityID, gamedataStatPoolType.Health)
              end)
              if type(hp) == 'number' and hp <= 0 then isDead = true end
            end

            if isDead then
              w.fired = true

              -- Determine asset name for status feedback first.
              local deathAsset = AssetRegistry.Get and AssetRegistry.Get(w.assetId)
              local deathName  = deathAsset and tostring(deathAsset.name or w.assetId) or w.assetId
              local assetType  = tostring(w.assetType or 'rule')
              local fired_ok   = false
              local fireErr    = 'not attempted'

              if assetType == 'rule' then
                -- Force-run: clone the rule and strip all conditions so the
                -- death event fires the action groups unconditionally regardless
                -- of whatever conditions the user put on the script.
                if type(deathAsset) == 'table' then
                  local draft = sb_clone(deathAsset)
                  draft.data = draft.data or {}
                  draft.data.conditions    = {}
                  draft.data.conditionMode = 'ALL'
                  local pok, perr = pcall(function()
                    RuleRunner.RunCreatedAssetDraft(draft, 'run',
                      'scenario_death_' .. tostring(w.assetId))
                  end)
                  fired_ok = pok == true
                  fireErr  = tostring(perr or '')
                end
              else
                -- Macros, teleports, launchers — no condition system, run directly.
                local pok, perr = pcall(function()
                  return RuleRunner.RunCreatedAssetById(w.assetId, 'run')
                end)
                fired_ok = pok == true
                fireErr  = tostring(perr or '')
              end

              st.status = fired_ok
                and ('On-death: fired "' .. deathName .. '"')
                or  ('On-death: "' .. deathName .. '" failed — ' .. fireErr)
            end
          end
        end
      end
    end
  end
  for i = #jobs, 1, -1 do
    local job = jobs[i]
    if now >= (tonumber(job.dueAt or 0) or 0) then
      if job.kind == 'spawn' then
        local okSpawn, itemOrErr = false, 'SpawnRecordAtPoint unavailable'
        if SpawnTools and type(SpawnTools.SpawnRecordAtPoint) == 'function' then
          okSpawn, itemOrErr = SpawnTools.SpawnRecordAtPoint(job.entry.record, job.entry.mode, job.spawnPos, 0)
        end
        if okSpawn == true and type(itemOrErr) == 'table' then
          local mode = tostring((job.entry or {}).mode or '')
          local supportsTargetActions = sb_modeSupportsTargetActions(mode)
          local handle = (itemOrErr or {}).handle or (((itemOrErr or {}).entityID and Game.FindEntityByID and Game.FindEntityByID((itemOrErr or {}).entityID)) or nil)
          -- Track this entityID so we can despawn it on the next run
          local spawnedEid = (itemOrErr or {}).entityID
          if spawnedEid then
            st.scenarioSpawnedIds[#st.scenarioSpawnedIds + 1] = spawnedEid
          end
          if supportsTargetActions and (handle or (itemOrErr or {}).entityID) then
            jobs[#jobs + 1] = {
              kind      = 'post_spawn',
              dueAt     = now + 0.10,
              spawnedAt = now,  -- anchor for all timed events on this entity
              tries     = 0,
              item      = itemOrErr,
              entry     = job.entry,
              pos       = job.spawnPos,
              yaw       = job.spawnYaw,
            }
          else
            local entry    = sb_cleanEntry(job.entry or {})
            local eid      = (itemOrErr or {}).entityID or nil
            local despawnAt = tonumber(entry.despawnAfterSeconds or 0) or 0
            if despawnAt > 0 then
              jobs[#jobs + 1] = { kind = 'despawn', dueAt = now + despawnAt, handle = handle, entityID = eid }
            end
          end
        end
        table.remove(jobs, i)
      elseif job.kind == 'post_spawn' then
        -- Re-resolve handle each retry in case it wasn't ready last tick
        local handle = ((job.item or {}).handle)
          or (((job.item or {}).entityID and Game.FindEntityByID
               and Game.FindEntityByID((job.item or {}).entityID)) or nil)
        -- CRITICAL: only proceed once the entity C++ object is fully initialized.
        -- A non-nil handle from FindEntityByID immediately after CreateEntity still
        -- has an uninitialized vtable — any field access will read 0x0 + offset = crash.
        if sb_isHandleReady(handle) then
          local entry     = sb_cleanEntry(job.entry or {})
          local spawnedAt = tonumber(job.spawnedAt or now) or now
          sb_teleportHandle(handle, job.pos, job.yaw)
          if entry.freezeOnSpawn ~= false and PoseBuilder and type(PoseBuilder.SetFrozen) == 'function' then
            pcall(function() PoseBuilder:SetFrozen(handle, true, false) end)
          end
          -- Get entityID safely — never access .GetEntityID as a field
          local eid = (job.item or {}).entityID
          if not eid then
            local ok, v = pcall(function() return handle:GetEntityID() end)
            if ok then eid = v end
          end
          local rid = nil
          pcall(function() if handle.GetRecordID then rid = handle:GetRecordID() end end)

          local appearanceId = sb_trim(entry.appearance or '')
          if appearanceId ~= '' and sb_modeSupportsAppearance(entry.mode) then
            jobs[#jobs + 1] = {
              kind = 'appearance_apply',
              dueAt = spawnedAt + math.max(0, tonumber(entry.appearanceApplyDelaySeconds or 0) or 0),
              handle = handle, appearance = appearanceId,
            }
          end
          local action = sb_entryAction(entry)
          if action and sb_modeSupportsAnimation(entry.mode) then
            -- Minimum 0.3s gap: entity must be fully frozen by the engine before
            -- we can safely unfreeze it and apply a pose. The action job itself
            -- adds another 0.15s gap between unfreeze and Apply, so total lag is
            -- at least 0.45s from spawn — enough for two engine frame-cycles.
            local actionDelay = math.max(0.30, tonumber(entry.actionDelaySeconds or 0) or 0)
            jobs[#jobs + 1] = {
              kind = 'action',
              dueAt = spawnedAt + actionDelay,
              handle = handle, entityID = eid, action = sb_clone(action),
            }
          end
          local statusId = sb_trim(entry.statusEffectId or '')
          if statusId ~= '' and sb_modeSupportsStatus(entry.mode) then
            jobs[#jobs + 1] = {
              kind = 'status_apply',
              dueAt = spawnedAt + math.max(0, tonumber(entry.statusApplyDelaySeconds or 0) or 0),
              handle = handle, entityID = eid, recordID = rid, effectId = statusId,
            }
            local removeAt = tonumber(entry.statusRemoveDelaySeconds or 0) or 0
            if removeAt > 0 then
              jobs[#jobs + 1] = {
                kind = 'status_remove',
                dueAt = spawnedAt + removeAt,
                handle = handle, entityID = eid, effectId = statusId,
              }
            end
          end
          local unfreezeAt = tonumber(entry.unfreezeAfterSeconds or 0) or 0
          if unfreezeAt > 0 then
            jobs[#jobs + 1] = {
              kind = 'unfreeze',
              dueAt = spawnedAt + unfreezeAt,
              handle = handle, entityID = eid,
            }
          end
          local despawnAt = tonumber(entry.despawnAfterSeconds or 0) or 0
          if despawnAt > 0 then
            jobs[#jobs + 1] = {
              kind = 'despawn',
              dueAt = spawnedAt + despawnAt,
              handle = handle, entityID = eid,
            }
          end
          -- Register on-death watcher if an asset is linked and entity has health (Characters only)
          local deathAssetId = sb_trim(tostring(entry.onDeathScriptId or ''))
          if deathAssetId ~= '' and eid and sb_modeSupportsStatus(entry.mode) then
            local watchers    = st.deathWatchers or {}
            st.deathWatchers  = watchers
            watchers[#watchers + 1] = {
              entityID  = eid,
              handle    = handle,   -- store directly; avoids FindEntityByID failures
              assetId   = deathAssetId,
              assetType = sb_trim(tostring(entry.onDeathAssetType or 'rule')),
              fired     = false,
              seenAlive = false,
            }
          end
          table.remove(jobs, i)
        else
          -- Entity not ready yet — retry with backoff, max ~4 seconds (40 * 0.10)
          job.tries = (tonumber(job.tries or 0) or 0) + 1
          if job.tries > 40 then
            table.remove(jobs, i)
          else
            job.dueAt = now + 0.10
          end
        end
      elseif job.kind == 'action' then
        -- Phase 1: unfreeze the entity so the engine restores its time dilation.
        -- TimeDilationHelper.UnsetIndividualTimeDilation is processed by the engine
        -- asynchronously - we MUST wait at least one frame before calling Apply(),
        -- otherwise PlayInDeviceSimple fires on a still-frozen entity and is ignored.
        if job.handle and PoseBuilder and type(PoseBuilder.SetFrozen) == 'function' then
          pcall(function() PoseBuilder:SetFrozen(job.handle, false, false) end)
        end
        -- Reschedule as 'do_action' 0.15s from now. This gives the engine two or three
        -- frames to process the time-dilation restore before the pose is actually applied.
        jobs[#jobs + 1] = {
          kind     = 'do_action',
          dueAt    = now + 0.15,
          handle   = job.handle,
          entityID = job.entityID,
          action   = job.action,
        }
        table.remove(jobs, i)
      elseif job.kind == 'do_action' then
        -- Phase 2: entity is unfrozen, now apply the pose.
        local ok = false
        if job.handle and PoseBuilder then
          if type(PoseBuilder.ExecuteActionOnHandle) == 'function' then
            local pok = pcall(function()
              ok = PoseBuilder.ExecuteActionOnHandle(job.action or {}, job.handle)
            end)
            if not pok then ok = false end
          end
          -- Fallback for saved_sequence if pose_db path failed
          if not ok
            and type(PoseBuilder.ExecuteSequenceAssetOnHandle) == 'function'
            and tostring(((job.action or {}).sourceMode or '')) == 'saved_sequence' then
            pcall(function()
              PoseBuilder.ExecuteSequenceAssetOnHandle(
                (job.action or {}).sequenceAsset or (job.action or {}).sequenceRef,
                job.handle, true)
            end)
          end
        end
        table.remove(jobs, i)
      elseif job.kind == 'status_apply' then
        if StatusActions and type(StatusActions.ApplyStatusEffectToEntity) == 'function' then
          pcall(function() StatusActions.ApplyStatusEffectToEntity(job.effectId, job.entityID, job.recordID) end)
        end
        table.remove(jobs, i)
      elseif job.kind == 'status_remove' then
        pcall(function() sb_removeStatusEffectFromEntity(job.effectId, job.entityID) end)
        table.remove(jobs, i)
      elseif job.kind == 'appearance_apply' then
        pcall(function() sb_applyAppearanceToHandle(job.handle, job.appearance) end)
        table.remove(jobs, i)
      elseif job.kind == 'preview_restore_appearance' then
        pcall(function() sb_applyAppearanceToHandle(job.handle, job.appearance) end)
        table.remove(jobs, i)
      elseif job.kind == 'preview_reset_animation' then
        pcall(function() sb_stopPoseOnHandle(job.handle) end)
        table.remove(jobs, i)
      elseif job.kind == 'preview_remove_status' then
        pcall(function() sb_removeStatusEffectFromEntity(job.effectId, job.entityID) end)
        table.remove(jobs, i)
      elseif job.kind == 'rebuild_draft_scene' then
        pcall(function() sb_clearLiveSpawnedScene() end)
        local draft = sb_buildScenarioAsset((ScenarioBuilder.state or {}).name or 'Scenario')
        pcall(function() ScenarioBuilder.ApplyScenarioAsset(draft) end)
        table.remove(jobs, i)
      elseif job.kind == 'unfreeze' then
        if job.handle and PoseBuilder and type(PoseBuilder.SetFrozen) == 'function' then
          pcall(function() PoseBuilder:SetFrozen(job.handle, false, false) end)
        end
        table.remove(jobs, i)
      elseif job.kind == 'despawn' then
        pcall(function() sb_despawnHandle(job.handle, job.entityID) end)
        table.remove(jobs, i)
      else
        table.remove(jobs, i)
      end
    end
  end
end

local function sb_selectedEntry()
  local st = ScenarioBuilder.state
  local idx = tonumber(st.selectedIndex or 0) or 0
  if idx < 1 or idx > #st.entities then return nil end
  return st.entities[idx], idx
end

local function sb_pushSelectedToLive()
  local st = ScenarioBuilder.state
  local entry, idx = sb_selectedEntry()
  if not entry then st.status = 'Select a captured entry first.' return end
  local handle = sb_findLiveHandleForEntry(entry)
  if not handle then st.status = 'Selected entry has no live spawned handle bound.' return end
  sb_teleportHandle(handle, entry.worldPos, entry.worldYaw)
  st.status = 'Applied selected entry transform to live object.'
end

local function sb_pullSelectedFromLive()
  local st = ScenarioBuilder.state
  local entry = sb_selectedEntry()
  if not entry then st.status = 'Select a captured entry first.' return end
  local handle = sb_findLiveHandleForEntry(entry)
  if not handle then st.status = 'Selected entry has no live spawned handle bound.' return end
  entry.worldPos = sb_pos(handle) or entry.worldPos
  entry.worldYaw = sb_yaw(handle)
  entry.relPos = sb_relativeFromWorld(st.origin, entry.worldPos or {})
  entry.relYaw = (tonumber(entry.worldYaw or 0) or 0) - (tonumber(st.origin.yaw or 0) or 0)
  st.status = 'Pulled live transform back into selected entry.'
end

local function sb_snapSelectedToTarget()
  local st = ScenarioBuilder.state
  local entry = sb_selectedEntry()
  if not entry then st.status = 'Select a captured entry first.' return end
  local snap = TargetService.GetSnapshot and TargetService.GetSnapshot(true) or nil
  if not snap or not snap.exists or not snap.handle then st.status = 'No target to snap to.' return end
  entry.worldPos = sb_pos(snap.handle) or entry.worldPos
  entry.worldYaw = sb_yaw(snap.handle)
  entry.relPos = sb_relativeFromWorld(st.origin, entry.worldPos or {})
  entry.relYaw = (tonumber(entry.worldYaw or 0) or 0) - (tonumber(st.origin.yaw or 0) or 0)
  st.status = 'Snapped selected entry to current target transform.'
end

local function sb_removeSelected()
  local st = ScenarioBuilder.state
  local _, idx = sb_selectedEntry()
  if not idx then st.status = 'Select a captured entry first.' return end
  table.remove(st.entities, idx)
  if idx > #st.entities then idx = #st.entities end
  st.selectedIndex = idx > 0 and idx or 0
  st.status = 'Removed captured entry.'
end

local function sb_currentTargetSnapshot(force)
  if TargetControl and type(TargetControl.GetCurrentTargetSnapshot) == 'function' then
    local snap = TargetControl.GetCurrentTargetSnapshot(force == true)
    if snap and snap.exists then return snap end
  end
  return (TargetService and TargetService.GetSnapshot and TargetService.GetSnapshot(force == true)) or nil
end

local function sb_syncTargetForgeFromTarget()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local snap = sb_currentTargetSnapshot(true)
  if not snap or not snap.exists or not snap.handle then
    st.status = 'No current target to load into Target Forge.'
    return nil
  end
  forge.pos = sb_pos(snap.handle) or forge.pos or { x = 0, y = 0, z = 0, w = 1 }
  forge.yaw = sb_yaw(snap.handle)
  forge.appearanceSelected = tostring(snap.appearance or forge.appearanceSelected or '')
  st.targetForge = forge
  return snap
end

local function sb_applyTargetForgeToTarget()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local snap = sb_currentTargetSnapshot(true)
  if not snap or not snap.exists or not snap.handle then
    st.status = 'No current target to move.'
    return false
  end
  local ok, err = sb_teleportHandle(snap.handle, forge.pos or {}, forge.yaw or 0)
  if ok then
    st.status = 'Applied Target Forge transform to current target.'
    return true
  end
  st.status = tostring(err or 'Could not move current target.')
  return false
end

local function sb_nudgeCurrentTarget(dx, dy, dz, dyaw)
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  forge.pos = forge.pos or { x = 0, y = 0, z = 0, w = 1 }
  forge.pos.x = (tonumber(forge.pos.x or 0) or 0) + (tonumber(dx or 0) or 0)
  forge.pos.y = (tonumber(forge.pos.y or 0) or 0) + (tonumber(dy or 0) or 0)
  forge.pos.z = (tonumber(forge.pos.z or 0) or 0) + (tonumber(dz or 0) or 0)
  forge.yaw = (tonumber(forge.yaw or 0) or 0) + (tonumber(dyaw or 0) or 0)
  st.targetForge = forge
  sb_applyTargetForgeToTarget()
end

local function sb_filteredTargetAppearanceOptions()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local options = {}
  if TargetControl and type(TargetControl.GetAppearanceOptionsForCurrentTarget) == 'function' then
    local raw = TargetControl.GetAppearanceOptionsForCurrentTarget(false) or {}
    if type(raw) == 'table' then options = raw end
  end
  local q = string.lower(sb_trim(forge.appearanceSearch or ''))
  if q == '' then return options end
  local out = {}
  for i = 1, #options do
    local name = tostring(options[i] or '')
    if string.find(string.lower(name), q, 1, true) then out[#out + 1] = name end
  end
  return out
end

local function sb_currentTargetPoint()
  local snap = sb_currentTargetSnapshot(true)
  if not snap or not snap.exists or not snap.handle then return nil end
  local pos = sb_pos(snap.handle)
  if not pos then return nil end
  return Vector4.new(pos.x or 0, pos.y or 0, pos.z or 0, 1)
end

local function sb_playerForwardPoint(distance)
  local p = sb_safePlayer()
  if not p then return nil end
  local pos = p.GetWorldPosition and p:GetWorldPosition() or nil
  local fwd = p.GetWorldForward and p:GetWorldForward() or nil
  if not pos or not fwd then return nil end
  local dist = tonumber(distance or 4.0) or 4.0
  return Vector4.new((pos.x or 0) + (fwd.x or 0) * dist, (pos.y or 0) + (fwd.y or 0) * dist, (pos.z or 0) + 0.20, 1)
end

local function sb_quickSpawnPoint()
  local st = ScenarioBuilder.state
  local qs = st.quickSpawn or {}
  local mode = tostring(qs.spawnLocation or 'in_front')
  if mode == 'at_target' then
    return sb_currentTargetPoint()
  elseif mode == 'scenario_origin' then
    return Vector4.new(tonumber(st.origin.x or 0) or 0, tonumber(st.origin.y or 0) or 0, tonumber(st.origin.z or 0) or 0, 1)
  elseif mode == 'custom' then
    local x = tonumber((qs.customXYZ or {}).x or '')
    local y = tonumber((qs.customXYZ or {}).y or '')
    local z = tonumber((qs.customXYZ or {}).z or '')
    if not x or not y or not z then return nil end
    return Vector4.new(x, y, z, 1)
  end
  return sb_playerForwardPoint(4.0)
end

local function sb_drawQuickSpawn()
  local st = ScenarioBuilder.state
  local qs = st.quickSpawn or {}
  ImGui.Separator()
  ImGui.Text('Quick Spawn')
  qs.mode = sb_combo('Spawn Mode##scenario_quick_mode', qs.mode, {
    { id = 'Character', label = 'Character' },
    { id = 'Vehicle', label = 'Vehicle' },
    { id = 'Prop', label = 'Prop' },
    { id = 'FX', label = 'FX' },
    { id = 'Attack', label = 'Attack' },
    { id = 'Entity', label = 'Entity' },
  })
  ImGui.TextUnformatted(type(IconGlyphs)=='table' and IconGlyphs['Magnify'] or '?')
  ImGui.SameLine()
  qs.search = sb_inputText('##scenario_quick_search', qs.search or '', 128)
  local records = (SpawnTools and SpawnTools.GetRecordsForMode and SpawnTools.GetRecordsForMode(qs.mode, qs.search)) or {}
  if qs.selectedIndex < 1 then qs.selectedIndex = 1 end
  if qs.selectedIndex > #records then qs.selectedIndex = math.max(1, #records) end
  local preview = records[qs.selectedIndex] or '(none)'
  if ImGui.BeginCombo('Spawn Record##scenario_quick_record', sb_basename(preview)) then
    local maxRows = math.min(#records, 250)
    for i = 1, maxRows do
      local rec = records[i]
      local selected = (qs.selectedIndex == i)
      if ImGui.Selectable(tostring(rec), selected) then qs.selectedIndex = i end
      if selected then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  qs.spawnLocation = sb_combo('Spawn At##scenario_quick_loc', qs.spawnLocation, {
    { id = 'in_front', label = 'In Front of Player' },
    { id = 'at_target', label = 'At Current Target' },
    { id = 'scenario_origin', label = 'Scenario Origin' },
    { id = 'custom', label = 'Custom XYZ' },
  })
  if tostring(qs.spawnLocation or '') == 'custom' then
    ImGui.PushItemWidth(90)
    qs.customXYZ.x = sb_inputText('X##scenario_quick_x', tostring((qs.customXYZ or {}).x or '0'), 18)
    ImGui.SameLine()
    qs.customXYZ.y = sb_inputText('Y##scenario_quick_y', tostring((qs.customXYZ or {}).y or '0'), 18)
    ImGui.SameLine()
    qs.customXYZ.z = sb_inputText('Z##scenario_quick_z', tostring((qs.customXYZ or {}).z or '0'), 18)
    ImGui.PopItemWidth()
  end
  if ImGui.Button('Spawn Selected##scenario_quick_spawn') then
    local rec = records[qs.selectedIndex]
    if not rec or rec == '' then
      st.status = 'No spawn record selected.'
    else
      local point = sb_quickSpawnPoint()
      if not point then
        st.status = 'Could not resolve quick-spawn point.'
      else
        if tostring(qs.mode or '') == 'FX' or tostring(qs.mode or '') == 'Attack' then
          qs.pendingDanger = { record = rec, mode = qs.mode, point = point }
          qs.dangerPopupOpen = true
          if ImGui.OpenPopup then ImGui.OpenPopup('scenario_danger_spawn_confirm') end
        else
          local ok, itemOrErr = sb_spawnScenarioQuickPayload({ record = rec, mode = qs.mode, point = point }, false)
          st.status = tostring(itemOrErr or (ok and ('Spawned ' .. tostring(sb_basename(rec))) or 'Spawn failed.'))
        end
      end
    end
  end
  ImGui.SameLine()
  if ImGui.Button('Capture Spawned Scene Now##scenario_quick_capture') then
    sb_captureSpawnedScene(true)
  end

  local popupOpen = false
  if qs.dangerPopupOpen == true and ImGui.BeginPopupModal then
    local ok1, ok2 = ImGui.BeginPopupModal('scenario_danger_spawn_confirm', true)
    popupOpen = (type(ok1) == 'boolean' and ok1) or (type(ok2) == 'boolean' and ok2) or false
  elseif ImGui.BeginPopup then
    popupOpen = ImGui.BeginPopup('scenario_danger_spawn_confirm')
  end
  if popupOpen then
    ImGui.TextWrapped('Spawning FX and Attacks can kill NPCs, damage vehicles, and may interfere with the editing of your Scenario. If you wish to spawn the FX now you can do so with these two options.')
    ImGui.Spacing()
    if ImGui.Button('Spawn Now##scenario_spawn_danger_now') then
      local ok, msg = sb_spawnScenarioQuickPayload(qs.pendingDanger, false)
      st.status = tostring(msg or (ok and 'Spawned dangerous effect.' or 'Spawn failed.'))
      qs.pendingDanger = nil
      qs.dangerPopupOpen = false
      if ImGui.CloseCurrentPopup then ImGui.CloseCurrentPopup() end
    end
    ImGui.SameLine()
    if ImGui.Button('Spawn Now But Reset Scene##scenario_spawn_danger_reset') then
      local ok, msg = sb_spawnScenarioQuickPayload(qs.pendingDanger, true)
      st.status = tostring(msg or (ok and 'Spawned dangerous effect and reset queued.' or 'Spawn failed.'))
      qs.pendingDanger = nil
      qs.dangerPopupOpen = false
      if ImGui.CloseCurrentPopup then ImGui.CloseCurrentPopup() end
    end
    ImGui.SameLine()
    if ImGui.Button('Cancel##scenario_spawn_danger_cancel') then
      qs.pendingDanger = nil
      qs.dangerPopupOpen = false
      if ImGui.CloseCurrentPopup then ImGui.CloseCurrentPopup() end
    end
    if ImGui.EndPopup then ImGui.EndPopup() end
  end

  st.quickSpawn = qs
end

local function sb_drawTargetForge()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  ImGui.Separator()
  ImGui.Text('Target Forge')
  local snap = sb_currentTargetSnapshot(false)
  if snap and snap.exists then
    ImGui.TextWrapped('Current Target: ' .. tostring(snap.recordId or snap.className or 'Target'))
    ImGui.TextWrapped('Appearance: ' .. tostring(snap.appearance or '-'))
  else
    ImGui.TextDisabled('No current target. Look at something spawnable or manipulable.')
  end
  if ImGui.Button('Pull Current Target##scenario_target_pull') then sb_syncTargetForgeFromTarget() end
  ImGui.SameLine()
  if ImGui.Button('Capture Current Target Into Scenario##scenario_target_capture') then sb_captureCurrentTarget() end
  ImGui.SameLine()
  if ImGui.Button('Snap Selected Entry To Current Target##scenario_target_snap_entry') then sb_snapSelectedToTarget() end

  forge.pos = forge.pos or { x = 0, y = 0, z = 0, w = 1 }
  ImGui.PushItemWidth(95)
  forge.pos.x = tonumber(sb_inputText('Target X##scenario_target_x', string.format('%.2f', tonumber(forge.pos.x or 0) or 0), 24)) or forge.pos.x or 0
  ImGui.SameLine()
  forge.pos.y = tonumber(sb_inputText('Target Y##scenario_target_y', string.format('%.2f', tonumber(forge.pos.y or 0) or 0), 24)) or forge.pos.y or 0
  ImGui.SameLine()
  forge.pos.z = tonumber(sb_inputText('Target Z##scenario_target_z', string.format('%.2f', tonumber(forge.pos.z or 0) or 0), 24)) or forge.pos.z or 0
  ImGui.SameLine()
  forge.yaw = tonumber(sb_inputText('Target Yaw##scenario_target_yaw', string.format('%.2f', tonumber(forge.yaw or 0) or 0), 24)) or forge.yaw or 0
  ImGui.PopItemWidth()
  if ImGui.SmallButton('-X##scenario_target_nx') then sb_nudgeCurrentTarget(-(tonumber(st.liveNudge or 0.10) or 0.10), 0, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+X##scenario_target_px') then sb_nudgeCurrentTarget((tonumber(st.liveNudge or 0.10) or 0.10), 0, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Y##scenario_target_ny') then sb_nudgeCurrentTarget(0, -(tonumber(st.liveNudge or 0.10) or 0.10), 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Y##scenario_target_py') then sb_nudgeCurrentTarget(0, (tonumber(st.liveNudge or 0.10) or 0.10), 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Z##scenario_target_nz') then sb_nudgeCurrentTarget(0, 0, -(tonumber(st.liveNudge or 0.10) or 0.10), 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Z##scenario_target_pz') then sb_nudgeCurrentTarget(0, 0, (tonumber(st.liveNudge or 0.10) or 0.10), 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Yaw##scenario_target_nyaw') then sb_nudgeCurrentTarget(0, 0, 0, -(tonumber(st.yawNudge or 15) or 15)) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Yaw##scenario_target_pyaw') then sb_nudgeCurrentTarget(0, 0, 0, (tonumber(st.yawNudge or 15) or 15)) end
  if ImGui.Button('Apply Forge Transform To Current Target##scenario_target_apply') then sb_applyTargetForgeToTarget() end

  ImGui.Text('Animation')
  if PoseBuilder and type(PoseBuilder.DrawActionSetup) == 'function' then
    PoseBuilder.DrawActionSetup(forge.action, 'target', 'scenario_targetforge')
    if ImGui.Button('Apply Animation To Current Target##scenario_target_apply_anim') then
      local ok, msg = PoseBuilder.ExecuteAction and PoseBuilder.ExecuteAction(forge.action, 'target')
      st.status = tostring(msg or (ok and 'Applied animation to current target.' or 'Animation apply failed.'))
    end
  else
    ImGui.TextDisabled('Pose Builder runtime unavailable.')
  end

  ImGui.Text('Appearance')
  ImGui.TextUnformatted(type(IconGlyphs)=='table' and IconGlyphs['Magnify'] or '?')
  ImGui.SameLine()
  forge.appearanceSearch = sb_inputText('##scenario_target_app_search', forge.appearanceSearch or '', 128)
  local appOptions = sb_filteredTargetAppearanceOptions()
  local appPreview = forge.appearanceSelected ~= '' and forge.appearanceSelected or '(none)'
  if ImGui.BeginCombo('Appearance##scenario_target_app_combo', appPreview) then
    for i = 1, #appOptions do
      local opt = tostring(appOptions[i])
      local selected = (tostring(forge.appearanceSelected or '') == opt)
      _scBmBtn("appearance", opt, "app1_"..tostring(i))
      ImGui.SameLine()
      if ImGui.Selectable(opt, selected) then forge.appearanceSelected = opt end
      if selected then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  if ImGui.Button('Apply Appearance##scenario_target_app_apply') then
    local ok, msg = TargetControl and TargetControl.ApplyAppearanceToCurrentTarget and TargetControl.ApplyAppearanceToCurrentTarget(forge.appearanceSelected or '')
    st.status = tostring(msg or (ok and 'Applied appearance.' or 'Appearance apply failed.'))
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Prev Appearance##scenario_target_app_prev') then
    local ok, msg = TargetControl and TargetControl.CycleAppearance and TargetControl.CycleAppearance(-1)
    st.status = tostring(msg or (ok and 'Cycled appearance.' or 'Appearance cycle failed.'))
    sb_syncTargetForgeFromTarget()
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Next Appearance##scenario_target_app_next') then
    local ok, msg = TargetControl and TargetControl.CycleAppearance and TargetControl.CycleAppearance(1)
    st.status = tostring(msg or (ok and 'Cycled appearance.' or 'Appearance cycle failed.'))
    sb_syncTargetForgeFromTarget()
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Reset Appearance##scenario_target_app_reset') then
    local ok, msg = TargetControl and TargetControl.RestoreOriginalAppearance and TargetControl.RestoreOriginalAppearance()
    st.status = tostring(msg or (ok and 'Restored original appearance.' or 'Reset appearance failed.'))
    sb_syncTargetForgeFromTarget()
  end

  ImGui.Text('Status / Tether / Tools')
  ImGui.TextUnformatted(type(IconGlyphs)=='table' and IconGlyphs['Magnify'] or '?')
  ImGui.SameLine()
  forge.statusSearch = sb_inputText('##scenario_target_status_search', forge.statusSearch or '', 128)
  local statusIds = (TargetControl and TargetControl.GetStatusEffectIds and TargetControl.GetStatusEffectIds(forge.statusSearch or '')) or {}
  local statusPreview = tostring(forge.statusSelected or '(none)')
  if ImGui.BeginCombo('Status Effect##scenario_target_status_combo', statusPreview) then
    for i = 1, math.min(#statusIds, 250) do
      local id = tostring(statusIds[i])
      local selected = (tostring(forge.statusSelected or '') == id)
      _scBmBtn("status_effect", id, "sts1_"..tostring(i))
      ImGui.SameLine()
      if ImGui.Selectable(id, selected) then forge.statusSelected = id end
      if selected then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  forge.manualStatusId = sb_inputText('Manual Status ID##scenario_target_status_manual', forge.manualStatusId or '', 128)
  if ImGui.Button('Apply Status Effect##scenario_target_status_apply') then
    local id = sb_trim(forge.manualStatusId or '')
    if id == '' then id = sb_trim(forge.statusSelected or '') end
    local ok, msg = TargetControl and TargetControl.ApplyStatusEffectToCurrentTarget and TargetControl.ApplyStatusEffectToCurrentTarget(id)
    st.status = tostring(msg or (ok and 'Applied status effect.' or 'Status effect apply failed.'))
  end
  ImGui.SameLine()
  if (TargetControl and TargetControl.IsTetherActive and TargetControl.IsTetherActive()) then
    if ImGui.SmallButton('Stop Tether##scenario_target_stop_tether') then
      local ok, msg = TargetControl.StopTether()
      st.status = tostring(msg or (ok and 'Stopped tether.' or 'Stop tether failed.'))
    end
  else
    if ImGui.SmallButton('Tether To Player##scenario_target_start_tether') then
      local ok, msg = TargetControl and TargetControl.StartTetherToPlayer and TargetControl.StartTetherToPlayer()
      st.status = tostring(msg or (ok and 'Started tether.' or 'Tether failed.'))
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Despawn Current Target##scenario_target_despawn') then
    local ok, msg = TargetControl and TargetControl.DespawnCurrentTarget and TargetControl.DespawnCurrentTarget()
    st.status = tostring(msg or (ok and 'Despawned current target.' or 'Despawn failed.'))
  end
  st.targetForge = forge
end

local function sb_drawPlayerState()
  local st = ScenarioBuilder.state
  ImGui.Separator()
  ImGui.Text('Player State')
  st.captureClothing = sb_checkbox('Capture Equipped Clothing', st.captureClothing)
  ImGui.SameLine()
  if ImGui.SmallButton('Capture Clothing Now') then sb_captureClothing() end
  st.forceEquipCurrentWeapon = sb_checkbox('Force Equip Current Weapon', st.forceEquipCurrentWeapon)
  ImGui.SameLine()
  if ImGui.SmallButton('Capture Current Weapon') then sb_captureCurrentWeapon() end
  if tostring(st.playerState.currentWeapon or '') ~= '' then
    ImGui.TextWrapped('Captured Weapon: ' .. tostring(st.playerState.currentWeapon or ''))
  end
  st.forceEquipWeapon = sb_checkbox('Force Equip Weapon', st.forceEquipWeapon)
  if st.forceEquipWeapon then
    st.customWeaponId = sb_inputText('Weapon ID##scenario_weapon_id', st.customWeaponId or '', 160)
  end
  st.captureTimeOfDay = sb_checkbox('Capture Time of Day', st.captureTimeOfDay)
  ImGui.SameLine()
  if ImGui.SmallButton('Capture Time Now') then sb_tryCaptureTimeOfDay() end
  ImGui.PushItemWidth(80)
  st.playerState.hour = tonumber(sb_inputText('Hour##scenario_hour', tostring(st.playerState.hour or 12), 8)) or st.playerState.hour or 12
  ImGui.SameLine()
  st.playerState.minute = tonumber(sb_inputText('Minute##scenario_minute', tostring(st.playerState.minute or 0), 8)) or st.playerState.minute or 0
  ImGui.PopItemWidth()
  st.frozenTime = sb_checkbox('Freeze Time', st.frozenTime)
  st.captureJohnnyArm = sb_checkbox('Capture Johnny Arm State', st.captureJohnnyArm)
  ImGui.SameLine()
  if ImGui.SmallButton('Capture Johnny Arm') then sb_captureJohnnyArm() end
  if st.captureJohnnyArm then
    ImGui.SameLine()
    ImGui.TextDisabled((st.playerState.johnnyArmOn and 'ON') or 'OFF')
  end
end

local function sb_drawTopBar()
  local st = ScenarioBuilder.state
  st.name = sb_inputText('Scenario Name', st.name or '', 128)
  st.mode = sb_combo('Scenario Mode', st.mode, {
    { id = 'relative', label = 'Relative To Player' },
    { id = 'absolute', label = 'Absolute World XYZ' },
    { id = 'anchored', label = 'Anchored / Optional Teleport' },
  })
  st.teleportPlayer = sb_checkbox('Teleport Player To Scenario Origin', st.teleportPlayer)
  if ImGui.Button('Capture Spawned Scene') then
    st.spawnCaptureOpen = true
    st.spawnCaptureChecked = {}
    -- Pre-check all, mark those already targeted
    local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
    local snap = TargetService and TargetService.GetSnapshot and TargetService.GetSnapshot(false) or nil
    local targetEid = snap and snap.entityID and tostring(snap.entityID) or nil
    for i = 1, #spawned do
      local s = spawned[i]
      if s and s.id ~= nil then
        st.spawnCaptureChecked[tostring(s.id)] = true
      end
    end
  end
  ImGui.SameLine()
  if ImGui.Button('Append Spawned Scene') then sb_captureSpawnedScene(true) end
  ImGui.SameLine()
  if ImGui.Button('Capture Current Target') then sb_captureCurrentTarget() end
  ImGui.SameLine()
  if ImGui.Button('Set Origin To Player') then st.origin = sb_currentPlayerOrigin(); sb_recomputeRelativeForAll(); st.status = 'Scenario origin updated from player.' end
  ImGui.SameLine()
  if ImGui.Button('Clear Scenario') then st.entities = {}; st.selectedIndex = 0; sb_refreshTimelineFromDraft(); st.status = 'Cleared current scenario draft.' end

  ImGui.PushItemWidth(90)
  st.origin.x = tonumber(sb_inputText('Origin X##scenario_origin_x', string.format('%.2f', tonumber(st.origin.x or 0) or 0), 24)) or st.origin.x or 0
  ImGui.SameLine()
  st.origin.y = tonumber(sb_inputText('Origin Y##scenario_origin_y', string.format('%.2f', tonumber(st.origin.y or 0) or 0), 24)) or st.origin.y or 0
  ImGui.SameLine()
  st.origin.z = tonumber(sb_inputText('Origin Z##scenario_origin_z', string.format('%.2f', tonumber(st.origin.z or 0) or 0), 24)) or st.origin.z or 0
  ImGui.SameLine()
  st.origin.yaw = tonumber(sb_inputText('Origin Yaw##scenario_origin_yaw', string.format('%.2f', tonumber(st.origin.yaw or 0) or 0), 24)) or st.origin.yaw or 0
  ImGui.PopItemWidth()
  if ImGui.SmallButton('Recompute Relative Offsets') then sb_recomputeRelativeForAll(); sb_refreshTimelineFromDraft(); st.status = 'Recomputed relative offsets from origin.' end

  -- Spawn capture picker popup
  if st.spawnCaptureOpen then
    ImGui.OpenPopup('##spawn_capture_picker')
    st.spawnCaptureOpen = false
  end
  if ImGui.BeginPopupModal('##spawn_capture_picker', true) then
    ImGui.Text('Select Spawned Entities to Capture')
    ImGui.Separator()
    local spawned = ((((SpawnTools or {}).state or {}).spawned) or {})
    local snap = TargetService and TargetService.GetSnapshot and TargetService.GetSnapshot(false) or nil
    local targetEid = snap and snap.entityID and tostring(snap.entityID) or nil
    if #spawned == 0 then
      ImGui.TextDisabled('No spawned entities found.')
    else
      for i = 1, #spawned do
        local s = spawned[i]
        if s and s.id ~= nil then
          local key = tostring(s.id)
          local checked = st.spawnCaptureChecked[key] ~= false
          local isTargeted = (targetEid ~= nil and s.entityID ~= nil
            and tostring(s.entityID) == targetEid)
          local label = sb_basename(tostring(s.record or ('Spawn '..i)))
          if isTargeted then
            ImGui.PushStyleColor(ImGuiCol.Text, 0.40, 0.90, 0.40, 1.0)
          end
          local newChecked, _ = ImGui.Checkbox('##spawn_cap_chk_'..key, checked)
          if isTargeted then ImGui.PopStyleColor(1) end
          ImGui.SameLine()
          local rowLabel = label .. ' [' .. tostring(s.mode or '?') .. ']'
          if isTargeted then rowLabel = rowLabel .. '  << current target' end
          ImGui.Text(rowLabel)
          st.spawnCaptureChecked[key] = newChecked
        end
      end
    end
    ImGui.Separator()
    if ImGui.Button('Capture Selected') then
      -- Build filtered spawned list from checked entries
      local filtered = {}
      for i = 1, #spawned do
        local s = spawned[i]
        if s and s.id ~= nil and st.spawnCaptureChecked[tostring(s.id)] ~= false then
          filtered[#filtered+1] = s
        end
      end
      st.entities = {}
      local origin = sb_currentPlayerOrigin()
      st.origin = sb_clone(origin)
      for i = 1, #filtered do
        local s = filtered[i]
        local handle = s.handle or (s.entityID and Game.FindEntityByID and Game.FindEntityByID(s.entityID)) or nil
        local pos = (handle and sb_pos(handle)) or { x=tonumber(((s.xyz or {}).x) or 0) or 0, y=tonumber(((s.xyz or {}).y) or 0) or 0, z=tonumber(((s.xyz or {}).z) or 0) or 0, w=1 }
        local yaw = handle and sb_yaw(handle) or 0
        st.entities[#st.entities+1] = sb_cleanEntry({
          id='spawned_'..tostring(s.id or i), label=sb_basename(s.record or ('Spawn '..i)),
          mode=tostring(s.mode or 'Character'), record=tostring(s.record or ''),
          worldPos=pos, worldYaw=yaw,
          relPos=sb_relativeFromWorld(origin, pos), relYaw=yaw-(tonumber(origin.yaw or 0) or 0),
          freezeOnSpawn=true, sourceSpawnId=s.id, sourceEntityID=s.entityID,
        })
      end
      st.selectedIndex = #st.entities > 0 and 1 or 0
      sb_refreshTimelineFromDraft()
      st.status = 'Captured '..tostring(#st.entities)..' entr'..(#st.entities==1 and 'y' or 'ies')..'.'
      st.spawnCaptureChecked = {}
      ImGui.CloseCurrentPopup()
    end
    ImGui.SameLine()
    if ImGui.Button('Cancel') then
      st.spawnCaptureChecked = {}
      ImGui.CloseCurrentPopup()
    end
    ImGui.EndPopup()
  end
  if ImGui.SmallButton('Apply Draft') then
    local ok, msg = ScenarioBuilder.ApplyScenarioAsset(sb_buildScenarioAsset(st.name or 'Scenario'))
    st.status = tostring(msg or (ok and 'Applied scenario draft.' or 'Scenario apply failed.'))
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Save New') then
    local saved, err = ScenarioBuilder.SaveScenarioAsset(st.name or 'Scenario', nil)
    st.status = saved and ('Saved scenario: ' .. tostring(saved.name or saved.id)) or ('Save failed: ' .. tostring(err))
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Update Loaded') then
    if st.loadedAssetId then
      local saved, err = ScenarioBuilder.SaveScenarioAsset(st.name or 'Scenario', st.loadedAssetId)
      st.status = saved and ('Updated scenario: ' .. tostring(saved.name or saved.id)) or ('Update failed: ' .. tostring(err))
    else
      st.status = 'No loaded scenario to update.'
    end
  end
end

local function sb_drawEntityList()
  local st   = ScenarioBuilder.state
  local ents = st.entities
  local now  = os.clock()

  -- Pre-compute location warnings: exact duplicate XYZ or within 0.5m
  -- suppressedWarnings[entryId] = true means the player dismissed the warning
  local warned = {}  -- [i] = 'exact' | 'near' | nil
  for i = 1, #ents do
    if not warned[i] then
      local ei = ents[i]
      local eid = tostring(ei.id or i)
      if not (st.suppressedWarnings or {})[eid] then
        for j = i+1, #ents do
          local ej = ents[j]
          local ejid = tostring(ej.id or j)
          if not (st.suppressedWarnings or {})[ejid] then
            local d = sb_vecDist(ei.worldPos, ej.worldPos)
            if d < 0.001 then
              warned[i] = 'exact'; warned[j] = 'exact'
            elseif d < 0.5 then
              if warned[i] ~= 'exact' then warned[i] = 'near' end
              if warned[j] ~= 'exact' then warned[j] = 'near' end
            end
          end
        end
      end
    end
  end

  local hasAnyWarning = false
  for _ in pairs(warned) do hasAnyWarning = true; break end

  ImGui.BeginChild('scenario_entities', 300, 340, true)

  -- "Clear all warnings" button at top when warnings exist
  if hasAnyWarning then
    ImGui.PushStyleColor(ImGuiCol.Button,        0.55, 0.12, 0.06, 1.0)
    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.70, 0.18, 0.08, 1.0)
    if ImGui.SmallButton('Clear All Location Warnings##scenario_clear_all_warnings') then
      st.suppressedWarnings = st.suppressedWarnings or {}
      for i = 1, #ents do
        st.suppressedWarnings[tostring(ents[i].id or i)] = true
      end
    end
    ImGui.PopStyleColor(2)
    ImGui.Separator()
  end

  for i = 1, #ents do
    local e      = ents[i]
    local onOff  = (e.enabled ~= false) and 'ON' or 'OFF'
    local badges = {}
    if sb_modeSupportsAppearance(e.mode) and sb_trim(e.appearance or '') ~= '' then badges[#badges+1]='app' end
    if sb_modeSupportsAnimation(e.mode)  and sb_entryAction(e)                   then badges[#badges+1]='anim' end
    if sb_modeSupportsStatus(e.mode)     and sb_trim(e.statusEffectId or '') ~= '' then badges[#badges+1]='fx' end
    if sb_modeSupportsStatus(e.mode)     and sb_trim(e.onDeathScriptId or '') ~= '' then badges[#badges+1]='death→script' end
    local badgeStr  = #badges > 0 and (' ['..table.concat(badges,',')..']') or ''
    local modeShort = ({Character='NPC',Vehicle='VEH',Prop='PROP',Entity='ENT',FX='FX',Attack='ATK'})[tostring(e.mode or '')] or tostring(e.mode or '?')
    local entLabel  = tostring(e.label or e.record or ('Entry '..tostring(i)))

    local warnType = warned[i]
    if warnType then
      -- Flash: alternate colour every 0.6s
      local flash = math.floor(now / 0.6) % 2 == 0
      if flash then
        ImGui.PushStyleColor(ImGuiCol.Text, 1.0, 0.20, 0.10, 1.0)  -- bright red
      else
        ImGui.PushStyleColor(ImGuiCol.Text, 0.70, 0.12, 0.06, 1.0)  -- dim red
      end
    end

    local rowLabel = string.format('[%s][%s] %s%s##scenario_entity_%d', onOff, modeShort, entLabel, badgeStr, i)
    local clicked  = ImGui.Selectable(rowLabel, st.selectedIndex == i)

    if warnType then ImGui.PopStyleColor(1) end

    if clicked then
      st.selectedIndex = i
      -- Show inline warning prompt when clicking a warned entry
      if warnType and not ((st.suppressedWarnings or {})[tostring(e.id or i)]) then
        st.locationWarningPrompt = i  -- signal to show popup
      end
    end
  end

  ImGui.EndChild()

  -- Location warning popup
  if st.locationWarningPrompt and st.locationWarningPrompt > 0 then
    ImGui.OpenPopup('##loc_warn_popup')
    local pi = st.locationWarningPrompt
    local pe = ents[pi]
    if pe and ImGui.BeginPopupModal('##loc_warn_popup', true) then
      local wt = warned[pi]
      if wt == 'exact' then
        ImGui.TextColored(1.0, 0.20, 0.10, 1.0, 'Location Conflict')
        ImGui.TextWrapped('This entry shares an exact location with another entry. Would you like to remove it?')
      else
        ImGui.TextColored(1.0, 0.55, 0.10, 1.0, 'Entries Are Close')
        ImGui.TextWrapped('This entry is within 0.5m of another entry. Would you like to remove it?')
      end
      ImGui.Spacing()
      if ImGui.Button('Remove Entry') then
        table.remove(ents, pi)
        if st.selectedIndex >= pi and st.selectedIndex > 1 then
          st.selectedIndex = st.selectedIndex - 1
        end
        sb_refreshTimelineFromDraft()
        st.locationWarningPrompt = 0
        ImGui.CloseCurrentPopup()
      end
      ImGui.SameLine()
      if ImGui.Button('No, Keep It') then
        st.suppressedWarnings = st.suppressedWarnings or {}
        st.suppressedWarnings[tostring(pe.id or pi)] = true
        st.locationWarningPrompt = 0
        ImGui.CloseCurrentPopup()
      end
      ImGui.EndPopup()
    else
      st.locationWarningPrompt = 0
    end
  end
end

local function sb_drawSelectedEditor()
  local st = ScenarioBuilder.state
  local entry, idx = sb_selectedEntry()
  ImGui.BeginGroup()
  if not entry then
    ImGui.TextDisabled('Select a captured entry to edit it.')
    ImGui.EndGroup()
    return
  end
  entry.enabled = sb_checkbox('Enabled##scenario_entry_enabled', entry.enabled ~= false)
  entry.label = sb_inputText('Label##scenario_entry_label', entry.label or '', 128)
  ImGui.TextWrapped('Record: ' .. tostring(entry.record or ''))
  ImGui.TextWrapped('Mode: '   .. tostring(entry.mode   or ''))

  -- World position — editing these recomputes relative offsets immediately
  local prevWX = tonumber((entry.worldPos or {}).x or 0) or 0
  local prevWY = tonumber((entry.worldPos or {}).y or 0) or 0
  local prevWZ = tonumber((entry.worldPos or {}).z or 0) or 0
  local prevWYaw = tonumber(entry.worldYaw or 0) or 0
  ImGui.PushItemWidth(100)
  entry.worldPos.x   = tonumber(sb_inputText('World X##scenario_world_x',   string.format('%.2f', prevWX),   24)) or prevWX
  ImGui.SameLine()
  entry.worldPos.y   = tonumber(sb_inputText('World Y##scenario_world_y',   string.format('%.2f', prevWY),   24)) or prevWY
  ImGui.SameLine()
  entry.worldPos.z   = tonumber(sb_inputText('World Z##scenario_world_z',   string.format('%.2f', prevWZ),   24)) or prevWZ
  entry.worldYaw     = tonumber(sb_inputText('World Yaw##scenario_world_yaw', string.format('%.2f', prevWYaw), 24)) or prevWYaw
  -- Keep relative in sync whenever world values change
  if entry.worldPos.x ~= prevWX or entry.worldPos.y ~= prevWY
      or entry.worldPos.z ~= prevWZ or entry.worldYaw ~= prevWYaw then
    entry.relPos = sb_relativeFromWorld(st.origin, entry.worldPos)
    entry.relYaw = entry.worldYaw - (tonumber(st.origin.yaw or 0) or 0)
  end

  ImGui.Separator()

  -- Relative position — editing these recomputes world position immediately
  local prevRX = tonumber((entry.relPos or {}).x or 0) or 0
  local prevRY = tonumber((entry.relPos or {}).y or 0) or 0
  local prevRZ = tonumber((entry.relPos or {}).z or 0) or 0
  local prevRYaw = tonumber(entry.relYaw or 0) or 0
  entry.relPos.x  = tonumber(sb_inputText('Relative X##scenario_rel_x',   string.format('%.2f', prevRX),   24)) or prevRX
  ImGui.SameLine()
  entry.relPos.y  = tonumber(sb_inputText('Relative Y##scenario_rel_y',   string.format('%.2f', prevRY),   24)) or prevRY
  ImGui.SameLine()
  entry.relPos.z  = tonumber(sb_inputText('Relative Z##scenario_rel_z',   string.format('%.2f', prevRZ),   24)) or prevRZ
  entry.relYaw    = tonumber(sb_inputText('Relative Yaw##scenario_rel_yaw', string.format('%.2f', prevRYaw), 24)) or prevRYaw
  if entry.relPos.x ~= prevRX or entry.relPos.y ~= prevRY
      or entry.relPos.z ~= prevRZ or entry.relYaw ~= prevRYaw then
    local world = sb_worldFromRelative(st.origin, entry.relPos)
    entry.worldPos.x = world.x
    entry.worldPos.y = world.y
    entry.worldPos.z = world.z
    entry.worldYaw   = (tonumber(st.origin.yaw or 0) or 0) + entry.relYaw
  end
  ImGui.PopItemWidth()


ImGui.Separator()
ImGui.Text('Scenario Timing')
entry.spawnDelaySeconds    = sb_inputNumber('Spawn after seconds##scenario_spawn_delay',    entry.spawnDelaySeconds    or 0, 18) or 0
ImGui.SameLine()
entry.unfreezeAfterSeconds = sb_inputNumber('Unfreeze after seconds##scenario_unfreeze_after', entry.unfreezeAfterSeconds or 0, 18) or 0
ImGui.SameLine()
entry.despawnAfterSeconds  = sb_inputNumber('Despawn after seconds##scenario_despawn_after',  entry.despawnAfterSeconds  or 0, 18) or 0
entry.freezeOnSpawn = sb_checkbox('Freeze on spawn', entry.freezeOnSpawn ~= false)

-- Appearance — Characters and Vehicles have named appearances
if sb_modeSupportsAppearance(entry.mode) then
  ImGui.Separator()
  ImGui.Text('Appearance Event')
  -- Show what is currently saved so the user can tell at a glance
  local appSaved = sb_trim(entry.appearance or '')
  if appSaved ~= '' then
    ImGui.TextColored(0.40, 0.90, 0.40, 1.0, 'Saved: ' .. appSaved)
  else
    ImGui.TextDisabled('No appearance saved for this entry yet.')
  end
  entry.appearance = sb_inputText('Appearance ID##scenario_entry_appearance', entry.appearance or '', 200)
  ImGui.SameLine()
  if ImGui.SmallButton('Copy from Target##scenario_copy_appearance') then
    local snap2 = sb_currentTargetSnapshot(true)
    local app = snap2 and sb_trim(tostring(snap2.appearance or '')) or ''
    if app == '' then app = sb_trim(tostring(((st.targetForge or {}).appearanceSelected) or '')) end
    if app ~= '' then
      entry.appearance = app
      sb_refreshTimelineFromDraft()
      st.status = 'Copied appearance "' .. app .. '" into entry.'
    else
      st.status = 'No appearance found on current target.'
    end
  end
  entry.appearanceApplyDelaySeconds = sb_inputNumber('Apply after seconds##scenario_appearance_apply_delay', entry.appearanceApplyDelaySeconds or 0, 18) or 0
end

-- Animation — Characters only (workspot system is NPC-only)
if sb_modeSupportsAnimation(entry.mode) then
  ImGui.Separator()
  ImGui.Text('Animation Event')
  entry.actionDelaySeconds = sb_inputNumber('Animation fires after seconds##scenario_action_delay', entry.actionDelaySeconds or 0, 18) or 0
  -- Show what's saved in this entry
  local actionSummary = sb_actionSummary(sb_entryAction(entry))
  if actionSummary ~= '(none)' then
    ImGui.TextColored(0.40, 0.90, 0.40, 1.0, 'Saved: ' .. actionSummary)
  else
    ImGui.TextDisabled('No animation saved for this entry yet.')
  end
  -- Show Animations tab forge state live — highlights when it differs from saved
  local forgeSummary = sb_actionSummary(type((st.targetForge or {}).action) == 'table' and st.targetForge.action or nil)
  if forgeSummary ~= '(none)' then
    if forgeSummary ~= actionSummary then
      ImGui.TextColored(1.0, 0.80, 0.20, 1.0, 'Animations tab ready: ' .. forgeSummary)
      if ImGui.SmallButton('Use this##scenario_anim_quickcopy') then
        if sb_copyForgeActionIntoEntry(entry) then
          sb_refreshTimelineFromDraft()
          st.status = 'Applied Animations tab setup to entry.'
        end
      end
      ImGui.SameLine()
      ImGui.TextDisabled('(differs from saved)')
    else
      ImGui.TextColored(0.40, 0.90, 0.40, 1.0, 'Animations tab matches saved.')
    end
  end
  if ImGui.SmallButton('Copy from Animation tab##scenario_use_forge_action') then
    if sb_copyForgeActionIntoEntry(entry) then
      sb_refreshTimelineFromDraft()
      st.status = 'Copied animation setup into entry.'
    else
      st.status = 'No animation configured in the Animations tab yet.'
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Clear animation##scenario_clear_action') then
    entry.action       = nil
    entry.sequenceRef  = nil
    entry.sequenceAsset = nil
    sb_refreshTimelineFromDraft()
    st.status = 'Cleared animation from entry.'
  end
  -- Inline action setup so the user can configure it directly in the Scene tab
  entry.action = type(entry.action) == 'table' and entry.action
    or sb_entryAction(entry)
    or { sourceMode = 'pose_db', rig = 'Man Average', poseSearch = '', poseName = '',
         instant = true, freezeAfterSeconds = 0, stopAfterSeconds = 0 }
  if PoseBuilder and type(PoseBuilder.DrawActionSetup) == 'function' then
    PoseBuilder.DrawActionSetup(entry.action, 'target', 'scenario_entry_action_' .. tostring(idx or 0))
    if tostring((entry.action or {}).sourceMode or 'pose_db') == 'saved_sequence' then
      entry.sequenceRef   = entry.action.sequenceRef
      entry.sequenceAsset = type(entry.action.sequenceAsset) == 'table'
        and sb_clone(entry.action.sequenceAsset)
        or sb_captureSequenceAsset(entry.sequenceRef)
    end
  else
    ImGui.TextDisabled('Pose Builder runtime unavailable.')
  end
end

-- Status effects — Characters only (NPC puppet system)
if sb_modeSupportsStatus(entry.mode) then
  ImGui.Separator()
  ImGui.Text('Status Effect Event')
  local statusSaved = sb_trim(entry.statusEffectId or '')
  if statusSaved ~= '' then
    ImGui.TextColored(0.40, 0.90, 0.40, 1.0, 'Saved: ' .. statusSaved)
  else
    ImGui.TextDisabled('No status effect saved for this entry yet.')
  end
  entry.statusEffectId = sb_inputText('Status Effect ID##scenario_entry_status', entry.statusEffectId or '', 200)
  ImGui.SameLine()
  if ImGui.SmallButton('Copy from Target##scenario_copy_status') then
    local id = sb_trim(((st.targetForge or {}).manualStatusId) or '')
    if id == '' then id = sb_trim(((st.targetForge or {}).statusSelected) or '') end
    if id ~= '' then
      entry.statusEffectId = id
      sb_refreshTimelineFromDraft()
      st.status = 'Copied status "' .. id .. '" into entry.'
    else
      st.status = 'No status effect selected in Target tab.'
    end
  end
  entry.statusApplyDelaySeconds  = sb_inputNumber('Apply after seconds##scenario_status_apply_delay',  entry.statusApplyDelaySeconds  or 0, 18) or 0
  ImGui.SameLine()
  entry.statusRemoveDelaySeconds = sb_inputNumber('Remove after seconds##scenario_status_remove_delay', entry.statusRemoveDelaySeconds or 0, 18) or 0
elseif not sb_modeSupportsAnimation(entry.mode) and not sb_modeSupportsAppearance(entry.mode) then
  -- FX / Attack / Entity - nothing to configure beyond position
  ImGui.Separator()
  ImGui.TextDisabled('This entry type (' .. tostring(entry.mode) .. ') spawns without further configuration.')
end

-- On-Death Action — only meaningful for Characters that have HP
if sb_modeSupportsStatus(entry.mode) then
  ImGui.Separator()
  ImGui.Text('On-Death Action')
  local deathSaved = sb_trim(entry.onDeathScriptId or '')
  if deathSaved ~= '' then
    local deathAsset = AssetRegistry.Get and AssetRegistry.Get(deathSaved) or nil
    local deathLabel = deathAsset and tostring(deathAsset.name or deathSaved) or deathSaved
    local deathType  = deathAsset and tostring(deathAsset.type or '') or ''
    local typeLabel  = ({
      rule             = 'Script',
      macro            = 'Macro',
      teleport_preset  = 'Teleport',
      launcher         = 'Launcher',
    })[deathType] or deathType
    ImGui.TextColored(0.40, 0.90, 0.40, 1.0,
      string.format('Linked [%s]: %s', typeLabel, deathLabel))
  else
    ImGui.TextDisabled('No action linked. When this NPC dies, nothing extra happens.')
  end

  -- Build a combined picker across all supported "runnable" asset types.
  -- Group by type so the list stays readable.
  local pickerLabels = { '(none)' }
  local pickerIds    = { '' }
  local currentIdx   = 1
  local function addGroup(assetType, groupLabel)
    local items = AssetRegistry.List and AssetRegistry.List(assetType) or {}
    table.sort(items, function(a, b)
      return tostring(a.name or a.id or ''):lower() < tostring(b.name or b.id or ''):lower()
    end)
    if #items == 0 then return end
    -- Section header (non-selectable)
    pickerLabels[#pickerLabels + 1] = '── ' .. groupLabel .. ' ──'
    pickerIds[#pickerIds + 1]       = '__header__'
    for _, item in ipairs(items) do
      local label = tostring(item.name or item.id or '')
      pickerLabels[#pickerLabels + 1] = '  ' .. label
      pickerIds[#pickerIds + 1]       = tostring(item.id or '')
      if tostring(item.id or '') == deathSaved then
        currentIdx = #pickerIds
      end
    end
  end
  addGroup('rule',            'Scripts')
  addGroup('macro',           'Macros')
  addGroup('teleport_preset', 'Teleports')
  addGroup('launcher',        'Launchers')

  local comboPreview = pickerLabels[currentIdx] or '(none)'
  -- Strip the leading spaces used for group indentation in the preview
  comboPreview = comboPreview:match('^%s*(.-)%s*$') or comboPreview
  if ImGui.BeginCombo('On-Death Action##scenario_entry_death_combo', comboPreview) then
    for li = 1, #pickerLabels do
      local id = pickerIds[li]
      if id == '__header__' then
        -- Non-selectable section header
        ImGui.TextDisabled(pickerLabels[li])
      else
        local selected = (li == currentIdx)
        if ImGui.Selectable(pickerLabels[li], selected) then
          entry.onDeathScriptId  = pickerIds[li]
          -- Detect type from the asset so watcher fires correctly
          local picked = AssetRegistry.Get and AssetRegistry.Get(pickerIds[li])
          entry.onDeathAssetType = picked and tostring(picked.type or 'rule') or 'rule'
        end
        if selected then ImGui.SetItemDefaultFocus() end
      end
    end
    ImGui.EndCombo()
  end
  if deathSaved ~= '' then
    ImGui.SameLine()
    if ImGui.SmallButton('Clear##scenario_death_clear') then
      entry.onDeathScriptId  = ''
      entry.onDeathAssetType = 'rule'
    end
  end
  ImGui.TextDisabled('Fires once when this NPC dies. Works with Scripts, Macros, Teleports, and Launchers.')
  ImGui.TextDisabled('Scripts fire their actions directly. Leave conditions empty on a Script for reliable triggering.')
end

sb_refreshTimelineFromDraft()

ImGui.Text('Forge Tools')
  ImGui.PushItemWidth(90)
  st.liveNudge = tonumber(sb_inputText('Move Step##scenario_move_step', tostring(st.liveNudge or 0.10), 24)) or st.liveNudge or 0.10
  ImGui.SameLine()
  st.yawNudge = tonumber(sb_inputText('Yaw Step##scenario_yaw_step', tostring(st.yawNudge or 15), 24)) or st.yawNudge or 15
  ImGui.PopItemWidth()

  local nudge = tonumber(st.liveNudge or 0.10) or 0.10
  local ynudge = tonumber(st.yawNudge or 15) or 15
  local function nudgeEntry(dx, dy, dz, dyaw)
    entry.worldPos.x = (tonumber(entry.worldPos.x or 0) or 0) + dx
    entry.worldPos.y = (tonumber(entry.worldPos.y or 0) or 0) + dy
    entry.worldPos.z = (tonumber(entry.worldPos.z or 0) or 0) + dz
    entry.worldYaw   = (tonumber(entry.worldYaw   or 0) or 0) + dyaw
    entry.relPos     = sb_relativeFromWorld(st.origin, entry.worldPos)
    entry.relYaw     = entry.worldYaw - (tonumber(st.origin.yaw or 0) or 0)
  end

  if ImGui.SmallButton('-X##scenario_nx')   then nudgeEntry(-nudge, 0, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+X##scenario_px')   then nudgeEntry( nudge, 0, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Y##scenario_ny')   then nudgeEntry(0, -nudge, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Y##scenario_py')   then nudgeEntry(0,  nudge, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Z##scenario_nz')   then nudgeEntry(0, 0, -nudge, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Z##scenario_pz')   then nudgeEntry(0, 0,  nudge, 0) end
  if ImGui.SmallButton('-Yaw##scenario_nyaw') then nudgeEntry(0, 0, 0, -ynudge) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Yaw##scenario_pyaw') then nudgeEntry(0, 0, 0,  ynudge) end

  if ImGui.Button('Apply To Live Spawn') then sb_pushSelectedToLive() end
  ImGui.SameLine()
  if ImGui.Button('Pull From Live Spawn') then sb_pullSelectedFromLive() end
  ImGui.SameLine()
  if ImGui.Button('Snap To Current Target') then sb_snapSelectedToTarget() end
  ImGui.SameLine()
  if ImGui.Button('Remove Entry') then sb_removeSelected() end
  ImGui.EndGroup()
end

local function sb_drawSavedScenarios()
  local st = ScenarioBuilder.state
  local items = ScenarioBuilder.GetScenarioAssets()
  ImGui.Separator()
  ImGui.Text('Saved Scenarios')
  if #items == 0 then
    ImGui.TextDisabled('No saved scenarios yet.')
    return
  end
  if ImGui.BeginTable('scenario_saved_tbl', 5, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn('Scenario')
    ImGui.TableSetupColumn('Mode', ImGuiTableColumnFlags.WidthFixed, 90)
    ImGui.TableSetupColumn('Entities', ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableSetupColumn('Load / Run', ImGuiTableColumnFlags.WidthFixed, 130)
    ImGui.TableSetupColumn('Delete', ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableHeadersRow()
    for i = 1, #items do
      local a = items[i]
      local data = a.data or {}
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(tostring(a.name or a.id))
      ImGui.TableSetColumnIndex(1)
      ImGui.TextUnformatted(tostring(data.mode or 'relative'))
      ImGui.TableSetColumnIndex(2)
      ImGui.TextUnformatted(tostring(#(data.entities or {})))
      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton('Load##scenario_load_' .. tostring(a.id)) then ScenarioBuilder.LoadScenarioAssetIntoBuilder(a.id) end
      ImGui.SameLine()
      if ImGui.SmallButton('Run##scenario_run_' .. tostring(a.id)) then
        local ok, msg = ScenarioBuilder.ApplyScenarioAsset(a.id)
        st.status = tostring(msg or (ok and 'Applied scenario.' or 'Apply failed.'))
      end
      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton('Delete##scenario_delete_' .. tostring(a.id)) then AssetRegistry.Delete(a.id) end
    end
    ImGui.EndTable()
  end
end

local function sb_drawHomeTab()
  local st = ScenarioBuilder.state
  sb_drawTopBar()
  ImGui.Separator()
  ImGui.Text('Scenario Summary')
  ImGui.BulletText('Captured Entries: ' .. tostring(#(st.entities or {})))
  ImGui.BulletText('Mode: ' .. tostring(st.mode or 'relative'))
  ImGui.BulletText('Loaded Asset: ' .. tostring(st.loadedAssetId or '(draft only)'))
  local entry = sb_selectedEntry()
  ImGui.BulletText('Selected Entry: ' .. tostring((entry and (entry.label or entry.record)) or '(none)'))
  ImGui.TextWrapped('Home keeps the scenario-specific controls small. Use Scene for forge editing, Animations for pose tools, Spawn for quick spawning, Target for live target manipulation, Player for captured player state, Timeline for timed events and preview, and Saved for loading older scenarios.')
end

local function sb_drawSceneTab()
  ImGui.TextDisabled('Captured entries and forge editing.')
  local ww = ImGui.GetWindowWidth and ImGui.GetWindowWidth() or 960
  if ww < 1280 then
    sb_drawEntityList()
    ImGui.Separator()
    sb_drawSelectedEditor()
  else
    ImGui.Columns(2, 'scenario_scene_cols', false)
    sb_drawEntityList()
    ImGui.NextColumn()
    sb_drawSelectedEditor()
    ImGui.Columns(1)
  end
end

local function sb_drawAnimationTab()
  local st    = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local snap  = sb_currentTargetSnapshot(false)
  local entry, entryIdx = sb_selectedEntry()

  ImGui.Text('Current Target Animation')
  if snap and snap.exists then
    ImGui.TextWrapped('Target: '     .. tostring(snap.recordId  or snap.className or 'Target'))
    ImGui.TextWrapped('Appearance: ' .. tostring(snap.appearance or '-'))
  else
    ImGui.TextDisabled('No current target. Look at an NPC before applying animation.')
  end
  if ImGui.SmallButton('Pull Current Target##scenario_anim_pull')       then sb_syncTargetForgeFromTarget() end
  ImGui.SameLine()
  if ImGui.SmallButton('Capture Into Scenario##scenario_anim_capture')  then sb_captureCurrentTarget() end
  ImGui.SameLine()
  if ImGui.SmallButton('Snap Entry To Target##scenario_anim_snap')      then sb_snapSelectedToTarget() end

  -- Show what the selected scenario entry has saved
  if entry then
    ImGui.Separator()
    local saved = sb_actionSummary(sb_entryAction(entry))
    if saved ~= '(none)' then
      ImGui.TextColored(0.40, 0.90, 0.40, 1.0,
        string.format('Entry "%s" has: %s', tostring(entry.label or entry.record or '?'), saved))
    else
      ImGui.TextDisabled(string.format('Entry "%s" has no animation yet.', tostring(entry.label or entry.record or '?')))
    end
  else
    ImGui.Separator()
    ImGui.TextDisabled('Select a captured entry in the Scene tab to see its saved animation.')
  end

  ImGui.Separator()
  ImGui.Text('Configure Animation')
  if not (snap and snap.exists and snap.className == 'NPCPuppet') then
    ImGui.TextDisabled('Animation can only be applied to NPCs. Target an NPC first.')
  end

  if PoseBuilder and type(PoseBuilder.DrawActionSetup) == 'function' then
    PoseBuilder.DrawActionSetup(forge.action, 'target', 'scenario_animation_tab')
    forge.previewResetAnimation     = sb_checkbox('Reset after seconds##anim_reset_check', forge.previewResetAnimation == true)
    ImGui.SameLine()
    forge.previewResetAnimationAfter = sb_inputNumber('##anim_reset_secs', forge.previewResetAnimationAfter or 2.0, 18) or 2.0

    if ImGui.Button('Preview on Current Target##scenario_animation_apply') then
      local ok, msg = PoseBuilder.ExecuteAction and PoseBuilder.ExecuteAction(forge.action, 'target')
      st.status = tostring(msg or (ok and 'Applied animation preview.' or 'Animation apply failed.'))
      if ok and forge.previewResetAnimation == true then
        local h = TargetControl and TargetControl.GetCurrentTargetHandle and TargetControl.GetCurrentTargetHandle(true) or nil
        if h then
          sb_scheduleJob({ kind = 'preview_reset_animation',
            dueAt = os.clock() + math.max(0.05, tonumber(forge.previewResetAnimationAfter or 2.0) or 2.0),
            handle = h })
        end
      end
    end
    ImGui.SameLine()
    if ImGui.Button('Save To Selected Entry##scenario_animation_copy_entry') then
      if entry and sb_modeSupportsAnimation(entry.mode) then
        if sb_copyForgeActionIntoEntry(entry) then
          sb_refreshTimelineFromDraft()
          st.status = 'Saved animation into entry "' .. tostring(entry.label or entry.record or '?') .. '".'
        end
      elseif entry then
        st.status = 'Entry mode "' .. tostring(entry.mode) .. '" does not support animations.'
      else
        st.status = 'Select a captured entry in the Scene tab first.'
      end
    end
    ImGui.TextDisabled('Preview applies to the live target only. "Save To Selected Entry" stores it in the scenario.')
  else
    ImGui.TextDisabled('Pose Builder runtime unavailable.')
  end
  st.targetForge = forge
end

local function sb_drawTargetTransformPane()
  local st = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local snap = sb_currentTargetSnapshot(false)
  ImGui.Text('Live Target Transform')
  if snap and snap.exists then
    ImGui.TextWrapped('Current Target: ' .. tostring(snap.recordId or snap.className or 'Target'))
    ImGui.TextWrapped('Appearance: ' .. tostring(snap.appearance or '-'))
  else
    ImGui.TextDisabled('No current target. Look at something spawnable or manipulable.')
  end
  if ImGui.Button('Pull Current Target##scenario_target_pull2') then sb_syncTargetForgeFromTarget() end
  ImGui.SameLine()
  if ImGui.Button('Capture Current Target Into Scenario##scenario_target_capture2') then sb_captureCurrentTarget() end
  ImGui.SameLine()
  if ImGui.Button('Snap Selected Entry To Current Target##scenario_target_snap_entry2') then sb_snapSelectedToTarget() end

  forge.pos = forge.pos or { x = 0, y = 0, z = 0, w = 1 }
  ImGui.PushItemWidth(95)
  forge.pos.x = tonumber(sb_inputText('Target X##scenario_target_x2', string.format('%.2f', tonumber(forge.pos.x or 0) or 0), 24)) or forge.pos.x or 0
  ImGui.SameLine()
  forge.pos.y = tonumber(sb_inputText('Target Y##scenario_target_y2', string.format('%.2f', tonumber(forge.pos.y or 0) or 0), 24)) or forge.pos.y or 0
  ImGui.SameLine()
  forge.pos.z = tonumber(sb_inputText('Target Z##scenario_target_z2', string.format('%.2f', tonumber(forge.pos.z or 0) or 0), 24)) or forge.pos.z or 0
  ImGui.SameLine()
  forge.yaw = tonumber(sb_inputText('Target Yaw##scenario_target_yaw2', string.format('%.2f', tonumber(forge.yaw or 0) or 0), 24)) or forge.yaw or 0
  ImGui.PopItemWidth()

  ImGui.PushItemWidth(90)
  st.liveNudge = tonumber(sb_inputText('Move Step##scenario_target_move_step2', tostring(st.liveNudge or 0.10), 24)) or st.liveNudge or 0.10
  ImGui.SameLine()
  st.yawNudge = tonumber(sb_inputText('Yaw Step##scenario_target_yaw_step2', tostring(st.yawNudge or 15), 24)) or st.yawNudge or 15
  ImGui.PopItemWidth()

  if ImGui.SmallButton('-X##scenario_target_nx2') then sb_nudgeCurrentTarget(-(tonumber(st.liveNudge or 0.10) or 0.10), 0, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+X##scenario_target_px2') then sb_nudgeCurrentTarget((tonumber(st.liveNudge or 0.10) or 0.10), 0, 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Y##scenario_target_ny2') then sb_nudgeCurrentTarget(0, -(tonumber(st.liveNudge or 0.10) or 0.10), 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Y##scenario_target_py2') then sb_nudgeCurrentTarget(0, (tonumber(st.liveNudge or 0.10) or 0.10), 0, 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Z##scenario_target_nz2') then sb_nudgeCurrentTarget(0, 0, -(tonumber(st.liveNudge or 0.10) or 0.10), 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Z##scenario_target_pz2') then sb_nudgeCurrentTarget(0, 0, (tonumber(st.liveNudge or 0.10) or 0.10), 0) end
  ImGui.SameLine()
  if ImGui.SmallButton('-Yaw##scenario_target_nyaw2') then sb_nudgeCurrentTarget(0, 0, 0, -(tonumber(st.yawNudge or 15) or 15)) end
  ImGui.SameLine()
  if ImGui.SmallButton('+Yaw##scenario_target_pyaw2') then sb_nudgeCurrentTarget(0, 0, 0, (tonumber(st.yawNudge or 15) or 15)) end
  if ImGui.Button('Apply Forge Transform To Current Target##scenario_target_apply2') then sb_applyTargetForgeToTarget() end
  st.targetForge = forge
end

local function sb_drawTargetAppearancePane()
  local st    = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local entry = sb_selectedEntry()

  ImGui.Text('Appearance')

  -- Show what the selected entry already has saved
  if entry then
    if sb_modeSupportsAppearance(entry.mode) then
      local saved = sb_trim(entry.appearance or '')
      if saved ~= '' then
        ImGui.TextColored(0.40, 0.90, 0.40, 1.0,
          string.format('Entry "%s" saved: %s', tostring(entry.label or entry.record or '?'), saved))
      else
        ImGui.TextDisabled(string.format('Entry "%s" has no appearance saved yet.', tostring(entry.label or entry.record or '?')))
      end
    else
      ImGui.TextColored(1.0, 0.65, 0.20, 1.0,
        'Selected entry mode "' .. tostring(entry.mode) .. '" does not support appearances.')
    end
  else
    ImGui.TextDisabled('No entry selected — changes only persist when you press "Save To Entry".')
  end
  ImGui.Separator()

  ImGui.TextUnformatted(type(IconGlyphs)=='table' and IconGlyphs['Magnify'] or '?')
  ImGui.SameLine()
  forge.appearanceSearch = sb_inputText('##scenario_target_app_search2', forge.appearanceSearch or '', 128)
  local appOptions = sb_filteredTargetAppearanceOptions()
  local appPreview = (forge.appearanceSelected ~= '') and forge.appearanceSelected or '(none)'
  if ImGui.BeginCombo('Appearance##scenario_target_app_combo2', appPreview) then
    for i = 1, #appOptions do
      local opt      = tostring(appOptions[i])
      local selected = (tostring(forge.appearanceSelected or '') == opt)
      if ImGui.Selectable(opt, selected) then forge.appearanceSelected = opt end
      if selected then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end

  forge.previewRestoreAppearance      = sb_checkbox('Restore original after preview##app_restore_check', forge.previewRestoreAppearance == true)
  ImGui.SameLine()
  forge.previewRestoreAppearanceAfter = sb_inputNumber('sec##app_restore_secs', forge.previewRestoreAppearanceAfter or 2.0, 18) or 2.0

  if ImGui.Button('Preview On Target##scenario_target_app_apply2') then
    local snap2   = sb_currentTargetSnapshot(true)
    local origApp = snap2 and tostring(snap2.appearance or '') or ''
    local h       = snap2 and snap2.handle or nil
    local ok, msg = TargetControl and TargetControl.ApplyAppearanceToCurrentTarget
      and TargetControl.ApplyAppearanceToCurrentTarget(forge.appearanceSelected or '')
    st.status = tostring(msg or (ok and 'Applied appearance preview.' or 'Appearance apply failed.'))
    if ok and forge.previewRestoreAppearance == true and h and origApp ~= '' then
      sb_scheduleJob({ kind = 'preview_restore_appearance',
        dueAt  = os.clock() + math.max(0.05, tonumber(forge.previewRestoreAppearanceAfter or 2.0) or 2.0),
        handle = h, appearance = origApp })
    end
  end
  ImGui.SameLine()
  if ImGui.Button('Save To Entry##scenario_target_app_copy2') then
    if entry and sb_modeSupportsAppearance(entry.mode) then
      entry.appearance = tostring(forge.appearanceSelected or '')
      sb_refreshTimelineFromDraft()
      st.status = 'Saved appearance "' .. tostring(forge.appearanceSelected or '') .. '" into entry "' .. tostring(entry.label or entry.record or '?') .. '".'
    elseif entry then
      st.status = 'Entry mode "' .. tostring(entry.mode) .. '" does not support appearances. Only Characters and Vehicles have named appearances.'
    else
      st.status = 'Select a captured entry in the Scene tab first.'
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Prev##app_prev2') then
    local ok, msg = TargetControl and TargetControl.CycleAppearance and TargetControl.CycleAppearance(-1)
    st.status = tostring(msg or (ok and 'Cycled appearance.' or 'Failed.'))
    sb_syncTargetForgeFromTarget()
    -- Auto-write to selected entry so Scene tab stays in sync
    if entry and sb_modeSupportsAppearance(entry.mode) and (forge.appearanceSelected or '') ~= '' then
      entry.appearance = forge.appearanceSelected
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Next##app_next2') then
    local ok, msg = TargetControl and TargetControl.CycleAppearance and TargetControl.CycleAppearance(1)
    st.status = tostring(msg or (ok and 'Cycled appearance.' or 'Failed.'))
    sb_syncTargetForgeFromTarget()
    -- Auto-write to selected entry so Scene tab stays in sync
    if entry and sb_modeSupportsAppearance(entry.mode) and (forge.appearanceSelected or '') ~= '' then
      entry.appearance = forge.appearanceSelected
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Reset##app_reset2') then
    local ok, msg = TargetControl and TargetControl.RestoreOriginalAppearance and TargetControl.RestoreOriginalAppearance()
    st.status = tostring(msg or (ok and 'Restored original.' or 'Failed.'))
    sb_syncTargetForgeFromTarget()
  end
  st.targetForge = forge
end

local function sb_drawTargetStatusPane()
  local st    = ScenarioBuilder.state
  local forge = st.targetForge or {}
  local entry = sb_selectedEntry()

  ImGui.Text('Status Effects')

  -- Show what the selected entry already has saved
  if entry then
    if sb_modeSupportsStatus(entry.mode) then
      local saved = sb_trim(entry.statusEffectId or '')
      if saved ~= '' then
        ImGui.TextColored(0.40, 0.90, 0.40, 1.0,
          string.format('Entry "%s" saved: %s', tostring(entry.label or entry.record or '?'), saved))
      else
        ImGui.TextDisabled(string.format('Entry "%s" has no status effect saved yet.', tostring(entry.label or entry.record or '?')))
      end
    else
      ImGui.TextColored(1.0, 0.65, 0.20, 1.0,
        'Selected entry mode "' .. tostring(entry.mode) .. '" does not support status effects. Only NPCs (Characters) do.')
    end
  else
    ImGui.TextDisabled('No entry selected — changes only persist when you press "Save To Entry".')
  end
  ImGui.Separator()

  ImGui.TextUnformatted(type(IconGlyphs)=='table' and IconGlyphs['Magnify'] or '?')
  ImGui.SameLine()
  forge.statusSearch = sb_inputText('##scenario_target_status_search2', forge.statusSearch or '', 128)
  local statusIds    = (TargetControl and TargetControl.GetStatusEffectIds
    and TargetControl.GetStatusEffectIds(forge.statusSearch or '')) or {}
  local statusPreview = tostring(forge.statusSelected or '(none)')
  if ImGui.BeginCombo('Status Effect##scenario_target_status_combo2', statusPreview) then
    for i = 1, math.min(#statusIds, 250) do
      local id       = tostring(statusIds[i])
      local selected = (tostring(forge.statusSelected or '') == id)
      if ImGui.Selectable(id, selected) then forge.statusSelected = id end
      if selected then ImGui.SetItemDefaultFocus() end
    end
    ImGui.EndCombo()
  end
  forge.manualStatusId = sb_inputText('Manual ID##scenario_target_status_manual2', forge.manualStatusId or '', 128)

  forge.previewRemoveStatus      = sb_checkbox('Remove after preview##status_remove_check', forge.previewRemoveStatus == true)
  ImGui.SameLine()
  forge.previewRemoveStatusAfter = sb_inputNumber('sec##status_remove_secs', forge.previewRemoveStatusAfter or 2.0, 18) or 2.0

  if ImGui.Button('Preview On Target##scenario_target_status_apply2') then
    local id = sb_trim(forge.manualStatusId or '')
    if id == '' then id = sb_trim(forge.statusSelected or '') end
    local snap2   = sb_currentTargetSnapshot(true)
    local ok, msg = TargetControl and TargetControl.ApplyStatusEffectToCurrentTarget
      and TargetControl.ApplyStatusEffectToCurrentTarget(id)
    st.status = tostring(msg or (ok and 'Applied status preview.' or 'Status effect apply failed.'))
    if ok and forge.previewRemoveStatus == true and snap2 and snap2.entityID ~= nil and id ~= '' then
      sb_scheduleJob({ kind = 'preview_remove_status',
        dueAt    = os.clock() + math.max(0.05, tonumber(forge.previewRemoveStatusAfter or 2.0) or 2.0),
        entityID = snap2.entityID, effectId = id })
    end
  end
  ImGui.SameLine()
  if ImGui.Button('Save To Entry##scenario_target_status_copy2') then
    local id = sb_trim(forge.manualStatusId or '')
    if id == '' then id = sb_trim(forge.statusSelected or '') end
    if entry and sb_modeSupportsStatus(entry.mode) then
      entry.statusEffectId = id
      sb_refreshTimelineFromDraft()
      st.status = 'Saved status "' .. tostring(id) .. '" into entry "' .. tostring(entry.label or entry.record or '?') .. '".'
    elseif entry then
      st.status = 'Entry mode "' .. tostring(entry.mode) .. '" does not support status effects. Only Characters (NPCs) do.'
    else
      st.status = 'Select a captured entry in the Scene tab first.'
    end
  end

  ImGui.Separator()
  ImGui.Text('Tether / Despawn')
  if (TargetControl and TargetControl.IsTetherActive and TargetControl.IsTetherActive()) then
    if ImGui.SmallButton('Stop Tether##scenario_target_stop_tether2') then
      local ok, msg = TargetControl.StopTether()
      st.status = tostring(msg or (ok and 'Stopped tether.' or 'Stop tether failed.'))
    end
  else
    if ImGui.SmallButton('Tether To Player##scenario_target_start_tether2') then
      local ok, msg = TargetControl and TargetControl.StartTetherToPlayer and TargetControl.StartTetherToPlayer()
      st.status = tostring(msg or (ok and 'Started tether.' or 'Tether failed.'))
    end
  end
  ImGui.SameLine()
  if ImGui.SmallButton('Despawn Current Target##scenario_target_despawn2') then
    local ok, msg = TargetControl and TargetControl.DespawnCurrentTarget and TargetControl.DespawnCurrentTarget()
    st.status = tostring(msg or (ok and 'Despawned current target.' or 'Despawn failed.'))
  end
  st.targetForge = forge
end




local function sb_sliderValue(label, current, minv, maxv)
  local a, b = ImGui.SliderFloat(label, tonumber(current or 0) or 0, tonumber(minv or 0) or 0, tonumber(maxv or 0) or 0)
  if type(a) == 'number' then return a end
  if type(b) == 'number' then return b end
  return tonumber(current or 0) or 0
end

local function sb_drawTimelineTab()
  local st = ScenarioBuilder.state
  sb_refreshTimelineFromDraft()
  local tl = st.timeline or { playing = false, startedAt = 0, duration = 0, playhead = 0, events = {} }
  local duration = math.max(tonumber(tl.duration or 0) or 0, 0)
  ImGui.Text('Scenario Timeline')
  ImGui.TextWrapped('Each captured entry now carries explicit timing. Spawn, freeze, unfreeze, appearance, animation, status, and despawn happen on the timeline instead of depending on how the author happened to look at the scene while building it.')
  if ImGui.Button('Preview Draft Timeline##scenario_timeline_preview') then
    local ok, msg = ScenarioBuilder.ApplyScenarioAsset(sb_buildScenarioAsset(st.name or 'Scenario'))
    st.status = tostring(msg or (ok and 'Preview started.' or 'Preview failed.'))
  end
  ImGui.SameLine()
  if ImGui.Button('Stop Timeline##scenario_timeline_stop') then
    tl.playing = false
    st.runtimeJobs = {}
    st.status = 'Stopped scenario timeline preview.'
  end
  ImGui.Text('Duration: ' .. string.format('%.2fs', duration))
  tl.playhead = sb_sliderValue('Playhead##scenario_timeline_playhead', tl.playhead or 0, 0, math.max(duration, 0.10))
  ImGui.TextDisabled(tl.playing == true and 'Preview running live. Use this playhead as a timeline readout while events execute.' or 'Preview idle. Move the playhead to inspect event timing.')
  if ImGui.BeginChild('scenario_timeline_events', 0, 320, true) then
    for i = 1, #(tl.events or {}) do
      local ev = tl.events[i]
      local hit = (tonumber(ev.time or 0) or 0) <= (tonumber(tl.playhead or 0) or 0)
      if hit then
        ImGui.TextColored(0.30, 0.95, 0.45, 1.00, string.format('%.2fs | %s', tonumber(ev.time or 0) or 0, tostring(ev.label or 'event')))
      else
        ImGui.Text(string.format('%.2fs | %s', tonumber(ev.time or 0) or 0, tostring(ev.label or 'event')))
      end
      if ImGui.IsItemClicked() then
        tl.playhead = tonumber(ev.time or 0) or 0
        if tonumber(ev.entryIndex or 0) > 0 then st.selectedIndex = tonumber(ev.entryIndex or 0) or st.selectedIndex end
      end
    end
    ImGui.EndChild()
  end
  st.timeline = tl
end

function ScenarioBuilder.DrawTab(_)
  if ImGui.BeginTabBar('scenario_builder_tabs') then
    if ImGui.BeginTabItem('Home') then
      sb_drawHomeTab()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Scene') then
      sb_drawSceneTab()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Animations') then
      sb_drawAnimationTab()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Spawn') then
      sb_drawQuickSpawn()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Target') then
      if ImGui.BeginTabBar('scenario_target_tabs') then
        if ImGui.BeginTabItem('Transform') then
          sb_drawTargetTransformPane()
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem('Appearance') then
          sb_drawTargetAppearancePane()
          ImGui.EndTabItem()
        end
        if ImGui.BeginTabItem('Status / Tools') then
          sb_drawTargetStatusPane()
          ImGui.EndTabItem()
        end
        ImGui.EndTabBar()
      end
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Player') then
      sb_drawPlayerState()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Timeline') then
      sb_drawTimelineTab()
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem('Saved') then
      sb_drawSavedScenarios()
      ImGui.EndTabItem()
    end
    ImGui.EndTabBar()
  else
    sb_drawHomeTab()
  end
  ImGui.Separator()
  ImGui.TextWrapped(tostring(ScenarioBuilder.state.status or 'Ready.'))
end

return ScenarioBuilder
