-- GTS/stats_browser.lua
-- Stats Editor tab (ImGui). Drawn by GTS/main_ui.lua.

local StatsUI = StatsUI or {}
local AssetRegistry = require("GTS/Core/asset_registry")

StatsUI.state = StatsUI.state or {
  keyword = "",
  -- Bookmarks
  bookmarks = {}, -- [statName]=true
  showOnlyBookmarked = false,
  bookmarkPick = "",
  showOnlyWeaponStats = false,
  _weaponEID = nil,
  cmpEnabled = false,
  cmpOp = "==", -- one of: ==  ~=  >  <  >=  <=
  cmpValueStr = "",
  cmpValueValid = false,
  cmpValue = 0,
  cmpSource = "Current Amount",
  refreshEvery = 0.50,
  _nextRefresh = 0,
  _built = false,
  stats = {},     -- { name, comment, rec, enum, poolEnum, cur, poolCur, poolMax, max, liveCurrent, liveMax, poolPercent, editMode, editValueStr }
  _filtered = {},
  _lastFilter = "",
  scanPresetName = "",
  scanPresets = {},
  observerBuilder = {
    search = "",
    source = "Current Amount",
    compareMode = "True Number",
    op = ">",
    valueStr = "100",
    pickIndex = 1,
    filtered = {},
    lastFilter = "",
    nextId = 1,
    list = {},
    presetName = "",
    selectedPresetId = "",
    status = "",
  },
  presetBuilder = {
    search = "",
    mode = "Add",
    valueStr = "10",
    pickIndex = 1,
    filtered = {},
    lastFilter = "",
    nextId = 1,
    list = {},
    presetName = "",
    selectedPresetId = "",
    status = "",
  },
  _presetStatus = "",
  _observerStatus = "",
  _guideStatus = "",
  _guideStatusKind = "info",
  activeSubtab = "Live Stats",
  -- Bookmark system: keys are "type:name" e.g. "stat:Health"
  bookmarks = {},
  _bookmarksSubtab = "Live Stats",
}

local function _pcall(f)
  local ok, r = pcall(f)
  if ok then return r end
  return nil
end

-- ── Glyph helpers (same pattern as shooter_tab / spawn_tools) ────────
local function _glyphFromKeys(keys, fallback)
  if type(IconGlyphs) == "table" then
    for _, k in ipairs(keys) do
      local g = IconGlyphs[k]
      if g ~= nil and g ~= "" and g ~= "?" and g ~= "S" then return g end
    end
  end
  return fallback
end
local function _glyphMagnify()
  return _glyphFromKeys({"Magnify","MagnifyPlus","MagnifyScan","Search","FindReplace"}, "?")
end
local function _glyphBmOn()
  return _glyphFromKeys({"Bookmark","BookmarkCheck","BookmarkStar"}, "*")
end
local function _glyphBmOff()
  return _glyphFromKeys({"BookmarkOutline","BookmarkPlusOutline","BookmarkAddOutline"}, "o")
end

-- ── Bookmark helpers — thin wrappers around the global GTS_Bookmarks store ──
-- The global store is defined in utils.lua and shared across all GTS modules.
local function _bm_is(itemType, name)
  return (GTS_Bookmarks ~= nil) and GTS_Bookmarks[tostring(itemType or "item") .. ":" .. tostring(name or "")] ~= nil
end
local function _bm_set(itemType, name, val)
  if type(GTS_Bookmarks) ~= "table" then GTS_Bookmarks = {} end
  local key = tostring(itemType or "item") .. ":" .. tostring(name or "")
  if val then
    GTS_Bookmarks[key] = { type = tostring(itemType), id = tostring(name), label = tostring(name),
      savedAt = (os and os.date and os.date("%Y-%m-%d %H:%M")) or "" }
  else
    GTS_Bookmarks[key] = nil
  end
  -- Save to disk on every change
  local ok, P = pcall(require, "GTS/Core/persistence")
  if ok and P and P.SaveBookmarks then pcall(P.SaveBookmarks) end
end
local function _bm_star(itemType, name, uid)
  local on = _bm_is(itemType, name)
  local glyph = on and _glyphBmOn() or _glyphBmOff()
  local lbl = glyph .. "##bm_" .. tostring(uid or name)
  if ImGui.SmallButton(lbl) then
    _bm_set(itemType, name, not on)
    on = not on
  end
  if ImGui.IsItemHovered() then
    ImGui.BeginTooltip()
    ImGui.TextUnformatted(on and "Remove bookmark" or "Bookmark this item")
    ImGui.EndTooltip()
  end
  return on
end
-- ─────────────────────────────────────────────────────────────────────

-- Normalize CET ImGui return conventions (different builds return either value, (changed,value) or (value,changed))
local function _CheckboxValue(label, value)
  local a, b = ImGui.Checkbox(label, value)
  -- CET ImGui bindings vary:
  --  * some return (changed:boolean, value:boolean)
  --  * some return (value:boolean, changed:boolean)
  --  * some return just (value:boolean)
  -- We only care about the resulting value, so detect ordering when both are booleans.
  if type(a) == "boolean" and type(b) == "boolean" then
    -- If b matches "changed" for a, then a is the value.
    if b == (a ~= value) then return a end
    -- If a matches "changed" for b, then b is the value.
    if a == (b ~= value) then return b end
    -- Fallback: most common CET binding is (changed, value)
    return b
  end
  if type(a) == "boolean" then
    return a
  end
  return value
end

-- Normalize CET ImGui InputText return conventions.
local function _InputTextValue(label, value, bufSize, flags)
  if flags ~= nil then
    local a, b = ImGui.InputText(label, value, bufSize, flags)
    if type(a) == "boolean" and type(b) == "string" then return b end
    if type(a) == "string" then return a end
    if type(b) == "string" then return b end
    return value
  end
  local a, b = ImGui.InputText(label, value, bufSize)
  if type(a) == "boolean" and type(b) == "string" then return b end
  if type(a) == "string" then return a end
  if type(b) == "string" then return b end
  return value
end

local function _InputFloatValue(label, value, step, stepFast, fmt)
  local a, b = ImGui.InputFloat(label, value, step, stepFast, fmt)
  if type(a) == "boolean" and type(b) == "number" then return b end
  if type(a) == "number" then return a end
  if type(b) == "number" then return b end
  return value
end

local function _ComboSelect(label, currentValue, labels, width)
  if type(labels) ~= "table" or #labels == 0 then return tostring(currentValue or "") end
  local current = tostring(currentValue or labels[1] or "")
  local found = false
  for i = 1, #labels do
    if tostring(labels[i] or "") == current then found = true break end
  end
  if not found then current = tostring(labels[1] or current) end

  if type(ImGui.SetNextItemWidth) == "function" then
    if type(width) == "number" and width > 0 then
      ImGui.SetNextItemWidth(width)
    else
      ImGui.SetNextItemWidth(-1)
    end
  end

  if type(ImGui.BeginCombo) == "function" then
    if ImGui.BeginCombo(label, current) then
      for i = 1, #labels do
        local item = tostring(labels[i] or "")
        local selected = (item == current)
        if ImGui.Selectable(item, selected) then current = item end
      end
      ImGui.EndCombo()
    end
    return current
  end

  local currentIndex = 0
  for i = 1, #labels do
    if tostring(labels[i] or "") == current then currentIndex = i - 1 break end
  end
  local r1, r2 = ImGui.Combo(label, currentIndex, labels, #labels)
  local newIndex = nil
  if type(r1) == "boolean" then
    if r1 then newIndex = r2 end
  elseif type(r1) == "number" then
    newIndex = r1
  end
  if type(newIndex) == "number" then return tostring(labels[newIndex + 1] or current) end
  return current
end

local function _drawInlineChoiceButtons(uniqueId, currentValue, options, labels, perLine)
  if type(options) ~= "table" or #options == 0 then return tostring(currentValue or "") end
  local picked = tostring(currentValue or options[1] or "")
  local current = picked
  local maxPerLine = math.max(1, tonumber(perLine or #options) or #options)
  for i = 1, #options do
    local optionValue = tostring(options[i] or "")
    local buttonText = type(labels) == "table" and tostring(labels[i] or optionValue) or optionValue
    local drawText = (current == optionValue) and ("[ " .. buttonText .. " ]") or buttonText
    if ImGui.SmallButton(drawText .. "##" .. tostring(uniqueId or "choice") .. "_" .. tostring(i)) then
      picked = optionValue
      current = optionValue
    end
    local endOfLine = ((i % maxPerLine) == 0)
    if i < #options and not endOfLine then ImGui.SameLine() end
  end
  return picked
end

local function _drawInlineChoiceList(uniqueId, currentValue, options, labels, _)
  if type(options) ~= "table" or #options == 0 then return tostring(currentValue or "") end
  local picked = tostring(currentValue or options[1] or "")
  local current = picked
  for i = 1, #options do
    local optionValue = tostring(options[i] or "")
    local label = type(labels) == "table" and tostring(labels[i] or optionValue) or optionValue
    local selected = (current == optionValue)
    if ImGui.Selectable(label .. "##" .. tostring(uniqueId or "choice") .. "_pick_" .. tostring(i), selected) then
      picked = optionValue
      current = optionValue
    end
  end
  return picked
end

local function _getPlayer() return Game.GetPlayer() end
local function _getEID() local p=_getPlayer(); return p and p:GetEntityID() or nil end
local function _getSS() return Game.GetStatsSystem() end
local function _getSPS() return Game.GetStatPoolsSystem and Game.GetStatPoolsSystem() or nil end

local function _normalizeEditMode(v)
  local s = tostring(v or "add"):lower()
  if s == "set" or s == "Set" then return "set" end
  if s == "mul" or s == "multiply" or s == "x" or s == "*" then return "mul" end
  if s == "div" or s == "divide" or s == "/" then return "div" end
  return "add"
end

-- Compute the result value of applying an edit operation to a base value.
local function _computeEditResult(base, op, operand)
  if type(base) ~= "number" or type(operand) ~= "number" then return nil end
  if op == "set" then return operand end
  if op == "mul" then return base * operand end
  if op == "div" then
    if math.abs(operand) < 0.00001 then return nil end  -- avoid div/0
    return base / operand
  end
  return base + operand  -- "add" default
end

local function _parseEditValue(valueStr)
  local raw = tostring(valueStr or "")
  local trimmed = raw:gsub("^%s+", ""):gsub("%s+$", "")
  if trimmed == "" then return nil end
  return tonumber(trimmed)
end

local function _statPoolEnumForName(name)
  if type(name) ~= "string" or name == "" then return nil end
  return gamedataStatPoolType and gamedataStatPoolType[name] or nil
end

local function _clone(value, seen)
  if type(value) ~= "table" then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do
    out[_clone(k, seen)] = _clone(v, seen)
  end
  return out
end

local function _trim(s)
  s = tostring(s or "")
  return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function _normalizeObserverSource(v)
  local src = tostring(v or "Current Amount")
  if src == "Pool Current" then return "Current Amount" end
  if src == "Pool Max" then return "Max Amount" end
  if src == "Pool %" then return "Pool Percent" end
  if src ~= "Current Amount" and src ~= "Max Amount" and src ~= "Pool Percent" and src ~= "Stat Value" then
    src = "Current Amount"
  end
  return src
end

local function _observerSourceOptions()
  return {"Current Amount", "Max Amount", "Pool Percent", "Stat Value"}
end

local function _prettyStatName(name)
  local s = tostring(name or "Stat")
  if s == "" then s = "Stat" end
  s = s:gsub("_", " ")
  s = s:gsub("(%l)(%u)", "%1 %2")
  return s
end

local function _observerSourceDisplayLabel(statName, source)
  local src = _normalizeObserverSource(source)
  local pretty = _prettyStatName(statName)
  if tostring(statName or "") == "CarryCapacity" then
    if src == "Current Amount" then return "Current Carry Used" end
    if src == "Max Amount" then return "Carry Capacity Max" end
    if src == "Pool Percent" then return "Carry Usage %" end
    return "Raw Carry Capacity Stat"
  end
  if src == "Current Amount" then return "Current " .. pretty end
  if src == "Max Amount" then return "Max " .. pretty end
  if src == "Pool Percent" then return pretty .. " %" end
  return "Raw " .. pretty .. " Stat"
end

local function _drawObserverSourceCombo(label, currentValue, statName, width)
  local current = _normalizeObserverSource(currentValue)
  local opts = _observerSourceOptions()
  local display = {}
  for i = 1, #opts do display[i] = _observerSourceDisplayLabel(statName, opts[i]) end
  return _drawInlineChoiceList(label, current, opts, display, 88)
end

local function _observerCompareModeOptions(source)
  local src = _normalizeObserverSource(source)
  if src == "Current Amount" then return {"True Number", "Percent"} end
  if src == "Pool Percent" then return {"Percent"} end
  return {"True Number"}
end

local function _normalizeObserverCompareMode(source, mode)
  local opts = _observerCompareModeOptions(source)
  local wanted = tostring(mode or opts[1] or "True Number")
  for i = 1, #opts do
    if tostring(opts[i]) == wanted then return tostring(opts[i]) end
  end
  return tostring(opts[1] or "True Number")
end

local function _observerCompareModeLabel(source, mode)
  local m = _normalizeObserverCompareMode(source, mode)
  if m == "Percent" then return "Percent" end
  return "True Number"
end

local function _resolveObserverCompareTarget(entry, snap)
  entry = entry or {}
  local src = _normalizeObserverSource(entry.src or "Current Amount")
  local compareMode = _normalizeObserverCompareMode(src, entry.compareMode or "True Number")
  local rawTarget = tonumber(entry.value or entry.valueStr)
  if rawTarget == nil then return nil, nil, compareMode end
  if src == "Current Amount" and compareMode == "Percent" then
    local maxValue = type(snap) == "table" and tonumber(snap.max) or nil
    if maxValue == nil then return nil, rawTarget, compareMode end
    return (rawTarget / 100.0) * maxValue, rawTarget, compareMode
  end
  return rawTarget, rawTarget, compareMode
end

local function _getCarryUsageCurrent(player)
  local p = player or _getPlayer()
  if not p then return nil end
  _pcall(function()
    if p.UpdateInventoryWeight ~= nil then p:UpdateInventoryWeight(0) end
    if p.EvaluateEncumbrance ~= nil then p:EvaluateEncumbrance() end
  end)
  if p.curInventoryWeight ~= nil then
    return tonumber(p.curInventoryWeight)
  end
  return nil
end

local function _shouldTreatPoolAsPercent(statName, poolCur, resolvedMax, poolMax)
  if type(poolCur) ~= "number" then return false end
  if poolCur < -0.0001 or poolCur > 100.0001 then return false end
  if type(poolMax) == "number" and poolMax > 100.0001 then return false end
  if tostring(statName or "") == "Health" or tostring(statName or "") == "Stamina" or tostring(statName or "") == "Oxygen" then
    return true
  end
  if type(resolvedMax) == "number" and resolvedMax > 100.0001 then
    return true
  end
  return false
end

local function _buildStatSnapshot(statName, statValue, poolCur, poolMax, fallbackMax)
  local snap = {
    stat = tostring(statName or ""),
    value = statValue,
    poolCur = poolCur,
    poolMax = poolMax,
    current = nil,
    max = nil,
    percent = nil,
    sourceMode = "stat",
  }

  local player = _getPlayer()
  if snap.stat == "CarryCapacity" then
    local maxv = (type(statValue) == "number") and statValue or fallbackMax
    local used = _getCarryUsageCurrent(player)
    snap.current = used
    snap.max = maxv
    snap.sourceMode = used ~= nil and "carry_usage" or "stat"
    if type(used) == "number" and type(maxv) == "number" and maxv > 0 then
      snap.percent = (used / maxv) * 100.0
    end
    if snap.current == nil then snap.current = statValue end
    if snap.max == nil then snap.max = fallbackMax end
    return snap
  end

  local resolvedMax = nil
  if type(poolMax) == "number" then
    resolvedMax = poolMax
  elseif type(statValue) == "number" then
    resolvedMax = statValue
  elseif type(fallbackMax) == "number" then
    resolvedMax = fallbackMax
  end

  local resolvedCurrent = nil
  if type(poolCur) == "number" then
    if _shouldTreatPoolAsPercent(statName, poolCur, resolvedMax, poolMax) then
      snap.percent = poolCur
      if type(resolvedMax) == "number" then
        resolvedCurrent = (poolCur / 100.0) * resolvedMax
      else
        resolvedCurrent = poolCur
      end
      snap.sourceMode = "normalized_pool"
    else
      resolvedCurrent = poolCur
      snap.sourceMode = "absolute_pool"
      if type(resolvedMax) == "number" and resolvedMax > 0 then
        snap.percent = (resolvedCurrent / resolvedMax) * 100.0
      end
    end
  end

  if resolvedCurrent == nil then resolvedCurrent = statValue end
  if resolvedMax == nil and type(statValue) == "number" then resolvedMax = statValue end
  if snap.percent == nil and type(resolvedCurrent) == "number" and type(resolvedMax) == "number" and resolvedMax > 0 then
    snap.percent = (resolvedCurrent / resolvedMax) * 100.0
  end

  snap.current = resolvedCurrent
  snap.max = resolvedMax
  return snap
end

local function _getStatSourceValue(statRow, source)
  local row = type(statRow) == "table" and statRow or {}
  local src = _normalizeObserverSource(source)
  local snap = row.snapshot or {
    current = row.liveCurrent,
    max = row.liveMax,
    percent = row.poolPercent,
    value = row.cur,
  }
  if src == "Current Amount" then return snap.current end
  if src == "Max Amount" then return snap.max end
  if src == "Pool Percent" then return snap.percent end
  return snap.value
end

local function _opEval(cur, op, target)
  if type(cur) ~= "number" or type(target) ~= "number" then return nil end
  if op == "==" then return (cur == target)
  elseif op == "~=" then return (cur ~= target)
  elseif op == ">" then return (cur > target)
  elseif op == "<" then return (cur < target)
  elseif op == ">=" then return (cur >= target)
  elseif op == "<=" then return (cur <= target)
  end
  return nil
end

local Guide = nil
do
  local ok, mod = pcall(require, "GTS/Guides/stats_editor_guide")
  if ok and type(mod) == "table" then
    Guide = mod
  elseif not ok then
    print("[GTS][StatsUI] Guide module failed to load: " .. tostring(mod))
  end
end

local function _guideCanPerform(action, ctx)
  if type(Guide) ~= "table" or type(Guide.CanPerform) ~= "function" then return true end
  local ok, msg = Guide.CanPerform(action, ctx)
  if ok then return true end
  if msg and msg ~= "" then
    _setGuideStatus(tostring(msg), "error")
    if type(Guide.ShowNotice) == "function" then
      Guide.ShowNotice("Guide Hint", tostring(msg), "error")
    end
  end
  return false
end

local function _guideExpected(action)
  return type(Guide) == "table" and type(Guide.IsFocus) == "function" and Guide.IsFocus(action) == true
end

local function _guideStep()
  if type(Guide) == "table" and type(Guide.GetStep) == "function" then
    return Guide.GetStep()
  end
  return nil
end

local function _drawGuideTarget(text)
  if not text or text == "" then return end
  ImGui.TextWrapped("Guide target: " .. tostring(text))
end


local function _setGuideStatus(text, kind)
  local st = StatsUI.state
  st._guideStatus = tostring(text or "")
  st._guideStatusKind = tostring(kind or "info")
end

local function _drawGuideStatus()
  local st = StatsUI.state
  if not st._guideStatus or st._guideStatus == "" then return end
  local kind = st._guideStatusKind or "info"
  local colors = {
    info = {0.90, 0.82, 0.28, 1.0},
    error = {1.00, 0.28, 0.28, 1.0},
    success = {0.35, 0.95, 0.45, 1.0},
  }
  local c = colors[kind] or colors.info
  if ImGui.PushStyleColor then
    ImGui.PushStyleColor(ImGuiCol.Text, c[1], c[2], c[3], c[4])
    ImGui.TextWrapped("[ Guide Status ] " .. tostring(st._guideStatus))
    ImGui.PopStyleColor()
  else
    ImGui.TextWrapped("[ Guide Status ] " .. tostring(st._guideStatus))
  end
end


local function _tabBarOpen(id)
  if type(ImGui.BeginTabBar) ~= "function" then return false end
  local a,b = ImGui.BeginTabBar(id)
  if type(a) == "boolean" then return a end
  if type(b) == "boolean" then return b end
  return false
end

local function _tabItemOpen(label, selected)
  if type(ImGui.BeginTabItem) ~= "function" then return false end

  local flags = 0
  if selected == true and type(ImGuiTabItemFlags) == "table" and ImGuiTabItemFlags.SetSelected ~= nil then
    flags = ImGuiTabItemFlags.SetSelected
  end

  local ok, a, b
  if flags ~= 0 then
    ok, a, b = pcall(ImGui.BeginTabItem, label, nil, flags)
  else
    ok, a, b = pcall(ImGui.BeginTabItem, label)
  end

  if not ok then
    local c, d = ImGui.BeginTabItem(label)
    if type(c) == "boolean" and type(d) == "boolean" then return c or d end
    if type(c) == "boolean" then return c end
    if type(d) == "boolean" then return d end
    return false
  end

  if type(a) == "boolean" and type(b) == "boolean" then return a or b end
  if type(a) == "boolean" then return a end
  if type(b) == "boolean" then return b end
  return false
end

local function _countChangedScanRows()
  local a = StatsUI.analyzer or {}
  return #(a.inc or {}) + #(a.dec or {}) + #(a.returned or {}) + #(a.persisted or {})
end

-- Bookmark filter uses the _bm_is wrapper defined above (GTS_Bookmarks global).

local function _tryMax(rec)
  local tries = {"GetMaxValue","GetMax","MaxValue","Max","UpperLimit","GetUpperLimit","GetLimitMax"}
  for i=1,#tries do
    local m = tries[i]
    local v = _pcall(function()
      local fn = rec[m]
      if type(fn) == "function" then return fn(rec) end
      return nil
    end)
    if v ~= nil then return v end
  end
  return nil
end

local function _buildOnce()
  local st = StatsUI.state
  st.stats = {}
  st._filtered = {}

  local records = _pcall(function() return TweakDB:GetRecords("gamedataStat_Record") end)
  if type(records) ~= "table" then
    st._built = true
    return
  end

  for i=1,#records do
    local rec = records[i]
    local name = _pcall(function() return tostring(rec:EnumName()) end) or ""
    if name ~= "" then
      local comment = _pcall(function() return tostring(rec:EnumComment()) end) or ""
      local enum = gamedataStatType[name]
      st.stats[#st.stats+1] = {
        name = name,
        comment = comment,
        rec = rec,
        enum = enum,
        poolEnum = _statPoolEnumForName(name),
        cur = nil,
        wcur = nil,
        poolCur = nil,
        poolMax = nil,
        max = _tryMax(rec),
        liveCurrent = nil,
        liveMax = nil,
        poolPercent = nil,
        snapshot = nil,
        editMode = "add",   -- "add" | "set" | "mul" | "div"
        editValueStr = "",
      }
    end
  end

  table.sort(st.stats, function(a,b) return a.name < b.name end)
  st._built = true
end

local function _refreshLive()
  local st = StatsUI.state
  local now = os.clock()
  if now < st._nextRefresh then return end
  st._nextRefresh = now + (st.refreshEvery or 0.50)

  local ss = _getSS()
  local sps = _getSPS()
  local eid = _getEID()
  local pl = _getPlayer()
  local w = pl and _pcall(function() return pl:GetActiveWeapon() end) or nil
  local wid = w and _pcall(function() return w:GetEntityID() end) or nil
  st._weaponEID = wid
  if not ss or not eid then
    for i=1,#st.stats do
      local row = st.stats[i]
      row.cur = nil
      row.wcur = nil
      row.poolCur = nil
      row.poolMax = nil
      row.liveCurrent = nil
      row.liveMax = nil
      row.poolPercent = nil
      row.snapshot = nil
    end
    return
  end

  local hasPoolMax = (sps ~= nil and sps.GetStatPoolMaxValue ~= nil)
  for i=1,#st.stats do
    local s = st.stats[i]
    if s.enum ~= nil then
      s.cur = _pcall(function() return ss:GetStatValue(eid, s.enum) end)
      if wid ~= nil then
        s.wcur = _pcall(function() return ss:GetStatValue(wid, s.enum) end)
      else
        s.wcur = nil
      end
    else
      s.cur = nil
      s.wcur = nil
    end
    if s.poolEnum ~= nil and sps then
      s.poolCur = _pcall(function() return sps:GetStatPoolValue(eid, s.poolEnum) end)
      if hasPoolMax then
        s.poolMax = _pcall(function() return sps:GetStatPoolMaxValue(eid, s.poolEnum) end)
      else
        s.poolMax = nil
      end
    else
      s.poolCur = nil
      s.poolMax = nil
    end
    local snap = _buildStatSnapshot(s.name, s.cur, s.poolCur, s.poolMax, s.max)
    s.snapshot = snap
    s.liveCurrent = snap.current
    s.liveMax = snap.max
    s.poolPercent = snap.percent
  end
end

local function _filter()
  local st = StatsUI.state
  local kw = st.keyword or ""
  local cmpEnabled = (st.cmpEnabled == true)
  local cmpOp = st.cmpOp or "=="
  local cmpValueStr = st.cmpValueStr or ""
  local cmpValue = st.cmpValue
  local cmpValueValid = (st.cmpValueValid == true)
  local cmpSource = tostring(st.cmpSource or "Stat Value")
  local filterKey = string.format("%s|%s|%s|src:%s|bm:%s|w:%s", kw, tostring(cmpEnabled), tostring(cmpOp) .. ":" .. tostring(cmpValueStr), cmpSource, tostring(st.showOnlyBookmarked), tostring(st.showOnlyWeaponStats))
  if filterKey == st._lastFilter then return end
  st._lastFilter = filterKey

  st._filtered = {}
  local low = string.lower(kw)
  for i=1,#st.stats do
    local s = st.stats[i]
    local okCmp = true
    local bmOk = (not st.showOnlyBookmarked) or _bm_is("stat", s.name)
    local wOk = true
    if st.showOnlyWeaponStats then
      local wv = s.wcur
      wOk = (type(wv) == "number") and (math.abs(wv) > 0.0001)
    end
    if cmpEnabled then
      if not cmpValueValid then
        okCmp = false
      else
        local v = _getStatSourceValue(s, cmpSource)
        if type(v) ~= "number" or type(cmpValue) ~= "number" then
          okCmp = false
        else
          if cmpOp == "==" then okCmp = (v == cmpValue)
          elseif cmpOp == "~=" then okCmp = (v ~= cmpValue)
          elseif cmpOp == ">" then okCmp = (v > cmpValue)
          elseif cmpOp == "<" then okCmp = (v < cmpValue)
          elseif cmpOp == ">=" then okCmp = (v >= cmpValue)
          elseif cmpOp == "<=" then okCmp = (v <= cmpValue)
          else okCmp = true end
        end
      end
    end

        if low == "" then
      if okCmp and bmOk and wOk then st._filtered[#st._filtered+1] = s end
    else
      local n = string.lower(s.name or "")
      local c = string.lower(s.comment or "")
      if string.find(n, low, 1, true) or string.find(c, low, 1, true) then
        if okCmp and bmOk and wOk then st._filtered[#st._filtered+1] = s end
      end
    end
  end

  -- When value filtering is enabled, sort results in a way that matches the comparison.
  if cmpEnabled then
    local function _abs(x) return (x < 0) and -x or x end
    table.sort(st._filtered, function(a,b)
      local av, bv = _getStatSourceValue(a, cmpSource), _getStatSourceValue(b, cmpSource)
      if type(av) ~= "number" and type(bv) ~= "number" then return (a.name or "") < (b.name or "") end
      if type(av) ~= "number" then return false end
      if type(bv) ~= "number" then return true end

      if cmpOp == "<" or cmpOp == "<=" then
        if av == bv then return (a.name or "") < (b.name or "") end
        return av < bv
      elseif cmpOp == ">" or cmpOp == ">=" then
        if av == bv then return (a.name or "") < (b.name or "") end
        return av > bv
      elseif cmpOp == "==" then
        local ad = _abs(av - cmpValue)
        local bd = _abs(bv - cmpValue)
        if ad == bd then return (a.name or "") < (b.name or "") end
        return ad < bd
      elseif cmpOp == "~=" then
        local ad = _abs(av - cmpValue)
        local bd = _abs(bv - cmpValue)
        if ad == bd then return (a.name or "") < (b.name or "") end
        return ad > bd
      end

      return (a.name or "") < (b.name or "")
    end)
  end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Stat apply functions - correct CET API usage for Cyberpunk 2077
--
-- Two distinct systems govern stat values:
--   1. StatsSystem (ss) — governs stat modifiers (Strength, Reflexes, damage
--      multipliers, carry capacity, etc.) via gameStatModifierType
--   2. StatPoolsSystem (sps) — governs pool current values (Health, Stamina,
--      Oxygen, etc.) via RequestSettingStatPoolValue
--
-- For pool stats, the pool stores a percentage (0–100) internally.
-- For plain stats, modifiers stack; we use Override type to set exact values.
-- ─────────────────────────────────────────────────────────────────────────────

-- Set a pool stat current value (Health, Stamina, Oxygen, etc.)
-- targetValue is in the same units as snap.current (absolute HP, not percent)
local function _getLiveStatValue(statName, source)
  local st = StatsUI.state
  if type(st.stats) == "table" then
    for i=1,#st.stats do
      local s = st.stats[i]
      if s and s.name == statName then
        local picked = _getStatSourceValue(s, source)
        if type(picked) == "number" then return picked end
        local snap = _buildStatSnapshot(s.name, s.cur, s.poolCur, s.poolMax, s.max)
        picked = _getStatSourceValue({ snapshot = snap, cur = s.cur }, source)
        if type(picked) == "number" then return picked end
        break
      end
    end
  end

  local eid = _getEID()
  if not eid then return nil end
  local ss = _getSS()
  local sps = _getSPS()
  local statEnum = gamedataStatType[statName]
  local poolEnum = _statPoolEnumForName(statName)
  local statValue = nil
  local poolCur = nil
  local poolMax = nil
  if ss and statEnum ~= nil then
    statValue = _pcall(function() return ss:GetStatValue(eid, statEnum) end)
  end
  if sps and poolEnum ~= nil then
    poolCur = _pcall(function() return sps:GetStatPoolValue(eid, poolEnum) end)
    if sps.GetStatPoolMaxValue ~= nil then
      poolMax = _pcall(function() return sps:GetStatPoolMaxValue(eid, poolEnum) end)
    end
  end
  local snap = _buildStatSnapshot(statName, statValue, poolCur, poolMax, nil)
  return _getStatSourceValue({ snapshot = snap, cur = statValue }, source)
end

-- _applySet: legacy wrapper - routes through unified _applyEditOp
-- ─────────────────────────────────────────────────────────────────────────────
-- Stat apply functions — uses the original verified RPGManager pattern.
-- All operators reduce to: compute target, compute delta, apply delta.
-- ─────────────────────────────────────────────────────────────────────────────

local function _applyDelta(statName, delta)
  local ss     = _getSS()
  local eid    = _getEID()
  local stEnum = gamedataStatType[statName]
  if not ss or not eid or not stEnum then return false end

  local mt  = gameStatModifierType.Additive
  local mod = _pcall(function()
    return RPGManager.CreateStatModifier(stEnum, mt, gameStatModifierOperation.Add, delta)
  end) or _pcall(function()
    return RPGManager.CreateStatModifier(stEnum, mt, delta)
  end)
  if not mod then return false end

  -- Pool stats: also update the visible bar via RequestSettingStatPoolValue
  local poolEnum = _statPoolEnumForName(statName)
  if poolEnum then
    local sps = _getSPS()
    if sps then
      local lv = _getLiveStatValue(statName) or 0
      local tgt = lv + delta
      local poolMax = _pcall(function()
        return sps.GetStatPoolMaxValue and sps:GetStatPoolMaxValue(eid, poolEnum) or nil
      end)
      if type(poolMax) == "number" and poolMax > 0 then
        local pct = math.max(0, math.min(100, (tgt / poolMax) * 100.0))
        _pcall(function() sps:RequestSettingStatPoolValue(eid, poolEnum, pct, eid) end)
      end
    end
  end

  ss:AddModifier(eid, mod)
  return true
end

local function _applySet(statName, targetValue)
  if type(targetValue) ~= "number" then return false end
  local current = _getLiveStatValue(statName)
  local delta = type(current) == "number" and (targetValue - current) or targetValue
  if math.abs(delta) < 0.0001 then return true end
  return _applyDelta(statName, delta)
end

local function _applyEditOp(statName, op, operand)
  if type(operand) ~= "number" then return false end
  op = _normalizeEditMode(op)
  if op == "add" then return _applyDelta(statName, operand) end
  local current = _getLiveStatValue(statName)
  if type(current) ~= "number" then
    if op == "set" then return _applyDelta(statName, operand) end
    return false
  end
  local target = _computeEditResult(current, op, operand)
  if type(target) ~= "number" then return false end
  local delta = target - current
  if math.abs(delta) < 0.0001 then return true end
  return _applyDelta(statName, delta)
end


local function _scanRowsForPreset()
  local a = StatsUI.analyzer
  local rows = {}
  local seen = {}
  local buckets = { a.inc or {}, a.dec or {} }
  for bi=1,#buckets do
    local bucket = buckets[bi]
    for i=1,#bucket do
      local r = bucket[i]
      if r and r.name and not seen[r.name] and type(r.activated) == "number" then
        seen[r.name] = true
        rows[#rows+1] = { stat = r.name, mode = "set", value = r.activated }
      end
    end
  end
  table.sort(rows, function(a,b) return tostring(a.stat) < tostring(b.stat) end)
  return rows
end

local function _findNamedStatPreset(name)
  if type(name) ~= "string" or name == "" then return nil end
  return AssetRegistry.FindByTypeAndName and AssetRegistry.FindByTypeAndName("stat_preset", name) or nil
end

local function _upsertStatPreset(name, entries, source, existingId)
  local trimmed = tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if trimmed == "" then return nil, "Enter a preset name first." end
  if type(entries) ~= "table" or #entries == 0 then return nil, "No stat entries to save." end
  local asset = {
    type = "stat_preset",
    name = trimmed,
    data = {
      source = source or "stats_editor",
      entries = entries,
    }
  }
  local existing = nil
  if tostring(existingId or "") ~= "" then
    local loaded = AssetRegistry.Get and AssetRegistry.Get(existingId) or nil
    if type(loaded) == "table" and tostring(loaded.type or "") == "stat_preset" then
      existing = loaded
    end
  end
  if not existing then
    existing = AssetRegistry.FindByTypeAndName and AssetRegistry.FindByTypeAndName("stat_preset", trimmed) or nil
  end
  if type(existing) == "table" then
    asset.id = existing.id
    asset.createdAtText = existing.createdAtText
    return AssetRegistry.Upsert(asset)
  end
  return (AssetRegistry.UpsertNew and AssetRegistry.UpsertNew(asset, trimmed)) or AssetRegistry.Upsert(asset)
end

local function _editedRowsForPreset()
  local st = StatsUI.state
  local rows = {}
  for i = 1, #(st.stats or {}) do
    local s = st.stats[i]
    local mode = _normalizeEditMode((s or {}).editMode)
    local value = _parseEditValue((s or {}).editValueStr)
    if s and s.name and value ~= nil then
      if mode == "add" then
        if math.abs(value) > 0.0001 then
          rows[#rows + 1] = { stat = s.name, mode = "add", value = value }
        end
      elseif mode == "mul" then
        rows[#rows + 1] = { stat = s.name, mode = "mul", value = value }
      elseif mode == "div" then
        if math.abs(value) > 0.00001 then
          rows[#rows + 1] = { stat = s.name, mode = "div", value = value }
        end
      else
        rows[#rows + 1] = { stat = s.name, mode = "set", value = value }
      end
    end
  end
  table.sort(rows, function(a, b) return tostring(a.stat) < tostring(b.stat) end)
  return rows
end

function StatsUI.SaveCurrentEditedValuesAsPreset(name)
  local st = StatsUI.state
  local entries = _editedRowsForPreset()
  if #entries == 0 then
    st._presetStatus = "Enter at least one Add or Set value first."
    return false
  end
  local saved, err = _upsertStatPreset(name, entries, "stats_editor")
  if not saved then
    st._presetStatus = tostring(err or "Could not save preset.")
    return false
  end
  st._presetStatus = string.format("Saved Stat Profile '%s' with %d entries.", tostring(saved.name), #entries)
  return true
end

function StatsUI.ApplyPresetEntries(entries)
  if type(entries) ~= "table" then return false end
  local applied = 0
  for i = 1, #entries do
    local entry = entries[i]
    if entry and entry.stat then
      local ok = false
      if entry.mode == "set" then
        ok = _applySet(entry.stat, entry.value)
      elseif entry.mode == "mul" or entry.mode == "div" then
        ok = _applyEditOp(entry.stat, entry.mode, entry.value)
      else
        ok = _applyDelta(entry.stat, entry.value or 0)
      end
      if ok then applied = applied + 1 end
    end
  end
  return applied > 0
end

function StatsUI.BuildBaselineEntries(entries)
  if type(entries) ~= "table" then return {} end
  local out = {}
  local seen = {}
  for i = 1, #entries do
    local entry = entries[i]
    local stat = entry and entry.stat or nil
    if stat and not seen[stat] then
      local current = _getLiveStatValue(stat)
      if type(current) == "number" then
        out[#out + 1] = { stat = stat, mode = "set", value = current }
        seen[stat] = true
      end
    end
  end
  return out
end

local function _saveScanPreset(name)
  local st = StatsUI.state
  local trimmed = tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if trimmed == "" then
    st._presetStatus = "Enter a preset name first."
    return false
  end

  local entries = _scanRowsForPreset()
  if #entries == 0 then
    st._presetStatus = "No changed scan results are available to save yet."
    return false
  end

  st.scanPresets = st.scanPresets or {}
  local replaced = false
  for i=1,#st.scanPresets do
    local preset = st.scanPresets[i]
    if preset and preset.name == trimmed then
      st.scanPresets[i] = {
        name = trimmed,
        source = "scan_result",
        entryCount = #entries,
        entries = entries
      }
      replaced = true
      break
    end
  end

  if not replaced then
    st.scanPresets[#st.scanPresets+1] = {
      name = trimmed,
      source = "scan_result",
      entryCount = #entries,
      entries = entries
    }
  end

  table.sort(st.scanPresets, function(a,b) return tostring(a.name) < tostring(b.name) end)
  _upsertStatPreset(trimmed, entries, "scan_result")
  if Guide and Guide.IsEnabled and Guide.IsEnabled() then
    st._presetStatus = string.format("Saved preset '%s' with %d changed stats. Look below in Saved Scan Presets to apply or review it.", trimmed, #entries)
  else
    st._presetStatus = string.format("Saved preset '%s' with %d changed stats.", trimmed, #entries)
  end
  if Guide and Guide.Notify then Guide.Notify("saved_preset") end
  return true
end

local function _applyPreset(preset)
  if type(preset) ~= "table" or type(preset.entries) ~= "table" then return false, 0 end
  local applied = 0
  for i=1,#preset.entries do
    local entry = preset.entries[i]
    if entry and entry.stat then
      local ok = false
      if entry.mode == "set" then
        ok = _applySet(entry.stat, entry.value)
      else
        ok = _applyDelta(entry.stat, entry.value or 0)
      end
      if ok then applied = applied + 1 end
    end
  end
  return applied > 0, applied
end

local function _drawSavedScanPresets()
  local st = StatsUI.state
  if not ImGui.CollapsingHeader("Saved Scan Presets") then return end

  if Guide and Guide.IsEnabled and Guide.IsEnabled() and _guideStep() == "complete" then
    ImGui.TextWrapped("Guide complete: the preset you just saved appears in this list. Hover it to preview the saved values, or apply it to replay the scan result.")
    ImGui.Separator()
  end

  local presets = st.scanPresets or {}
  if #presets == 0 then
    ImGui.TextUnformatted("No saved scan presets yet. Finish a Cheat Impact Analyzer scan, enter a preset name, and save the changed results.")
    ImGui.Separator()
    return
  end

  if ImGui.BeginTable("scan_presets_tbl", 4, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders) then
    ImGui.TableSetupColumn("Preset", ImGuiTableColumnFlags.WidthStretch)
    ImGui.TableSetupColumn("Entries", ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableSetupColumn("Apply", ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableSetupColumn("Delete", ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableHeadersRow()

    local removeIndex = nil

    for i=1,#presets do
      local preset = presets[i]
      ImGui.TableNextRow()

      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(tostring(preset.name or ("Preset " .. tostring(i))))
      if ImGui.IsItemHovered() and type(preset.entries) == "table" then
        ImGui.BeginTooltip()
        local maxRows = math.min(#preset.entries, 12)
        for j=1,maxRows do
          local e = preset.entries[j]
          local op = (tostring(e.mode or "set") == "add") and "+=" or "="
          ImGui.TextUnformatted(string.format("%s %s %s", tostring(e.stat), op, _an_fmt(e.value)))
        end
        if #preset.entries > maxRows then
          ImGui.TextUnformatted("...")
        end
        ImGui.EndTooltip()
      end

      ImGui.TableSetColumnIndex(1)
      ImGui.TextUnformatted(tostring(preset.entryCount or (preset.entries and #preset.entries) or 0))

      ImGui.TableSetColumnIndex(2)
      if ImGui.SmallButton("Apply##scanpreset_" .. tostring(i)) then
        local ok, count = _applyPreset(preset)
        if ok then
          st._presetStatus = string.format("Applied preset '%s' to %d stats.", tostring(preset.name), tonumber(count) or 0)
        else
          st._presetStatus = string.format("Preset '%s' could not be applied.", tostring(preset.name))
        end
      end

      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton("Delete##scanpreset_" .. tostring(i)) then
        removeIndex = i
      end
    end

    if removeIndex then
      local dead = presets[removeIndex]
      table.remove(presets, removeIndex)
      local reg = _findNamedStatPreset(dead and dead.name or "")
      if reg then AssetRegistry.Delete(reg.id) end
      st._presetStatus = string.format("Deleted preset '%s'.", tostring(dead and dead.name or ""))
    end

    ImGui.EndTable()
  end

  if st._presetStatus and st._presetStatus ~= "" then
    ImGui.TextWrapped(st._presetStatus)
  end

  ImGui.Separator()
end

local function _drawGuideControls()
  if type(Guide) ~= "table" or type(Guide.IsEnabled) ~= "function" or type(Guide.SetEnabled) ~= "function" then return end

  local enabled = Guide.IsEnabled() == true
  local newEnabled = _CheckboxValue("Enable Stats Editor Guide", enabled)
  if newEnabled ~= enabled then
    Guide.SetEnabled(newEnabled)
    _an_reset()
    _setGuideStatus("", "info")
    if newEnabled then
      local suggested = (Guide.GetSuggestedPresetName and Guide.GetSuggestedPresetName()) or "Guide Demo Preset"
      StatsUI.state.scanPresetName = suggested
      StatsUI.state._presetStatus = "Guide enabled. Follow the popup instructions to run the example scan."
      _setGuideStatus("Guide enabled. Follow the popup instructions.", "info")
    else
      StatsUI.state._presetStatus = "Guide disabled."
      _setGuideStatus("", "info")
    end
  end

  if Guide.IsEnabled() then
    ImGui.SameLine()
    if ImGui.SmallButton("Restart Guide") then
      Guide.Reset()
      _an_reset()
      local suggested = (Guide.GetSuggestedPresetName and Guide.GetSuggestedPresetName()) or "Guide Demo Preset"
      StatsUI.state.scanPresetName = suggested
      StatsUI.state._presetStatus = "Guide restarted."
      _setGuideStatus("Guide restarted. Read the popup and follow the next step.", "info")
      _setGuideStatus("", "info")
    end
    ImGui.TextWrapped("The guide uses a safe mock mod menu so players can learn the Cheat Impact Analyzer, how result buckets work, how to bookmark them, and how to save a reusable preset.")
  else
    ImGui.TextWrapped("Enable the guide to open locked step-by-step popup windows that explain the Cheat Impact Analyzer, bookmarking, and saving scan results as a preset.")
  end

  _drawGuideStatus()
  ImGui.Separator()
end


-- =========================
-- Bookmarks
-- =========================
-- _bm_glyph/_bm_is/_bm_set/_bm_toggle/_bm_list are defined at the top of this file
-- using the GTS_Bookmarks global. These stubs keep any remaining callers working.
local function _bm_glyph() return _glyphBmOn() end
local function _bm_toggle(name) _bm_set("stat", name, not _bm_is("stat", name)) end
local function _bm_list()
  local out = {}
  for _, v in pairs(GTS_Bookmarks or {}) do
    if tostring(v.type or "") == "stat" then out[#out+1] = tostring(v.id or "") end
  end
  table.sort(out)
  return out
end

local function _bm_addFromBucket(bucket)
  if type(bucket) ~= "table" then return end
  for i=1,#bucket do
    local r = bucket[i]
    if r and r.name then _bm_set("stat", r.name, true) end
  end
end

-- =========================
-- Cheat Impact Analyzer
-- =========================
StatsUI.analyzer = StatsUI.analyzer or {
  state = "idle", -- idle -> baseline -> activated -> complete
  baseline = {},
  activated = {},
  deactivated = {},
  inc = {},
  dec = {},
  returned = {},
  persisted = {},
  _lastErr = nil
}


local function _an_arrow()
  if type(IconGlyphs) == "table" then
    local keys = {
      "ArrowRightThin", "ArrowRight", "ArrowRightBold",
      "ChevronRight", "ChevronRightThin", "AngleRight", "CaretRight",
    }
    for _,k in ipairs(keys) do
      local g = IconGlyphs[k]
      if g ~= nil and g ~= "" and g ~= "?" and g ~= "S" then return g end
    end
  end
  return "->"
end

local function _an_delta_glyph()
  -- Some CET builds may render certain Unicode symbols (like Δ) as '?'.
  -- Prefer a known icon glyph if available; otherwise use a safe ASCII label.
  if type(IconGlyphs) == "table" then
    local keys = {
      "PlusMinus", "Delta", "SwapHorizontal", "ArrowsLeftRight",
      "Compare", "Change", "Difference",
    }
    for _,k in ipairs(keys) do
      local g = IconGlyphs[k]
      if g ~= nil and g ~= "" and g ~= "?" and g ~= "S" then return g end
    end
  end
  return "+/-"
end

local function _an_fmt(v)
  if type(v) == "number" then
    -- Prefer integers when they are close to whole numbers
    if math.abs(v - math.floor(v + 0.5)) < 0.0001 then
      return tostring(math.floor(v + 0.5))
    end
    return string.format("%.3f", v)
  end
  return tostring(v)
end

local function _an_fmtDelta(d)
  if type(d) ~= "number" then return tostring(d) end
  local sign = (d > 0) and "+" or ""
  if math.abs(d - math.floor(d + 0.5)) < 0.0001 then
    return sign .. tostring(math.floor(d + 0.5))
  end
  return string.format("%s%.3f", sign, d)
end

local function _an_reset()
  local a = StatsUI.analyzer
  a.state = "idle"
  a.baseline = {}
  a.activated = {}
  a.deactivated = {}
  a.inc, a.dec, a.returned, a.persisted = {}, {}, {}, {}
end

local function _an_capture(which)
  local st = StatsUI.state
  local a = StatsUI.analyzer
  local ss = _getSS()
  local eid = _getEID()
  if not ss or not eid or type(st.stats) ~= "table" then return false end

  local tgt = a[which]
  if type(tgt) ~= "table" then return false end
  for i=1,#st.stats do
    local s = st.stats[i]
    if s and s.name and s.enum ~= nil then
      local liveValue = _pcall(function() return ss:GetStatValue(eid, s.enum) end)
      local handled, mockValue = false, liveValue
      if Guide and Guide.GetMockStatValue then
        handled, mockValue = Guide.GetMockStatValue(s.name, liveValue)
      end
      tgt[s.name] = handled and mockValue or liveValue
    end
  end
  return true
end

local function _an_compare()
  local a = StatsUI.analyzer
  a.inc, a.dec, a.returned, a.persisted = {}, {}, {}, {}

  for name, base in pairs(a.baseline) do
    local trackThis = true
    if Guide and Guide.IsEnabled and Guide.IsEnabled() and Guide.ShouldTrackStat then
      trackThis = Guide.ShouldTrackStat(name) == true
    end

    local act = a.activated[name]
    local deact = a.deactivated[name]
    if trackThis and base ~= nil and act ~= nil and deact ~= nil then
      if act ~= base then
        local delta = act - base
        local row = { name=name, baseline=base, activated=act, deactivated=deact, delta=delta }
        if delta > 0 then a.inc[#a.inc+1] = row
        elseif delta < 0 then a.dec[#a.dec+1] = row
        end
        if deact == base then a.returned[#a.returned+1] = row
        else a.persisted[#a.persisted+1] = row end
      end
    end
  end

  local function _sort(t)
    table.sort(t, function(x,y)
      local ax = math.abs(x.delta or 0)
      local ay = math.abs(y.delta or 0)
      if ax == ay then return (x.name or "") < (y.name or "") end
      return ax > ay
    end)
  end
  _sort(a.inc); _sort(a.dec); _sort(a.returned); _sort(a.persisted)
end

local function _an_draw()
  local a = StatsUI.analyzer
  local changedRows = _countChangedScanRows()
  local bookmarkCount = #_bm_list()

  if Guide and Guide.IsEnabled and Guide.IsEnabled() and Guide.GetSuggestedPresetName then
    local suggested = Guide.GetSuggestedPresetName()
    local currentName = tostring(StatsUI.state.scanPresetName or "")
    if suggested and suggested ~= "" and (currentName == "" or currentName == "Guide Demo Preset" or currentName:match("^Guide %- ")) then
      StatsUI.state.scanPresetName = suggested
    end
  end

  if not ImGui.CollapsingHeader("Cheat Impact Analyzer") then return end

  if a.state == "idle" then
    ImGui.TextUnformatted("1) Ensure the cheat is OFF, then capture a baseline snapshot.")
    if _guideExpected("capture_baseline") then
      _drawGuideTarget("press Capture Baseline with both mock cheats OFF")
    end
    if ImGui.Button("Capture Baseline") then
      if _guideCanPerform("capture_baseline") then
        a.baseline = {}
        if _an_capture("baseline") then
          a.state = "baseline"
          _setGuideStatus("Baseline captured.", "success")
          if Guide and Guide.Notify then Guide.Notify("captured_baseline") end
        end
      end
    end
  elseif a.state == "baseline" then
    ImGui.TextUnformatted("2) Turn the cheat ON, then capture the activated snapshot.")
    if _guideExpected("capture_activated") then
      _drawGuideTarget("turn on God Mode or No Recoil in the mock menu, then press Capture Activated")
    end
    if ImGui.Button("Capture Activated") then
      if _guideCanPerform("capture_activated") then
        a.activated = {}
        if _an_capture("activated") then
          a.state = "activated"
          _setGuideStatus("Activated snapshot captured.", "success")
          if Guide and Guide.Notify then Guide.Notify("captured_activated") end
        end
      end
    end
    ImGui.SameLine()
    if ImGui.Button("Reset##an1") then _an_reset() end
  elseif a.state == "activated" then
    ImGui.TextUnformatted("3) Turn the cheat OFF, then capture the deactivated snapshot.")
    if _guideExpected("capture_deactivated") then
      _drawGuideTarget("turn the mock cheat back OFF, then press Capture Deactivated")
    end
    if ImGui.Button("Capture Deactivated") then
      if _guideCanPerform("capture_deactivated") then
        a.deactivated = {}
        if _an_capture("deactivated") then
          a.state = "complete"
          _an_compare()
          _setGuideStatus("Deactivated snapshot captured. Review the results below.", "success")
          if Guide and Guide.Notify then Guide.Notify("captured_deactivated") end
        end
      end
    end
    ImGui.SameLine()
    if ImGui.Button("Reset##an2") then _an_reset() end
  else
    ImGui.TextUnformatted("Results (only stats that changed while ON):")
    if ImGui.Button("Reset##an3") then _an_reset() end

    if Guide and Guide.IsEnabled and Guide.IsEnabled() then
      ImGui.TextWrapped("Impact Analyzer buckets: Increased/Decreased when ON show what the cheat changed while active. Returned to baseline after OFF means the effect was temporary. Stayed changed after OFF means the change persisted after disable.")
    end

    ImGui.SameLine()
    local bmGlyph = _bm_glyph()
    if _guideExpected("bookmark_results") then
      ImGui.SameLine()
      ImGui.TextUnformatted("<- Guide target")
    end
    if ImGui.SmallButton(bmGlyph .. "##an_bm") then
      if _guideCanPerform("bookmark_results", { hasChangedRows = changedRows > 0 }) then
        ImGui.OpenPopup("an_bm_popup")
      end
    end
    if ImGui.IsItemHovered() then
      ImGui.BeginTooltip()
      ImGui.TextUnformatted("Bookmark results...")
      ImGui.EndTooltip()
    end

    if ImGui.BeginPopup("an_bm_popup") then
      if ImGui.MenuItem("Bookmark ALL results") then
        _bm_addFromBucket(a.inc)
        _bm_addFromBucket(a.dec)
        _bm_addFromBucket(a.returned)
        _bm_addFromBucket(a.persisted)
        _setGuideStatus("Bookmarked the changed results. Save them as a preset next.", "success")
        if Guide and Guide.Notify then Guide.Notify("bookmarked_results") end
      end
      ImGui.Separator()
      if ImGui.MenuItem("Bookmark Increased when ON (" .. tostring(#a.inc) .. ")") then _bm_addFromBucket(a.inc); _setGuideStatus("Bookmarked increased rows.", "success"); if Guide and Guide.Notify then Guide.Notify("bookmarked_results") end end
      if ImGui.MenuItem("Bookmark Decreased when ON (" .. tostring(#a.dec) .. ")") then _bm_addFromBucket(a.dec); _setGuideStatus("Bookmarked decreased rows.", "success"); if Guide and Guide.Notify then Guide.Notify("bookmarked_results") end end
      if ImGui.MenuItem("Bookmark Returned to baseline after OFF (" .. tostring(#a.returned) .. ")") then _bm_addFromBucket(a.returned); _setGuideStatus("Bookmarked returned rows.", "success"); if Guide and Guide.Notify then Guide.Notify("bookmarked_results") end end
      if ImGui.MenuItem("Bookmark Stayed changed after OFF (" .. tostring(#a.persisted) .. ")") then _bm_addFromBucket(a.persisted); _setGuideStatus("Bookmarked persisted rows.", "success"); if Guide and Guide.Notify then Guide.Notify("bookmarked_results") end end
      ImGui.EndPopup()
    end

    ImGui.Spacing()
    ImGui.TextUnformatted("Save changed results as a Stat Profile")
    if _guideExpected("save_preset") then
      _drawGuideTarget("enter a preset name, then press Save Changed Results as Preset")
    end
    ImGui.PushItemWidth(240)
    StatsUI.state.scanPresetName = _InputTextValue("Preset Name##scan_preset_name", StatsUI.state.scanPresetName or "", 128)
    ImGui.PopItemWidth()
    ImGui.SameLine()
    if ImGui.Button("Save Changed Results as Preset") then
      if _guideCanPerform("save_preset", {
        hasBookmarks = bookmarkCount > 0,
        presetName = StatsUI.state.scanPresetName,
        hasEntries = changedRows > 0,
      }) then
        _saveScanPreset(StatsUI.state.scanPresetName)
        _setGuideStatus("Preset saved. Look below in Saved Scan Presets to review or apply it.", "success")
      end
    end
    if StatsUI.state._presetStatus and StatsUI.state._presetStatus ~= "" then
      ImGui.TextWrapped(StatsUI.state._presetStatus)
    end
    ImGui.Separator()

    local function _drawList(label, t)
      if not ImGui.TreeNode(label .. " (" .. tostring(#t) .. ")") then return end

      local function _deltaColor(d)
        if type(d) ~= "number" then return nil end
        if d > 0 then return 0.20, 1.00, 0.20 end -- green
        if d < 0 then return 1.00, 0.20, 0.20 end -- red
        return nil
      end

      ImGui.Columns(5, "anCols##" .. label, true)
      ImGui.TextUnformatted("Stat"); ImGui.NextColumn()
      ImGui.TextUnformatted("Baseline"); ImGui.NextColumn()
      ImGui.TextUnformatted("ON"); ImGui.NextColumn()
      ImGui.TextUnformatted("OFF"); ImGui.NextColumn()
      ImGui.TextUnformatted(_an_delta_glyph()); ImGui.NextColumn()
      ImGui.Separator()

      for i=1,#t do
        local r = t[i]
        ImGui.TextUnformatted(tostring(r.name)); ImGui.NextColumn()
        ImGui.TextUnformatted(_an_fmt(r.baseline)); ImGui.NextColumn()
        ImGui.TextUnformatted(_an_fmt(r.activated)); ImGui.NextColumn()
        ImGui.TextUnformatted(_an_fmt(r.deactivated)); ImGui.NextColumn()

        local cr,cg,cb = _deltaColor(r.delta)
        if cr ~= nil then ImGui.PushStyleColor(ImGuiCol.Text, cr,cg,cb,1.0) end
        ImGui.TextUnformatted(_an_fmtDelta(r.delta))
        if cr ~= nil then ImGui.PopStyleColor() end
        ImGui.NextColumn()
      end

      ImGui.Columns(1)
      ImGui.TreePop()
    end

    _drawList("Increased when ON", a.inc)
    _drawList("Decreased when ON", a.dec)
    _drawList("Returned to baseline after OFF", a.returned)
    _drawList("Stayed changed after OFF", a.persisted)
  end
end

local function _ensureBuilderState()
  local st = StatsUI.state
  st.observerBuilder = st.observerBuilder or {}
  st.presetBuilder = st.presetBuilder or {}

  local ob = st.observerBuilder
  ob.search = tostring(ob.search or "")
  ob.source = _normalizeObserverSource(ob.source or "Current Amount")
  ob.compareMode = tostring(ob.compareMode or "True Number")
  ob.op = tostring(ob.op or ">")
  ob.valueStr = tostring(ob.valueStr or "100")
  ob.pickIndex = tonumber(ob.pickIndex or 1) or 1
  ob.filtered = type(ob.filtered) == "table" and ob.filtered or {}
  ob.lastFilter = tostring(ob.lastFilter or "")
  ob.nextId = tonumber(ob.nextId or 1) or 1
  ob.list = type(ob.list) == "table" and ob.list or {}
  ob.presetName = tostring(ob.presetName or "")
  ob.selectedPresetId = tostring(ob.selectedPresetId or "")
  ob.status = tostring(ob.status or "")

  local pb = st.presetBuilder
  pb.search = tostring(pb.search or "")
  pb.mode = _normalizeEditMode(pb.mode or "Add")
  pb.valueStr = tostring(pb.valueStr or "10")
  pb.pickIndex = tonumber(pb.pickIndex or 1) or 1
  pb.filtered = type(pb.filtered) == "table" and pb.filtered or {}
  pb.lastFilter = tostring(pb.lastFilter or "")
  pb.nextId = tonumber(pb.nextId or 1) or 1
  pb.list = type(pb.list) == "table" and pb.list or {}
  pb.presetName = tostring(pb.presetName or "")
  pb.selectedPresetId = tostring(pb.selectedPresetId or "")
  pb.status = tostring(pb.status or "")
end

local function _filterBuilderStats(builder)
  local st = StatsUI.state
  local key = tostring((builder or {}).search or "")
  if key == tostring((builder or {}).lastFilter or "") and type(builder.filtered) == "table" and #builder.filtered > 0 then return end
  builder.lastFilter = key
  builder.filtered = {}
  local low = string.lower(key)
  for i = 1, #(st.stats or {}) do
    local s = st.stats[i]
    local name = string.lower(tostring((s or {}).name or ""))
    local comment = string.lower(tostring((s or {}).comment or ""))
    if low == "" or string.find(name, low, 1, true) or string.find(comment, low, 1, true) then
      builder.filtered[#builder.filtered + 1] = s
    end
  end
  if builder.pickIndex < 1 then builder.pickIndex = 1 end
  if builder.pickIndex > #builder.filtered then builder.pickIndex = math.max(1, #builder.filtered) end
end

local function _getSnapshotSourceValue(snap, source)
  if type(snap) ~= "table" then return nil end
  local src = _normalizeObserverSource(source)
  if src == "Current Amount" then return snap.current end
  if src == "Max Amount" then return snap.max end
  if src == "Pool Percent" then return snap.percent end
  return snap.value
end

local function _observerExpression(entry)
  entry = entry or {}
  local src = _normalizeObserverSource(entry.src or "Current Amount")
  local sourceLabel = _observerSourceDisplayLabel(entry.stat, src)
  local compareMode = _normalizeObserverCompareMode(src, entry.compareMode or "True Number")
  local valueText = tostring(entry.valueStr or entry.value or "0")
  if compareMode == "Percent" then
    if src == "Current Amount" then
      return string.format("%s %s %s%% of %s", tostring(sourceLabel), tostring(entry.op or "=="), tostring(valueText), _observerSourceDisplayLabel(entry.stat, "Max Amount"))
    end
    return string.format("%s %s %s%%", tostring(sourceLabel), tostring(entry.op or "=="), tostring(valueText))
  end
  return string.format("%s %s %s", tostring(sourceLabel), tostring(entry.op or "=="), tostring(valueText))
end

local function _observerEvaluate(entry)
  local snap = StatsUI.GetStatSnapshot and StatsUI.GetStatSnapshot(entry and entry.stat or nil) or nil
  local live = _getSnapshotSourceValue(snap, entry and entry.src or "Current Amount")
  local target, rawTarget, compareMode = _resolveObserverCompareTarget(entry, snap)
  local result = _opEval(live, tostring(entry and entry.op or "=="), target)
  return snap, live, target, result == true, rawTarget, compareMode
end

local function _presetExpression(entry)
  entry = entry or {}
  local mode = tostring(entry.mode or "add")
  local op = "+="
  if mode == "set" then op = "="
  elseif mode == "mul" then op = "x="
  elseif mode == "div" then op = "/=" end
  return string.format("%s %s %s", tostring(entry.stat or "Stat"), op, tostring(entry.valueStr or entry.value or "0"))
end

local function _ensureObserverEntry(entry, id)
  local out = _clone(entry or {})
  out.id = tonumber(out.id or id or 0) or id or 0
  out.enabled = out.enabled ~= false
  out.stat = tostring(out.stat or "")
  out.src = _normalizeObserverSource(out.src or "Current Amount")
  out.compareMode = _normalizeObserverCompareMode(out.src, out.compareMode or "True Number")
  out.op = tostring(out.op or ">")
  out.valueStr = tostring(out.valueStr or out.value or "0")
  out.value = tonumber(out.value or out.valueStr or 0) or 0
  return out
end

local function _normalizePresetMode(m)
  m = tostring(m or "add"):lower()
  if m == "set" then return "set" end
  if m == "mul" then return "mul" end
  if m == "div" then return "div" end
  return "add"
end

local function _ensurePresetEntry(entry, id)
  local out = _clone(entry or {})
  out.id = tonumber(out.id or id or 0) or id or 0
  out.stat = tostring(out.stat or "")
  out.mode = _normalizePresetMode(out.mode)
  out.valueStr = tostring(out.valueStr or out.value or "0")
  out.value = tonumber(out.value or out.valueStr or 0) or 0
  return out
end

local function _loadObserverBuilderFromAsset(assetId, append)
  local st = StatsUI.state
  local ob = st.observerBuilder
  local asset = AssetRegistry.Get and AssetRegistry.Get(assetId) or nil
  if type(asset) ~= "table" or tostring(asset.type or "") ~= "observer_preset" then
    ob.status = "Missing Stat Condition."
    return false
  end
  local list = append and _clone(ob.list or {}) or {}
  local nextId = tonumber(ob.nextId or 1) or 1
  for i = 1, #((asset.observers) or {}) do
    local row = _ensureObserverEntry(asset.observers[i], nextId)
    row.id = nextId
    nextId = nextId + 1
    list[#list + 1] = row
  end
  ob.list = list
  ob.nextId = nextId
  ob.selectedPresetId = tostring(asset.id or "")
  ob.presetName = tostring(asset.name or ob.presetName or "")
  ob.status = string.format("%s Stat Condition '%s'.", append and "Appended" or "Loaded", tostring(asset.name or asset.id or "Preset"))
  return true
end

local function _saveObserverBuilderPreset(name)
  local st = StatsUI.state
  local ob = st.observerBuilder
  local trimmed = _trim(name)
  if trimmed == "" then
    ob.status = "Enter a Stat Condition name first."
    return false
  end
  if #(ob.list or {}) == 0 then
    ob.status = "Add at least one stat observer condition first."
    return false
  end
  local payload = {
    type = "observer_preset",
    name = trimmed,
    observers = {},
  }
  for i = 1, #(ob.list or {}) do
    local row = _ensureObserverEntry(ob.list[i], i)
    row.id = nil
    payload.observers[#payload.observers + 1] = row
  end
  local existing = nil
  if tostring(ob.selectedPresetId or "") ~= "" then
    local loaded = AssetRegistry.Get and AssetRegistry.Get(ob.selectedPresetId) or nil
    if type(loaded) == "table" and tostring(loaded.type or "") == "observer_preset" then
      existing = loaded
    end
  end
  if not existing then
    existing = AssetRegistry.FindByTypeAndName and AssetRegistry.FindByTypeAndName("observer_preset", trimmed) or nil
  end
  if type(existing) == "table" then
    payload.id = existing.id
    payload.createdAtText = existing.createdAtText
  end
  local saved, err = AssetRegistry.Upsert(payload)
  if not saved then
    ob.status = tostring(err or "Could not save Stat Condition.")
    return false
  end
  ob.selectedPresetId = tostring(saved.id or "")
  ob.presetName = tostring(saved.name or trimmed)
  ob.status = string.format("Saved Stat Condition '%s' to disk.", tostring(saved.name or trimmed))
  return true
end

local function _drawObserverPresetTable()
  local st = StatsUI.state
  local ob = st.observerBuilder
  local presets = AssetRegistry.List("observer_preset") or {}
  ImGui.TextUnformatted("Saved Stat Conditions")
  if #presets == 0 then
    ImGui.TextDisabled("No saved Stat Conditions yet.")
    return
  end
  if ImGui.BeginTable("stats_observer_presets_tbl", 6, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("Preset")
    ImGui.TableSetupColumn("Saved", ImGuiTableColumnFlags.WidthFixed, 140)
    ImGui.TableSetupColumn("Entries", ImGuiTableColumnFlags.WidthFixed, 60)
    ImGui.TableSetupColumn("Load", ImGuiTableColumnFlags.WidthFixed, 60)
    ImGui.TableSetupColumn("Append", ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableSetupColumn("Delete", ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableHeadersRow()
    local deleteId = nil
    for i = 1, #presets do
      local asset = presets[i]
      local entries = asset.observers or {}
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(tostring(asset.name or asset.id))
      if ImGui.IsItemHovered() and type(entries) == "table" then
        ImGui.BeginTooltip()
        local maxRows = math.min(#entries, 10)
        for j = 1, maxRows do
          ImGui.TextUnformatted(_observerExpression(entries[j]))
        end
        if #entries > maxRows then ImGui.TextUnformatted("...") end
        ImGui.EndTooltip()
      end
      ImGui.TableSetColumnIndex(1)
      ImGui.TextUnformatted(tostring(asset.updatedAtText or asset.createdAtText or ""))
      ImGui.TableSetColumnIndex(2)
      ImGui.TextUnformatted(tostring(#entries))
      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton("Load##stats_observer_asset_load_" .. tostring(asset.id)) then
        _loadObserverBuilderFromAsset(asset.id, false)
      end
      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton("Append##stats_observer_asset_append_" .. tostring(asset.id)) then
        _loadObserverBuilderFromAsset(asset.id, true)
      end
      ImGui.TableSetColumnIndex(5)
      if ImGui.SmallButton("Delete##stats_observer_asset_delete_" .. tostring(asset.id)) then deleteId = asset.id end
    end
    ImGui.EndTable()
    if deleteId then
      AssetRegistry.Delete(deleteId)
      ob.status = "Deleted Stat Condition."
    end
  end
end

local function _drawBuilderFieldTitle(title, helpText)
  ImGui.TextUnformatted(tostring(title or "Field"))
  if tostring(helpText or "") ~= "" then
    ImGui.TextDisabled(tostring(helpText))
  end
end

-- Two-panel stat picker: left = scrollable stat list, right = config area.
-- Returns the picked stat row (or nil). The right-panel content is drawn
-- by the caller via the rightFn callback: rightFn(picked).
local function _drawTwoPanelStatBuilder(builderState, uniquePrefix, rightFn)
  builderState = builderState or {}
  uniquePrefix = tostring(uniquePrefix or "stats_builder")
  _filterBuilderStats(builderState)

  local avail = (ImGui.GetContentRegionAvail and ImGui.GetContentRegionAvail()) or 600
  local leftW = math.max(180, math.floor(avail * 0.32))
  local panelH = 380

  -- LEFT panel: search + bookmarked toggle + scrollable stat list
  ImGui.BeginChild(uniquePrefix .. "_left", leftW, panelH, true)

  -- Search row: glyph + input
  ImGui.TextUnformatted(_glyphMagnify())
  ImGui.SameLine()
  if type(ImGui.SetNextItemWidth) == "function" then ImGui.SetNextItemWidth(-1) end
  builderState.search = _InputTextValue("##" .. uniquePrefix .. "_search", builderState.search or "", 128)

  -- Bookmark filter toggle
  local bmOnly = (builderState.showBmOnly == true)
  local bmBtnLbl = bmOnly and "[*] Bookmarked##" .. uniquePrefix .. "_bm" or " o  All Stats##" .. uniquePrefix .. "_bm"
  if ImGui.SmallButton(bmBtnLbl) then
    builderState.showBmOnly = not bmOnly
    bmOnly = builderState.showBmOnly
  end

  ImGui.Separator()

  -- Stat list
  local filtered = builderState.filtered or {}
  local displayList = {}
  for i = 1, #filtered do
    local row = filtered[i]
    if not bmOnly or _bm_is("stat", row.name) then
      displayList[#displayList + 1] = { row = row, origIdx = i }
    end
  end

  for di = 1, #displayList do
    local entry = displayList[di]
    local row = entry.row
    local origIdx = entry.origIdx
    local isSel = (origIdx == builderState.pickIndex)
    local isBm = _bm_is("stat", row.name)
    local labelStar = isBm and "* " or "  "
    if ImGui.Selectable(labelStar .. tostring(row.name or "?") .. "##" .. uniquePrefix .. "_pick_" .. tostring(origIdx), isSel) then
      builderState.pickIndex = origIdx
    end
  end
  if #displayList == 0 then
    ImGui.TextDisabled(bmOnly and "No bookmarked stats match." or "No stats match the search.")
  end

  ImGui.EndChild()

  ImGui.SameLine()

  -- RIGHT panel: stat info + caller-supplied config
  ImGui.BeginChild(uniquePrefix .. "_right", 0, panelH, true)

  local picked = builderState.filtered and builderState.filtered[builderState.pickIndex] or nil

  if picked then
    -- Stat header: name + live values + bookmark star
    _bm_star("stat", picked.name, uniquePrefix .. "_hdr")
    ImGui.SameLine()
    ImGui.TextUnformatted(picked.name)
    if tostring(picked.comment or "") ~= "" then
      ImGui.TextDisabled(tostring(picked.comment))
    end
    -- Live values
    local snap = StatsUI.GetStatSnapshot and StatsUI.GetStatSnapshot(picked.name) or nil
    if snap then
      local cur = (snap.current ~= nil) and _an_fmt(snap.current) or "-"
      local mx  = (snap.max ~= nil)     and _an_fmt(snap.max)     or "-"
      local pct = (type(snap.percent) == "number") and string.format(" (%.0f%%)", snap.percent) or ""
      ImGui.TextDisabled(string.format("Current: %s  |  Max: %s%s", cur, mx, pct))
    else
      ImGui.TextDisabled("Live values unavailable")
    end
    ImGui.Separator()
    -- Right-panel content supplied by caller
    if type(rightFn) == "function" then rightFn(picked) end
  else
    ImGui.TextDisabled("Select a stat from the left panel.")
  end

  ImGui.EndChild()

  return picked
end

-- Legacy thin wrapper so old call sites still compile.
local function _drawBuilderStatPicker(builderState, uniquePrefix)
  builderState = builderState or {}
  uniquePrefix = tostring(uniquePrefix or "stats_builder")
  _filterBuilderStats(builderState)
  ImGui.TextUnformatted(_glyphMagnify())
  ImGui.SameLine()
  if type(ImGui.SetNextItemWidth) == "function" then ImGui.SetNextItemWidth(200) end
  builderState.search = _InputTextValue("##" .. uniquePrefix .. "_search", builderState.search or "", 128)
  for i = 1, #(builderState.filtered or {}) do
    local row = builderState.filtered[i]
    local isBm = _bm_is("stat", row.name)
    if ImGui.Selectable((isBm and "* " or "  ") .. tostring(row.name or "?") .. "##" .. uniquePrefix .. "_pick_" .. tostring(i), i == builderState.pickIndex) then
      builderState.pickIndex = i
    end
  end
  return builderState.filtered and builderState.filtered[builderState.pickIndex] or nil
end

local function _drawObserverBuilder()
  local st = StatsUI.state
  local ob = st.observerBuilder
  ob.source = _normalizeObserverSource(ob.source or "Current Amount")
  ob.compareMode = _normalizeObserverCompareMode(ob.source, ob.compareMode or "True Number")

  local picked = _drawTwoPanelStatBuilder(ob, "stats_condition_builder", function(pk)
    -- Right panel content for conditions builder
    local pickedName = pk.name
    ob.source = _normalizeObserverSource(ob.source or "Current Amount")
    ob.compareMode = _normalizeObserverCompareMode(ob.source, ob.compareMode or "True Number")

  ImGui.Separator()
    _drawBuilderFieldTitle("Observed Value", "Current Amount / Max Amount / Pool Percent / Stat Value")
    ob.source = _drawObserverSourceCombo("stats_observer_source", ob.source or "Current Amount", pickedName, 260)
    ob.compareMode = _normalizeObserverCompareMode(ob.source, ob.compareMode or "True Number")
    ImGui.TextDisabled("Selected: " .. tostring(_observerSourceDisplayLabel(pickedName, ob.source)))

    _drawBuilderFieldTitle("Operator", "Direction of the comparison: == equal, > greater than, etc.")
    ob.op = _drawInlineChoiceButtons("stats_observer_op", ob.op or ">", {"==", "~=", ">", "<", ">=", "<="}, nil, 6)

    _drawBuilderFieldTitle("Compare As", "Number vs Percent threshold")
    ob.compareMode = _drawInlineChoiceButtons("stats_observer_compare_mode", _observerCompareModeLabel(ob.source, ob.compareMode), _observerCompareModeOptions(ob.source), nil, 2)

    local valueLabel = (_observerCompareModeLabel(ob.source, ob.compareMode) == "Percent") and "Percent" or "Value"
    _drawBuilderFieldTitle(valueLabel, "")
    if type(ImGui.SetNextItemWidth) == "function" then ImGui.SetNextItemWidth(90) end
    ob.valueStr = _InputTextValue("##stats_observer_compare", ob.valueStr or "100", 64)

    ImGui.Separator()
    local snap2 = StatsUI.GetStatSnapshot and StatsUI.GetStatSnapshot(pk.name) or nil
    local previewValue = _getSnapshotSourceValue(snap2, ob.source)
    local previewTarget, previewRawTarget, previewCompareMode = _resolveObserverCompareTarget({ stat = pk.name, src = ob.source, compareMode = ob.compareMode, valueStr = ob.valueStr, value = tonumber(ob.valueStr), op = ob.op }, snap2)
    local previewResult = _opEval(previewValue, ob.op, previewTarget) == true
    ImGui.TextUnformatted("Preview:")
    ImGui.TextWrapped(_observerExpression({ stat = pk.name, src = ob.source, compareMode = ob.compareMode, op = ob.op, valueStr = ob.valueStr, value = tonumber(ob.valueStr) }))
    if type(previewValue) == "number" then
      local info = string.format("Observed: %s", _an_fmt(previewValue))
      if type(previewTarget) == "number" then info = info .. string.format(" | Threshold %s", _an_fmt(previewTarget)) end
      info = info .. string.format(" | %s", previewResult and "TRUE" or "FALSE")
      ImGui.TextDisabled(info)
    else
      ImGui.TextDisabled("Live value unavailable.")
    end

    ImGui.Separator()
    ImGui.TextUnformatted("Draft")
    ImGui.Separator()
    if ImGui.Button("Add Condition To Draft##stats_observer_add") then
      if pk and tonumber(ob.valueStr) ~= nil then
        ob.list[#ob.list + 1] = _ensureObserverEntry({
          id = ob.nextId,
          stat = pk.name,
          src = ob.source,
          compareMode = ob.compareMode,
          op = ob.op,
          valueStr = ob.valueStr,
          value = tonumber(ob.valueStr),
          enabled = true,
        }, ob.nextId)
        ob.nextId = ob.nextId + 1
        ob.status = "Added to draft."
      else
        ob.status = "Select a stat and enter a compare value."
      end
    end
    ImGui.SameLine()
    if ImGui.Button("Clear Draft##stats_observer_clear") then
      ob.list = {}
      ob.status = "Cleared."
    end
  end)  -- end two-panel right callback

  ImGui.Separator()
  _drawBuilderFieldTitle("Saved Stat Condition", "Choose an existing Stat Condition here if you want to load or append it into the current draft.")
  local observerLabels = {}
  local savedObservers = AssetRegistry.List("observer_preset") or {}
  local selectedObserverLabel = "No saved conditions"
  for i = 1, #savedObservers do
    local asset = savedObservers[i]
    observerLabels[#observerLabels + 1] = tostring(asset.name or asset.id or ("Condition " .. tostring(i)))
    if tostring(ob.selectedPresetId or "") == tostring(asset.id or "") then
      selectedObserverLabel = observerLabels[#observerLabels]
    end
  end
  if #observerLabels > 0 then
    selectedObserverLabel = _ComboSelect("##stats_observer_saved_combo", selectedObserverLabel, observerLabels, 260)
    for i = 1, #savedObservers do
      local asset = savedObservers[i]
      if tostring(selectedObserverLabel) == tostring(asset.name or asset.id or ("Condition " .. tostring(i))) then
        ob.selectedPresetId = tostring(asset.id or "")
        break
      end
    end
  else
    ImGui.TextDisabled("No saved Stat Conditions yet.")
  end

  _drawBuilderFieldTitle("Stat Condition Name", "Enter the saved asset name here when you want to write the current draft to disk.")
  ob.presetName = _InputTextValue("##stats_observer_preset_name", ob.presetName or "", 128)
  if ImGui.Button("Save Draft As Stat Condition##stats_observer_save") then
    _saveObserverBuilderPreset(ob.presetName)
  end
  ImGui.SameLine()
  if ImGui.Button("Load Saved Into Draft##stats_observer_load") and tostring(ob.selectedPresetId or "") ~= "" then
    _loadObserverBuilderFromAsset(ob.selectedPresetId, false)
  end
  ImGui.SameLine()
  if ImGui.Button("Append Saved##stats_observer_append") and tostring(ob.selectedPresetId or "") ~= "" then
    _loadObserverBuilderFromAsset(ob.selectedPresetId, true)
  end
  if ob.status ~= "" then ImGui.TextWrapped(ob.status) end

  ImGui.Separator()
  ImGui.TextUnformatted("Stat Condition Draft")
  if #(ob.list or {}) == 0 then
    ImGui.TextDisabled("No Stat Conditions in the draft yet.")
  else
    for i = #ob.list, 1, -1 do
      local row = ob.list[i]
      row.src = _normalizeObserverSource(row.src)
      row.compareMode = _normalizeObserverCompareMode(row.src, row.compareMode or "True Number")
      local snap2, liveValue, targetValue, result, rawTarget, liveCompareMode = _observerEvaluate(row)
      local header = string.format("[%s] %s", row.enabled ~= false and "ON" or "OFF", _observerExpression(row))
      if ImGui.CollapsingHeader(header .. "##stats_observer_row_" .. tostring(row.id or i)) then
        row.enabled = _CheckboxValue("Enabled##stats_observer_enabled_" .. tostring(row.id or i), row.enabled ~= false)
        _drawBuilderFieldTitle("Observed Value", "Choose whether this row watches the live amount, the max amount, the pool percent, or the raw stat value.")
        row.src = _drawObserverSourceCombo("stats_observer_row_src_" .. tostring(row.id or i), row.src or "Current Amount", row.stat, 260)
        row.compareMode = _normalizeObserverCompareMode(row.src, row.compareMode or "True Number")
        ImGui.TextDisabled("Selected: " .. tostring(_observerSourceDisplayLabel(row.stat, row.src)))
        _drawBuilderFieldTitle("Operator", "This is the direction of the condition for this row.")
        row.op = _drawInlineChoiceButtons("stats_observer_row_op_" .. tostring(row.id or i), row.op or ">", {"==", "~=", ">", "<", ">=", "<="}, nil, 6)
        _drawBuilderFieldTitle("Compare As", "Choose whether the value below is a real number or a percent.")
        row.compareMode = _drawInlineChoiceButtons("stats_observer_row_mode_" .. tostring(row.id or i), _observerCompareModeLabel(row.src, row.compareMode), _observerCompareModeOptions(row.src), nil, 2)
        local rowValueLabel = (_observerCompareModeLabel(row.src, row.compareMode) == "Percent") and "Compare Percent" or "Compare Number"
        local rowValueHelp = (_observerCompareModeLabel(row.src, row.compareMode) == "Percent") and "Enter the percent threshold for this condition row." or "Enter the real numeric threshold for this condition row."
        _drawBuilderFieldTitle(rowValueLabel, rowValueHelp)
        row.valueStr = _InputTextValue("##stats_observer_row_val_" .. tostring(row.id or i), row.valueStr or tostring(row.value or 0), 64)
        row.value = tonumber(row.valueStr or "") or row.value or 0
        ImGui.TextWrapped("Statement: " .. _observerExpression(row))
        if type(liveValue) == "number" then
          local info = string.format("Observed: %s", _an_fmt(liveValue))
          if type((snap2 or {}).current) == "number" and type((snap2 or {}).max) == "number" then
            info = info .. string.format(" | Current / Max %s / %s", _an_fmt(snap2.current), _an_fmt(snap2.max))
          end
          if type((snap2 or {}).percent) == "number" then
            info = info .. string.format(" | Pool %.1f%%", tonumber(snap2.percent) or 0)
          end
          if liveCompareMode == "Percent" then
            if row.src == "Current Amount" and type(targetValue) == "number" then
              info = info .. string.format(" | Threshold %s (%s%% of max)", _an_fmt(targetValue), tostring(rawTarget or 0))
            else
              info = info .. string.format(" | Threshold %s%%", tostring(rawTarget or 0))
            end
          elseif type(targetValue) == "number" then
            info = info .. string.format(" | Threshold %s", _an_fmt(targetValue))
          end
          info = info .. string.format(" | Result %s", result and "TRUE" or "FALSE")
          ImGui.TextDisabled(info)
        else
          ImGui.TextDisabled("Live value unavailable right now.")
        end
        if ImGui.SmallButton("Remove##stats_observer_remove_" .. tostring(row.id or i)) then
          table.remove(ob.list, i)
        end
      end
    end
  end

  ImGui.Separator()
  ImGui.TextUnformatted("Saved Stat Conditions")
  _drawObserverPresetTable()
end

local function _loadPresetBuilderFromAsset(assetId, append)
  local st = StatsUI.state
  local pb = st.presetBuilder
  local asset = AssetRegistry.Get and AssetRegistry.Get(assetId) or nil
  if type(asset) ~= "table" or tostring(asset.type or "") ~= "stat_preset" then
    pb.status = "Missing Stat Profile."
    return false
  end
  local list = append and _clone(pb.list or {}) or {}
  local nextId = tonumber(pb.nextId or 1) or 1
  for i = 1, #((((asset or {}).data or {}).entries) or {}) do
    local row = _ensurePresetEntry((((asset or {}).data or {}).entries)[i], nextId)
    row.id = nextId
    nextId = nextId + 1
    list[#list + 1] = row
  end
  pb.list = list
  pb.nextId = nextId
  pb.selectedPresetId = tostring(asset.id or "")
  pb.presetName = tostring(asset.name or pb.presetName or "")
  pb.status = string.format("%s Stat Profile '%s'.", append and "Appended" or "Loaded", tostring(asset.name or asset.id or "Preset"))
  return true
end

local function _savePresetBuilderToAsset(name)
  local st = StatsUI.state
  local pb = st.presetBuilder
  local trimmed = _trim(name)
  if trimmed == "" then
    pb.status = "Enter a Stat Profile name first."
    return false
  end
  if #(pb.list or {}) == 0 then
    pb.status = "Add at least one stat entry to the draft first."
    return false
  end
  local entries = {}
  for i = 1, #(pb.list or {}) do
    local row = _ensurePresetEntry(pb.list[i], i)
    row.id = nil
    row.value = tonumber(row.valueStr or row.value or 0) or 0
    entries[#entries + 1] = {
      stat = row.stat,
      mode = row.mode,
      value = row.value,
      valueStr = row.valueStr,
    }
  end
  local saved, err = _upsertStatPreset(trimmed, entries, "stats_preset_builder", pb.selectedPresetId)
  if not saved then
    pb.status = tostring(err or "Could not save Stat Profile.")
    return false
  end
  pb.selectedPresetId = tostring(saved.id or "")
  pb.presetName = tostring(saved.name or trimmed)
  pb.status = string.format("Saved Stat Profile '%s' to disk.", tostring(saved.name or trimmed))
  return true
end

local function _drawSavedStatPresetTable()
  local st = StatsUI.state
  local pb = st.presetBuilder
  local presets = AssetRegistry.List("stat_preset")
  ImGui.TextUnformatted("Saved Stat Profiles")
  if #presets == 0 then
    ImGui.TextDisabled("No Stat Profiles saved yet.")
    return
  end
  if ImGui.BeginTable("stats_saved_presets_tbl", 6, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.SizingStretchProp) then
    ImGui.TableSetupColumn("Preset")
    ImGui.TableSetupColumn("Source", ImGuiTableColumnFlags.WidthFixed, 100)
    ImGui.TableSetupColumn("Entries", ImGuiTableColumnFlags.WidthFixed, 60)
    ImGui.TableSetupColumn("Apply", ImGuiTableColumnFlags.WidthFixed, 60)
    ImGui.TableSetupColumn("Load", ImGuiTableColumnFlags.WidthFixed, 60)
    ImGui.TableSetupColumn("Delete", ImGuiTableColumnFlags.WidthFixed, 70)
    ImGui.TableHeadersRow()
    local deleteId = nil
    for i = 1, #presets do
      local asset = presets[i]
      local entries = (((asset or {}).data or {}).entries) or {}
      ImGui.TableNextRow()
      ImGui.TableSetColumnIndex(0)
      ImGui.TextUnformatted(tostring(asset.name or asset.id))
      if ImGui.IsItemHovered() and type(entries) == "table" then
        ImGui.BeginTooltip()
        local maxRows = math.min(#entries, 12)
        for j = 1, maxRows do
          ImGui.TextUnformatted(_presetExpression(entries[j]))
        end
        if #entries > maxRows then ImGui.TextUnformatted("...") end
        ImGui.EndTooltip()
      end
      ImGui.TableSetColumnIndex(1)
      local ts = tostring(asset.updatedAtText or asset.createdAtText or "")
      ImGui.TextUnformatted(ts ~= "" and ts or tostring((((asset or {}).data or {}).source) or "stats_editor"))
      ImGui.TableSetColumnIndex(2)
      ImGui.TextUnformatted(tostring(#entries))
      ImGui.TableSetColumnIndex(3)
      if ImGui.SmallButton("Apply##stats_asset_apply_" .. tostring(asset.id)) then
        local ok, count = _applyPreset({ entries = entries })
        if ok then pb.status = string.format("Applied preset '%s' to %d stats.", tostring(asset.name), tonumber(count) or 0)
        else pb.status = string.format("Preset '%s' could not be applied.", tostring(asset.name)) end
      end
      ImGui.TableSetColumnIndex(4)
      if ImGui.SmallButton("Load##stats_asset_load_" .. tostring(asset.id)) then
        _loadPresetBuilderFromAsset(asset.id, false)
      end
      ImGui.TableSetColumnIndex(5)
      if ImGui.SmallButton("Delete##stats_asset_delete_" .. tostring(asset.id)) then deleteId = asset.id end
    end
    ImGui.EndTable()
    if deleteId then
      AssetRegistry.Delete(deleteId)
      pb.status = "Deleted Stat Profile."
    end
  end
end

local function _drawStatPresetManager()
  local st = StatsUI.state
  local pb = st.presetBuilder
  pb.mode = _normalizeEditMode(pb.mode or "add")

  local picked = _drawTwoPanelStatBuilder(pb, "stats_profile_builder", function(pk)
    -- Right panel: operator + value + preview + add button
    local pbOps  = { "add", "set", "mul", "div" }
    local pbSyms = { "+",   "=",   "x",   "/"  }
    local pbTips = { "Add to current", "Set value", "Multiply current", "Divide current" }

    ImGui.TextUnformatted("Operation")
    local modeIdx = 1
    for oi = 1, #pbOps do if pbOps[oi] == pb.mode then modeIdx = oi break end end
    if type(ImGui.SetNextItemWidth) == "function" then ImGui.SetNextItemWidth(50) end
    local r1, r2 = ImGui.Combo("##pb_op_combo", modeIdx - 1, pbSyms, #pbSyms)
    local newModeIdx = modeIdx
    if type(r1) == "boolean" then if r1 then newModeIdx = (r2 or (modeIdx-1)) + 1 end
    elseif type(r1) == "number" then newModeIdx = r1 + 1 end
    if newModeIdx >= 1 and newModeIdx <= #pbOps then
      pb.mode = pbOps[newModeIdx]
    end
    if ImGui.IsItemHovered() then
      ImGui.BeginTooltip()
      ImGui.TextUnformatted(pbTips[newModeIdx] or pbTips[1])
      ImGui.EndTooltip()
    end

    ImGui.SameLine()
    ImGui.TextUnformatted("Value")
    ImGui.SameLine()
    if type(ImGui.SetNextItemWidth) == "function" then ImGui.SetNextItemWidth(90) end
    pb.valueStr = _InputTextValue("##stats_preset_value", pb.valueStr or "10", 64)

    local entered = tonumber(pb.valueStr)
    local current = _getLiveStatValue(pk.name, "Current Amount")
    local previewExpr = _presetExpression({ stat = pk.name, mode = pb.mode, valueStr = pb.valueStr })
    ImGui.TextWrapped(previewExpr)
    if type(current) == "number" and type(entered) == "number" then
      local finalValue = _computeEditResult(current, pb.mode, entered)
      if finalValue ~= nil then
        ImGui.TextDisabled(string.format("Current: %s  ->  %s", _an_fmt(current), _an_fmt(finalValue)))
      else
        ImGui.TextDisabled("Cannot preview.")
      end
    end

    ImGui.Separator()
    if ImGui.Button("Add To Draft##stats_preset_add") then
      if entered ~= nil then
        pb.list[#pb.list + 1] = _ensurePresetEntry({
          id = pb.nextId,
          stat = pk.name,
          mode = pb.mode,
          valueStr = pb.valueStr,
          value = entered,
        }, pb.nextId)
        pb.nextId = pb.nextId + 1
        pb.status = "Added."
      else
        pb.status = "Enter a numeric value."
      end
    end
  end)  -- end two-panel right callback

  -- Import/export buttons below the two-panel area
  local entered = tonumber(pb.valueStr)
  ImGui.SameLine()
  if ImGui.Button("Import Edited Rows##stats_preset_import_edit") then
    local rows = _editedRowsForPreset()
    for i = 1, #rows do
      local row = _ensurePresetEntry(rows[i], pb.nextId)
      row.id = pb.nextId
      pb.nextId = pb.nextId + 1
      pb.list[#pb.list + 1] = row
    end
    pb.status = (#rows > 0) and string.format("Imported %d edited Stat Change(s).", #rows) or "No edited Stat Changes to import."
  end
  ImGui.SameLine()
  if ImGui.Button("Import Scan Results##stats_preset_import_scan") then
    local rows = _scanRowsForPreset()
    for i = 1, #rows do
      local row = _ensurePresetEntry(rows[i], pb.nextId)
      row.id = pb.nextId
      pb.nextId = pb.nextId + 1
      pb.list[#pb.list + 1] = row
    end
    pb.status = (#rows > 0) and string.format("Imported %d scan Stat Change(s).", #rows) or "No changed scan results available yet."
  end
  ImGui.SameLine()
  if ImGui.Button("Clear Draft##stats_preset_clear") then
    pb.list = {}
    pb.status = "Cleared Stat Profile draft."
  end

  ImGui.Separator()
  _drawBuilderFieldTitle("Saved Profile", "Choose an existing Stat Profile here if you want to load or append it into the current draft.")
  local presetLabels = {}
  local savedPresets = AssetRegistry.List("stat_preset") or {}
  local selectedPresetLabel = "No saved presets"
  for i = 1, #savedPresets do
    local asset = savedPresets[i]
    presetLabels[#presetLabels + 1] = tostring(asset.name or asset.id or ("Preset " .. tostring(i)))
    if tostring(pb.selectedPresetId or "") == tostring(asset.id or "") then
      selectedPresetLabel = presetLabels[#presetLabels]
    end
  end
  if #presetLabels > 0 then
    selectedPresetLabel = _ComboSelect("##stats_preset_saved_combo", selectedPresetLabel, presetLabels, 260)
    for i = 1, #savedPresets do
      local asset = savedPresets[i]
      if tostring(selectedPresetLabel) == tostring(asset.name or asset.id or ("Preset " .. tostring(i))) then
        pb.selectedPresetId = tostring(asset.id or "")
        break
      end
    end
  else
    ImGui.TextDisabled("No saved Stat Profiles yet.")
  end
  _drawBuilderFieldTitle("Stat Profile Name", "Enter the saved asset name here when you want to write the current draft to disk.")
  pb.presetName = _InputTextValue("##stats_preset_name", pb.presetName or "", 128)
  if ImGui.Button("Save Draft As Stat Profile##stats_preset_save") then
    _savePresetBuilderToAsset(pb.presetName)
  end
  ImGui.SameLine()
  if ImGui.Button("Load Saved Into Draft##stats_preset_load") and tostring(pb.selectedPresetId or "") ~= "" then
    _loadPresetBuilderFromAsset(pb.selectedPresetId, false)
  end
  ImGui.SameLine()
  if ImGui.Button("Append Saved##stats_preset_append") and tostring(pb.selectedPresetId or "") ~= "" then
    _loadPresetBuilderFromAsset(pb.selectedPresetId, true)
  end
  ImGui.SameLine()
  if ImGui.Button("Apply Draft##stats_preset_apply_draft") then
    local ok, count = _applyPreset({ entries = pb.list })
    pb.status = ok and string.format("Applied draft profile to %d stats.", tonumber(count) or 0) or "Draft could not be applied."
  end
  if pb.status ~= "" then ImGui.TextWrapped(pb.status) end

  ImGui.Separator()
  ImGui.TextUnformatted("Stat Profile Draft")
  if #(pb.list or {}) == 0 then
    ImGui.TextDisabled("No Stat Changes in the profile draft yet.")
  else
    for i = #pb.list, 1, -1 do
      local row = pb.list[i]
      local _modeLabelMap = { add="+=", set="=", mul="x=", div="/=" }
      local modeLabel = _modeLabelMap[tostring(row.mode or "add")] or "+="
      local header = string.format("[%s] %s", modeLabel, _presetExpression(row))
      if ImGui.CollapsingHeader(header .. "##stats_preset_row_" .. tostring(row.id or i)) then
        _drawBuilderFieldTitle("Operation", "+= add  |  = set  |  x= multiply  |  /= divide")
        row.mode = _normalizePresetMode(row.mode)
        local rowOps  = { "add", "set", "mul", "div" }
        local rowSyms = { "+=",  "=",   "x=",  "/="  }
        for ri = 1, #rowOps do
          local isActive = (row.mode == rowOps[ri])
          local rlbl = isActive and ("[" .. rowSyms[ri] .. "]") or rowSyms[ri]
          if ImGui.SmallButton(rlbl .. "##row_op_" .. tostring(row.id or i) .. "_" .. rowOps[ri]) then
            row.mode = rowOps[ri]
          end
          if ri < #rowOps then ImGui.SameLine() end
        end
        _drawBuilderFieldTitle("Value", "Enter the numeric amount for this Stat Change row.")
        row.valueStr = _InputTextValue("##stats_preset_row_value_" .. tostring(row.id or i), row.valueStr or tostring(row.value or 0), 64)
        row.value = tonumber(row.valueStr or "") or row.value or 0
        ImGui.TextWrapped("Statement: " .. _presetExpression(row))
        local currentValue = _getLiveStatValue(row.stat, "Current Amount")
        if type(currentValue) == "number" then
          local finalValue = _computeEditResult(currentValue, row.mode, row.value)
          if finalValue ~= nil then
            ImGui.TextDisabled(string.format("Current: %s | After apply: %s", _an_fmt(currentValue), _an_fmt(finalValue)))
          else
            ImGui.TextDisabled("Cannot preview result.")
          end
        else
          ImGui.TextDisabled("Current value unavailable right now.")
        end
        if ImGui.SmallButton("Remove##stats_preset_remove_" .. tostring(row.id or i)) then
          table.remove(pb.list, i)
        end
      end
    end
  end

  ImGui.Separator()
  _drawSavedStatPresetTable()
end

function StatsUI.GetStatCatalog()
  local st = StatsUI.state
  if not st._built then _buildOnce() end
  local out = {}
  for i = 1, #(st.stats or {}) do
    local s = st.stats[i]
    out[#out + 1] = {
      name = tostring((s or {}).name or ""),
      comment = tostring((s or {}).comment or ""),
      hasPool = ((s or {}).poolEnum ~= nil),
    }
  end
  return out
end

function StatsUI.GetStatSnapshot(statName)
  if type(statName) ~= "string" or statName == "" then return nil end
  local st = StatsUI.state
  if not st._built then _buildOnce() end
  _refreshLive()
  for i = 1, #(st.stats or {}) do
    local s = st.stats[i]
    if s and s.name == statName then
      local snap = _buildStatSnapshot(s.name, s.cur, s.poolCur, s.poolMax, s.max)
      snap.comment = tostring(s.comment or "")
      snap.hasPool = (s.poolEnum ~= nil)
      return _clone(snap)
    end
  end

  local eid = _getEID()
  if not eid then return nil end
  local ss = _getSS()
  local sps = _getSPS()
  local statEnum = gamedataStatType[statName]
  local poolEnum = _statPoolEnumForName(statName)
  local statValue = nil
  local poolCur = nil
  local poolMax = nil
  if ss and statEnum ~= nil then
    statValue = _pcall(function() return ss:GetStatValue(eid, statEnum) end)
  end
  if sps and poolEnum ~= nil then
    poolCur = _pcall(function() return sps:GetStatPoolValue(eid, poolEnum) end)
    if sps.GetStatPoolMaxValue ~= nil then
      poolMax = _pcall(function() return sps:GetStatPoolMaxValue(eid, poolEnum) end)
    end
  end
  local snap = _buildStatSnapshot(statName, statValue, poolCur, poolMax, nil)
  if snap.value == nil and snap.current == nil and snap.max == nil and snap.poolCur == nil and snap.poolMax == nil then return nil end
  return snap
end

local function _drawStatsSubtabs(st)
  local current = tostring((st and st.activeSubtab) or "Live Stats")
  if ImGui.BeginTabBar("stats_editor_subtabs") then
    if ImGui.BeginTabItem("Live Stats") then
      st.activeSubtab = "Live Stats"
      current = "Live Stats"
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem("Stat Conditions") then
      st.activeSubtab = "Stat Conditions"
      current = "Stat Conditions"
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem("Stat Profiles") then
      st.activeSubtab = "Stat Profiles"
      current = "Stat Profiles"
      ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem("Bookmarked") then
      st.activeSubtab = "Bookmarked"
      current = "Bookmarked"
      ImGui.EndTabItem()
    end
    ImGui.EndTabBar()
  end
  return tostring((st and st.activeSubtab) or current)
end

local function _DrawTabImpl(ui)
  local st = StatsUI.state
  _ensureBuilderState()
  if not st._built then _buildOnce() end
  _refreshLive()
  st.activeSubtab = tostring(st.activeSubtab or "Live Stats")

  local function _drawLiveStatsTab()
    -- Header controls (kept on one line to avoid needing to stretch the window)
    -- Search row: glyph + box + filters
    ImGui.TextUnformatted(_glyphMagnify())
    ImGui.SameLine()
    ImGui.PushItemWidth(240)
    st.keyword = _InputTextValue("##st_search", st.keyword, 256)
    ImGui.PopItemWidth()
    ImGui.SameLine()
    -- Bookmark toggle: clicking the icon filters to bookmarked stats only
    local bmActive = (st.showOnlyBookmarked == true)
    local bmLbl = (bmActive and _glyphBmOn() or _glyphBmOff()) .. "##bm_toggle"
    if ImGui.SmallButton(bmLbl) then
      st.showOnlyBookmarked = not bmActive
    end
    if ImGui.IsItemHovered() then
      ImGui.BeginTooltip()
      ImGui.TextUnformatted(bmActive and "Showing bookmarked only - click to show all" or "Click to show bookmarked stats only")
      ImGui.EndTooltip()
    end
    ImGui.SameLine()
    st.showOnlyWeaponStats = (_CheckboxValue("Weapon Only", st.showOnlyWeaponStats == true) == true)

    -- Value filter (comparison search)
    ImGui.SameLine()
    st.cmpEnabled = _CheckboxValue("##cmp_en", st.cmpEnabled)
    if ImGui.IsItemHovered() then
      ImGui.BeginTooltip()
      ImGui.TextUnformatted("Enable value filter")
      ImGui.EndTooltip()
    end
    ImGui.SameLine()
    ImGui.TextUnformatted("Value")
    ImGui.SameLine()
    do
      local ops = {"==", "~=", ">", "<", ">=", "<="}
      local idx = 0
      for i=1,#ops do if ops[i] == (st.cmpOp or "==") then idx = i-1 break end end
      ImGui.PushItemWidth(58)
      local r1, r2 = ImGui.Combo("##cmp_op", idx, ops, #ops)
      ImGui.PopItemWidth()
      local changed, newIdx
      if type(r1) == "boolean" then changed, newIdx = r1, r2
      else changed, newIdx = (r1 ~= idx), r1 end
      if changed and type(newIdx) == "number" then st.cmpOp = ops[newIdx+1] or "==" end
    end
    ImGui.SameLine()
    ImGui.PushItemWidth(90)
    st.cmpValueStr = _InputTextValue("##cmp_val", st.cmpValueStr or "", 32)
    ImGui.PopItemWidth()
    ImGui.SameLine()
    st.cmpSource = _ComboSelect("##cmp_source", _normalizeObserverSource(st.cmpSource or "Current Amount"), _observerSourceOptions(), 140)

    local v = tonumber(st.cmpValueStr)
    if v ~= nil then
      st.cmpValue = v
      st.cmpValueValid = true
    else
      st.cmpValueValid = false
    end

    ImGui.SameLine()
    ImGui.TextUnformatted("Refresh (sec)")
    ImGui.SameLine()
    ImGui.PushItemWidth(90)
    st.refreshEvery = _InputFloatValue("##st_refresh", st.refreshEvery, 0.0, 2.0, "%.2f")
    ImGui.PopItemWidth()
    if st.refreshEvery < 0.05 then st.refreshEvery = 0.05 end

    _filter()

    ImGui.Separator()
    ImGui.Text(string.format("Stats: %d | Showing: %d", #st.stats, #st._filtered))
    ImGui.TextDisabled("Edit operators: += adds, = sets, x= multiplies, /= divides the current stat value. Enter a number and the preview shows the result. Apply commits the change. Use Show More Info to reveal Current / Max columns.")
    ImGui.Separator()

    _drawGuideControls()
    _an_draw()
    _drawSavedScanPresets()
    ImGui.Separator()

    -- Always-on layout: Bm | Stat | Current | Max | Edit | Comment
    ImGui.BeginChild("stat_list", 0, 0, true)
    if ImGui.BeginTable("stats_tbl", 6, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.ScrollY) then
      ImGui.TableSetupColumn("*", ImGuiTableColumnFlags.WidthFixed, 26)   -- bookmark star
      ImGui.TableSetupColumn("Stat", ImGuiTableColumnFlags.WidthFixed, 240)
      ImGui.TableSetupColumn("Current", ImGuiTableColumnFlags.WidthFixed, 90)
      ImGui.TableSetupColumn("Max", ImGuiTableColumnFlags.WidthFixed, 90)
      ImGui.TableSetupColumn("Edit", ImGuiTableColumnFlags.WidthFixed, 310)
      ImGui.TableSetupColumn("Comment", ImGuiTableColumnFlags.WidthStretch)
      ImGui.TableHeadersRow()

      for i=1,#st._filtered do
        local s = st._filtered[i]
        local snap = s.snapshot or _buildStatSnapshot(s.name, s.cur, s.poolCur, s.poolMax, s.max)
        ImGui.TableNextRow()

        -- Col 0: Bookmark star
        ImGui.TableSetColumnIndex(0)
        _bm_star("stat", s.name, "tbl_" .. s.name)

        -- Col 1: Stat name with right-click to copy
        ImGui.TableSetColumnIndex(1)
        ImGui.PushID(s.name)
        ImGui.TextUnformatted(s.name)
        if ImGui.BeginPopupContextItem("stat_ctx") then
          if ImGui.MenuItem("Copy stat name") then
            pcall(function()
              if ImGui.SetClipboardText then ImGui.SetClipboardText(s.name) end
            end)
          end
          ImGui.EndPopup()
        end
        ImGui.PopID()

        -- Col 2: Current
        ImGui.TableSetColumnIndex(2)
        ImGui.TextUnformatted((snap.current ~= nil) and _an_fmt(snap.current) or "-")
        if ImGui.IsItemHovered() then
          ImGui.BeginTooltip()
          ImGui.TextUnformatted("Resolved Current Amount")
          ImGui.TextUnformatted("Raw Stat: " .. tostring((snap.value ~= nil) and _an_fmt(snap.value) or "-"))
          ImGui.TextUnformatted("Pool Cur: " .. tostring((snap.poolCur ~= nil) and _an_fmt(snap.poolCur) or "-"))
          ImGui.EndTooltip()
        end

        -- Col 3: Max
        ImGui.TableSetColumnIndex(3)
        local maxStr = (snap.max ~= nil) and _an_fmt(snap.max) or "-"
        if type(snap.percent) == "number" and snap.max ~= nil then
          maxStr = maxStr .. string.format(" %.0f%%", tonumber(snap.percent) or 0)
        end
        ImGui.TextUnformatted(maxStr)
        if ImGui.IsItemHovered() and snap.poolMax ~= nil then
          ImGui.BeginTooltip()
          ImGui.TextUnformatted("Pool Max: " .. _an_fmt(snap.poolMax))
          ImGui.EndTooltip()
        end

        -- Col 4: Edit
        -- Layout: [op▾] [value input — press Enter to apply]
        --         Equation preview line below: currentVal op entered = result
        -- No Apply button: Enter key fires the stat change immediately.
        ImGui.TableSetColumnIndex(4)

        s.editMode = _normalizeEditMode(s.editMode)
        local mode = s.editMode

        -- Operator dropdown (36px, icon only)
        local ops    = { "add", "set", "mul", "div" }
        local opSyms = { "+",   "=",   "x",   "/"  }
        local opTips = {
          "Add (+): current + entered",
          "Set (=): current = entered",
          "Multiply (x): current x entered",
          "Divide (/): current / entered",
        }
        local modeIdx = 1
        for oi = 1, #ops do if ops[oi] == mode then modeIdx = oi break end end
        if type(ImGui.SetNextItemWidth) == "function" then ImGui.SetNextItemWidth(36) end
        local r1, r2 = ImGui.Combo("##op_combo_" .. s.name, modeIdx - 1, opSyms, #opSyms)
        local newModeIdx = modeIdx
        if type(r1) == "boolean" then
          if r1 then newModeIdx = (r2 or (modeIdx - 1)) + 1 end
        elseif type(r1) == "number" then
          newModeIdx = r1 + 1
        end
        if newModeIdx ~= modeIdx and newModeIdx >= 1 and newModeIdx <= #ops then
          s.editMode = ops[newModeIdx]
          mode = ops[newModeIdx]
          modeIdx = newModeIdx
        end
        if ImGui.IsItemHovered() then
          ImGui.BeginTooltip()
          ImGui.TextUnformatted(opTips[modeIdx])
          ImGui.EndTooltip()
        end

        -- Value input with EnterReturnsTrue so we detect the Enter keypress.
        -- When the user presses Enter: apply the op and clear the field.
        ImGui.SameLine()
        if type(ImGui.SetNextItemWidth) == "function" then ImGui.SetNextItemWidth(100) end
        local enterFlag = (ImGuiInputTextFlags and ImGuiInputTextFlags.EnterReturnsTrue) or 0
        local ea, eb = ImGui.InputText("##edit_" .. s.name, s.editValueStr or "", 48, enterFlag)
        -- Normalise CET return convention: (changed:bool, value:string) or (value:string, changed:bool)
        local enterPressed = false
        local newEditStr = s.editValueStr or ""
        if type(ea) == "boolean" and type(eb) == "string" then
          enterPressed = ea
          newEditStr   = eb
        elseif type(ea) == "string" then
          newEditStr   = ea
        elseif type(eb) == "string" then
          newEditStr   = eb
        end
        s.editValueStr = newEditStr

        local parsedEdit = _parseEditValue(s.editValueStr)
        local curVal     = (snap.current ~= nil) and snap.current or nil

        -- Apply on Enter press
        if enterPressed and parsedEdit ~= nil then
          _applyEditOp(s.name, mode, parsedEdit)
          s.editValueStr = ""
        end

        -- Equation preview on a second line: "100 + 50 = 150"
        -- Shown whenever the user is typing a valid number.
        -- This line is always rendered (empty or with preview) so row height stays stable.
        if parsedEdit ~= nil and curVal ~= nil then
          local result = _computeEditResult(curVal, mode, parsedEdit)
          local sym    = opSyms[modeIdx] or "+"
          if result ~= nil then
            ImGui.TextDisabled(_an_fmt(curVal) .. " " .. sym .. " " .. _an_fmt(parsedEdit) .. " = " .. _an_fmt(result))
          else
            ImGui.TextDisabled("(cannot compute)")
          end
        elseif s.editValueStr ~= "" then
          ImGui.TextDisabled("enter a number, then press Enter")
        else
          ImGui.TextDisabled("")
        end

        -- Col 5: Comment
        ImGui.TableSetColumnIndex(5)
        ImGui.TextUnformatted(s.comment or "")
      end

      ImGui.EndTable()
    end
    ImGui.EndChild()
  end

  local currentSubtab = _drawStatsSubtabs(st)
  ImGui.Separator()
  if currentSubtab == "Stat Conditions" then
    _drawObserverBuilder()
  elseif currentSubtab == "Stat Profiles" then
    _drawStatPresetManager()
  elseif currentSubtab == "Bookmarked" then
    -- Bookmarked items view: all bookmarked stats shown with live values
    local bmList = {}
    for key, bm in pairs(GTS_Bookmarks or {}) do
      if tostring(bm.type or "") == "stat" then
        bmList[#bmList + 1] = bm
      end
    end
    table.sort(bmList, function(a,b) return tostring(a.name) < tostring(b.name) end)
    if #bmList == 0 then
      ImGui.TextDisabled("No bookmarked stats yet.")
      ImGui.TextDisabled("In the Live Stats tab, click the star ( o ) icon next to any stat to bookmark it.")
    else
      if ImGui.BeginTable("stats_bm_tbl", 5, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.ScrollY) then
        ImGui.TableSetupColumn("*", ImGuiTableColumnFlags.WidthFixed, 26)
        ImGui.TableSetupColumn("Stat", ImGuiTableColumnFlags.WidthFixed, 240)
        ImGui.TableSetupColumn("Current", ImGuiTableColumnFlags.WidthFixed, 90)
        ImGui.TableSetupColumn("Max", ImGuiTableColumnFlags.WidthFixed, 90)
        ImGui.TableSetupColumn("Comment", ImGuiTableColumnFlags.WidthStretch)
        ImGui.TableHeadersRow()
        for _, bm in ipairs(bmList) do
          local statName = tostring(bm.name or "")
          -- find stat row
          local sRow = nil
          for _, s in ipairs(st.stats or {}) do
            if s.name == statName then sRow = s; break end
          end
          local snap = sRow and (sRow.snapshot or _buildStatSnapshot(sRow.name, sRow.cur, sRow.poolCur, sRow.poolMax, sRow.max)) or nil
          ImGui.TableNextRow()
          ImGui.TableSetColumnIndex(0)
          _bm_star("stat", statName, "bm_view_" .. statName)  -- click to unbookmark
          ImGui.TableSetColumnIndex(1)
          ImGui.TextUnformatted(statName)
          ImGui.TableSetColumnIndex(2)
          ImGui.TextUnformatted(snap and snap.current ~= nil and _an_fmt(snap.current) or "-")
          ImGui.TableSetColumnIndex(3)
          local mx = snap and snap.max ~= nil and _an_fmt(snap.max) or "-"
          local pct = snap and type(snap.percent) == "number" and string.format(" %.0f%%", snap.percent) or ""
          ImGui.TextUnformatted(mx .. pct)
          ImGui.TableSetColumnIndex(4)
          ImGui.TextUnformatted(sRow and sRow.comment or "")
        end
        ImGui.EndTable()
      end
    end
  else
    _drawLiveStatsTab()
  end

  if Guide and Guide.DrawWindows then Guide.DrawWindows() end
end

function StatsUI.DrawTab(ui)
  local ok, err = pcall(_DrawTabImpl, ui)
  if not ok then
    if StatsUI._lastDrawErr ~= err then
      StatsUI._lastDrawErr = err
      print("[GTS][StatsUI] DrawTab error: " .. tostring(err))
    end
    ImGui.Separator()
    ImGui.TextUnformatted("Stats UI error. Open CET console for details.")
    ImGui.Separator()
  end
end

return StatsUI
