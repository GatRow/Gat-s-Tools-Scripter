local AssetRegistry = require("GTS/Core/asset_registry")

local RuleRunner = RuleRunner or {}
RuleRunner.state = RuleRunner.state or {
  manual          = { manual_1 = false, manual_2 = false, manual_3 = false },
  statusByRuleId  = {},
  debugLog        = {},
  createdAssetState = {},
}

local function _safeRequire(name)
  local ok, mod = pcall(require, name)
  if ok then return mod end
  print("[GTS] RuleRunner require failed for '" .. tostring(name) .. "': " .. tostring(mod))
  return nil
end

local function _clone(value, seen)
  if type(value) ~= "table" then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do out[_clone(k, seen)] = _clone(v, seen) end
  return out
end

local function _now()
  return (os and os.clock and os.clock()) or 0
end

local function _pushLog(ruleId, level, msg)
  msg = tostring(msg or "")
  if msg == "" then return end
  local logs = RuleRunner.state.debugLog or {}
  RuleRunner.state.debugLog = logs
  logs[#logs + 1] = {
    t      = _now(),
    ruleId = tostring(ruleId or ""),
    level  = tostring(level or "info"),
    msg    = msg,
  }
  while #logs > 300 do table.remove(logs, 1) end
end

local function _createdRuntime(assetId)
  local key = tostring(assetId or "")
  local st  = RuleRunner.state.createdAssetState or {}
  RuleRunner.state.createdAssetState = st
  st[key] = st[key] or { enabled = false, type = "", restoreActions = {} }
  return st[key]
end

local function _createdStatusId(assetId)
  return "created:" .. tostring(assetId or "")
end

-- Forward declarations
local _normalizeActionGroups
local _status
local _cancelSequence
local _startSequence
local _advanceSequence
local _captureRestoreGroups

local function _executeCustomCode(code, contextLabel)
  local src = tostring(code or "")
  src = src:gsub("^%s+", ""):gsub("%s+$", "")
  if src == "" then return false, "No CET code entered" end

  local env = setmetatable({
    Game        = Game,
    Vector4     = Vector4,
    EulerAngles = EulerAngles,
    AssetRegistry = AssetRegistry,
    print       = print,
    math        = math,
    string      = string,
    table       = table,
    pairs       = pairs,
    ipairs      = ipairs,
    tonumber    = tonumber,
    tostring    = tostring,
    type        = type,
    os          = os,
  }, { __index = _G })

  local label = tostring(contextLabel or "GTS_Custom_Code")
  local chunk, err

  if type(loadstring) == "function" then
    chunk, err = loadstring(src, label)
    if chunk and type(setfenv) == "function" then
      local okEnv, envErr = pcall(setfenv, chunk, env)
      if not okEnv then return false, tostring(envErr or "Could not apply custom code environment") end
    end
  elseif type(load) == "function" then
    chunk, err = load(src, label, "t", env)
    if chunk and type(setfenv) == "function" then pcall(setfenv, chunk, env) end
  else
    return false, "Lua dynamic code execution is unavailable in this CET runtime"
  end

  if not chunk then return false, tostring(err or "Could not compile code") end
  local ok, result = pcall(chunk)
  if not ok then return false, tostring(result or "Custom code failed") end
  if result ~= nil then return true, tostring(result) end
  return true, "Executed custom CET code"
end

local function _normalizeMacroData(data)
  data = type(data) == "table" and data or {}
  data.mode      = (tostring(data.mode or "toggle") == "button") and "button" or "toggle"
  data.offPolicy = tostring(data.offPolicy or ((data.mode == "toggle") and "restore" or "none"))
  if data.offPolicy ~= "run_off_actions" and data.offPolicy ~= "restore" then data.offPolicy = "none" end
  data.onActionGroups  = _normalizeActionGroups(data.onActionGroups,  nil, "Group")
  data.offActionGroups = _normalizeActionGroups(data.offActionGroups, nil, "Off Group")
  return data
end

local function _unwrapEmbeddedAsset(asset)
  if type(asset) ~= "table" then return nil end
  if tostring(asset.type or "") ~= "" then return asset end
  if type(asset.asset) == "table" then return asset.asset end
  return nil
end

local function _resolveReferencedAsset(refId, embeddedAsset)
  local asset = nil
  if tostring(refId or "") ~= "" then
    asset = AssetRegistry.Get and AssetRegistry.Get(refId) or nil
  end
  if type(asset) ~= "table" then asset = _unwrapEmbeddedAsset(embeddedAsset) end
  return asset
end

local _startMainSequence
local _armFirePattern

local function _runRuleDraft(rule, runtimeKey)
  if type(rule) ~= "table" then return false, "Missing rule" end
  local draft    = _clone(rule)
  draft.id       = tostring(runtimeKey or draft.id or "rule:draft")
  draft.type     = "rule"
  local rs       = _status(draft.id)
  local conds    = (((draft or {}).data or {}).conditions) or {}
  local pass, reason, results
  if type(conds) == "table" and #conds == 0 then
    pass, reason, results = true, nil, {}
  else
    pass, reason, results = _evaluateConditions(draft.data or {})
  end
  rs.lastConditionResults = results or {}
  rs.lastEval             = pass == true
  rs.lastBlockedReason    = tostring(reason or "")
  if not pass then
    rs.lastActionResults  = {}
    rs.lastTriggeredCount = 0
    rs.lastMessage        = tostring(reason or "Manual run blocked")
    return false, rs.lastMessage
  end
  _cancelSequence(draft.id, "")
  _resetPattern(draft.id)
  _armFirePattern(draft, "manual", _now())
  return true, tostring(rs.lastMessage or "Manual sequence started")
end

local function _runCreatedAssetInternal(asset, desiredState, runtimeKey, isDraft)
  if type(asset) ~= "table" then return false, "Missing asset" end
  local assetType = tostring(asset.type or "")
  local key       = tostring(runtimeKey or asset.id or (assetType .. ":draft") or "draft")
  local runtime   = _createdRuntime(key)
  runtime.type    = assetType
  runtime.isDraft = (isDraft == true)
  runtime.assetMode = tostring((((asset or {}).data or {}).mode) or runtime.assetMode or "")
  local statusId  = _createdStatusId(key)
  local rs        = _status(statusId)

  local state
  if type(desiredState) == "boolean" then
    state = desiredState and "on" or "off"
  else
    state = tostring(desiredState or "")
    if state == "true"  then state = "on"  end
    if state == "false" then state = "off" end
  end
  if state == "" then
    if (assetType == "macro" or assetType == "custom_code" or assetType == "launcher")
       and tostring((((asset or {}).data or {}).mode) or "button") == "toggle" then
      state = runtime.enabled and "off" or "on"
    else
      state = "run"
    end
  end

  if assetType == "macro" then
    local data = _normalizeMacroData(asset.data)
    if data.mode == "button" then
      _cancelSequence(statusId, "")
      _startSequence(statusId, data.onActionGroups or {}, "manual", "main")
      _advanceSequence(statusId, _now())
      return true, tostring(rs.lastMessage or "Ran macro button")
    end
    if state == "off" then
      runtime.enabled = false
      if data.offPolicy == "restore" then
        local restore = runtime.restoreActions or {}
        if #restore > 0 then
          _startSequence(statusId, restore, "manual", "restore")
          _advanceSequence(statusId, _now())
        end
      elseif data.offPolicy == "run_off_actions" then
        _startSequence(statusId, data.offActionGroups or {}, "manual", "false")
        _advanceSequence(statusId, _now())
      else
        rs.lastMessage = "Macro OFF"
      end
      runtime.restoreActions = {}
      return true, tostring(rs.lastMessage or "Macro OFF")
    end
    runtime.enabled = true
    if data.offPolicy == "restore" then
      runtime.restoreActions = _captureRestoreGroups(data.onActionGroups or {})
    end
    _cancelSequence(statusId, "")
    _startSequence(statusId, data.onActionGroups or {}, "manual", "main")
    _advanceSequence(statusId, _now())
    return true, tostring(rs.lastMessage or "Macro ON")

  elseif assetType == "custom_code" then
    local data = type(asset.data) == "table" and asset.data or {}
    local mode = (tostring(data.mode or "button") == "toggle") and "toggle" or "button"
    if mode == "toggle" then
      if state == "off" then
        runtime.enabled = false
        return _executeCustomCode(data.offCode, "GTS_CustomCode_OFF_" .. tostring(asset.id))
      end
      runtime.enabled = true
      return _executeCustomCode(data.onCode, "GTS_CustomCode_ON_" .. tostring(asset.id))
    end
    return _executeCustomCode(data.onCode, "GTS_CustomCode_RUN_" .. tostring(asset.id))

  elseif assetType == "teleport_preset" then
    local World = _safeRequire("GTS/Actions/macro_actions_world")
    local d = type(asset.data) == "table" and asset.data or {}
    if World and type(World.Teleport) == "function" then
      return World.Teleport({ x = d.x, y = d.y, z = d.z, label = d.label })
    end
    return false, "Teleport action unavailable"

  elseif assetType == "launcher" then
    local data    = type(asset.data) == "table" and asset.data or {}
    local mode    = (tostring(data.mode or "button") == "toggle") and "toggle" or "button"
    local entries = type(data.entries) == "table" and data.entries or {}
    local desired = state
    if mode == "toggle" then runtime.enabled = (desired ~= "off") end
    local ran = 0
    for i = 1, #entries do
      local e = entries[i]
      if type(e) == "table" then
        local childDesired = tostring(e.desiredState or ((mode == "toggle" and desired == "off") and "off" or "run"))
        if mode == "toggle" and desired == "off" and childDesired == "run" then childDesired = "off" end
        local embedded = _resolveReferencedAsset(e.ref, e.embeddedAsset)
        local ok = false
        if embedded then
          ok = select(1, RuleRunner.RunCreatedAssetDraft(embedded, childDesired, tostring(key) .. ":launcher:" .. tostring(i)))
        elseif tostring(e.ref or "") ~= "" then
          ok = select(1, RuleRunner.RunCreatedAssetById(e.ref, childDesired))
        end
        if ok then ran = ran + 1 end
      end
    end
    return ran > 0, string.format("Launcher ran %d item(s)", ran)

  elseif assetType == "rule" then
    local mutable = (not isDraft) and AssetRegistry.GetMutable(asset.id) or nil
    if mutable and mutable.data and (state == "on" or state == "off") then
      mutable.data.enabled = (state == "on")
      return true, (state == "on") and "Enabled script" or "Disabled script"
    end
    if state == "on" or state == "off" then
      local data = type(asset.data) == "table" and asset.data or {}
      data.enabled = (state == "on")
      asset.data   = data
      runtime.enabled = (state == "on")
      return true, (state == "on") and "Enabled script" or "Disabled script"
    end
    if not isDraft and tostring(asset.id or "") ~= "" then
      return RuleRunner.RunRuleNow(asset.id)
    end
    return _runRuleDraft(asset, key)

  elseif assetType == "stat_preset" then
    local StatsUI = _safeRequire("GTS/Builders/stats_browser")
    if StatsUI and type(StatsUI.ApplyPresetEntries) == "function" then
      local ok = StatsUI.ApplyPresetEntries((((asset or {}).data or {}).entries) or {})
      return ok == true, ok and "Applied Stat Profile" or "Could not apply Stat Profile"
    end

  elseif assetType == "spawn_set" then
    local SpawnTools = _safeRequire("GTS/Tools/spawn_tools")
    if SpawnTools and type(SpawnTools.ApplySpawnSet) == "function" then
      local ok = SpawnTools.ApplySpawnSet((((asset or {}).data or {}).entries) or {})
      return ok == true, ok and "Applied spawn preset" or "Could not apply spawn preset"
    end

  elseif assetType == "spawn_grid" then
    local SpawnTools = _safeRequire("GTS/Tools/spawn_tools")
    if SpawnTools and type(SpawnTools.ApplyGridAsset) == "function" then
      local ok = SpawnTools.ApplyGridAsset(asset)
      return ok == true, ok and "Applied saved grid" or "Could not apply saved grid"
    end

  elseif assetType == "inventory_bundle" then
    local InventoryTab = _safeRequire("GTS/Tools/inventory_tab")
    if InventoryTab and type(InventoryTab.ApplyInventoryBundle) == "function" then
      local ok = InventoryTab.ApplyInventoryBundle((((asset or {}).data or {}).entries) or {})
      return ok == true, ok and "Applied inventory bundle" or "Could not apply inventory bundle"
    end

  elseif assetType == "shooter_profile" then
    local Shooter = _safeRequire("GTS/Tools/shooter_tab")
    if Shooter and type(Shooter.ApplyProfileAsset) == "function" then
      return Shooter.ApplyProfileAsset(asset, "global", false)
    end

  elseif assetType == "animation_sequence" then
    local PoseBuilder = _safeRequire("GTS/Builders/pose_builder")
    if PoseBuilder and type(PoseBuilder.ExecuteSequenceAsset) == "function" then
      local desired = tostring(state or "run")
      if desired == "off" then
        local targetMode = "target"
        local target = PoseBuilder.ResolveActionTarget and PoseBuilder.ResolveActionTarget(targetMode) or nil
        if not target then targetMode = "player" end
        local resolved = target or (PoseBuilder.ResolveActionTarget and select(1, PoseBuilder.ResolveActionTarget(targetMode)) or nil)
        if resolved then return PoseBuilder.Stop(resolved) end
        return false, "No valid target for stop"
      end
      local ok, msg = PoseBuilder.ExecuteSequenceAsset(asset, "target", true)
      if not ok then ok, msg = PoseBuilder.ExecuteSequenceAsset(asset, "player", true) end
      return ok, msg or (ok and "Ran animation sequence" or "Could not run animation sequence")
    end

  elseif assetType == "scenario" then
    local ScenarioBuilder = _safeRequire("GTS/Builders/scenario_builder")
    if ScenarioBuilder and type(ScenarioBuilder.ApplyScenarioAsset) == "function" then
      return ScenarioBuilder.ApplyScenarioAsset(asset)
    end
  end

  return false, "Unsupported created asset type: " .. assetType
end

function RuleRunner.RunCreatedAssetById(assetId, desiredState)
  local asset = AssetRegistry.Get(assetId)
  if type(asset) ~= "table" then return false, "Missing created asset" end
  return _runCreatedAssetInternal(asset, desiredState, tostring(asset.id or ""))
end

function RuleRunner.RunCreatedAssetDraft(asset, desiredState, runtimeKey)
  if type(asset) ~= "table" then return false, "Missing draft asset" end
  local draft = _clone(asset)
  local key   = tostring(runtimeKey or draft.id or (tostring(draft.type or "asset") .. ":draft"))
  return _runCreatedAssetInternal(draft, desiredState, key, true)
end

function RuleRunner.ExecuteCustomCodeNow(code, contextLabel)
  return _executeCustomCode(code, contextLabel or "GTS_Manual_Custom_Code")
end

function RuleRunner.IsCreatedAssetEnabled(assetId)
  return _createdRuntime(assetId).enabled == true
end

local function _normalizeGroupMode(mode)
  mode = tostring(mode or "ordered")
  if mode ~= "parallel" then mode = "ordered" end
  return mode
end

function _normalizeActionGroups(groups, fallbackActions, defaultName)
  local src = type(groups) == "table" and groups or {}
  if #src == 0 and type(fallbackActions) == "table" and #fallbackActions > 0 then
    src = { {
      id      = string.format("%s_1", tostring(defaultName or "group"):gsub("%s+", "_"):lower()),
      name    = tostring(defaultName or "Group") .. " 1",
      mode    = "ordered",
      actions = _clone(fallbackActions),
    } }
  end
  local out = {}
  for i = 1, #src do
    local g   = type(src[i]) == "table" and _clone(src[i]) or {}
    g.id      = tostring(g.id or string.format("%s_%d", tostring(defaultName or "group"):gsub("%s+", "_"):lower(), i))
    g.name    = tostring(g.name or string.format("%s %d", tostring(defaultName or "Group"), i))
    g.mode    = _normalizeGroupMode(g.mode)
    g.actions = type(g.actions) == "table" and g.actions or {}
    if #g.actions > 0 then out[#out + 1] = g end
  end
  return out
end

local function _conditionLabel(cond)
  cond = cond or {}
  local base = tostring(cond.label or cond.key or cond.kind or "Condition")
  local kind = tostring(cond.kind or "")
  if kind == "saved_stat_condition" then
    return string.format("%s [%s]", base, tostring(cond.ref or "Unbound"))
  elseif kind == "target_class" then
    return string.format("%s [%s]", base, tostring(cond.targetClass or "NPCPuppet"))
  elseif kind == "owned_item" then
    return string.format("%s [%s]", base, tostring(cond.itemId or ""))
  elseif kind == "owned_vehicle" then
    return string.format("%s [%s]", base, tostring(cond.vehicleId or ""))
  elseif kind == "active_weapon_id" then
    return string.format("%s [%s]", base, tostring(cond.weaponId or ""))
  elseif kind == "equipped_slot_item" then
    return string.format("%s [%s = %s]", base, tostring(cond.slotKey or "Slot 1"), tostring(cond.itemId or ""))
  elseif kind == "difficulty_level" then
    return string.format("%s [%s]", base, tostring(cond.difficulty or "Story"))
  elseif kind == "tracked_quest_id" then
    return string.format("%s [%s]", base, tostring(cond.questId or ""))
  end
  return base
end

local function _actionLabel(action)
  local map = {
    apply_stat_preset              = "Apply Stat Profile",
    runtime_apply_stat_entries     = "Restore Stat Values",
    spawn_set                      = "Spawn Preset",
    spawn_saved_grid               = "Spawn Saved Grid",
    spawn_saved_grid_at_target     = "Spawn Grid at Target",
    add_inventory_bundle           = "Add Inventory Bundle",
    use_shooter_profile            = "Use Shooter Profile",
    set_time_of_day                = "Set Time Of Day",
    set_weather                    = "Set Weather",
    reset_weather                  = "Reset Weather",
    set_time_dilation              = "Set Time Manipulation",
    reset_time_dilation            = "Reset Time Manipulation",
    set_fov                        = "Set FOV",
    reset_fov                      = "Remove Zoom / Reset FOV",
    camera                         = "Camera / No Clip",
    show_ui_message                = "Show UI Message",
    toggle_hud                     = "Toggle HUD",
    johnny_hud                     = "Johnny HUD",
    arasaka_hud                    = "Arasaka HUD",
    open_fast_travel               = "Open Fast Travel Menu",
    teleport                       = "Teleport",
    repair_current_vehicle         = "Repair Current Vehicle",
    passive_mode                   = "Passive Mode",
    wanted_system                  = "Wanted System",
    set_wanted_stars               = "Set Wanted Stars",
    clear_wanted_level             = "Clear Wanted Level",
    johnny_arm                     = "Johnny Silverhand Arm",
    force_equip_weapon             = "Force Equip Weapon",
    force_equip_clothing           = "Force Equip Clothing",
    apply_status_effect            = "Apply Status Effect",
    remove_status_effect           = "Remove Status Effect",
    force_kill_lookat_npc          = "Force Kill Looked-At NPC",
    despawn_target                 = "Despawn Target",
    move_target                    = "Move Target",
    spawn_at_target                = "Spawn at Target",
    apply_status_effect_to_target  = "Apply Status Effect To Target",
    tether_target                  = "Tether Target",
    cycle_target_appearance        = "Cycle Target Appearance",
    wait                           = "Wait / Delay",
  }
  return map[tostring((action or {}).type or "")] or tostring((action or {}).type or "Action")
end

function _status(ruleId)
  local st = RuleRunner.state.statusByRuleId
  st[ruleId] = st[ruleId] or {
    lastEval                = false,
    lastRunAt               = 0,
    firedWhileTrue          = false,
    lastMessage             = "Idle",
    lastBlockedReason       = "",
    lastConditionResults    = {},
    lastActionResults       = {},
    lastTriggeredCount      = 0,
    sequenceActive          = false,
    sequenceIndex           = 0,
    sequenceTotal           = 0,
    sequenceWaitUntil       = 0,
    sequenceStartedAt       = 0,
    sequenceSource          = "",
    sequenceKind            = "",
    sequenceActions         = {},
    planGroups              = {},
    groupState              = nil,
    activeGroupIndex        = 0,
    activeGroupName         = "",
    activeGroupMode         = "",
    activeActionIndex       = 0,
    prevCondition           = false,
    trueCount               = 0,
    hasFiredEver            = false,
    lastTriggerEventAt      = 0,
    activeSession           = false,
    restoreActions          = {},
    pendingFalseTransition  = false,
    disableAfterSequence    = false,
    patternActive           = false,
    patternKind             = "single",
    patternRemaining        = 0,
    patternNextAt           = 0,
    patternCycleCount       = 1,
    patternInterval         = 0,
    patternLoopDelay        = 0,
    patternWaitingRestart   = false,
    patternRestartAt        = 0,
    patternSource           = "",
    patternStopOnFalse      = false,
    lastRuleStamp           = nil,
    lastEvalAt              = 0,
    evalCount               = 0,
    totalFireCount          = 0,
    pendingCount            = 0,
    lastActionError         = "",
    lastConditionChangeAt   = 0,
    lastEnabledState        = true,
    lastLoggedBlockedReason = "",
    lastTriggerDecision     = "idle",
    lastTriggerReason       = "",
    lastTriggerReady        = false,
    lastTriggerEventOccurred = false,
  }
  return st[ruleId]
end

local function _resetSequence(ruleId)
  local rs = _status(ruleId)
  rs.sequenceActive    = false
  rs.sequenceIndex     = 0
  rs.sequenceTotal     = 0
  rs.sequenceWaitUntil = 0
  rs.sequenceStartedAt = 0
  rs.sequenceSource    = ""
  rs.sequenceKind      = ""
  rs.sequenceActions   = {}
  rs.planGroups        = {}
  rs.groupState        = nil
  rs.activeGroupIndex  = 0
  rs.activeGroupName   = ""
  rs.activeGroupMode   = ""
  rs.activeActionIndex = 0
  rs.pendingCount      = 0
end

local function _resetPattern(ruleId)
  local rs = _status(ruleId)
  rs.patternActive         = false
  rs.patternKind           = "single"
  rs.patternRemaining      = 0
  rs.patternNextAt         = 0
  rs.patternCycleCount     = 1
  rs.patternInterval       = 0
  rs.patternLoopDelay      = 0
  rs.patternWaitingRestart = false
  rs.patternRestartAt      = 0
  rs.patternSource         = ""
  rs.patternStopOnFalse    = false
end

function _cancelSequence(ruleId, message)
  local rs = _status(ruleId)
  _resetSequence(ruleId)
  rs.lastMessage = tostring(message or "Sequence canceled")
end

local function _recordActionResult(ruleId, rs, groupIndex, actionIndex, result)
  rs.lastActionResults[groupIndex] = rs.lastActionResults[groupIndex] or {}
  rs.lastActionResults[groupIndex][actionIndex] = result
  if type(result) == "table" and result.success ~= true then
    rs.lastActionError = tostring(result.message or "Action failed")
    _pushLog(ruleId, "error", string.format("Action fail: %s - %s",
      tostring(result.actionLabel or result.actionType or (groupIndex .. "." .. actionIndex)),
      tostring(result.message or "Failed")))
  elseif type(result) == "table" then
    rs.lastActionError = ""
  end
end

local _runAction

local function _runActionSafe(action)
  action = action or {}
  if type(_runAction) ~= "function" then
    print("[GTS] RuleRunner action dispatch missing for '" .. tostring(action.type or "") .. "'")
    return false, {
      actionType  = tostring(action.type or ""),
      actionLabel = _actionLabel(action),
      target      = "",
      success     = false,
      message     = "Internal action dispatcher missing",
    }
  end
  local ok, success, result = pcall(_runAction, action)
  if ok then return success, result end
  local msg = tostring(success)
  print("[GTS] RuleRunner action error for '" .. tostring(_actionLabel(action)) .. "': " .. msg)
  return false, {
    actionType  = tostring(action.type or ""),
    actionLabel = _actionLabel(action),
    target      = "",
    success     = false,
    message     = "Action error: " .. msg,
  }
end

local function _buildPendingEntry(action, result, now)
  action = action or {}
  result = result or {}
  local t = tostring(action.type or "")
  if t == "wait" then
    local seconds = tonumber(result.waitSeconds or action.seconds or 0.25) or 0.25
    if seconds < 0 then seconds = 0 end
    return { pendingType = "timer", finishAt = (now or _now()) + seconds, waitSeconds = seconds }
  end
  if result.pending == true then return _clone(result) end
  return nil
end

local function _isPendingEntryComplete(entry, now)
  if type(entry) ~= "table" then return true end
  local pendingType = tostring(entry.pendingType or "")
  if pendingType == "timer" then
    return (now or _now()) >= (tonumber(entry.finishAt or 0) or 0)
  elseif pendingType == "camera_session" then
    local Camera = _safeRequire("GTS/Actions/macro_actions_camera")
    if Camera and type(Camera.IsSessionComplete) == "function" then
      local ok, done = pcall(Camera.IsSessionComplete, entry.token)
      return ok and done == true
    end
    return false
  end
  return true
end

function _startSequence(ruleId, groups, source, kind)
  local rs          = _status(ruleId)
  local defaultName = (tostring(kind or "main") == "false") and "Exit Group" or "Group"
  local planGroups  = _normalizeActionGroups(groups, nil, defaultName)
  rs.lastActionResults  = {}
  rs.lastTriggeredCount = 0
  rs.lastActionError    = ""
  rs.sequenceActive     = true
  rs.sequenceIndex      = 1
  rs.sequenceTotal      = #planGroups
  rs.sequenceWaitUntil  = _now()
  rs.sequenceStartedAt  = _now()
  rs.sequenceSource     = tostring(source or "auto")
  rs.sequenceKind       = tostring(kind or "main")
  rs.sequenceActions    = {}
  rs.planGroups         = planGroups
  rs.groupState         = nil
  rs.activeGroupIndex   = (rs.sequenceTotal > 0) and 1 or 0
  rs.activeGroupName    = ""
  rs.activeGroupMode    = ""
  rs.activeActionIndex  = 0
  rs.pendingCount       = 0
  rs.lastMessage = string.format("%s plan started (%d group%s)",
    rs.sequenceKind == "main" and "Main" or "Exit",
    rs.sequenceTotal,
    rs.sequenceTotal == 1 and "" or "s")
  _pushLog(ruleId, "info", rs.lastMessage)
  if rs.sequenceTotal <= 0 then
    _resetSequence(ruleId)
    rs.lastRunAt  = _now()
    rs.lastMessage = (kind == "main") and "Plan complete: 0 group(s)" or "Exit plan complete: 0 group(s)"
  end
end

local function _finishSequence(ruleId, now, message)
  local rs = _status(ruleId)
  _resetSequence(ruleId)
  rs.lastRunAt   = now or _now()
  rs.lastMessage = tostring(message or string.format("Plan complete: %d action(s)", tonumber(rs.lastTriggeredCount or 0) or 0))
  _pushLog(ruleId, "info", rs.lastMessage)
end

local function _startCurrentGroup(ruleId)
  local rs    = _status(ruleId)
  local group = rs.planGroups[rs.sequenceIndex]
  if not group then return nil end
  rs.groupState = {
    id              = tostring(group.id or string.format("group_%d", rs.sequenceIndex)),
    name            = tostring(group.name or string.format("Group %d", rs.sequenceIndex)),
    mode            = _normalizeGroupMode(group.mode),
    actions         = _clone(group.actions or {}),
    pendingByIndex  = {},
    completedByIndex = {},
    nextActionIndex = 1,
    pendingActionIndex = 0,
    launched        = false,
  }
  rs.activeGroupIndex  = rs.sequenceIndex
  rs.activeGroupName   = rs.groupState.name
  rs.activeGroupMode   = rs.groupState.mode
  rs.activeActionIndex = (#rs.groupState.actions > 0) and 1 or 0
  rs.sequenceWaitUntil = _now()
  _pushLog(ruleId, "info", string.format("Start group %d: %s [%s]",
    math.max(1, tonumber(rs.sequenceIndex or 1) or 1),
    rs.groupState.name,
    (rs.groupState.mode == "parallel") and "Parallel" or "Ordered"))
  return rs.groupState
end

local function _advanceOrderedGroup(ruleId, now)
  local rs = _status(ruleId)
  local gs = rs.groupState or _startCurrentGroup(ruleId)
  if not gs then return true end

  if gs.pendingActionIndex and gs.pendingActionIndex > 0 then
    local idx     = gs.pendingActionIndex
    local pending = gs.pendingByIndex[idx]
    rs.activeActionIndex = idx
    if _isPendingEntryComplete(pending, now) then
      _pushLog(ruleId, "info", string.format("Action done: %s", tostring(_actionLabel(gs.actions[idx] or {}))))
      gs.pendingByIndex[idx]    = nil
      gs.completedByIndex[idx]  = true
      gs.nextActionIndex        = idx + 1
      gs.pendingActionIndex     = 0
      rs.sequenceWaitUntil      = now
    else
      if tostring((pending or {}).pendingType or "") == "timer" then
        rs.sequenceWaitUntil = tonumber(pending.finishAt or now) or now
      else
        rs.sequenceWaitUntil = now + 0.05
      end
      rs.pendingCount = 1
      return false
    end
  end

  while gs.nextActionIndex <= #gs.actions do
    local idx    = gs.nextActionIndex
    local action = gs.actions[idx] or {}
    rs.activeActionIndex = idx
    _pushLog(ruleId, "info", string.format("Action start: %s", tostring(_actionLabel(action))))
    local ok, result = _runActionSafe(action)
    _recordActionResult(ruleId, rs, rs.sequenceIndex, idx, result)
    if ok and type(result) == "table" and result.pending ~= true then
      _pushLog(ruleId, "info", string.format("Action done: %s - %s",
        tostring(result.actionLabel or _actionLabel(action)),
        tostring(result.message or "Executed")))
    elseif ok and type(result) == "table" and result.pending == true then
      _pushLog(ruleId, "info", string.format("Action pending: %s", tostring(result.actionLabel or _actionLabel(action))))
    end
    if ok and tostring(action.type or "") ~= "wait" then
      rs.lastTriggeredCount = (tonumber(rs.lastTriggeredCount or 0) or 0) + 1
    end
    local pending = _buildPendingEntry(action, result, now)
    if pending then
      gs.pendingByIndex[idx]   = pending
      gs.pendingActionIndex    = idx
      if tostring((pending or {}).pendingType or "") == "timer" then
        rs.sequenceWaitUntil = tonumber(pending.finishAt or now) or now
      else
        rs.sequenceWaitUntil = now + 0.05
      end
      rs.pendingCount = 1
      return false
    end
    gs.completedByIndex[idx] = true
    gs.nextActionIndex       = idx + 1
    rs.sequenceWaitUntil     = now
  end

  rs.activeActionIndex = #gs.actions
  rs.pendingCount      = 0
  return true
end

local function _advanceParallelGroup(ruleId, now)
  local rs = _status(ruleId)
  local gs = rs.groupState or _startCurrentGroup(ruleId)
  if not gs then return true end

  if not gs.launched then
    gs.launched = true
    for idx = 1, #gs.actions do
      local action = gs.actions[idx] or {}
      rs.activeActionIndex = idx
      _pushLog(ruleId, "info", string.format("Action start: %s", tostring(_actionLabel(action))))
      local ok, result = _runActionSafe(action)
      _recordActionResult(ruleId, rs, rs.sequenceIndex, idx, result)
      if ok and type(result) == "table" and result.pending ~= true then
        _pushLog(ruleId, "info", string.format("Action done: %s - %s",
          tostring(result.actionLabel or _actionLabel(action)),
          tostring(result.message or "Executed")))
      elseif ok and type(result) == "table" and result.pending == true then
        _pushLog(ruleId, "info", string.format("Action pending: %s", tostring(result.actionLabel or _actionLabel(action))))
      end
      if ok and tostring(action.type or "") ~= "wait" then
        rs.lastTriggeredCount = (tonumber(rs.lastTriggeredCount or 0) or 0) + 1
      end
      local pending = _buildPendingEntry(action, result, now)
      if pending then gs.pendingByIndex[idx] = pending
      else            gs.completedByIndex[idx] = true end
    end
  end

  local pendingCount = 0
  local soonest      = nil
  for idx, pending in pairs(gs.pendingByIndex or {}) do
    if _isPendingEntryComplete(pending, now) then
      _pushLog(ruleId, "info", string.format("Action done: %s", tostring(_actionLabel(gs.actions[idx] or {}))))
      gs.pendingByIndex[idx]   = nil
      gs.completedByIndex[idx] = true
    else
      pendingCount = pendingCount + 1
      if tostring((pending or {}).pendingType or "") == "timer" then
        local finishAt = tonumber(pending.finishAt or now) or now
        soonest = (soonest == nil) and finishAt or math.min(soonest, finishAt)
      end
    end
  end

  rs.pendingCount = pendingCount
  if pendingCount > 0 then
    rs.activeActionIndex = #gs.actions
    rs.sequenceWaitUntil = soonest or (now + 0.05)
    return false
  end
  rs.activeActionIndex = #gs.actions
  rs.sequenceWaitUntil = now
  rs.pendingCount      = 0
  return true
end

function _advanceSequence(ruleId, now)
  local rs = _status(ruleId)
  if rs.sequenceActive ~= true then return false end
  if rs.sequenceTotal <= 0 then
    _finishSequence(ruleId, now, "Plan complete: 0 group(s)")
    return true
  end

  while rs.sequenceActive == true do
    if rs.sequenceIndex < 1 then rs.sequenceIndex = 1 end
    if rs.sequenceIndex > rs.sequenceTotal then
      local prefix = (rs.sequenceKind == "main") and "Plan complete" or "Exit plan complete"
      _finishSequence(ruleId, now, string.format("%s: %d action(s)", prefix, tonumber(rs.lastTriggeredCount or 0) or 0))
      return true
    end

    if not rs.groupState then _startCurrentGroup(ruleId) end
    local gs       = rs.groupState
    local complete = false
    if tostring((gs or {}).mode or "ordered") == "parallel" then
      complete = _advanceParallelGroup(ruleId, now)
    else
      complete = _advanceOrderedGroup(ruleId, now)
    end

    if complete then
      rs.sequenceIndex    = rs.sequenceIndex + 1
      rs.groupState       = nil
      rs.sequenceWaitUntil = now
      if rs.sequenceIndex > rs.sequenceTotal then
        local prefix = (rs.sequenceKind == "main") and "Plan complete" or "Exit plan complete"
        _finishSequence(ruleId, now, string.format("%s: %d action(s)", prefix, tonumber(rs.lastTriggeredCount or 0) or 0))
      else
        rs.activeGroupIndex = rs.sequenceIndex
        return true
      end
    else
      local groupCount  = math.max(0, tonumber(rs.sequenceTotal or 0) or 0)
      local actionCount = #((gs or {}).actions or {})
      if tostring((gs or {}).mode or "ordered") == "parallel" then
        local pc = 0
        for _ in pairs((gs and gs.pendingByIndex) or {}) do pc = pc + 1 end
        rs.lastMessage = string.format("Plan running | group %d/%d [%s] parallel | %d pending",
          math.max(1, tonumber(rs.sequenceIndex or 1) or 1), groupCount,
          tostring(rs.activeGroupName or "Group"), pc)
      else
        local remain = math.max(0, (tonumber(rs.sequenceWaitUntil or now) or now) - now)
        if remain > 0 then
          rs.lastMessage = string.format("Plan running | group %d/%d [%s] waiting %.2f sec | step %d/%d",
            math.max(1, tonumber(rs.sequenceIndex or 1) or 1), groupCount,
            tostring(rs.activeGroupName or "Group"), remain,
            math.max(1, tonumber(rs.activeActionIndex or 1) or 1), actionCount)
        else
          rs.lastMessage = string.format("Plan running | group %d/%d [%s] ordered | step %d/%d",
            math.max(1, tonumber(rs.sequenceIndex or 1) or 1), groupCount,
            tostring(rs.activeGroupName or "Group"),
            math.max(1, tonumber(rs.activeActionIndex or 1) or 1), actionCount)
        end
      end
      return true
    end
  end
  return false
end

function RuleRunner.GetManualToggle(key)
  return RuleRunner.state.manual[tostring(key or "manual_1")] == true
end

function RuleRunner.SetManualToggle(key, value)
  RuleRunner.state.manual[tostring(key or "manual_1")] = (value == true)
end

function RuleRunner.GetStatus(ruleId)
  return _clone(_status(ruleId))
end

function RuleRunner.GetEventLog(ruleId, limit)
  local logs  = RuleRunner.state.debugLog or {}
  local out   = {}
  local wanted = tostring(ruleId or "")
  local cap   = math.max(1, math.floor(tonumber(limit or 150) or 150))
  for i = #logs, 1, -1 do
    local entry = logs[i]
    if wanted == "" or tostring((entry or {}).ruleId or "") == wanted then
      out[#out + 1] = _clone(entry)
      if #out >= cap then break end
    end
  end
  return out
end

function RuleRunner.GetConditionDebug(cond)
  cond = cond or {}
  local expected = (cond.expected ~= false)
  local detail   = nil
  local kind     = tostring(cond.kind or "")
  local key      = tostring(cond.key  or "")

  if kind == "manual_toggle" or key == "manual_1" or key == "manual_2" or key == "manual_3" then
    detail = {
      label   = _conditionLabel(cond),
      kind    = "manual_toggle",
      current = RuleRunner.GetManualToggle(key) == true,
      left    = RuleRunner.GetManualToggle(key) == true,
      op      = "==",
      right   = true,
      reason  = "",
    }
  else
    local MoveObserver = _safeRequire("GTS/Services/move_observer")
    if MoveObserver and type(MoveObserver.GetConditionDetail) == "function" then
      local ok, result = pcall(MoveObserver.GetConditionDetail, cond)
      if ok and type(result) == "table" then
        detail = result
      elseif not ok then
        print("[GTS] Condition detail failed for '" .. tostring(_conditionLabel(cond)) .. "': " .. tostring(result))
      end
    end

    if detail == nil and MoveObserver and type(MoveObserver.GetConditionValue) == "function" then
      local ok, result = pcall(MoveObserver.GetConditionValue, cond)
      if ok then
        detail = {
          label   = _conditionLabel(cond),
          current = (result == true),
          left    = (result == true),
          op      = "==",
          right   = true,
          reason  = "",
        }
      elseif MoveObserver and type(MoveObserver.EvaluateCondition) == "function" then
        local copy = _clone(cond)
        copy.expected = true
        local ok2, result2 = pcall(MoveObserver.EvaluateCondition, copy)
        if ok2 then
          detail = {
            label   = _conditionLabel(cond),
            current = (result2 == true),
            left    = (result2 == true),
            op      = "==",
            right   = true,
            reason  = "",
          }
        else
          print("[GTS] Condition eval failed for '" .. tostring(_conditionLabel(cond)) .. "': " .. tostring(result))
        end
      end
    end
  end

  detail = detail or {
    label   = _conditionLabel(cond),
    current = false,
    left    = false,
    op      = "==",
    right   = true,
    reason  = "Condition unavailable",
  }
  detail.label    = tostring(detail.label or _conditionLabel(cond))
  detail.expected = expected == true
  detail.pass     = ((detail.current == true) == detail.expected)
  return detail
end

-- Single flat evaluator — no condition group machinery.
local function _evaluateConditions(data)
  data = data or {}
  local conditions = data.conditions
  if type(conditions) ~= "table" or #conditions == 0 then
    if type(data.condition) == "table" then
      conditions = { data.condition }
    else
      return false, "No WHEN lines", {}
    end
  end

  local results   = {}
  local mode      = tostring(data.conditionMode or "ALL")
  if mode ~= "ANY" then mode = "ALL" end

  local anyPass   = false
  local firstFail = nil
  for i = 1, #conditions do
    local cond = conditions[i]
    local dbg  = RuleRunner.GetConditionDebug(cond)
    results[#results + 1] = dbg
    if dbg.pass then anyPass = true
    elseif not firstFail then firstFail = dbg.label end
  end

  if mode == "ANY" then
    if anyPass then return true, nil, results end
    return false, "Waiting for any condition", results
  end

  if firstFail then return false, "Blocked by " .. tostring(firstFail), results end
  return true, nil, results
end

local function _actionTarget(action, asset)
  action = action or {}
  local t = tostring(action.type or "")
  if t == "spawn_saved_grid_at_target" then
    return string.format("%s @ target", tostring(asset and (asset.name or asset.id) or "saved grid"))
  end
  if asset then return tostring(asset.name or asset.id or "asset") end
  if t == "runtime_apply_stat_entries" then
    return string.format("%d stat(s)", #((action.entries) or {}))
  elseif t == "set_time_of_day" then
    return string.format("%02d:%02d", math.floor(tonumber(action.hour or 0) or 0), math.floor(tonumber(action.minute or 0) or 0))
  elseif t == "set_weather" then
    return tostring(action.weatherId or "weather")
  elseif t == "set_time_dilation" then
    local mode = (tostring(action.timeTarget or "world_only") == "world_and_v") and "world + V" or "world only"
    return string.format("%s | %.2f", mode, tonumber(action.timeScale or 0.20) or 0.20)
  elseif t == "reset_time_dilation" then return "Reset"
  elseif t == "set_fov" then
    return string.format("%.1f", tonumber(action.fovValue or 80.0) or 80.0)
  elseif t == "reset_fov" then return "Reset to default"
  elseif t == "camera" then
    local cmd         = tostring(action.command or "on")
    local mode        = (tostring(action.mode or "detached") == "noclip") and "No Clip" or "Detached"
    local disableMode = tostring(action.disableMode or "manual")
    local dText       = "manual"
    if disableMode == "after_time" then
      dText = string.format("off after %.1fs", tonumber(action.disableAfterSeconds or 5.0) or 5.0)
    elseif disableMode == "while_still" then
      dText = string.format("off still %.1fs", tonumber(action.disableStillSeconds or 3.0) or 3.0)
    elseif disableMode == "either" then
      dText = string.format("off %.1fs / still %.1fs",
        tonumber(action.disableAfterSeconds or 5.0) or 5.0,
        tonumber(action.disableStillSeconds or 3.0) or 3.0)
    end
    return string.format("%s | %s | %.2f | %s", string.upper(cmd), mode, tonumber(action.speed or 0.18) or 0.18, dText)
  elseif t == "show_ui_message" then
    return tostring(action.messageMode or "screen") .. ": " .. tostring(action.messageText or "")
  elseif t == "toggle_hud" or t == "johnny_hud" or t == "arasaka_hud" then
    return (action.enabled == false) and "OFF" or "ON"
  elseif t == "open_fast_travel" then return "Open"
  elseif t == "teleport" then
    return string.format("%.2f, %.2f, %.2f", tonumber(action.x or 0) or 0, tonumber(action.y or 0) or 0, tonumber(action.z or 0) or 0)
  elseif t == "passive_mode" or t == "wanted_system" then
    return (action.enabled == false) and "OFF" or "ON"
  elseif t == "set_wanted_stars" then
    return tostring(math.floor(tonumber(action.level or 0) or 0))
  elseif t == "johnny_arm" then return tostring(action.mode or "toggle")
  elseif t == "force_equip_weapon" or t == "force_equip_clothing" then
    return tostring(action.itemId or "")
  elseif t == "apply_status_effect" or t == "remove_status_effect" then
    return tostring(action.effectId or "")
  elseif t == "force_kill_lookat_npc" then return "Current looked-at NPC"
  elseif t == "despawn_target" then return "Current target"
  elseif t == "move_target" then
    local mode = (tostring(action.moveMode or "offset") == "absolute") and "To" or "By"
    return string.format("%s %.2f, %.2f, %.2f", mode,
      tonumber(action.x or 0) or 0, tonumber(action.y or 0) or 0, tonumber(action.z or 0) or 0)
  elseif t == "spawn_at_target" then
    local mode      = tostring(action.spawnMode or "Character")
    local modeLabel = (mode == "Character") and "NPC" or string.upper(mode)
    return string.format("%s | %s @ target", modeLabel, tostring(action.recordId or action.record or ""))
  elseif t == "apply_status_effect_to_target" then return tostring(action.effectId or "")
  elseif t == "tether_target" then return tostring(action.endMode or "manual")
  elseif t == "cycle_target_appearance" then
    return ((tonumber(action.step or 1) or 1) < 0) and "previous" or "next"
  elseif t == "apply_animation_to_player" or t == "apply_animation_to_target" then
    local PoseBuilder = _safeRequire("GTS/Builders/pose_builder")
    if PoseBuilder and type(PoseBuilder.DescribeActionTarget) == "function" then
      return PoseBuilder.DescribeActionTarget(action)
    end
    return tostring(action.poseName or action.name or "")
  elseif t == "use_shooter_profile" then
    return (tostring(action.applyTo or "global") == "active_override") and "Apply to active weapon" or "Apply to global shooter"
  elseif t == "wait" then
    return string.format("%.2f sec", tonumber(action.seconds or 0) or 0)
  end
  return ""
end

_runAction = function(action)
  action = action or {}
  local actionType = tostring(action.type or "")
  local assetTypeActions = {
    apply_stat_preset          = true,
    spawn_set                  = true,
    spawn_saved_grid           = true,
    spawn_saved_grid_at_target = true,
    add_inventory_bundle       = true,
    use_shooter_profile        = true,
  }
  local asset  = assetTypeActions[actionType] and _resolveReferencedAsset(action.ref, action.embeddedAsset) or nil
  local result = {
    actionType  = actionType,
    actionLabel = _actionLabel(action),
    target      = _actionTarget(action, asset),
    success     = false,
    message     = "Not run",
  }

  local success, message = false, nil

  if actionType == "custom_cet_code" then
    success, message = _executeCustomCode(action.code, "GTS_Action_CustomCode")

  elseif actionType == "run_created_asset" then
    local embedded = _resolveReferencedAsset(action.ref, action.embeddedAsset)
    if embedded then
      success, message = RuleRunner.RunCreatedAssetDraft(embedded, action.desiredState,
        tostring(action.ref or embedded.id or action.type or "embedded_asset"))
    elseif tostring(action.ref or "") == "" then
      message = "Missing created asset"
    else
      success, message = RuleRunner.RunCreatedAssetById(action.ref, action.desiredState)
    end

  elseif actionType == "wait" then
    local seconds = tonumber(action.seconds or 0.25) or 0.25
    if seconds < 0 then seconds = 0 end
    success          = true
    message          = string.format("Wait %.2f sec", seconds)
    result.waitSeconds = seconds

  elseif actionType == "runtime_apply_stat_entries" then
    local StatsUI = _safeRequire("GTS/Builders/stats_browser")
    if StatsUI and type(StatsUI.ApplyPresetEntries) == "function" then
      success = StatsUI.ApplyPresetEntries(action.entries or {}) == true
      message = success and "Restored stat values" or "Could not restore stat values"
    end

  elseif actionType == "apply_stat_preset" then
    if not asset then message = "Missing asset"
    else
      local StatsUI = _safeRequire("GTS/Builders/stats_browser")
      success = StatsUI and type(StatsUI.ApplyPresetEntries) == "function" and asset.type == "stat_preset"
        and StatsUI.ApplyPresetEntries(asset.data and asset.data.entries or {}) == true or false
    end

  elseif actionType == "spawn_set" then
    if not asset then message = "Missing asset"
    else
      local SpawnTools = _safeRequire("GTS/Tools/spawn_tools")
      success = SpawnTools and type(SpawnTools.ApplySpawnSet) == "function" and asset.type == "spawn_set"
        and SpawnTools.ApplySpawnSet(asset.data and asset.data.entries or {}) == true or false
    end

  elseif actionType == "spawn_saved_grid" then
    if not asset then message = "Missing asset"
    else
      local SpawnTools = _safeRequire("GTS/Tools/spawn_tools")
      success = SpawnTools and type(SpawnTools.ApplyGridAsset) == "function" and asset.type == "spawn_grid"
        and SpawnTools.ApplyGridAsset(asset) == true or false
    end

  elseif actionType == "spawn_saved_grid_at_target" then
    if not asset then message = "Missing asset"
    else
      local Target = _safeRequire("GTS/Actions/macro_actions_target")
      if Target and type(Target.SpawnGridAtTargetAsset) == "function" and asset.type == "spawn_grid" then
        success, message = Target.SpawnGridAtTargetAsset(asset)
      end
    end

  elseif actionType == "add_inventory_bundle" then
    if not asset then message = "Missing asset"
    else
      local InventoryTab = _safeRequire("GTS/Tools/inventory_tab")
      success = InventoryTab and type(InventoryTab.ApplyInventoryBundle) == "function" and asset.type == "inventory_bundle"
        and InventoryTab.ApplyInventoryBundle(asset.data and asset.data.entries or {}) == true or false
    end

  elseif actionType == "set_time_of_day" then
    local World = _safeRequire("GTS/Actions/macro_actions_world")
    if World and type(World.SetTimeOfDay) == "function" then success, message = World.SetTimeOfDay(action.hour, action.minute) end

  elseif actionType == "set_weather" then
    local World = _safeRequire("GTS/Actions/macro_actions_world")
    if World and type(World.SetWeather) == "function" then success, message = World.SetWeather(action.weatherId) end

  elseif actionType == "reset_weather" then
    local World = _safeRequire("GTS/Actions/macro_actions_world")
    if World and type(World.ResetWeather) == "function" then success, message = World.ResetWeather() end

  elseif actionType == "set_time_dilation" then
    local World = _safeRequire("GTS/Actions/macro_actions_world")
    if World and type(World.SetTimeDilation) == "function" then success, message = World.SetTimeDilation(action.timeTarget, action.timeScale) end

  elseif actionType == "reset_time_dilation" then
    local World = _safeRequire("GTS/Actions/macro_actions_world")
    if World and type(World.ResetTimeDilation) == "function" then success, message = World.ResetTimeDilation() end

  elseif actionType == "set_fov" then
    local World = _safeRequire("GTS/Actions/macro_actions_world")
    if World and type(World.SetFOV) == "function" then success, message = World.SetFOV(action.fovValue) end

  elseif actionType == "reset_fov" then
    local World = _safeRequire("GTS/Actions/macro_actions_world")
    if World and type(World.ResetFOV) == "function" then success, message = World.ResetFOV() end

  elseif actionType == "camera" then
    local Camera = _safeRequire("GTS/Actions/macro_actions_camera")
    if Camera and type(Camera.Execute) == "function" then
      local pending
      success, message, pending = Camera.Execute(action)
      if type(pending) == "table" then
        result.pending = true
        for k, v in pairs(pending) do result[k] = v end
      end
    end

  elseif actionType == "show_ui_message" then
    local World = _safeRequire("GTS/Actions/macro_actions_world")
    if World and type(World.ShowUIMessage) == "function" then
      success, message = World.ShowUIMessage(action.messageMode, action.messageText, action.messageDuration)
    end

  elseif actionType == "toggle_hud" then
    local UI = _safeRequire("GTS/Actions/macro_actions_interface")
    if UI and type(UI.SetHUDEnabled) == "function" then success, message = UI.SetHUDEnabled(action.enabled ~= false) end

  elseif actionType == "johnny_hud" then
    local UI = _safeRequire("GTS/Actions/macro_actions_interface")
    if UI and type(UI.SetJohnnyHUD) == "function" then success, message = UI.SetJohnnyHUD(action.enabled ~= false) end

  elseif actionType == "arasaka_hud" then
    local UI = _safeRequire("GTS/Actions/macro_actions_interface")
    if UI and type(UI.SetArasakaHUD) == "function" then success, message = UI.SetArasakaHUD(action.enabled ~= false) end

  elseif actionType == "open_fast_travel" then
    local UI = _safeRequire("GTS/Actions/macro_actions_interface")
    if UI and type(UI.OpenFastTravelMenu) == "function" then success, message = UI.OpenFastTravelMenu() end

  elseif actionType == "teleport" then
    local World = _safeRequire("GTS/Actions/macro_actions_world")
    if World and type(World.Teleport) == "function" then success, message = World.Teleport(action) end

  elseif actionType == "repair_current_vehicle" then
    local Vehicle = _safeRequire("GTS/Actions/macro_actions_vehicle")
    if Vehicle and type(Vehicle.RepairCurrentVehicle) == "function" then success, message = Vehicle.RepairCurrentVehicle() end

  elseif actionType == "passive_mode" then
    local Player = _safeRequire("GTS/Actions/macro_actions_player")
    if Player and type(Player.SetPassiveMode) == "function" then success, message = Player.SetPassiveMode(action.enabled ~= false) end

  elseif actionType == "wanted_system" then
    local Player = _safeRequire("GTS/Actions/macro_actions_player")
    if Player and type(Player.SetWantedSystemEnabled) == "function" then success, message = Player.SetWantedSystemEnabled(action.enabled ~= false) end

  elseif actionType == "set_wanted_stars" then
    local Player = _safeRequire("GTS/Actions/macro_actions_player")
    if Player and type(Player.SetWantedLevel) == "function" then success, message = Player.SetWantedLevel(action.level) end

  elseif actionType == "clear_wanted_level" then
    local Player = _safeRequire("GTS/Actions/macro_actions_player")
    if Player and type(Player.ClearWantedLevel) == "function" then success, message = Player.ClearWantedLevel() end

  elseif actionType == "johnny_arm" then
    local Player = _safeRequire("GTS/Actions/macro_actions_player")
    if Player and type(Player.SetJohnnySilverhandArm) == "function" then success, message = Player.SetJohnnySilverhandArm(action.mode) end

  elseif actionType == "force_equip_weapon" or actionType == "force_equip_clothing" then
    local Equip = _safeRequire("GTS/Actions/macro_actions_equipment")
    if Equip and type(Equip.EquipItemRecord) == "function" then success, message = Equip.EquipItemRecord(action.itemId) end

  elseif actionType == "apply_status_effect" then
    local Status = _safeRequire("GTS/Actions/macro_actions_status")
    if Status and type(Status.ApplyStatusEffect) == "function" then success, message = Status.ApplyStatusEffect(action.effectId) end

  elseif actionType == "remove_status_effect" then
    local Status = _safeRequire("GTS/Actions/macro_actions_status")
    if Status and type(Status.RemoveStatusEffect) == "function" then success, message = Status.RemoveStatusEffect(action.effectId) end

  elseif actionType == "force_kill_lookat_npc" then
    local Area = _safeRequire("GTS/Actions/macro_actions_area")
    if Area and type(Area.ForceKillLookAtNPC) == "function" then success, message = Area.ForceKillLookAtNPC() end

  elseif actionType == "despawn_target" then
    local Target = _safeRequire("GTS/Actions/macro_actions_target")
    if Target and type(Target.DespawnTarget) == "function" then success, message = Target.DespawnTarget() end

  elseif actionType == "move_target" then
    local Target = _safeRequire("GTS/Actions/macro_actions_target")
    if Target and type(Target.MoveTarget) == "function" then success, message = Target.MoveTarget(action) end

  elseif actionType == "spawn_at_target" then
    local Target = _safeRequire("GTS/Actions/macro_actions_target")
    if Target and type(Target.SpawnAtTarget) == "function" then success, message = Target.SpawnAtTarget(action) end

  elseif actionType == "apply_status_effect_to_target" then
    local Target = _safeRequire("GTS/Actions/macro_actions_target")
    if Target and type(Target.ApplyStatusEffectToTarget) == "function" then success, message = Target.ApplyStatusEffectToTarget(action.effectId) end

  elseif actionType == "tether_target" then
    local Target = _safeRequire("GTS/Actions/macro_actions_target")
    if Target and type(Target.StartTetherToPlayer) == "function" then success, message = Target.StartTetherToPlayer(action) end

  elseif actionType == "cycle_target_appearance" then
    local Target = _safeRequire("GTS/Actions/macro_actions_target")
    if Target and type(Target.CycleAppearance) == "function" then success, message = Target.CycleAppearance(action.step) end

  elseif actionType == "use_shooter_profile" then
    if not asset then message = "Missing asset"
    else
      local Shooter = _safeRequire("GTS/Tools/shooter_tab")
      if Shooter and type(Shooter.ApplyProfileAsset) == "function" and asset.type == "shooter_profile" then
        success, message = Shooter.ApplyProfileAsset(asset, action.applyTo, action.forceEnabled)
      end
    end

  elseif actionType == "apply_animation_to_player" or actionType == "apply_animation_to_target" then
    local PoseBuilder = _safeRequire("GTS/Builders/pose_builder")
    if PoseBuilder and type(PoseBuilder.ExecuteAction) == "function" then
      success, message = PoseBuilder.ExecuteAction(action,
        (actionType == "apply_animation_to_player") and "player" or "target")
    end
  end

  result.success = success == true
  result.message = result.success and tostring(message or "Executed") or tostring(message or "Failed")
  return result.success, result
end

function _captureRestoreGroups(groups)
  local restoreActions = {}
  groups = _normalizeActionGroups(groups, nil, "Group")
  for gi = #groups, 1, -1 do
    local actions = (groups[gi] or {}).actions or {}
    for i = #actions, 1, -1 do
      local action = actions[i] or {}
      local t      = tostring(action.type or "")
      if t == "apply_stat_preset" then
        local asset = action.ref and AssetRegistry.Get(action.ref) or nil
        if asset and asset.type == "stat_preset" then
          local StatsUI = _safeRequire("GTS/Builders/stats_browser")
          if StatsUI and type(StatsUI.BuildBaselineEntries) == "function" then
            local entries = StatsUI.BuildBaselineEntries((((asset or {}).data or {}).entries) or {}) or {}
            if #entries > 0 then
              restoreActions[#restoreActions + 1] = { type = "runtime_apply_stat_entries", entries = entries }
            end
          end
        end
      elseif t == "set_time_dilation" then
        restoreActions[#restoreActions + 1] = { type = "reset_time_dilation" }
      elseif t == "set_fov" then
        restoreActions[#restoreActions + 1] = { type = "reset_fov" }
      elseif t == "camera" then
        if tostring(action.command or "on") == "on" then
          restoreActions[#restoreActions + 1] = { type = "camera", command = "off" }
        end
      elseif t == "apply_status_effect" then
        restoreActions[#restoreActions + 1] = { type = "remove_status_effect", effectId = action.effectId }
      elseif t == "remove_status_effect" then
        restoreActions[#restoreActions + 1] = { type = "apply_status_effect", effectId = action.effectId }
      elseif t == "toggle_hud" or t == "johnny_hud" or t == "arasaka_hud" or t == "passive_mode" or t == "wanted_system" then
        local copy = _clone(action)
        copy.enabled = not (action.enabled ~= false)
        restoreActions[#restoreActions + 1] = copy
      elseif t == "set_wanted_stars" then
        restoreActions[#restoreActions + 1] = { type = "clear_wanted_level" }
      elseif t == "run_created_asset" then
        restoreActions[#restoreActions + 1] = {
          type          = "run_created_asset",
          ref           = action.ref,
          embeddedAsset = _clone(action.embeddedAsset),
          desiredState  = "off",
        }
      end
    end
  end
  if #restoreActions <= 0 then return {} end
  return { { id = "restore_1", name = "Restore", mode = "ordered", actions = restoreActions } }
end

local function _normalizeExecution(data)
  data = data or {}
  local exec = type(data.execution) == "table" and data.execution or {
    triggerMode      = (data.runOnceUntilFalse ~= false) and "on_true" or "while_true",
    cadence          = "every_time",
    cadenceValue     = 2,
    cooldown         = tonumber(data.cooldown or 0.25) or 0.25,
    firePattern      = "single",
    burstCount       = 3,
    burstInterval    = 0.20,
    burstStopOnFalse = false,
    loopCount        = 3,
    loopInterval     = 0.15,
    loopRestartDelay = 1.00,
    disableAfterFire = false,
    falsePolicy      = "do_nothing",
    falseActions     = type(data.falseActions) == "table" and data.falseActions or {},
  }
  exec.triggerMode = tostring(exec.triggerMode or "on_true")
  if exec.triggerMode ~= "while_true" then exec.triggerMode = "on_true" end

  exec.cadence = tostring(exec.cadence or "every_time")
  if exec.cadence ~= "first_true_only" and exec.cadence ~= "every_nth_true" and exec.cadence ~= "after_nth_true" then
    exec.cadence = "every_time"
  end

  exec.cadenceValue    = math.max(1, math.floor(tonumber(exec.cadenceValue or 2) or 2))
  exec.cooldown        = tonumber(exec.cooldown or data.cooldown or 0.25) or 0.25
  if exec.cooldown < 0 then exec.cooldown = 0 end

  exec.firePattern = tostring(exec.firePattern or "single")
  if exec.firePattern ~= "burst" and exec.firePattern ~= "loop" then exec.firePattern = "single" end
  exec.burstCount = math.max(1, math.floor(tonumber(exec.burstCount or 3) or 3))
  exec.burstInterval = tonumber(exec.burstInterval or 0.20) or 0.20
  if exec.burstInterval < 0 then exec.burstInterval = 0 end
  exec.burstStopOnFalse = exec.burstStopOnFalse == true
  exec.loopCount = math.max(1, math.floor(tonumber(exec.loopCount or 3) or 3))
  exec.loopInterval = tonumber(exec.loopInterval or 0.15) or 0.15
  if exec.loopInterval < 0 then exec.loopInterval = 0 end
  exec.loopRestartDelay = tonumber(exec.loopRestartDelay or 1.00) or 1.00
  if exec.loopRestartDelay < 0 then exec.loopRestartDelay = 0 end

  exec.disableAfterFire = exec.disableAfterFire == true

  exec.falsePolicy = tostring(exec.falsePolicy or "do_nothing")
  if exec.falsePolicy ~= "restore" and exec.falsePolicy ~= "run_exit_actions" and exec.falsePolicy ~= "disable_rule" then
    exec.falsePolicy = "do_nothing"
  end
  exec.falseActions = type(exec.falseActions) == "table" and exec.falseActions
                      or type(data.falseActions) == "table" and data.falseActions or {}

  data.actionGroups      = _normalizeActionGroups(data.actionGroups,      type(data.actions)      == "table" and data.actions      or {}, "Group")
  data.falseActionGroups = _normalizeActionGroups(data.falseActionGroups, type(data.falseActions) == "table" and data.falseActions or {}, "Exit Group")
  data.execution         = exec
  data.falseActions      = exec.falseActions
  data.runOnceUntilFalse = (exec.triggerMode == "on_true")
  data.cooldown          = exec.cooldown
  return exec
end

local function _shouldFireForCadence(exec, trueCount, hasFiredEver)
  exec = exec or {}
  local cadence = tostring(exec.cadence or "every_time")
  local n       = math.max(1, math.floor(tonumber(exec.cadenceValue or 2) or 2))
  if cadence == "first_true_only" then
    if hasFiredEver == true then return false, "First true already used" end
    return true, nil
  elseif cadence == "every_nth_true" then
    if (trueCount % n) == 0 then return true, nil end
    return false, string.format("Waiting for every %dth true (%d/%d)", n, trueCount % n, n)
  elseif cadence == "after_nth_true" then
    if trueCount >= n then return true, nil end
    return false, string.format("Waiting until true #%d (%d/%d)", n, trueCount, n)
  end
  return true, nil
end

local function _patternTickDelay(value)
  local n = tonumber(value or 0) or 0
  if n < 0 then n = 0 end
  if n < 0.01 then n = 0.01 end
  return n
end

_armFirePattern = function(rule, source, now)
  local data = (rule or {}).data or {}
  local exec = _normalizeExecution(data)
  local rs   = _status(rule.id)
  local pattern = tostring(exec.firePattern or "single")
  now = now or _now()

  _resetPattern(rule.id)

  if pattern == "single" then
    _startMainSequence(rule, source)
    return
  end

  rs.patternActive      = true
  rs.patternKind        = pattern
  rs.patternSource      = tostring(source or "auto")
  rs.patternWaitingRestart = false
  rs.patternRestartAt   = 0

  if pattern == "burst" then
    rs.patternRemaining   = math.max(1, math.floor(tonumber(exec.burstCount or 3) or 3)) - 1
    rs.patternInterval    = tonumber(exec.burstInterval or 0.20) or 0.20
    rs.patternCycleCount  = 1
    rs.patternLoopDelay   = 0
    rs.patternStopOnFalse = exec.burstStopOnFalse == true
    _startMainSequence(rule, source)
  else
    rs.patternCycleCount  = math.max(1, math.floor(tonumber(exec.loopCount or 3) or 3))
    rs.patternRemaining   = rs.patternCycleCount - 1
    rs.patternInterval    = tonumber(exec.loopInterval or 0.15) or 0.15
    rs.patternLoopDelay   = tonumber(exec.loopRestartDelay or 1.00) or 1.00
    rs.patternStopOnFalse = true
    _startMainSequence(rule, source)
  end

  if rs.sequenceActive ~= true then
    if rs.patternKind == "burst" then
      if rs.patternRemaining > 0 then
        rs.patternNextAt = now + _patternTickDelay(rs.patternInterval)
      else
        _resetPattern(rule.id)
      end
    elseif rs.patternKind == "loop" then
      if rs.patternRemaining > 0 then
        rs.patternNextAt = now + _patternTickDelay(rs.patternInterval)
      else
        rs.patternWaitingRestart = true
        rs.patternRestartAt = now + _patternTickDelay(rs.patternLoopDelay)
      end
    end
  end
end

local function _advanceFirePattern(rule, now, isTrue)
  local rs = _status(rule.id)
  if rs.patternActive ~= true or rs.sequenceActive == true then return false end
  if ((rule or {}).data or {}).enabled == false then
    _resetPattern(rule.id)
    return false
  end

  if rs.patternWaitingRestart == true then
    if now < (tonumber(rs.patternRestartAt or 0) or 0) then return false end
    if isTrue ~= true then
      _resetPattern(rule.id)
      return false
    end
    rs.patternWaitingRestart = false
    rs.patternRemaining = math.max(1, tonumber(rs.patternCycleCount or 1) or 1) - 1
    _startMainSequence(rule, rs.patternSource)
    if rs.sequenceActive ~= true then
      if rs.patternRemaining > 0 then
        rs.patternNextAt = now + _patternTickDelay(rs.patternInterval)
      else
        rs.patternWaitingRestart = true
        rs.patternRestartAt = now + _patternTickDelay(rs.patternLoopDelay)
      end
    end
    return true
  end

  if now < (tonumber(rs.patternNextAt or 0) or 0) then return false end
  _startMainSequence(rule, rs.patternSource)
  rs.patternRemaining = math.max(0, math.floor((tonumber(rs.patternRemaining or 0) or 0) - 1))
  if rs.sequenceActive ~= true then
    if rs.patternKind == "burst" then
      if rs.patternRemaining > 0 then
        rs.patternNextAt = now + _patternTickDelay(rs.patternInterval)
      else
        _resetPattern(rule.id)
      end
    elseif rs.patternKind == "loop" then
      if rs.patternRemaining > 0 then
        rs.patternNextAt = now + _patternTickDelay(rs.patternInterval)
      else
        rs.patternWaitingRestart = true
        rs.patternRestartAt = now + _patternTickDelay(rs.patternLoopDelay)
      end
    end
  end
  return true
end

local function _handlePatternSequenceFinished(rule, now, isTrue)
  local rs = _status(rule.id)
  if rs.patternActive ~= true then return end
  if rs.patternKind == "burst" then
    if tonumber(rs.patternRemaining or 0) > 0 then
      rs.patternNextAt = now + _patternTickDelay(rs.patternInterval)
      rs.lastMessage = string.format("Burst waiting %.2fs", _patternTickDelay(rs.patternInterval))
    else
      _resetPattern(rule.id)
    end
  elseif rs.patternKind == "loop" then
    if tonumber(rs.patternRemaining or 0) > 0 then
      rs.patternNextAt = now + _patternTickDelay(rs.patternInterval)
      rs.lastMessage = string.format("Loop waiting %.2fs", _patternTickDelay(rs.patternInterval))
    elseif isTrue == true then
      rs.patternWaitingRestart = true
      rs.patternRestartAt = now + _patternTickDelay(rs.patternLoopDelay)
      rs.lastMessage = string.format("Loop cycle complete | next cycle in %.2fs", _patternTickDelay(rs.patternLoopDelay))
    else
      _resetPattern(rule.id)
    end
  end
end

local function _isPatternStillScheduled(rs)
  if type(rs) ~= "table" then return false end
  if rs.patternActive ~= true then return false end
  if tonumber(rs.patternRemaining or 0) > 0 then return true end
  if rs.patternWaitingRestart == true then return true end
  return false
end

_startMainSequence = function(rule, source)
  local data = (rule or {}).data or {}
  local exec = _normalizeExecution(data)
  local rs   = _status(rule.id)
  if rs.activeSession ~= true and exec.falsePolicy == "restore" then
    rs.restoreActions = _captureRestoreGroups(data.actionGroups or data.actions or {})
  end
  rs.activeSession       = true
  rs.pendingFalseTransition = false
  rs.lastFireMode        = tostring(source or "auto")
  rs.hasFiredEver        = true
  rs.totalFireCount      = (tonumber(rs.totalFireCount or 0) or 0) + 1
  _pushLog(rule.id, "info", string.format("Trigger fired (%s)", tostring(source or "auto")))
  _startSequence(rule.id, data.actionGroups or data.actions or {}, source or "auto", "main")
  if exec.disableAfterFire then rs.disableAfterSequence = true end
  _advanceSequence(rule.id, _now())
  if exec.disableAfterFire and rs.sequenceActive ~= true and _isPatternStillScheduled(rs) ~= true then
    data.enabled            = false
    rs.disableAfterSequence = false
    rs.lastMessage          = "Rule fired and disabled"
  end
end

local function _handleFalseTransition(rule, now)
  local data = (rule or {}).data or {}
  local exec = _normalizeExecution(data)
  local rs   = _status(rule.id)
  rs.pendingFalseTransition = false

  if rs.activeSession ~= true then
    rs.restoreActions = {}
    _pushLog(rule.id, "info", "WHEN became false: session ended")
    return
  end

  if exec.falsePolicy == "restore" then
    local restoreActions = rs.restoreActions or {}
    if #restoreActions > 0 then
      _startSequence(rule.id, restoreActions, "auto", "restore")
      rs.lastMessage = "WHEN became false: restoring / resetting"
      _pushLog(rule.id, "info", rs.lastMessage)
    else
      rs.lastMessage = "WHEN became false: nothing to restore"
    end
  elseif exec.falsePolicy == "run_exit_actions" then
    local falseGroups = _normalizeActionGroups(data.falseActionGroups, data.falseActions or {}, "Exit Group")
    if #falseGroups > 0 then
      _startSequence(rule.id, falseGroups, "auto", "false")
      rs.lastMessage = "WHEN became false: running exit groups"
      _pushLog(rule.id, "info", rs.lastMessage)
    else
      rs.lastMessage = "WHEN became false: no exit actions"
    end
  elseif exec.falsePolicy == "disable_rule" then
    data.enabled   = false
    rs.lastMessage = "WHEN became false: rule disabled"
    _pushLog(rule.id, "info", rs.lastMessage)
  else
    rs.lastMessage = "WHEN became false"
  end

  rs.activeSession    = false
  rs.restoreActions   = {}
  if data.enabled ~= false and rs.sequenceActive ~= true then rs.lastRunAt = now or _now() end
end

function RuleRunner.RunRuleNow(ruleId)
  local rule = AssetRegistry.GetMutable(ruleId)
  if not rule or rule.type ~= "rule" then return false, "Missing rule" end

  local rs   = _status(ruleId)
  local pass, reason, results = _evaluateConditions(rule.data or {})
  rs.lastConditionResults = results or {}
  rs.lastEval             = pass == true
  rs.lastBlockedReason    = tostring(reason or "")

  if not pass then
    rs.lastActionResults  = {}
    rs.lastTriggeredCount = 0
    rs.lastMessage        = tostring(reason or "Manual run blocked")
    return false, rs.lastMessage
  end

  _cancelSequence(ruleId, "")
  _resetPattern(ruleId)
  rs.lastTriggerDecision = "manual"
  rs.lastTriggerReason   = "Manual run accepted"
  _armFirePattern(rule, "manual", _now())
  return true, tostring(rs.lastMessage or "Manual sequence started")
end

function RuleRunner.Update(_)
  local rules = AssetRegistry.ListMutable("rule")
  local now   = _now()

  for i = 1, #rules do
    local rule = rules[i]
    local data = rule.data or {}
    local exec = _normalizeExecution(data)
    local rs   = _status(rule.id)

    local ruleStamp = table.concat({
      tostring(rule.id or ""),
      tostring(rule.updatedAtText or ""),
      tostring(data.enabled ~= false),
      tostring(exec.triggerMode  or ""),
      tostring(exec.cadence      or ""),
      tostring(exec.cadenceValue or ""),
      tostring(exec.cooldown     or ""),
      tostring(exec.firePattern  or ""),
      tostring(exec.burstCount   or ""),
      tostring(exec.burstInterval or ""),
      tostring(exec.burstStopOnFalse or false),
      tostring(exec.loopCount or ""),
      tostring(exec.loopInterval or ""),
      tostring(exec.loopRestartDelay or ""),
    }, "|")

    if rs.lastRuleStamp ~= ruleStamp then
      _resetSequence(rule.id)
      _resetPattern(rule.id)
      rs.prevCondition          = false
      rs.trueCount              = 0
      rs.hasFiredEver           = false
      rs.lastTriggerEventAt     = 0
      rs.lastRunAt              = 0
      rs.activeSession          = false
      rs.pendingFalseTransition = false
      rs.restoreActions         = {}
      rs.disableAfterSequence   = false
      rs.lastConditionResults   = {}
      rs.lastActionResults      = {}
      rs.lastTriggeredCount     = 0
      rs.lastBlockedReason      = ""
      rs.lastTriggerDecision    = "armed"
      rs.lastTriggerReason      = ""
      rs.lastTriggerReady       = false
      rs.lastTriggerEventOccurred = false
      rs.lastMessage            = (rs.lastRuleStamp == nil) and "Rule armed" or "Rule updated and re-armed"
      rs.lastRuleStamp          = ruleStamp
      _pushLog(rule.id, "info", tostring(rs.lastMessage or "Rule armed"))
    end

    if data.enabled == false then
      if rs.lastEnabledState ~= false then _pushLog(rule.id, "info", "Rule disabled") end
      _resetSequence(rule.id)
      _resetPattern(rule.id)
      rs.lastEval               = false
      rs.firedWhileTrue         = false
      rs.lastBlockedReason      = "Disabled"
      rs.lastMessage            = "Disabled"
      rs.lastConditionResults   = {}
      rs.lastTriggerDecision    = "disabled"
      rs.lastTriggerReason      = "Rule disabled"
      rs.lastTriggerReady       = false
      rs.lastTriggerEventOccurred = false
      rs.prevCondition          = false
      rs.activeSession          = false
      rs.pendingFalseTransition = false
      rs.restoreActions         = {}
      rs.disableAfterSequence   = false
      rs.lastEnabledState       = false
    else
      if rs.lastEnabledState == false then _pushLog(rule.id, "info", "Rule enabled") end
      rs.lastEnabledState = true

      local isTrue, evalReason, results = _evaluateConditions(data)
      rs.lastConditionResults = results or {}
      rs.lastBlockedReason    = tostring(evalReason or "")
      rs.lastEval             = isTrue == true
      rs.lastEvalAt           = now
      rs.evalCount            = (tonumber(rs.evalCount or 0) or 0) + 1

      local justTrue  = (isTrue == true) and (rs.prevCondition ~= true)
      local justFalse = (isTrue ~= true) and (rs.prevCondition == true)

      if justTrue then
        rs.lastConditionChangeAt = now
        _pushLog(rule.id, "info", "WHEN -> TRUE")
        _pushLog(rule.id, "info", "Rising edge detected")
      elseif justFalse then
        rs.lastConditionChangeAt = now
        _pushLog(rule.id, "info", "WHEN -> FALSE")
        _pushLog(rule.id, "info", "Falling edge detected")
      end

      if rs.lastBlockedReason ~= tostring(rs.lastLoggedBlockedReason or "") and rs.lastBlockedReason ~= "" and isTrue ~= true then
        _pushLog(rule.id, "info", "Blocked: " .. tostring(rs.lastBlockedReason))
        rs.lastLoggedBlockedReason = rs.lastBlockedReason
      elseif isTrue == true then
        rs.lastLoggedBlockedReason = ""
      end

      if rs.sequenceActive == true and rs.sequenceKind == "main" and exec.triggerMode == "while_true" and justFalse then
        _cancelSequence(rule.id, "Main sequence canceled: WHEN went false")
      end

      if rs.sequenceActive == true then
        local wasActive = rs.sequenceActive == true
        _advanceSequence(rule.id, now)
        if wasActive and rs.sequenceActive ~= true then
          _handlePatternSequenceFinished(rule, now, isTrue)
        end
        if wasActive and rs.sequenceActive ~= true and rs.disableAfterSequence == true and _isPatternStillScheduled(rs) ~= true then
          data.enabled            = false
          rs.disableAfterSequence = false
          rs.lastMessage          = "Rule fired and disabled"
        end
      end

      if justFalse then
        if rs.patternActive == true and (rs.patternKind == "loop" or rs.patternStopOnFalse == true) then
          _resetPattern(rule.id)
        end
        if rs.sequenceActive == true and rs.sequenceKind == "main" then
          rs.pendingFalseTransition = true
        elseif rs.patternActive == true then
          rs.pendingFalseTransition = true
          rs.lastMessage = (rs.patternKind == "burst") and "WHEN false: finishing burst" or "WHEN false"
        else
          _handleFalseTransition(rule, now)
        end
      elseif rs.pendingFalseTransition == true and rs.sequenceActive ~= true and rs.patternActive ~= true then
        _handleFalseTransition(rule, now)
      end

      if rs.sequenceActive ~= true and rs.patternActive == true and data.enabled ~= false then
        _advanceFirePattern(rule, now, isTrue)
      end

      if rs.sequenceActive ~= true and rs.patternActive ~= true and data.enabled ~= false then
        local ready, eventOccurred = false, false
        if exec.triggerMode == "on_true" then
          ready         = (now - (tonumber(rs.lastRunAt or 0) or 0)) >= (tonumber(exec.cooldown or 0) or 0)
          eventOccurred = justTrue
        else
          ready         = (now - (tonumber(rs.lastTriggerEventAt or 0) or 0)) >= (tonumber(exec.cooldown or 0) or 0)
          eventOccurred = (isTrue == true) and ready
        end
        rs.lastTriggerReady          = ready == true
        rs.lastTriggerEventOccurred  = eventOccurred == true

        if eventOccurred then
          if exec.triggerMode == "while_true" then rs.lastTriggerEventAt = now end
          rs.trueCount = (tonumber(rs.trueCount or 0) or 0) + 1
          local cadenceOK, cadenceReason = _shouldFireForCadence(exec, rs.trueCount, rs.hasFiredEver)
          if cadenceOK and (exec.triggerMode ~= "on_true" or ready) then
            rs.lastTriggerDecision = "sequence_started"
            rs.lastTriggerReason   = "Trigger event accepted"
            _armFirePattern(rule, "auto", now)
          elseif not ready then
            rs.lastTriggerDecision = "cooldown"
            rs.lastTriggerReason   = "Cooldown active"
            rs.lastMessage         = "Cooling down"
          else
            rs.lastTriggerDecision = "cadence_filtered"
            rs.lastTriggerReason   = tostring(cadenceReason or "Trigger filtered")
            rs.lastMessage         = tostring(cadenceReason or "Trigger filtered")
          end
        else
          if isTrue then
            if exec.triggerMode == "on_true" then
              if not ready and rs.prevCondition == true then
                rs.lastTriggerDecision = "cooldown"
                rs.lastTriggerReason   = "WHEN is true, but the script is cooling down after its last run."
                rs.lastMessage         = "Cooling down"
              else
                rs.lastTriggerDecision = "awaiting_rising_edge"
                rs.lastTriggerReason   = "WHEN is already true. on_true scripts only fire when the condition changes from FALSE to TRUE."
                rs.lastMessage         = "True (waiting for change)"
              end
            else
              if not ready then
                rs.lastTriggerDecision = "cooldown"
                rs.lastTriggerReason   = "WHEN is true, but cadence cooldown is still active."
                rs.lastMessage         = "Cooling down"
              else
                rs.lastTriggerDecision = "holding_true"
                rs.lastTriggerReason   = "WHEN is true and waiting for the next while_true cadence tick."
                rs.lastMessage         = "Holding true"
              end
            end
          else
            rs.lastTriggerDecision = "blocked"
            rs.lastTriggerReason   = tostring(evalReason or "False")
            rs.lastMessage         = tostring(evalReason or "False")
          end
        end
      end

      rs.prevCondition = (isTrue == true)
    end
  end

  local created = RuleRunner.state.createdAssetState or {}
  for assetId, runtime in pairs(created) do
    local sid = _createdStatusId(assetId)
    local rs  = _status(sid)
    if rs.sequenceActive == true then _advanceSequence(sid, now) end
    local asset = runtime.isDraft and nil or AssetRegistry.Get(assetId)
    if runtime.isDraft ~= true and type(asset) ~= "table" then created[assetId] = nil end
    local launcherMode = tostring(
      (type(asset) == "table" and ((((asset or {}).data or {}).mode) or "")) or
      (runtime.assetMode or ""))
    if type(runtime) == "table" and tostring(runtime.type or "") == "launcher" and launcherMode ~= "toggle" then
      runtime.enabled = false
    end
  end
end

return RuleRunner
