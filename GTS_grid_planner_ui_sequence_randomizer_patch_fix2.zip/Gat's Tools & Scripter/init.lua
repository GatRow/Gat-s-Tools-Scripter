print("[GTS] init.lua loaded")

GTS_BOOT_ERROR = nil
GTS_BOOT_ERROR_OVERLAY_REGISTERED = GTS_BOOT_ERROR_OVERLAY_REGISTERED or false

-- Clear cached Gat's Tools & Scripter modules so CET reloads always pick up the latest files.
local function _unloadGTSModules()
  if type(package) ~= "table" or type(package.loaded) ~= "table" then return end
  for name, _ in pairs(package.loaded) do
    if type(name) == "string" and string.match(name, "^GTS[/.]") then
      package.loaded[name] = nil
    end
  end
end

local function _registerBootErrorOverlay(err)
  GTS_BOOT_ERROR = tostring(err or "Unknown GTS boot error")
  if type(registerForEvent) ~= "function" or GTS_BOOT_ERROR_OVERLAY_REGISTERED then
    return
  end

  local ok = pcall(function()
    registerForEvent("onDraw", function()
      if not GTS_BOOT_ERROR or type(ImGui) ~= "table" or type(ImGui.Begin) ~= "function" then
        return
      end

      if ImGui.SetNextWindowSize then
        ImGui.SetNextWindowSize(760, 0, ImGuiCond.FirstUseEver)
      end

      ImGui.Begin("GTS Load Error")
      ImGui.TextWrapped("Gat's Tools & Scripter failed to load. The CET console has the same error, but this overlay keeps it visible in-game.")
      ImGui.Separator()
      ImGui.TextWrapped(tostring(GTS_BOOT_ERROR))
      ImGui.End()
    end)
  end)

  if ok then
    GTS_BOOT_ERROR_OVERLAY_REGISTERED = true
  end
end

_unloadGTSModules()

-- Legacy inventory ID globals kept as safe fallbacks.
INV_IDS = INV_IDS or {}
INV_ID_SET = INV_ID_SET or {}
INV_ID_INDEX = INV_ID_INDEX or {}

local ok, err = pcall(require, "GTS/UI/main_ui")
if not ok then
  print("[GTS] Failed to load module 'GTS/UI/main_ui': " .. tostring(err))
  _registerBootErrorOverlay(err)
else
  GTS_BOOT_ERROR = nil
end
