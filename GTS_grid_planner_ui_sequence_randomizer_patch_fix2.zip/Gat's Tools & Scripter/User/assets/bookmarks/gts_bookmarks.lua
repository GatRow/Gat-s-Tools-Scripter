-- GTS bookmarks (auto)
-- 2026-04-01 02:26:26

return {
  ["pose:add_accl"] = {
    id = "add_accl",
    key = "pose:add_accl",
    label = "add accl",
    meta = "Player Woman",
    savedAt = "2026-04-01 02:26",
    type = "pose",
  },
  ["pose:add_action_pose"] = {
    id = "add_action_pose",
    key = "pose:add_action_pose",
    label = "add action pose",
    meta = "Player Woman",
    savedAt = "2026-04-01 02:26",
    type = "pose",
  },
  ["pose:add_bike_air"] = {
    id = "add_bike_air",
    key = "pose:add_bike_air",
    label = "add bike air",
    meta = "Player Woman",
    savedAt = "2026-04-01 02:26",
    type = "pose",
  },
  ["pose:add_bike_drive_progression"] = {
    id = "add_bike_drive_progression",
    key = "pose:add_bike_drive_progression",
    label = "add bike drive progression",
    meta = "Player Woman",
    savedAt = "2026-04-01 02:26",
    type = "pose",
  },
  ["pose:lie_bed_270__sleep__01"] = {
    id = "lie_bed_270__sleep__01",
    key = "pose:lie_bed_270__sleep__01",
    label = "lie bed 270 sleep 01",
    meta = "Player Woman",
    savedAt = "2026-03-31 22:17",
    type = "pose",
  },
}
