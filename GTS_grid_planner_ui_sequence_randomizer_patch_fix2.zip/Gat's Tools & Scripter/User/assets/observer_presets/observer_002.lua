-- Gat's Tools & Scripter asset (auto)
-- 2026-03-29 04:01:46

return {
  asset = {
    createdAtText = "2026-03-29 04:01:46",
    id = "observer_002",
    name = "lOWER THAN 100",
    observers = {
      {
        compareMode = "Percent",
        enabled = true,
        op = "<",
        src = "Pool Percent",
        stat = "Health",
        value = 100,
        valueStr = "100",
      },
    },
    type = "observer_preset",
    updatedAtText = "2026-03-29 04:01:46",
  },
  kind = "gts_asset",
  savedAt = "2026-03-29 04:01:46",
  version = 3,
}
