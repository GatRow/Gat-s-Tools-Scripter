-- Gat's Tools & Scripter asset (auto)
-- 2026-03-27 02:00:06

return {
  asset = {
    createdAtText = "2026-03-27 02:00:06",
    data = {
      actionGroups = {
        {
          actions = {
            {
              freezeAfterSeconds = 0,
              instant = true,
              poseName = "",
              poseSearch = "",
              rig = "Player Man",
              sequenceAsset = {
                createdAtText = "2026-03-27 01:56:10",
                data = {
                  steps = {
                    {
                      displayName = "block deflect left",
                      endAction = "Stop",
                      name = "block_deflect_left",
                      rig = "Player Man",
                      seconds = 1,
                      secondsText = "1",
                    },
                    {
                      displayName = "block deflect right",
                      endAction = "Stop",
                      name = "block_deflect_right",
                      rig = "Player Man",
                      seconds = 1,
                      secondsText = "1",
                    },
                  },
                },
                id = "asset_004",
                name = "Fight",
                type = "animation_sequence",
                updatedAtText = "2026-03-27 01:56:10",
              },
              sequenceRef = "asset_004",
              sourceMode = "saved_sequence",
              stopAfterSeconds = 0,
              type = "apply_animation_to_player",
            },
            {
              despawnAfterSeconds = 0,
              recordId = "Attacks.BaseFragExplosion",
              spawnMode = "Attack",
              type = "spawn_at_target",
            },
          },
          id = "group_1",
          mode = "ordered",
          name = "Group 1",
        },
      },
      actions = {
      },
      conditionMode = "ALL",
      conditions = {
        {
          expected = true,
          key = "meleeAttack",
          kind = "observer_state",
          label = "Observer: Melee Attack",
        },
        {
          expected = true,
          key = "target_npc",
          kind = "observer_state",
          label = "Observer: Target Is NPC",
        },
      },
      cooldown = 0.25,
      enabled = true,
      execution = {
        cadence = "every_time",
        cadenceValue = 2,
        cooldown = 0.25,
        disableAfterFire = false,
        falseActions = {
        },
        falsePolicy = "do_nothing",
        triggerMode = "on_true",
      },
      falseActionGroups = {
        {
          actions = {
          },
          id = "exit_group_1",
          mode = "ordered",
          name = "Exit Group 1",
        },
      },
      falseActions = {
      },
      runOnceUntilFalse = true,
    },
    id = "rule_006",
    name = "Explosive Punch",
    type = "rule",
    updatedAtText = "2026-03-27 02:00:06",
  },
  kind = "gts_asset",
  savedAt = "2026-03-27 02:00:06",
  version = 3,
}
