-- Gat's Tools & Scripter asset (auto)
-- 2026-03-29 04:02:18

return {
  asset = {
    createdAtText = "2026-03-29 04:02:18",
    data = {
      actionGroups = {
        {
          actions = {
            {
              messageDuration = 8,
              messageMode = "screen",
              messageText = "Script activated",
              type = "show_ui_message",
            },
          },
          id = "group_1",
          mode = "ordered",
          name = "Group 1",
        },
      },
      actions = {
      },
      conditionMode = "ALL",
      conditions = {
        {
          expected = true,
          key = "saved_stat_condition",
          kind = "saved_stat_condition",
          label = "Condition: Saved Stat Condition",
          ref = "observer_002",
        },
      },
      cooldown = 0.25,
      enabled = true,
      execution = {
        cadence = "every_time",
        cadenceValue = 2,
        cooldown = 0.25,
        disableAfterFire = false,
        falseActions = {
        },
        falsePolicy = "do_nothing",
        triggerMode = "on_true",
      },
      falseActionGroups = {
        {
          actions = {
          },
          id = "exit_group_1",
          mode = "ordered",
          name = "Exit Group 1",
        },
      },
      falseActions = {
      },
      runOnceUntilFalse = true,
    },
    id = "rule_003",
    name = "New Script",
    type = "rule",
    updatedAtText = "2026-03-29 04:02:18",
  },
  kind = "gts_asset",
  savedAt = "2026-03-29 04:02:18",
  version = 3,
}
