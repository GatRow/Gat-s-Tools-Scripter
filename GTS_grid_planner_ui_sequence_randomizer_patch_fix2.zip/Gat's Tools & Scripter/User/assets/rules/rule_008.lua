-- Gat's Tools & Scripter asset (auto)
-- 2026-03-27 02:11:53

return {
  asset = {
    createdAtText = "2026-03-27 02:09:33",
    data = {
      actionGroups = {
        {
          actions = {
            {
              effectId = "BaseStatusEffect.Knockdown",
              type = "apply_status_effect_to_target",
            },
            {
              freezeAfterSeconds = 0,
              instant = true,
              poseName = "",
              poseSearch = "",
              rig = "Player Man",
              sequenceAsset = {
                createdAtText = "2026-03-27 02:07:56",
                data = {
                  steps = {
                    {
                      displayName = "grapple sync shove",
                      endAction = "Stop",
                      name = "grapple_sync_shove",
                      rig = "Player Man",
                      seconds = 1,
                      secondsText = "1",
                    },
                  },
                },
                id = "asset_007",
                name = "Kick",
                type = "animation_sequence",
                updatedAtText = "2026-03-27 02:07:56",
              },
              sequenceRef = "asset_007",
              sourceMode = "saved_sequence",
              stopAfterSeconds = 0,
              type = "apply_animation_to_player",
            },
          },
          id = "group_1",
          mode = "parallel",
          name = "Group 1",
        },
      },
      actions = {
      },
      conditionMode = "ALL",
      conditions = {
        {
          expected = true,
          key = "meleeAttack",
          kind = "observer_state",
          label = "Observer: Melee Attack",
        },
        {
          distanceMode = "within",
          expected = true,
          key = "target_distance",
          kind = "target_distance",
          label = "Observer: Target Within X Meters...",
          meters = 2,
        },
      },
      cooldown = 0.25,
      enabled = true,
      execution = {
        cadence = "every_time",
        cadenceValue = 2,
        cooldown = 0.25,
        disableAfterFire = false,
        falseActions = {
        },
        falsePolicy = "do_nothing",
        triggerMode = "on_true",
      },
      falseActionGroups = {
        {
          actions = {
          },
          id = "exit_group_1",
          mode = "ordered",
          name = "Exit Group 1",
        },
      },
      falseActions = {
      },
      runOnceUntilFalse = true,
    },
    id = "rule_008",
    name = "Kick",
    type = "rule",
    updatedAtText = "2026-03-27 02:11:53",
  },
  kind = "gts_asset",
  savedAt = "2026-03-27 02:11:53",
  version = 3,
}
