-- Gat's Tools & Scripter asset (auto)
-- 2026-03-29 05:09:09

return {
  asset = {
    createdAtText = "2026-03-29 05:09:09",
    data = {
      steps = {
        {
          displayName = "one punch heavy attack",
          endAction = "Stop",
          name = "one_punch_heavy_attack",
          rig = "Player Man",
          seconds = 1,
          secondsText = "1",
        },
      },
    },
    id = "asset_005",
    name = "Punch",
    type = "animation_sequence",
    updatedAtText = "2026-03-29 05:09:09",
  },
  kind = "gts_asset",
  savedAt = "2026-03-29 05:09:09",
  version = 3,
}
