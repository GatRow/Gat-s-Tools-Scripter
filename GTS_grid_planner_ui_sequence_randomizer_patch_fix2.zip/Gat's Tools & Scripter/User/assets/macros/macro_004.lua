-- Gat's Tools & Scripter asset (auto)
-- 2026-03-29 16:44:30

return {
  asset = {
    createdAtText = "2026-03-29 16:44:30",
    data = {
      mode = "button",
      offActionGroups = {
        {
          actions = {
          },
          id = "off_group_1",
          mode = "ordered",
          name = "Off Group 1",
        },
      },
      offPolicy = "none",
      onActionGroups = {
        {
          actions = {
            {
              messageDuration = 8,
              messageMode = "screen",
              messageText = "FUCK SMASHER",
              type = "show_ui_message",
            },
          },
          id = "group_1",
          mode = "ordered",
          name = "Group 1",
        },
      },
    },
    id = "macro_004",
    name = "New Button Macro",
    type = "macro",
    updatedAtText = "2026-03-29 16:44:30",
  },
  kind = "gts_asset",
  savedAt = "2026-03-29 16:44:30",
  version = 3,
}
