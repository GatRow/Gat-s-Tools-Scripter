-- Gat's Tools & Scripter asset (auto)
-- 2026-03-29 16:31:00

return {
  asset = {
    createdAtText = "2026-03-29 16:31:00",
    data = {
      mode = "button",
      offActionGroups = {
        {
          actions = {
          },
          id = "off_group_1",
          mode = "ordered",
          name = "Off Group 1",
        },
      },
      offPolicy = "none",
      onActionGroups = {
        {
          actions = {
            {
              command = "on",
              disableAfterSeconds = 5,
              disableMode = "while_still",
              disableStillSeconds = 5,
              fov = 60,
              mode = "noclip",
              noClipZOffset = 0,
              speed = 0.18000000715256,
              type = "camera",
            },
          },
          id = "group_1",
          mode = "ordered",
          name = "Group 1",
        },
      },
    },
    id = "macro_002",
    name = "No Clip",
    type = "macro",
    updatedAtText = "2026-03-29 16:31:00",
  },
  kind = "gts_asset",
  savedAt = "2026-03-29 16:31:00",
  version = 3,
}
