-- Gat's Tools & Scripter asset index (auto)
-- 2026-03-31 15:15:13

return {
  items = {
    rule_001 = {
      createdAtText = "2026-03-26 17:14:47",
      file = "assets/rules/rule_001.lua",
      id = "rule_001",
      name = "ff",
      type = "rule",
      updatedAtText = "2026-03-26 17:14:47",
    },
    scenario_003 = {
      createdAtText = "2026-03-30 03:17:02",
      file = "assets/scenarios/scenario_003.lua",
      id = "scenario_003",
      name = "Samash",
      type = "scenario",
      updatedAtText = "2026-03-30 03:17:02",
    },
  },
  mode = "per_asset_manifest",
  nextId = 5,
  order = {
    "rule_001",
    "scenario_003",
  },
  savedAt = "2026-03-31 15:15:13",
  selectedId = "rule_001",
  version = 3,
}
