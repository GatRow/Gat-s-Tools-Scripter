Gat's Tools & Scripter User folder

This folder stores user-created assets and settings that persist between sessions.

assets.lua / assets.json
- Manifest/index of saved assets.

assets/<type>/
- Individual saved assets for sharing and backup.
- Each saved item writes its own .lua and .json file.

menu_projects/
- Saved Menu Maker UI projects.
- Each project writes project.lua, theme.lua, and schema.lua.

Keep this folder with the mod so CET can write directly into it.
